!function(n,r){"object"==typeof exports&&"undefined"!=typeof module?module.exports=r():"function"==typeof define&&define.amd?define("underscore",r):(n="undefined"!=typeof globalThis?globalThis:n||self,function(){var t=n._,e=n._=r();e.noConflict=function(){return n._=t,e}}())}(this,(function(){
//     Underscore.js 1.13.3
//     https://underscorejs.org
//     (c) 2009-2022 Jeremy Ashkenas, Julian Gonggrijp, and DocumentCloud and Investigative Reporters & Editors
//     Underscore may be freely distributed under the MIT license.
var n="1.13.3",r="object"==typeof self&&self.self===self&&self||"object"==typeof global&&global.global===global&&global||Function("return this")()||{},t=Array.prototype,e=Object.prototype,u="undefined"!=typeof Symbol?Symbol.prototype:null,o=t.push,i=t.slice,a=e.toString,f=e.hasOwnProperty,c="undefined"!=typeof ArrayBuffer,l="undefined"!=typeof DataView,s=Array.isArray,p=Object.keys,v=Object.create,h=c&&ArrayBuffer.isView,y=isNaN,d=isFinite,g=!{toString:null}.propertyIsEnumerable("toString"),b=["valueOf","isPrototypeOf","toString","propertyIsEnumerable","hasOwnProperty","toLocaleString"],m=Math.pow(2,53)-1;function j(n,r){return r=null==r?n.length-1:+r,function(){for(var t=Math.max(arguments.length-r,0),e=Array(t),u=0;u<t;u++)e[u]=arguments[u+r];switch(r){case 0:return n.call(this,e);case 1:return n.call(this,arguments[0],e);case 2:return n.call(this,arguments[0],arguments[1],e)}var o=Array(r+1);for(u=0;u<r;u++)o[u]=arguments[u];return o[r]=e,n.apply(this,o)}}function _(n){var r=typeof n;return"function"===r||"object"===r&&!!n}function w(n){return void 0===n}function A(n){return!0===n||!1===n||"[object Boolean]"===a.call(n)}function x(n){var r="[object "+n+"]";return function(n){return a.call(n)===r}}var S=x("String"),O=x("Number"),M=x("Date"),E=x("RegExp"),B=x("Error"),N=x("Symbol"),I=x("ArrayBuffer"),T=x("Function"),k=r.document&&r.document.childNodes;"function"!=typeof/./&&"object"!=typeof Int8Array&&"function"!=typeof k&&(T=function(n){return"function"==typeof n||!1});var D=T,R=x("Object"),F=l&&R(new DataView(new ArrayBuffer(8))),V="undefined"!=typeof Map&&R(new Map),P=x("DataView");var q=F?function(n){return null!=n&&D(n.getInt8)&&I(n.buffer)}:P,U=s||x("Array");function W(n,r){return null!=n&&f.call(n,r)}var z=x("Arguments");!function(){z(arguments)||(z=function(n){return W(n,"callee")})}();var L=z;function $(n){return O(n)&&y(n)}function C(n){return function(){return n}}function K(n){return function(r){var t=n(r);return"number"==typeof t&&t>=0&&t<=m}}function J(n){return function(r){return null==r?void 0:r[n]}}var G=J("byteLength"),H=K(G),Q=/\[object ((I|Ui)nt(8|16|32)|Float(32|64)|Uint8Clamped|Big(I|Ui)nt64)Array\]/;var X=c?function(n){return h?h(n)&&!q(n):H(n)&&Q.test(a.call(n))}:C(!1),Y=J("length");function Z(n,r){r=function(n){for(var r={},t=n.length,e=0;e<t;++e)r[n[e]]=!0;return{contains:function(n){return!0===r[n]},push:function(t){return r[t]=!0,n.push(t)}}}(r);var t=b.length,u=n.constructor,o=D(u)&&u.prototype||e,i="constructor";for(W(n,i)&&!r.contains(i)&&r.push(i);t--;)(i=b[t])in n&&n[i]!==o[i]&&!r.contains(i)&&r.push(i)}function nn(n){if(!_(n))return[];if(p)return p(n);var r=[];for(var t in n)W(n,t)&&r.push(t);return g&&Z(n,r),r}function rn(n,r){var t=nn(r),e=t.length;if(null==n)return!e;for(var u=Object(n),o=0;o<e;o++){var i=t[o];if(r[i]!==u[i]||!(i in u))return!1}return!0}function tn(n){return n instanceof tn?n:this instanceof tn?void(this._wrapped=n):new tn(n)}function en(n){return new Uint8Array(n.buffer||n,n.byteOffset||0,G(n))}tn.VERSION=n,tn.prototype.value=function(){return this._wrapped},tn.prototype.valueOf=tn.prototype.toJSON=tn.prototype.value,tn.prototype.toString=function(){return String(this._wrapped)};var un="[object DataView]";function on(n,r,t,e){if(n===r)return 0!==n||1/n==1/r;if(null==n||null==r)return!1;if(n!=n)return r!=r;var o=typeof n;return("function"===o||"object"===o||"object"==typeof r)&&function n(r,t,e,o){r instanceof tn&&(r=r._wrapped);t instanceof tn&&(t=t._wrapped);var i=a.call(r);if(i!==a.call(t))return!1;if(F&&"[object Object]"==i&&q(r)){if(!q(t))return!1;i=un}switch(i){case"[object RegExp]":case"[object String]":return""+r==""+t;case"[object Number]":return+r!=+r?+t!=+t:0==+r?1/+r==1/t:+r==+t;case"[object Date]":case"[object Boolean]":return+r==+t;case"[object Symbol]":return u.valueOf.call(r)===u.valueOf.call(t);case"[object ArrayBuffer]":case un:return n(en(r),en(t),e,o)}var f="[object Array]"===i;if(!f&&X(r)){if(G(r)!==G(t))return!1;if(r.buffer===t.buffer&&r.byteOffset===t.byteOffset)return!0;f=!0}if(!f){if("object"!=typeof r||"object"!=typeof t)return!1;var c=r.constructor,l=t.constructor;if(c!==l&&!(D(c)&&c instanceof c&&D(l)&&l instanceof l)&&"constructor"in r&&"constructor"in t)return!1}o=o||[];var s=(e=e||[]).length;for(;s--;)if(e[s]===r)return o[s]===t;if(e.push(r),o.push(t),f){if((s=r.length)!==t.length)return!1;for(;s--;)if(!on(r[s],t[s],e,o))return!1}else{var p,v=nn(r);if(s=v.length,nn(t).length!==s)return!1;for(;s--;)if(p=v[s],!W(t,p)||!on(r[p],t[p],e,o))return!1}return e.pop(),o.pop(),!0}(n,r,t,e)}function an(n){if(!_(n))return[];var r=[];for(var t in n)r.push(t);return g&&Z(n,r),r}function fn(n){var r=Y(n);return function(t){if(null==t)return!1;var e=an(t);if(Y(e))return!1;for(var u=0;u<r;u++)if(!D(t[n[u]]))return!1;return n!==hn||!D(t[cn])}}var cn="forEach",ln="has",sn=["clear","delete"],pn=["get",ln,"set"],vn=sn.concat(cn,pn),hn=sn.concat(pn),yn=["add"].concat(sn,cn,ln),dn=V?fn(vn):x("Map"),gn=V?fn(hn):x("WeakMap"),bn=V?fn(yn):x("Set"),mn=x("WeakSet");function jn(n){for(var r=nn(n),t=r.length,e=Array(t),u=0;u<t;u++)e[u]=n[r[u]];return e}function _n(n){for(var r={},t=nn(n),e=0,u=t.length;e<u;e++)r[n[t[e]]]=t[e];return r}function wn(n){var r=[];for(var t in n)D(n[t])&&r.push(t);return r.sort()}function An(n,r){return function(t){var e=arguments.length;if(r&&(t=Object(t)),e<2||null==t)return t;for(var u=1;u<e;u++)for(var o=arguments[u],i=n(o),a=i.length,f=0;f<a;f++){var c=i[f];r&&void 0!==t[c]||(t[c]=o[c])}return t}}var xn=An(an),Sn=An(nn),On=An(an,!0);function Mn(n){if(!_(n))return{};if(v)return v(n);var r=function(){};r.prototype=n;var t=new r;return r.prototype=null,t}function En(n){return U(n)?n:[n]}function Bn(n){return tn.toPath(n)}function Nn(n,r){for(var t=r.length,e=0;e<t;e++){if(null==n)return;n=n[r[e]]}return t?n:void 0}function In(n,r,t){var e=Nn(n,Bn(r));return w(e)?t:e}function Tn(n){return n}function kn(n){return n=Sn({},n),function(r){return rn(r,n)}}function Dn(n){return n=Bn(n),function(r){return Nn(r,n)}}function Rn(n,r,t){if(void 0===r)return n;switch(null==t?3:t){case 1:return function(t){return n.call(r,t)};case 3:return function(t,e,u){return n.call(r,t,e,u)};case 4:return function(t,e,u,o){return n.call(r,t,e,u,o)}}return function(){return n.apply(r,arguments)}}function Fn(n,r,t){return null==n?Tn:D(n)?Rn(n,r,t):_(n)&&!U(n)?kn(n):Dn(n)}function Vn(n,r){return Fn(n,r,1/0)}function Pn(n,r,t){return tn.iteratee!==Vn?tn.iteratee(n,r):Fn(n,r,t)}function qn(){}function Un(n,r){return null==r&&(r=n,n=0),n+Math.floor(Math.random()*(r-n+1))}tn.toPath=En,tn.iteratee=Vn;var Wn=Date.now||function(){return(new Date).getTime()};function zn(n){var r=function(r){return n[r]},t="(?:"+nn(n).join("|")+")",e=RegExp(t),u=RegExp(t,"g");return function(n){return n=null==n?"":""+n,e.test(n)?n.replace(u,r):n}}var Ln={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#x27;","`":"&#x60;"},$n=zn(Ln),Cn=zn(_n(Ln)),Kn=tn.templateSettings={evaluate:/<%([\s\S]+?)%>/g,interpolate:/<%=([\s\S]+?)%>/g,escape:/<%-([\s\S]+?)%>/g},Jn=/(.)^/,Gn={"'":"'","\\":"\\","\r":"r","\n":"n","\u2028":"u2028","\u2029":"u2029"},Hn=/\\|'|\r|\n|\u2028|\u2029/g;function Qn(n){return"\\"+Gn[n]}var Xn=/^\s*(\w|\$)+\s*$/;var Yn=0;function Zn(n,r,t,e,u){if(!(e instanceof r))return n.apply(t,u);var o=Mn(n.prototype),i=n.apply(o,u);return _(i)?i:o}var nr=j((function(n,r){var t=nr.placeholder,e=function(){for(var u=0,o=r.length,i=Array(o),a=0;a<o;a++)i[a]=r[a]===t?arguments[u++]:r[a];for(;u<arguments.length;)i.push(arguments[u++]);return Zn(n,e,this,this,i)};return e}));nr.placeholder=tn;var rr=j((function(n,r,t){if(!D(n))throw new TypeError("Bind must be called on a function");var e=j((function(u){return Zn(n,e,r,this,t.concat(u))}));return e})),tr=K(Y);function er(n,r,t,e){if(e=e||[],r||0===r){if(r<=0)return e.concat(n)}else r=1/0;for(var u=e.length,o=0,i=Y(n);o<i;o++){var a=n[o];if(tr(a)&&(U(a)||L(a)))if(r>1)er(a,r-1,t,e),u=e.length;else for(var f=0,c=a.length;f<c;)e[u++]=a[f++];else t||(e[u++]=a)}return e}var ur=j((function(n,r){var t=(r=er(r,!1,!1)).length;if(t<1)throw new Error("bindAll must be passed function names");for(;t--;){var e=r[t];n[e]=rr(n[e],n)}return n}));var or=j((function(n,r,t){return setTimeout((function(){return n.apply(null,t)}),r)})),ir=nr(or,tn,1);function ar(n){return function(){return!n.apply(this,arguments)}}function fr(n,r){var t;return function(){return--n>0&&(t=r.apply(this,arguments)),n<=1&&(r=null),t}}var cr=nr(fr,2);function lr(n,r,t){r=Pn(r,t);for(var e,u=nn(n),o=0,i=u.length;o<i;o++)if(r(n[e=u[o]],e,n))return e}function sr(n){return function(r,t,e){t=Pn(t,e);for(var u=Y(r),o=n>0?0:u-1;o>=0&&o<u;o+=n)if(t(r[o],o,r))return o;return-1}}var pr=sr(1),vr=sr(-1);function hr(n,r,t,e){for(var u=(t=Pn(t,e,1))(r),o=0,i=Y(n);o<i;){var a=Math.floor((o+i)/2);t(n[a])<u?o=a+1:i=a}return o}function yr(n,r,t){return function(e,u,o){var a=0,f=Y(e);if("number"==typeof o)n>0?a=o>=0?o:Math.max(o+f,a):f=o>=0?Math.min(o+1,f):o+f+1;else if(t&&o&&f)return e[o=t(e,u)]===u?o:-1;if(u!=u)return(o=r(i.call(e,a,f),$))>=0?o+a:-1;for(o=n>0?a:f-1;o>=0&&o<f;o+=n)if(e[o]===u)return o;return-1}}var dr=yr(1,pr,hr),gr=yr(-1,vr);function br(n,r,t){var e=(tr(n)?pr:lr)(n,r,t);if(void 0!==e&&-1!==e)return n[e]}function mr(n,r,t){var e,u;if(r=Rn(r,t),tr(n))for(e=0,u=n.length;e<u;e++)r(n[e],e,n);else{var o=nn(n);for(e=0,u=o.length;e<u;e++)r(n[o[e]],o[e],n)}return n}function jr(n,r,t){r=Pn(r,t);for(var e=!tr(n)&&nn(n),u=(e||n).length,o=Array(u),i=0;i<u;i++){var a=e?e[i]:i;o[i]=r(n[a],a,n)}return o}function _r(n){var r=function(r,t,e,u){var o=!tr(r)&&nn(r),i=(o||r).length,a=n>0?0:i-1;for(u||(e=r[o?o[a]:a],a+=n);a>=0&&a<i;a+=n){var f=o?o[a]:a;e=t(e,r[f],f,r)}return e};return function(n,t,e,u){var o=arguments.length>=3;return r(n,Rn(t,u,4),e,o)}}var wr=_r(1),Ar=_r(-1);function xr(n,r,t){var e=[];return r=Pn(r,t),mr(n,(function(n,t,u){r(n,t,u)&&e.push(n)})),e}function Sr(n,r,t){r=Pn(r,t);for(var e=!tr(n)&&nn(n),u=(e||n).length,o=0;o<u;o++){var i=e?e[o]:o;if(!r(n[i],i,n))return!1}return!0}function Or(n,r,t){r=Pn(r,t);for(var e=!tr(n)&&nn(n),u=(e||n).length,o=0;o<u;o++){var i=e?e[o]:o;if(r(n[i],i,n))return!0}return!1}function Mr(n,r,t,e){return tr(n)||(n=jn(n)),("number"!=typeof t||e)&&(t=0),dr(n,r,t)>=0}var Er=j((function(n,r,t){var e,u;return D(r)?u=r:(r=Bn(r),e=r.slice(0,-1),r=r[r.length-1]),jr(n,(function(n){var o=u;if(!o){if(e&&e.length&&(n=Nn(n,e)),null==n)return;o=n[r]}return null==o?o:o.apply(n,t)}))}));function Br(n,r){return jr(n,Dn(r))}function Nr(n,r,t){var e,u,o=-1/0,i=-1/0;if(null==r||"number"==typeof r&&"object"!=typeof n[0]&&null!=n)for(var a=0,f=(n=tr(n)?n:jn(n)).length;a<f;a++)null!=(e=n[a])&&e>o&&(o=e);else r=Pn(r,t),mr(n,(function(n,t,e){((u=r(n,t,e))>i||u===-1/0&&o===-1/0)&&(o=n,i=u)}));return o}var Ir=/[^\ud800-\udfff]|[\ud800-\udbff][\udc00-\udfff]|[\ud800-\udfff]/g;function Tr(n){return n?U(n)?i.call(n):S(n)?n.match(Ir):tr(n)?jr(n,Tn):jn(n):[]}function kr(n,r,t){if(null==r||t)return tr(n)||(n=jn(n)),n[Un(n.length-1)];var e=Tr(n),u=Y(e);r=Math.max(Math.min(r,u),0);for(var o=u-1,i=0;i<r;i++){var a=Un(i,o),f=e[i];e[i]=e[a],e[a]=f}return e.slice(0,r)}function Dr(n,r){return function(t,e,u){var o=r?[[],[]]:{};return e=Pn(e,u),mr(t,(function(r,u){var i=e(r,u,t);n(o,r,i)})),o}}var Rr=Dr((function(n,r,t){W(n,t)?n[t].push(r):n[t]=[r]})),Fr=Dr((function(n,r,t){n[t]=r})),Vr=Dr((function(n,r,t){W(n,t)?n[t]++:n[t]=1})),Pr=Dr((function(n,r,t){n[t?0:1].push(r)}),!0);function qr(n,r,t){return r in t}var Ur=j((function(n,r){var t={},e=r[0];if(null==n)return t;D(e)?(r.length>1&&(e=Rn(e,r[1])),r=an(n)):(e=qr,r=er(r,!1,!1),n=Object(n));for(var u=0,o=r.length;u<o;u++){var i=r[u],a=n[i];e(a,i,n)&&(t[i]=a)}return t})),Wr=j((function(n,r){var t,e=r[0];return D(e)?(e=ar(e),r.length>1&&(t=r[1])):(r=jr(er(r,!1,!1),String),e=function(n,t){return!Mr(r,t)}),Ur(n,e,t)}));function zr(n,r,t){return i.call(n,0,Math.max(0,n.length-(null==r||t?1:r)))}function Lr(n,r,t){return null==n||n.length<1?null==r||t?void 0:[]:null==r||t?n[0]:zr(n,n.length-r)}function $r(n,r,t){return i.call(n,null==r||t?1:r)}var Cr=j((function(n,r){return r=er(r,!0,!0),xr(n,(function(n){return!Mr(r,n)}))})),Kr=j((function(n,r){return Cr(n,r)}));function Jr(n,r,t,e){A(r)||(e=t,t=r,r=!1),null!=t&&(t=Pn(t,e));for(var u=[],o=[],i=0,a=Y(n);i<a;i++){var f=n[i],c=t?t(f,i,n):f;r&&!t?(i&&o===c||u.push(f),o=c):t?Mr(o,c)||(o.push(c),u.push(f)):Mr(u,f)||u.push(f)}return u}var Gr=j((function(n){return Jr(er(n,!0,!0))}));function Hr(n){for(var r=n&&Nr(n,Y).length||0,t=Array(r),e=0;e<r;e++)t[e]=Br(n,e);return t}var Qr=j(Hr);function Xr(n,r){return n._chain?tn(r).chain():r}function Yr(n){return mr(wn(n),(function(r){var t=tn[r]=n[r];tn.prototype[r]=function(){var n=[this._wrapped];return o.apply(n,arguments),Xr(this,t.apply(tn,n))}})),tn}mr(["pop","push","reverse","shift","sort","splice","unshift"],(function(n){var r=t[n];tn.prototype[n]=function(){var t=this._wrapped;return null!=t&&(r.apply(t,arguments),"shift"!==n&&"splice"!==n||0!==t.length||delete t[0]),Xr(this,t)}})),mr(["concat","join","slice"],(function(n){var r=t[n];tn.prototype[n]=function(){var n=this._wrapped;return null!=n&&(n=r.apply(n,arguments)),Xr(this,n)}}));var Zr=Yr({__proto__:null,VERSION:n,restArguments:j,isObject:_,isNull:function(n){return null===n},isUndefined:w,isBoolean:A,isElement:function(n){return!(!n||1!==n.nodeType)},isString:S,isNumber:O,isDate:M,isRegExp:E,isError:B,isSymbol:N,isArrayBuffer:I,isDataView:q,isArray:U,isFunction:D,isArguments:L,isFinite:function(n){return!N(n)&&d(n)&&!isNaN(parseFloat(n))},isNaN:$,isTypedArray:X,isEmpty:function(n){if(null==n)return!0;var r=Y(n);return"number"==typeof r&&(U(n)||S(n)||L(n))?0===r:0===Y(nn(n))},isMatch:rn,isEqual:function(n,r){return on(n,r)},isMap:dn,isWeakMap:gn,isSet:bn,isWeakSet:mn,keys:nn,allKeys:an,values:jn,pairs:function(n){for(var r=nn(n),t=r.length,e=Array(t),u=0;u<t;u++)e[u]=[r[u],n[r[u]]];return e},invert:_n,functions:wn,methods:wn,extend:xn,extendOwn:Sn,assign:Sn,defaults:On,create:function(n,r){var t=Mn(n);return r&&Sn(t,r),t},clone:function(n){return _(n)?U(n)?n.slice():xn({},n):n},tap:function(n,r){return r(n),n},get:In,has:function(n,r){for(var t=(r=Bn(r)).length,e=0;e<t;e++){var u=r[e];if(!W(n,u))return!1;n=n[u]}return!!t},mapObject:function(n,r,t){r=Pn(r,t);for(var e=nn(n),u=e.length,o={},i=0;i<u;i++){var a=e[i];o[a]=r(n[a],a,n)}return o},identity:Tn,constant:C,noop:qn,toPath:En,property:Dn,propertyOf:function(n){return null==n?qn:function(r){return In(n,r)}},matcher:kn,matches:kn,times:function(n,r,t){var e=Array(Math.max(0,n));r=Rn(r,t,1);for(var u=0;u<n;u++)e[u]=r(u);return e},random:Un,now:Wn,escape:$n,unescape:Cn,templateSettings:Kn,template:function(n,r,t){!r&&t&&(r=t),r=On({},r,tn.templateSettings);var e=RegExp([(r.escape||Jn).source,(r.interpolate||Jn).source,(r.evaluate||Jn).source].join("|")+"|$","g"),u=0,o="__p+='";n.replace(e,(function(r,t,e,i,a){return o+=n.slice(u,a).replace(Hn,Qn),u=a+r.length,t?o+="'+\n((__t=("+t+"))==null?'':_.escape(__t))+\n'":e?o+="'+\n((__t=("+e+"))==null?'':__t)+\n'":i&&(o+="';\n"+i+"\n__p+='"),r})),o+="';\n";var i,a=r.variable;if(a){if(!Xn.test(a))throw new Error("variable is not a bare identifier: "+a)}else o="with(obj||{}){\n"+o+"}\n",a="obj";o="var __t,__p='',__j=Array.prototype.join,"+"print=function(){__p+=__j.call(arguments,'');};\n"+o+"return __p;\n";try{i=new Function(a,"_",o)}catch(n){throw n.source=o,n}var f=function(n){return i.call(this,n,tn)};return f.source="function("+a+"){\n"+o+"}",f},result:function(n,r,t){var e=(r=Bn(r)).length;if(!e)return D(t)?t.call(n):t;for(var u=0;u<e;u++){var o=null==n?void 0:n[r[u]];void 0===o&&(o=t,u=e),n=D(o)?o.call(n):o}return n},uniqueId:function(n){var r=++Yn+"";return n?n+r:r},chain:function(n){var r=tn(n);return r._chain=!0,r},iteratee:Vn,partial:nr,bind:rr,bindAll:ur,memoize:function(n,r){var t=function(e){var u=t.cache,o=""+(r?r.apply(this,arguments):e);return W(u,o)||(u[o]=n.apply(this,arguments)),u[o]};return t.cache={},t},delay:or,defer:ir,throttle:function(n,r,t){var e,u,o,i,a=0;t||(t={});var f=function(){a=!1===t.leading?0:Wn(),e=null,i=n.apply(u,o),e||(u=o=null)},c=function(){var c=Wn();a||!1!==t.leading||(a=c);var l=r-(c-a);return u=this,o=arguments,l<=0||l>r?(e&&(clearTimeout(e),e=null),a=c,i=n.apply(u,o),e||(u=o=null)):e||!1===t.trailing||(e=setTimeout(f,l)),i};return c.cancel=function(){clearTimeout(e),a=0,e=u=o=null},c},debounce:function(n,r,t){var e,u,o,i,a,f=function(){var c=Wn()-u;r>c?e=setTimeout(f,r-c):(e=null,t||(i=n.apply(a,o)),e||(o=a=null))},c=j((function(c){return a=this,o=c,u=Wn(),e||(e=setTimeout(f,r),t&&(i=n.apply(a,o))),i}));return c.cancel=function(){clearTimeout(e),e=o=a=null},c},wrap:function(n,r){return nr(r,n)},negate:ar,compose:function(){var n=arguments,r=n.length-1;return function(){for(var t=r,e=n[r].apply(this,arguments);t--;)e=n[t].call(this,e);return e}},after:function(n,r){return function(){if(--n<1)return r.apply(this,arguments)}},before:fr,once:cr,findKey:lr,findIndex:pr,findLastIndex:vr,sortedIndex:hr,indexOf:dr,lastIndexOf:gr,find:br,detect:br,findWhere:function(n,r){return br(n,kn(r))},each:mr,forEach:mr,map:jr,collect:jr,reduce:wr,foldl:wr,inject:wr,reduceRight:Ar,foldr:Ar,filter:xr,select:xr,reject:function(n,r,t){return xr(n,ar(Pn(r)),t)},every:Sr,all:Sr,some:Or,any:Or,contains:Mr,includes:Mr,include:Mr,invoke:Er,pluck:Br,where:function(n,r){return xr(n,kn(r))},max:Nr,min:function(n,r,t){var e,u,o=1/0,i=1/0;if(null==r||"number"==typeof r&&"object"!=typeof n[0]&&null!=n)for(var a=0,f=(n=tr(n)?n:jn(n)).length;a<f;a++)null!=(e=n[a])&&e<o&&(o=e);else r=Pn(r,t),mr(n,(function(n,t,e){((u=r(n,t,e))<i||u===1/0&&o===1/0)&&(o=n,i=u)}));return o},shuffle:function(n){return kr(n,1/0)},sample:kr,sortBy:function(n,r,t){var e=0;return r=Pn(r,t),Br(jr(n,(function(n,t,u){return{value:n,index:e++,criteria:r(n,t,u)}})).sort((function(n,r){var t=n.criteria,e=r.criteria;if(t!==e){if(t>e||void 0===t)return 1;if(t<e||void 0===e)return-1}return n.index-r.index})),"value")},groupBy:Rr,indexBy:Fr,countBy:Vr,partition:Pr,toArray:Tr,size:function(n){return null==n?0:tr(n)?n.length:nn(n).length},pick:Ur,omit:Wr,first:Lr,head:Lr,take:Lr,initial:zr,last:function(n,r,t){return null==n||n.length<1?null==r||t?void 0:[]:null==r||t?n[n.length-1]:$r(n,Math.max(0,n.length-r))},rest:$r,tail:$r,drop:$r,compact:function(n){return xr(n,Boolean)},flatten:function(n,r){return er(n,r,!1)},without:Kr,uniq:Jr,unique:Jr,union:Gr,intersection:function(n){for(var r=[],t=arguments.length,e=0,u=Y(n);e<u;e++){var o=n[e];if(!Mr(r,o)){var i;for(i=1;i<t&&Mr(arguments[i],o);i++);i===t&&r.push(o)}}return r},difference:Cr,unzip:Hr,transpose:Hr,zip:Qr,object:function(n,r){for(var t={},e=0,u=Y(n);e<u;e++)r?t[n[e]]=r[e]:t[n[e][0]]=n[e][1];return t},range:function(n,r,t){null==r&&(r=n||0,n=0),t||(t=r<n?-1:1);for(var e=Math.max(Math.ceil((r-n)/t),0),u=Array(e),o=0;o<e;o++,n+=t)u[o]=n;return u},chunk:function(n,r){if(null==r||r<1)return[];for(var t=[],e=0,u=n.length;e<u;)t.push(i.call(n,e,e+=r));return t},mixin:Yr,default:tn});return Zr._=Zr,Zr}));;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

if (!Element.prototype.matches) {
  Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector;
};
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

if (typeof Object.assign !== 'function') {
  Object.defineProperty(Object, 'assign', {
    value: function assign(target, varArgs) {
      'use strict';

      if (target === null || target === undefined) {
        throw new TypeError('Cannot convert undefined or null to object');
      }

      var to = Object(target);

      for (var index = 1; index < arguments.length; index++) {
        var nextSource = arguments[index];

        if (nextSource !== null && nextSource !== undefined) {
          for (var nextKey in nextSource) {
            if (Object.prototype.hasOwnProperty.call(nextSource, nextKey)) {
              to[nextKey] = nextSource[nextKey];
            }
          }
        }
      }

      return to;
    },
    writable: true,
    configurable: true
  });
};
/*! https://mths.be/cssescape v1.5.1 by @mathias | MIT license */
;(function(root, factory) {
	// https://github.com/umdjs/umd/blob/master/returnExports.js
	if (typeof exports == 'object') {
		// For Node.js.
		module.exports = factory(root);
	} else if (typeof define == 'function' && define.amd) {
		// For AMD. Register as an anonymous module.
		define([], factory.bind(root, root));
	} else {
		// For browser globals (not exposing the function separately).
		factory(root);
	}
}(typeof global != 'undefined' ? global : this, function(root) {

	if (root.CSS && root.CSS.escape) {
		return root.CSS.escape;
	}

	// https://drafts.csswg.org/cssom/#serialize-an-identifier
	var cssEscape = function(value) {
		if (arguments.length == 0) {
			throw new TypeError('`CSS.escape` requires an argument.');
		}
		var string = String(value);
		var length = string.length;
		var index = -1;
		var codeUnit;
		var result = '';
		var firstCodeUnit = string.charCodeAt(0);
		while (++index < length) {
			codeUnit = string.charCodeAt(index);
			// Note: there’s no need to special-case astral symbols, surrogate
			// pairs, or lone surrogates.

			// If the character is NULL (U+0000), then the REPLACEMENT CHARACTER
			// (U+FFFD).
			if (codeUnit == 0x0000) {
				result += '\uFFFD';
				continue;
			}

			if (
				// If the character is in the range [\1-\1F] (U+0001 to U+001F) or is
				// U+007F, […]
				(codeUnit >= 0x0001 && codeUnit <= 0x001F) || codeUnit == 0x007F ||
				// If the character is the first character and is in the range [0-9]
				// (U+0030 to U+0039), […]
				(index == 0 && codeUnit >= 0x0030 && codeUnit <= 0x0039) ||
				// If the character is the second character and is in the range [0-9]
				// (U+0030 to U+0039) and the first character is a `-` (U+002D), […]
				(
					index == 1 &&
					codeUnit >= 0x0030 && codeUnit <= 0x0039 &&
					firstCodeUnit == 0x002D
				)
			) {
				// https://drafts.csswg.org/cssom/#escape-a-character-as-code-point
				result += '\\' + codeUnit.toString(16) + ' ';
				continue;
			}

			if (
				// If the character is the first character and is a `-` (U+002D), and
				// there is no second character, […]
				index == 0 &&
				length == 1 &&
				codeUnit == 0x002D
			) {
				result += '\\' + string.charAt(index);
				continue;
			}

			// If the character is not handled by one of the above rules and is
			// greater than or equal to U+0080, is `-` (U+002D) or `_` (U+005F), or
			// is in one of the ranges [0-9] (U+0030 to U+0039), [A-Z] (U+0041 to
			// U+005A), or [a-z] (U+0061 to U+007A), […]
			if (
				codeUnit >= 0x0080 ||
				codeUnit == 0x002D ||
				codeUnit == 0x005F ||
				codeUnit >= 0x0030 && codeUnit <= 0x0039 ||
				codeUnit >= 0x0041 && codeUnit <= 0x005A ||
				codeUnit >= 0x0061 && codeUnit <= 0x007A
			) {
				// the character itself
				result += string.charAt(index);
				continue;
			}

			// Otherwise, the escaped character.
			// https://drafts.csswg.org/cssom/#escape-a-character
			result += '\\' + string.charAt(index);

		}
		return result;
	};

	if (!root.CSS) {
		root.CSS = {};
	}

	root.CSS.escape = cssEscape;
	return cssEscape;

}));
;
/*! @drupal/once - v1.0.1 - 2021-06-12 */
var once=function(){"use strict";var n=/[\11\12\14\15\40]+/,e="data-once",t=document;function r(n,t,r){return n[t+"Attribute"](e,r)}function o(e){if("string"!=typeof e)throw new TypeError("once ID must be a string");if(""===e||n.test(e))throw new RangeError("once ID must not be empty or contain spaces");return'[data-once~="'+e+'"]'}function u(n){if(!(n instanceof Element))throw new TypeError("The element must be an instance of Element");return!0}function i(n,e){void 0===e&&(e=t);var r=n;if(null===n)r=[];else{if(!n)throw new TypeError("Selector must not be empty");"string"!=typeof n||e!==t&&!u(e)?n instanceof Element&&(r=[n]):r=e.querySelectorAll(n)}return Array.prototype.slice.call(r)}function c(n,e,t){return e.filter((function(e){var r=u(e)&&e.matches(n);return r&&t&&t(e),r}))}function f(e,t){var o=t.add,u=t.remove,i=[];r(e,"has")&&r(e,"get").trim().split(n).forEach((function(n){i.indexOf(n)<0&&n!==u&&i.push(n)})),o&&i.push(o);var c=i.join(" ");r(e,""===c?"remove":"set",c)}function a(n,e,t){return c(":not("+o(n)+")",i(e,t),(function(e){return f(e,{add:n})}))}return a.remove=function(n,e,t){return c(o(n),i(e,t),(function(e){return f(e,{remove:n})}))},a.filter=function(n,e,t){return c(o(n),i(e,t))},a.find=function(n,e){return i(n?o(n):"[data-once]",e)},a}();

;
/*!
 * jQuery Once v2.2.3 - http://github.com/robloach/jquery-once
 * @license MIT, GPL-2.0
 *   http://opensource.org/licenses/MIT
 *   http://opensource.org/licenses/GPL-2.0
 */
(function(e){"use strict";if(typeof exports==="object"&&typeof exports.nodeName!=="string"){e(require("jquery"))}else if(typeof define==="function"&&define.amd){define(["jquery"],e)}else{e(jQuery)}})(function(t){"use strict";var r=function(e){e=e||"once";if(typeof e!=="string"){throw new TypeError("The jQuery Once id parameter must be a string")}return e};t.fn.once=function(e){var n="jquery-once-"+r(e);return this.filter(function(){return t(this).data(n)!==true}).data(n,true)};t.fn.removeOnce=function(e){return this.findOnce(e).removeData("jquery-once-"+r(e))};t.fn.findOnce=function(e){var n="jquery-once-"+r(e);return this.filter(function(){return t(this).data(n)===true})}});

(function(r){var n=typeof self=="object"&&self.self===self&&self||typeof global=="object"&&global.global===global&&global;if(typeof define==="function"&&define.amd){define(["underscore","jquery","exports"],function(t,e,i){n.Backbone=r(n,i,t,e)})}else if(typeof exports!=="undefined"){var t=require("underscore"),e;try{e=require("jquery")}catch(t){}r(n,exports,t,e)}else{n.Backbone=r(n,{},n._,n.jQuery||n.Zepto||n.ender||n.$)}})(function(t,h,x,e){var i=t.Backbone;var a=Array.prototype.slice;h.VERSION="1.4.1";h.$=e;h.noConflict=function(){t.Backbone=i;return this};h.emulateHTTP=false;h.emulateJSON=false;var r=h.Events={};var o=/\s+/;var l;var u=function(t,e,i,r,n){var s=0,a;if(i&&typeof i==="object"){if(r!==void 0&&"context"in n&&n.context===void 0)n.context=r;for(a=x.keys(i);s<a.length;s++){e=u(t,e,a[s],i[a[s]],n)}}else if(i&&o.test(i)){for(a=i.split(o);s<a.length;s++){e=t(e,a[s],r,n)}}else{e=t(e,i,r,n)}return e};r.on=function(t,e,i){this._events=u(n,this._events||{},t,e,{context:i,ctx:this,listening:l});if(l){var r=this._listeners||(this._listeners={});r[l.id]=l;l.interop=false}return this};r.listenTo=function(t,e,i){if(!t)return this;var r=t._listenId||(t._listenId=x.uniqueId("l"));var n=this._listeningTo||(this._listeningTo={});var s=l=n[r];if(!s){this._listenId||(this._listenId=x.uniqueId("l"));s=l=n[r]=new p(this,t)}var a=c(t,e,i,this);l=void 0;if(a)throw a;if(s.interop)s.on(e,i);return this};var n=function(t,e,i,r){if(i){var n=t[e]||(t[e]=[]);var s=r.context,a=r.ctx,o=r.listening;if(o)o.count++;n.push({callback:i,context:s,ctx:s||a,listening:o})}return t};var c=function(t,e,i,r){try{t.on(e,i,r)}catch(t){return t}};r.off=function(t,e,i){if(!this._events)return this;this._events=u(s,this._events,t,e,{context:i,listeners:this._listeners});return this};r.stopListening=function(t,e,i){var r=this._listeningTo;if(!r)return this;var n=t?[t._listenId]:x.keys(r);for(var s=0;s<n.length;s++){var a=r[n[s]];if(!a)break;a.obj.off(e,i,this);if(a.interop)a.off(e,i)}if(x.isEmpty(r))this._listeningTo=void 0;return this};var s=function(t,e,i,r){if(!t)return;var n=r.context,s=r.listeners;var a=0,o;if(!e&&!n&&!i){for(o=x.keys(s);a<o.length;a++){s[o[a]].cleanup()}return}o=e?[e]:x.keys(t);for(;a<o.length;a++){e=o[a];var h=t[e];if(!h)break;var l=[];for(var u=0;u<h.length;u++){var c=h[u];if(i&&i!==c.callback&&i!==c.callback._callback||n&&n!==c.context){l.push(c)}else{var f=c.listening;if(f)f.off(e,i)}}if(l.length){t[e]=l}else{delete t[e]}}return t};r.once=function(t,e,i){var r=u(f,{},t,e,this.off.bind(this));if(typeof t==="string"&&i==null)e=void 0;return this.on(r,e,i)};r.listenToOnce=function(t,e,i){var r=u(f,{},e,i,this.stopListening.bind(this,t));return this.listenTo(t,r)};var f=function(t,e,i,r){if(i){var n=t[e]=x.once(function(){r(e,n);i.apply(this,arguments)});n._callback=i}return t};r.trigger=function(t){if(!this._events)return this;var e=Math.max(0,arguments.length-1);var i=Array(e);for(var r=0;r<e;r++)i[r]=arguments[r+1];u(d,this._events,t,void 0,i);return this};var d=function(t,e,i,r){if(t){var n=t[e];var s=t.all;if(n&&s)s=s.slice();if(n)v(n,r);if(s)v(s,[e].concat(r))}return t};var v=function(t,e){var i,r=-1,n=t.length,s=e[0],a=e[1],o=e[2];switch(e.length){case 0:while(++r<n)(i=t[r]).callback.call(i.ctx);return;case 1:while(++r<n)(i=t[r]).callback.call(i.ctx,s);return;case 2:while(++r<n)(i=t[r]).callback.call(i.ctx,s,a);return;case 3:while(++r<n)(i=t[r]).callback.call(i.ctx,s,a,o);return;default:while(++r<n)(i=t[r]).callback.apply(i.ctx,e);return}};var p=function(t,e){this.id=t._listenId;this.listener=t;this.obj=e;this.interop=true;this.count=0;this._events=void 0};p.prototype.on=r.on;p.prototype.off=function(t,e){var i;if(this.interop){this._events=u(s,this._events,t,e,{context:void 0,listeners:void 0});i=!this._events}else{this.count--;i=this.count===0}if(i)this.cleanup()};p.prototype.cleanup=function(){delete this.listener._listeningTo[this.obj._listenId];if(!this.interop)delete this.obj._listeners[this.id]};r.bind=r.on;r.unbind=r.off;x.extend(h,r);var g=h.Model=function(t,e){var i=t||{};e||(e={});this.preinitialize.apply(this,arguments);this.cid=x.uniqueId(this.cidPrefix);this.attributes={};if(e.collection)this.collection=e.collection;if(e.parse)i=this.parse(i,e)||{};var r=x.result(this,"defaults");i=x.defaults(x.extend({},r,i),r);this.set(i,e);this.changed={};this.initialize.apply(this,arguments)};x.extend(g.prototype,r,{changed:null,validationError:null,idAttribute:"id",cidPrefix:"c",preinitialize:function(){},initialize:function(){},toJSON:function(t){return x.clone(this.attributes)},sync:function(){return h.sync.apply(this,arguments)},get:function(t){return this.attributes[t]},escape:function(t){return x.escape(this.get(t))},has:function(t){return this.get(t)!=null},matches:function(t){return!!x.iteratee(t,this)(this.attributes)},set:function(t,e,i){if(t==null)return this;var r;if(typeof t==="object"){r=t;i=e}else{(r={})[t]=e}i||(i={});if(!this._validate(r,i))return false;var n=i.unset;var s=i.silent;var a=[];var o=this._changing;this._changing=true;if(!o){this._previousAttributes=x.clone(this.attributes);this.changed={}}var h=this.attributes;var l=this.changed;var u=this._previousAttributes;for(var c in r){e=r[c];if(!x.isEqual(h[c],e))a.push(c);if(!x.isEqual(u[c],e)){l[c]=e}else{delete l[c]}n?delete h[c]:h[c]=e}if(this.idAttribute in r){var f=this.id;this.id=this.get(this.idAttribute);this.trigger("changeId",this,f,i)}if(!s){if(a.length)this._pending=i;for(var d=0;d<a.length;d++){this.trigger("change:"+a[d],this,h[a[d]],i)}}if(o)return this;if(!s){while(this._pending){i=this._pending;this._pending=false;this.trigger("change",this,i)}}this._pending=false;this._changing=false;return this},unset:function(t,e){return this.set(t,void 0,x.extend({},e,{unset:true}))},clear:function(t){var e={};for(var i in this.attributes)e[i]=void 0;return this.set(e,x.extend({},t,{unset:true}))},hasChanged:function(t){if(t==null)return!x.isEmpty(this.changed);return x.has(this.changed,t)},changedAttributes:function(t){if(!t)return this.hasChanged()?x.clone(this.changed):false;var e=this._changing?this._previousAttributes:this.attributes;var i={};var r;for(var n in t){var s=t[n];if(x.isEqual(e[n],s))continue;i[n]=s;r=true}return r?i:false},previous:function(t){if(t==null||!this._previousAttributes)return null;return this._previousAttributes[t]},previousAttributes:function(){return x.clone(this._previousAttributes)},fetch:function(i){i=x.extend({parse:true},i);var r=this;var n=i.success;i.success=function(t){var e=i.parse?r.parse(t,i):t;if(!r.set(e,i))return false;if(n)n.call(i.context,r,t,i);r.trigger("sync",r,t,i)};G(this,i);return this.sync("read",this,i)},save:function(t,e,i){var r;if(t==null||typeof t==="object"){r=t;i=e}else{(r={})[t]=e}i=x.extend({validate:true,parse:true},i);var n=i.wait;if(r&&!n){if(!this.set(r,i))return false}else if(!this._validate(r,i)){return false}var s=this;var a=i.success;var o=this.attributes;i.success=function(t){s.attributes=o;var e=i.parse?s.parse(t,i):t;if(n)e=x.extend({},r,e);if(e&&!s.set(e,i))return false;if(a)a.call(i.context,s,t,i);s.trigger("sync",s,t,i)};G(this,i);if(r&&n)this.attributes=x.extend({},o,r);var h=this.isNew()?"create":i.patch?"patch":"update";if(h==="patch"&&!i.attrs)i.attrs=r;var l=this.sync(h,this,i);this.attributes=o;return l},destroy:function(e){e=e?x.clone(e):{};var i=this;var r=e.success;var n=e.wait;var s=function(){i.stopListening();i.trigger("destroy",i,i.collection,e)};e.success=function(t){if(n)s();if(r)r.call(e.context,i,t,e);if(!i.isNew())i.trigger("sync",i,t,e)};var t=false;if(this.isNew()){x.defer(e.success)}else{G(this,e);t=this.sync("delete",this,e)}if(!n)s();return t},url:function(){var t=x.result(this,"urlRoot")||x.result(this.collection,"url")||V();if(this.isNew())return t;var e=this.get(this.idAttribute);return t.replace(/[^\/]$/,"$&/")+encodeURIComponent(e)},parse:function(t,e){return t},clone:function(){return new this.constructor(this.attributes)},isNew:function(){return!this.has(this.idAttribute)},isValid:function(t){return this._validate({},x.extend({},t,{validate:true}))},_validate:function(t,e){if(!e.validate||!this.validate)return true;t=x.extend({},this.attributes,t);var i=this.validationError=this.validate(t,e)||null;if(!i)return true;this.trigger("invalid",this,i,x.extend(e,{validationError:i}));return false}});var m=h.Collection=function(t,e){e||(e={});this.preinitialize.apply(this,arguments);if(e.model)this.model=e.model;if(e.comparator!==void 0)this.comparator=e.comparator;this._reset();this.initialize.apply(this,arguments);if(t)this.reset(t,x.extend({silent:true},e))};var w={add:true,remove:true,merge:true};var _={add:true,remove:false};var E=function(t,e,i){i=Math.min(Math.max(i,0),t.length);var r=Array(t.length-i);var n=e.length;var s;for(s=0;s<r.length;s++)r[s]=t[s+i];for(s=0;s<n;s++)t[s+i]=e[s];for(s=0;s<r.length;s++)t[s+n+i]=r[s]};x.extend(m.prototype,r,{model:g,preinitialize:function(){},initialize:function(){},toJSON:function(e){return this.map(function(t){return t.toJSON(e)})},sync:function(){return h.sync.apply(this,arguments)},add:function(t,e){return this.set(t,x.extend({merge:false},e,_))},remove:function(t,e){e=x.extend({},e);var i=!x.isArray(t);t=i?[t]:t.slice();var r=this._removeModels(t,e);if(!e.silent&&r.length){e.changes={added:[],merged:[],removed:r};this.trigger("update",this,e)}return i?r[0]:r},set:function(t,e){if(t==null)return;e=x.extend({},w,e);if(e.parse&&!this._isModel(t)){t=this.parse(t,e)||[]}var i=!x.isArray(t);t=i?[t]:t.slice();var r=e.at;if(r!=null)r=+r;if(r>this.length)r=this.length;if(r<0)r+=this.length+1;var n=[];var s=[];var a=[];var o=[];var h={};var l=e.add;var u=e.merge;var c=e.remove;var f=false;var d=this.comparator&&r==null&&e.sort!==false;var v=x.isString(this.comparator)?this.comparator:null;var p,g;for(g=0;g<t.length;g++){p=t[g];var m=this.get(p);if(m){if(u&&p!==m){var _=this._isModel(p)?p.attributes:p;if(e.parse)_=m.parse(_,e);m.set(_,e);a.push(m);if(d&&!f)f=m.hasChanged(v)}if(!h[m.cid]){h[m.cid]=true;n.push(m)}t[g]=m}else if(l){p=t[g]=this._prepareModel(p,e);if(p){s.push(p);this._addReference(p,e);h[p.cid]=true;n.push(p)}}}if(c){for(g=0;g<this.length;g++){p=this.models[g];if(!h[p.cid])o.push(p)}if(o.length)this._removeModels(o,e)}var y=false;var b=!d&&l&&c;if(n.length&&b){y=this.length!==n.length||x.some(this.models,function(t,e){return t!==n[e]});this.models.length=0;E(this.models,n,0);this.length=this.models.length}else if(s.length){if(d)f=true;E(this.models,s,r==null?this.length:r);this.length=this.models.length}if(f)this.sort({silent:true});if(!e.silent){for(g=0;g<s.length;g++){if(r!=null)e.index=r+g;p=s[g];p.trigger("add",p,this,e)}if(f||y)this.trigger("sort",this,e);if(s.length||o.length||a.length){e.changes={added:s,removed:o,merged:a};this.trigger("update",this,e)}}return i?t[0]:t},reset:function(t,e){e=e?x.clone(e):{};for(var i=0;i<this.models.length;i++){this._removeReference(this.models[i],e)}e.previousModels=this.models;this._reset();t=this.add(t,x.extend({silent:true},e));if(!e.silent)this.trigger("reset",this,e);return t},push:function(t,e){return this.add(t,x.extend({at:this.length},e))},pop:function(t){var e=this.at(this.length-1);return this.remove(e,t)},unshift:function(t,e){return this.add(t,x.extend({at:0},e))},shift:function(t){var e=this.at(0);return this.remove(e,t)},slice:function(){return a.apply(this.models,arguments)},get:function(t){if(t==null)return void 0;return this._byId[t]||this._byId[this.modelId(this._isModel(t)?t.attributes:t,t.idAttribute)]||t.cid&&this._byId[t.cid]},has:function(t){return this.get(t)!=null},at:function(t){if(t<0)t+=this.length;return this.models[t]},where:function(t,e){return this[e?"find":"filter"](t)},findWhere:function(t){return this.where(t,true)},sort:function(t){var e=this.comparator;if(!e)throw new Error("Cannot sort a set without a comparator");t||(t={});var i=e.length;if(x.isFunction(e))e=e.bind(this);if(i===1||x.isString(e)){this.models=this.sortBy(e)}else{this.models.sort(e)}if(!t.silent)this.trigger("sort",this,t);return this},pluck:function(t){return this.map(t+"")},fetch:function(i){i=x.extend({parse:true},i);var r=i.success;var n=this;i.success=function(t){var e=i.reset?"reset":"set";n[e](t,i);if(r)r.call(i.context,n,t,i);n.trigger("sync",n,t,i)};G(this,i);return this.sync("read",this,i)},create:function(t,e){e=e?x.clone(e):{};var r=e.wait;t=this._prepareModel(t,e);if(!t)return false;if(!r)this.add(t,e);var n=this;var s=e.success;e.success=function(t,e,i){if(r)n.add(t,i);if(s)s.call(i.context,t,e,i)};t.save(null,e);return t},parse:function(t,e){return t},clone:function(){return new this.constructor(this.models,{model:this.model,comparator:this.comparator})},modelId:function(t,e){return t[e||this.model.prototype.idAttribute||"id"]},values:function(){return new b(this,I)},keys:function(){return new b(this,k)},entries:function(){return new b(this,S)},_reset:function(){this.length=0;this.models=[];this._byId={}},_prepareModel:function(t,e){if(this._isModel(t)){if(!t.collection)t.collection=this;return t}e=e?x.clone(e):{};e.collection=this;var i;if(this.model.prototype){i=new this.model(t,e)}else{i=this.model(t,e)}if(!i.validationError)return i;this.trigger("invalid",this,i.validationError,e);return false},_removeModels:function(t,e){var i=[];for(var r=0;r<t.length;r++){var n=this.get(t[r]);if(!n)continue;var s=this.indexOf(n);this.models.splice(s,1);this.length--;delete this._byId[n.cid];var a=this.modelId(n.attributes,n.idAttribute);if(a!=null)delete this._byId[a];if(!e.silent){e.index=s;n.trigger("remove",n,this,e)}i.push(n);this._removeReference(n,e)}return i},_isModel:function(t){return t instanceof g},_addReference:function(t,e){this._byId[t.cid]=t;var i=this.modelId(t.attributes,t.idAttribute);if(i!=null)this._byId[i]=t;t.on("all",this._onModelEvent,this)},_removeReference:function(t,e){delete this._byId[t.cid];var i=this.modelId(t.attributes,t.idAttribute);if(i!=null)delete this._byId[i];if(this===t.collection)delete t.collection;t.off("all",this._onModelEvent,this)},_onModelEvent:function(t,e,i,r){if(e){if((t==="add"||t==="remove")&&i!==this)return;if(t==="destroy")this.remove(e,r);if(t==="changeId"){var n=this.modelId(e.previousAttributes(),e.idAttribute);var s=this.modelId(e.attributes,e.idAttribute);if(n!=null)delete this._byId[n];if(s!=null)this._byId[s]=e}}this.trigger.apply(this,arguments)}});var y=typeof Symbol==="function"&&Symbol.iterator;if(y){m.prototype[y]=m.prototype.values}var b=function(t,e){this._collection=t;this._kind=e;this._index=0};var I=1;var k=2;var S=3;if(y){b.prototype[y]=function(){return this}}b.prototype.next=function(){if(this._collection){if(this._index<this._collection.length){var t=this._collection.at(this._index);this._index++;var e;if(this._kind===I){e=t}else{var i=this._collection.modelId(t.attributes,t.idAttribute);if(this._kind===k){e=i}else{e=[i,t]}}return{value:e,done:false}}this._collection=void 0}return{value:void 0,done:true}};var A=h.View=function(t){this.cid=x.uniqueId("view");this.preinitialize.apply(this,arguments);x.extend(this,x.pick(t,P));this._ensureElement();this.initialize.apply(this,arguments)};var T=/^(\S+)\s*(.*)$/;var P=["model","collection","el","id","attributes","className","tagName","events"];x.extend(A.prototype,r,{tagName:"div",$:function(t){return this.$el.find(t)},preinitialize:function(){},initialize:function(){},render:function(){return this},remove:function(){this._removeElement();this.stopListening();return this},_removeElement:function(){this.$el.remove()},setElement:function(t){this.undelegateEvents();this._setElement(t);this.delegateEvents();return this},_setElement:function(t){this.$el=t instanceof h.$?t:h.$(t);this.el=this.$el[0]},delegateEvents:function(t){t||(t=x.result(this,"events"));if(!t)return this;this.undelegateEvents();for(var e in t){var i=t[e];if(!x.isFunction(i))i=this[i];if(!i)continue;var r=e.match(T);this.delegate(r[1],r[2],i.bind(this))}return this},delegate:function(t,e,i){this.$el.on(t+".delegateEvents"+this.cid,e,i);return this},undelegateEvents:function(){if(this.$el)this.$el.off(".delegateEvents"+this.cid);return this},undelegate:function(t,e,i){this.$el.off(t+".delegateEvents"+this.cid,e,i);return this},_createElement:function(t){return document.createElement(t)},_ensureElement:function(){if(!this.el){var t=x.extend({},x.result(this,"attributes"));if(this.id)t.id=x.result(this,"id");if(this.className)t["class"]=x.result(this,"className");this.setElement(this._createElement(x.result(this,"tagName")));this._setAttributes(t)}else{this.setElement(x.result(this,"el"))}},_setAttributes:function(t){this.$el.attr(t)}});var H=function(r,t,n,s){switch(t){case 1:return function(){return r[n](this[s])};case 2:return function(t){return r[n](this[s],t)};case 3:return function(t,e){return r[n](this[s],C(t,this),e)};case 4:return function(t,e,i){return r[n](this[s],C(t,this),e,i)};default:return function(){var t=a.call(arguments);t.unshift(this[s]);return r[n].apply(r,t)}}};var $=function(i,r,t,n){x.each(t,function(t,e){if(r[e])i.prototype[e]=H(r,t,e,n)})};var C=function(e,t){if(x.isFunction(e))return e;if(x.isObject(e)&&!t._isModel(e))return R(e);if(x.isString(e))return function(t){return t.get(e)};return e};var R=function(t){var e=x.matches(t);return function(t){return e(t.attributes)}};var M={forEach:3,each:3,map:3,collect:3,reduce:0,foldl:0,inject:0,reduceRight:0,foldr:0,find:3,detect:3,filter:3,select:3,reject:3,every:3,all:3,some:3,any:3,include:3,includes:3,contains:3,invoke:0,max:3,min:3,toArray:1,size:1,first:3,head:3,take:3,initial:3,rest:3,tail:3,drop:3,last:3,without:0,difference:0,indexOf:3,shuffle:1,lastIndexOf:3,isEmpty:1,chain:1,sample:3,partition:3,groupBy:3,countBy:3,sortBy:3,indexBy:3,findIndex:3,findLastIndex:3};var N={keys:1,values:1,pairs:1,invert:1,pick:0,omit:0,chain:1,isEmpty:1};x.each([[m,M,"models"],[g,N,"attributes"]],function(t){var i=t[0],e=t[1],r=t[2];i.mixin=function(t){var e=x.reduce(x.functions(t),function(t,e){t[e]=0;return t},{});$(i,t,e,r)};$(i,x,e,r)});h.sync=function(t,e,r){var i=j[t];x.defaults(r||(r={}),{emulateHTTP:h.emulateHTTP,emulateJSON:h.emulateJSON});var n={type:i,dataType:"json"};if(!r.url){n.url=x.result(e,"url")||V()}if(r.data==null&&e&&(t==="create"||t==="update"||t==="patch")){n.contentType="application/json";n.data=JSON.stringify(r.attrs||e.toJSON(r))}if(r.emulateJSON){n.contentType="application/x-www-form-urlencoded";n.data=n.data?{model:n.data}:{}}if(r.emulateHTTP&&(i==="PUT"||i==="DELETE"||i==="PATCH")){n.type="POST";if(r.emulateJSON)n.data._method=i;var s=r.beforeSend;r.beforeSend=function(t){t.setRequestHeader("X-HTTP-Method-Override",i);if(s)return s.apply(this,arguments)}}if(n.type!=="GET"&&!r.emulateJSON){n.processData=false}var a=r.error;r.error=function(t,e,i){r.textStatus=e;r.errorThrown=i;if(a)a.call(r.context,t,e,i)};var o=r.xhr=h.ajax(x.extend(n,r));e.trigger("request",e,o,r);return o};var j={create:"POST",update:"PUT",patch:"PATCH",delete:"DELETE",read:"GET"};h.ajax=function(){return h.$.ajax.apply(h.$,arguments)};var O=h.Router=function(t){t||(t={});this.preinitialize.apply(this,arguments);if(t.routes)this.routes=t.routes;this._bindRoutes();this.initialize.apply(this,arguments)};var U=/\((.*?)\)/g;var z=/(\(\?)?:\w+/g;var q=/\*\w+/g;var F=/[\-{}\[\]+?.,\\\^$|#\s]/g;x.extend(O.prototype,r,{preinitialize:function(){},initialize:function(){},route:function(i,r,n){if(!x.isRegExp(i))i=this._routeToRegExp(i);if(x.isFunction(r)){n=r;r=""}if(!n)n=this[r];var s=this;h.history.route(i,function(t){var e=s._extractParameters(i,t);if(s.execute(n,e,r)!==false){s.trigger.apply(s,["route:"+r].concat(e));s.trigger("route",r,e);h.history.trigger("route",s,r,e)}});return this},execute:function(t,e,i){if(t)t.apply(this,e)},navigate:function(t,e){h.history.navigate(t,e);return this},_bindRoutes:function(){if(!this.routes)return;this.routes=x.result(this,"routes");var t,e=x.keys(this.routes);while((t=e.pop())!=null){this.route(t,this.routes[t])}},_routeToRegExp:function(t){t=t.replace(F,"\\$&").replace(U,"(?:$1)?").replace(z,function(t,e){return e?t:"([^/?]+)"}).replace(q,"([^?]*?)");return new RegExp("^"+t+"(?:\\?([\\s\\S]*))?$")},_extractParameters:function(t,e){var i=t.exec(e).slice(1);return x.map(i,function(t,e){if(e===i.length-1)return t||null;return t?decodeURIComponent(t):null})}});var B=h.History=function(){this.handlers=[];this.checkUrl=this.checkUrl.bind(this);if(typeof window!=="undefined"){this.location=window.location;this.history=window.history}};var J=/^[#\/]|\s+$/g;var L=/^\/+|\/+$/g;var W=/#.*$/;B.started=false;x.extend(B.prototype,r,{interval:50,atRoot:function(){var t=this.location.pathname.replace(/[^\/]$/,"$&/");return t===this.root&&!this.getSearch()},matchRoot:function(){var t=this.decodeFragment(this.location.pathname);var e=t.slice(0,this.root.length-1)+"/";return e===this.root},decodeFragment:function(t){return decodeURI(t.replace(/%25/g,"%2525"))},getSearch:function(){var t=this.location.href.replace(/#.*/,"").match(/\?.+/);return t?t[0]:""},getHash:function(t){var e=(t||this).location.href.match(/#(.*)$/);return e?e[1]:""},getPath:function(){var t=this.decodeFragment(this.location.pathname+this.getSearch()).slice(this.root.length-1);return t.charAt(0)==="/"?t.slice(1):t},getFragment:function(t){if(t==null){if(this._usePushState||!this._wantsHashChange){t=this.getPath()}else{t=this.getHash()}}return t.replace(J,"")},start:function(t){if(B.started)throw new Error("Backbone.history has already been started");B.started=true;this.options=x.extend({root:"/"},this.options,t);this.root=this.options.root;this._wantsHashChange=this.options.hashChange!==false;this._hasHashChange="onhashchange"in window&&(document.documentMode===void 0||document.documentMode>7);this._useHashChange=this._wantsHashChange&&this._hasHashChange;this._wantsPushState=!!this.options.pushState;this._hasPushState=!!(this.history&&this.history.pushState);this._usePushState=this._wantsPushState&&this._hasPushState;this.fragment=this.getFragment();this.root=("/"+this.root+"/").replace(L,"/");if(this._wantsHashChange&&this._wantsPushState){if(!this._hasPushState&&!this.atRoot()){var e=this.root.slice(0,-1)||"/";this.location.replace(e+"#"+this.getPath());return true}else if(this._hasPushState&&this.atRoot()){this.navigate(this.getHash(),{replace:true})}}if(!this._hasHashChange&&this._wantsHashChange&&!this._usePushState){this.iframe=document.createElement("iframe");this.iframe.src="javascript:0";this.iframe.style.display="none";this.iframe.tabIndex=-1;var i=document.body;var r=i.insertBefore(this.iframe,i.firstChild).contentWindow;r.document.open();r.document.close();r.location.hash="#"+this.fragment}var n=window.addEventListener||function(t,e){return attachEvent("on"+t,e)};if(this._usePushState){n("popstate",this.checkUrl,false)}else if(this._useHashChange&&!this.iframe){n("hashchange",this.checkUrl,false)}else if(this._wantsHashChange){this._checkUrlInterval=setInterval(this.checkUrl,this.interval)}if(!this.options.silent)return this.loadUrl()},stop:function(){var t=window.removeEventListener||function(t,e){return detachEvent("on"+t,e)};if(this._usePushState){t("popstate",this.checkUrl,false)}else if(this._useHashChange&&!this.iframe){t("hashchange",this.checkUrl,false)}if(this.iframe){document.body.removeChild(this.iframe);this.iframe=null}if(this._checkUrlInterval)clearInterval(this._checkUrlInterval);B.started=false},route:function(t,e){this.handlers.unshift({route:t,callback:e})},checkUrl:function(t){var e=this.getFragment();if(e===this.fragment&&this.iframe){e=this.getHash(this.iframe.contentWindow)}if(e===this.fragment)return false;if(this.iframe)this.navigate(e);this.loadUrl()},loadUrl:function(e){if(!this.matchRoot())return false;e=this.fragment=this.getFragment(e);return x.some(this.handlers,function(t){if(t.route.test(e)){t.callback(e);return true}})},navigate:function(t,e){if(!B.started)return false;if(!e||e===true)e={trigger:!!e};t=this.getFragment(t||"");var i=this.root;if(t===""||t.charAt(0)==="?"){i=i.slice(0,-1)||"/"}var r=i+t;t=t.replace(W,"");var n=this.decodeFragment(t);if(this.fragment===n)return;this.fragment=n;if(this._usePushState){this.history[e.replace?"replaceState":"pushState"]({},document.title,r)}else if(this._wantsHashChange){this._updateHash(this.location,t,e.replace);if(this.iframe&&t!==this.getHash(this.iframe.contentWindow)){var s=this.iframe.contentWindow;if(!e.replace){s.document.open();s.document.close()}this._updateHash(s.location,t,e.replace)}}else{return this.location.assign(r)}if(e.trigger)return this.loadUrl(t)},_updateHash:function(t,e,i){if(i){var r=t.href.replace(/(javascript:|#).*$/,"");t.replace(r+"#"+e)}else{t.hash="#"+e}}});h.history=new B;var D=function(t,e){var i=this;var r;if(t&&x.has(t,"constructor")){r=t.constructor}else{r=function(){return i.apply(this,arguments)}}x.extend(r,i,e);r.prototype=x.create(i.prototype,t);r.prototype.constructor=r;r.__super__=i.prototype;return r};g.extend=m.extend=O.extend=A.extend=B.extend=D;var V=function(){throw new Error('A "url" property or function must be specified')};var G=function(e,i){var r=i.error;i.error=function(t){if(r)r.call(i.context,e,t,i);e.trigger("error",e,t,i)}};return h});

/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function () {
  var settingsElement = document.querySelector('head > script[type="application/json"][data-drupal-selector="drupal-settings-json"], body > script[type="application/json"][data-drupal-selector="drupal-settings-json"]');
  window.drupalSettings = {};

  if (settingsElement !== null) {
    window.drupalSettings = JSON.parse(settingsElement.textContent);
  }
})();;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

window.Drupal = {
  behaviors: {},
  locale: {}
};

(function (Drupal, drupalSettings, drupalTranslations, console, Proxy, Reflect) {
  Drupal.throwError = function (error) {
    setTimeout(function () {
      throw error;
    }, 0);
  };

  Drupal.attachBehaviors = function (context, settings) {
    context = context || document;
    settings = settings || drupalSettings;
    var behaviors = Drupal.behaviors;
    Object.keys(behaviors || {}).forEach(function (i) {
      if (typeof behaviors[i].attach === 'function') {
        try {
          behaviors[i].attach(context, settings);
        } catch (e) {
          Drupal.throwError(e);
        }
      }
    });
  };

  Drupal.detachBehaviors = function (context, settings, trigger) {
    context = context || document;
    settings = settings || drupalSettings;
    trigger = trigger || 'unload';
    var behaviors = Drupal.behaviors;
    Object.keys(behaviors || {}).forEach(function (i) {
      if (typeof behaviors[i].detach === 'function') {
        try {
          behaviors[i].detach(context, settings, trigger);
        } catch (e) {
          Drupal.throwError(e);
        }
      }
    });
  };

  Drupal.checkPlain = function (str) {
    str = str.toString().replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    return str;
  };

  Drupal.formatString = function (str, args) {
    var processedArgs = {};
    Object.keys(args || {}).forEach(function (key) {
      switch (key.charAt(0)) {
        case '@':
          processedArgs[key] = Drupal.checkPlain(args[key]);
          break;

        case '!':
          processedArgs[key] = args[key];
          break;

        default:
          processedArgs[key] = Drupal.theme('placeholder', args[key]);
          break;
      }
    });
    return Drupal.stringReplace(str, processedArgs, null);
  };

  Drupal.stringReplace = function (str, args, keys) {
    if (str.length === 0) {
      return str;
    }

    if (!Array.isArray(keys)) {
      keys = Object.keys(args || {});
      keys.sort(function (a, b) {
        return a.length - b.length;
      });
    }

    if (keys.length === 0) {
      return str;
    }

    var key = keys.pop();
    var fragments = str.split(key);

    if (keys.length) {
      for (var i = 0; i < fragments.length; i++) {
        fragments[i] = Drupal.stringReplace(fragments[i], args, keys.slice(0));
      }
    }

    return fragments.join(args[key]);
  };

  Drupal.t = function (str, args, options) {
    options = options || {};
    options.context = options.context || '';

    if (typeof drupalTranslations !== 'undefined' && drupalTranslations.strings && drupalTranslations.strings[options.context] && drupalTranslations.strings[options.context][str]) {
      str = drupalTranslations.strings[options.context][str];
    }

    if (args) {
      str = Drupal.formatString(str, args);
    }

    return str;
  };

  Drupal.url = function (path) {
    return drupalSettings.path.baseUrl + drupalSettings.path.pathPrefix + path;
  };

  Drupal.url.toAbsolute = function (url) {
    var urlParsingNode = document.createElement('a');

    try {
      url = decodeURIComponent(url);
    } catch (e) {}

    urlParsingNode.setAttribute('href', url);
    return urlParsingNode.cloneNode(false).href;
  };

  Drupal.url.isLocal = function (url) {
    var absoluteUrl = Drupal.url.toAbsolute(url);
    var protocol = window.location.protocol;

    if (protocol === 'http:' && absoluteUrl.indexOf('https:') === 0) {
      protocol = 'https:';
    }

    var baseUrl = "".concat(protocol, "//").concat(window.location.host).concat(drupalSettings.path.baseUrl.slice(0, -1));

    try {
      absoluteUrl = decodeURIComponent(absoluteUrl);
    } catch (e) {}

    try {
      baseUrl = decodeURIComponent(baseUrl);
    } catch (e) {}

    return absoluteUrl === baseUrl || absoluteUrl.indexOf("".concat(baseUrl, "/")) === 0;
  };

  Drupal.formatPlural = function (count, singular, plural, args, options) {
    args = args || {};
    args['@count'] = count;
    var pluralDelimiter = drupalSettings.pluralDelimiter;
    var translations = Drupal.t(singular + pluralDelimiter + plural, args, options).split(pluralDelimiter);
    var index = 0;

    if (typeof drupalTranslations !== 'undefined' && drupalTranslations.pluralFormula) {
      index = count in drupalTranslations.pluralFormula ? drupalTranslations.pluralFormula[count] : drupalTranslations.pluralFormula.default;
    } else if (args['@count'] !== 1) {
      index = 1;
    }

    return translations[index];
  };

  Drupal.encodePath = function (item) {
    return window.encodeURIComponent(item).replace(/%2F/g, '/');
  };

  Drupal.deprecationError = function (_ref) {
    var message = _ref.message;

    if (drupalSettings.suppressDeprecationErrors === false && typeof console !== 'undefined' && console.warn) {
      console.warn("[Deprecation] ".concat(message));
    }
  };

  Drupal.deprecatedProperty = function (_ref2) {
    var target = _ref2.target,
        deprecatedProperty = _ref2.deprecatedProperty,
        message = _ref2.message;

    if (!Proxy || !Reflect) {
      return target;
    }

    return new Proxy(target, {
      get: function get(target, key) {
        if (key === deprecatedProperty) {
          Drupal.deprecationError({
            message: message
          });
        }

        for (var _len = arguments.length, rest = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) {
          rest[_key - 2] = arguments[_key];
        }

        return Reflect.get.apply(Reflect, [target, key].concat(rest));
      }
    });
  };

  Drupal.theme = function (func) {
    if (func in Drupal.theme) {
      var _Drupal$theme;

      for (var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
        args[_key2 - 1] = arguments[_key2];
      }

      return (_Drupal$theme = Drupal.theme)[func].apply(_Drupal$theme, args);
    }
  };

  Drupal.theme.placeholder = function (str) {
    return "<em class=\"placeholder\">".concat(Drupal.checkPlain(str), "</em>");
  };
})(Drupal, window.drupalSettings, window.drupalTranslations, window.console, window.Proxy, window.Reflect);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

if (window.jQuery) {
  jQuery.noConflict();
}

document.documentElement.className += ' js';

(function (Drupal, drupalSettings) {
  var domReady = function domReady(callback) {
    var listener = function listener() {
      callback();
      document.removeEventListener('DOMContentLoaded', listener);
    };

    if (document.readyState !== 'loading') {
      setTimeout(callback, 0);
    } else {
      document.addEventListener('DOMContentLoaded', listener);
    }
  };

  domReady(function () {
    Drupal.attachBehaviors(document, drupalSettings);
  });
})(Drupal, window.drupalSettings);;
!function(e){"use strict";"function"==typeof define&&define.amd?define(["jquery"],e):e(jQuery)}((function(e){"use strict";return e.ui=e.ui||{},e.ui.version="1.13.1"}));

!function(e){"use strict";"function"==typeof define&&define.amd?define(["jquery","./version"],e):e(jQuery)}((function(e){"use strict";return e.ui.ie=!!/msie [\w.]+/.exec(navigator.userAgent.toLowerCase())}));

!function(t){"use strict";"function"==typeof define&&define.amd?define(["jquery","./version"],t):t(jQuery)}((function(t){"use strict";return t.fn._form=function(){return"string"==typeof this[0].form?this.closest("form"):t(this[0].form)}}));

/*!
 * jQuery UI Support for jQuery core 1.8.x and newer 1.13.1
 * http://jqueryui.com
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 */
!function(e){"use strict";"function"==typeof define&&define.amd?define(["jquery","./version"],e):e(jQuery)}((function(e){"use strict";if(e.expr.pseudos||(e.expr.pseudos=e.expr[":"]),e.uniqueSort||(e.uniqueSort=e.unique),!e.escapeSelector){var n=/([\0-\x1f\x7f]|^-?\d)|^-$|[^\x80-\uFFFF\w-]/g,t=function(e,n){return n?"\0"===e?"�":e.slice(0,-1)+"\\"+e.charCodeAt(e.length-1).toString(16)+" ":"\\"+e};e.escapeSelector=function(e){return(e+"").replace(n,t)}}e.fn.even&&e.fn.odd||e.fn.extend({even:function(){return this.filter((function(e){return e%2==0}))},odd:function(){return this.filter((function(e){return e%2==1}))}})}));

/*!
 * jQuery UI Scroll Parent 1.13.1
 * http://jqueryui.com
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 */
!function(t){"use strict";"function"==typeof define&&define.amd?define(["jquery","./version"],t):t(jQuery)}((function(t){"use strict";return t.fn.scrollParent=function(e){var s=this.css("position"),n="absolute"===s,o=e?/(auto|scroll|hidden)/:/(auto|scroll)/,i=this.parents().filter((function(){var e=t(this);return(!n||"static"!==e.css("position"))&&o.test(e.css("overflow")+e.css("overflow-y")+e.css("overflow-x"))})).eq(0);return"fixed"!==s&&i.length?i:t(this[0].ownerDocument||document)}}));

/*!
 * jQuery UI Focusable 1.13.1
 * http://jqueryui.com
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 */
!function(e){"use strict";"function"==typeof define&&define.amd?define(["jquery","./version"],e):e(jQuery)}((function(e){"use strict";return e.ui.focusable=function(i,t){var n,s,r,u,a,o=i.nodeName.toLowerCase();return"area"===o?(s=(n=i.parentNode).name,!(!i.href||!s||"map"!==n.nodeName.toLowerCase())&&((r=e("img[usemap='#"+s+"']")).length>0&&r.is(":visible"))):(/^(input|select|textarea|button|object)$/.test(o)?(u=!i.disabled)&&(a=e(i).closest("fieldset")[0])&&(u=!a.disabled):u="a"===o&&i.href||t,u&&e(i).is(":visible")&&function(e){var i=e.css("visibility");for(;"inherit"===i;)i=(e=e.parent()).css("visibility");return"visible"===i}(e(i)))},e.extend(e.expr.pseudos,{focusable:function(i){return e.ui.focusable(i,null!=e.attr(i,"tabindex"))}}),e.ui.focusable}));

!function(e){"use strict";"function"==typeof define&&define.amd?define(["jquery","./version"],e):e(jQuery)}((function(e){"use strict";return e.ui.safeBlur=function(n){n&&"body"!==n.nodeName.toLowerCase()&&e(n).trigger("blur")}}));

/*!
 * jQuery UI Keycode 1.13.1
 * http://jqueryui.com
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 */
!function(e){"use strict";"function"==typeof define&&define.amd?define(["jquery","./version"],e):e(jQuery)}((function(e){"use strict";return e.ui.keyCode={BACKSPACE:8,COMMA:188,DELETE:46,DOWN:40,END:35,ENTER:13,ESCAPE:27,HOME:36,LEFT:37,PAGE_DOWN:34,PAGE_UP:33,PERIOD:190,RIGHT:39,SPACE:32,TAB:9,UP:38}}));

!function(e){"use strict";"function"==typeof define&&define.amd?define(["jquery","./version"],e):e(jQuery)}((function(e){"use strict";return e.ui.plugin={add:function(n,i,t){var u,o=e.ui[n].prototype;for(u in t)o.plugins[u]=o.plugins[u]||[],o.plugins[u].push([i,t[u]])},call:function(e,n,i,t){var u,o=e.plugins[n];if(o&&(t||e.element[0].parentNode&&11!==e.element[0].parentNode.nodeType))for(u=0;u<o.length;u++)e.options[o[u][0]]&&o[u][1].apply(e.element,i)}}}));

!function(e){"use strict";"function"==typeof define&&define.amd?define(["jquery","./version"],e):e(jQuery)}((function(e){"use strict";return e.ui.safeActiveElement=function(e){var n;try{n=e.activeElement}catch(t){n=e.body}return n||(n=e.body),n.nodeName||(n=e.body),n}}));

/*!
 * jQuery UI Widget 1.13.1
 * http://jqueryui.com
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 */
!function(t){"use strict";"function"==typeof define&&define.amd?define(["jquery","./version"],t):t(jQuery)}((function(t){"use strict";var e,i=0,s=Array.prototype.hasOwnProperty,n=Array.prototype.slice;return t.cleanData=(e=t.cleanData,function(i){var s,n,o;for(o=0;null!=(n=i[o]);o++)(s=t._data(n,"events"))&&s.remove&&t(n).triggerHandler("remove");e(i)}),t.widget=function(e,i,s){var n,o,a,r={},l=e.split(".")[0],u=l+"-"+(e=e.split(".")[1]);return s||(s=i,i=t.Widget),Array.isArray(s)&&(s=t.extend.apply(null,[{}].concat(s))),t.expr.pseudos[u.toLowerCase()]=function(e){return!!t.data(e,u)},t[l]=t[l]||{},n=t[l][e],o=t[l][e]=function(t,e){if(!this||!this._createWidget)return new o(t,e);arguments.length&&this._createWidget(t,e)},t.extend(o,n,{version:s.version,_proto:t.extend({},s),_childConstructors:[]}),(a=new i).options=t.widget.extend({},a.options),t.each(s,(function(t,e){r[t]="function"==typeof e?function(){function s(){return i.prototype[t].apply(this,arguments)}function n(e){return i.prototype[t].apply(this,e)}return function(){var t,i=this._super,o=this._superApply;return this._super=s,this._superApply=n,t=e.apply(this,arguments),this._super=i,this._superApply=o,t}}():e})),o.prototype=t.widget.extend(a,{widgetEventPrefix:n&&a.widgetEventPrefix||e},r,{constructor:o,namespace:l,widgetName:e,widgetFullName:u}),n?(t.each(n._childConstructors,(function(e,i){var s=i.prototype;t.widget(s.namespace+"."+s.widgetName,o,i._proto)})),delete n._childConstructors):i._childConstructors.push(o),t.widget.bridge(e,o),o},t.widget.extend=function(e){for(var i,o,a=n.call(arguments,1),r=0,l=a.length;r<l;r++)for(i in a[r])o=a[r][i],s.call(a[r],i)&&void 0!==o&&(t.isPlainObject(o)?e[i]=t.isPlainObject(e[i])?t.widget.extend({},e[i],o):t.widget.extend({},o):e[i]=o);return e},t.widget.bridge=function(e,i){var s=i.prototype.widgetFullName||e;t.fn[e]=function(o){var a="string"==typeof o,r=n.call(arguments,1),l=this;return a?this.length||"instance"!==o?this.each((function(){var i,n=t.data(this,s);return"instance"===o?(l=n,!1):n?"function"!=typeof n[o]||"_"===o.charAt(0)?t.error("no such method '"+o+"' for "+e+" widget instance"):(i=n[o].apply(n,r))!==n&&void 0!==i?(l=i&&i.jquery?l.pushStack(i.get()):i,!1):void 0:t.error("cannot call methods on "+e+" prior to initialization; attempted to call method '"+o+"'")})):l=void 0:(r.length&&(o=t.widget.extend.apply(null,[o].concat(r))),this.each((function(){var e=t.data(this,s);e?(e.option(o||{}),e._init&&e._init()):t.data(this,s,new i(o,this))}))),l}},t.Widget=function(){},t.Widget._childConstructors=[],t.Widget.prototype={widgetName:"widget",widgetEventPrefix:"",defaultElement:"<div>",options:{classes:{},disabled:!1,create:null},_createWidget:function(e,s){s=t(s||this.defaultElement||this)[0],this.element=t(s),this.uuid=i++,this.eventNamespace="."+this.widgetName+this.uuid,this.bindings=t(),this.hoverable=t(),this.focusable=t(),this.classesElementLookup={},s!==this&&(t.data(s,this.widgetFullName,this),this._on(!0,this.element,{remove:function(t){t.target===s&&this.destroy()}}),this.document=t(s.style?s.ownerDocument:s.document||s),this.window=t(this.document[0].defaultView||this.document[0].parentWindow)),this.options=t.widget.extend({},this.options,this._getCreateOptions(),e),this._create(),this.options.disabled&&this._setOptionDisabled(this.options.disabled),this._trigger("create",null,this._getCreateEventData()),this._init()},_getCreateOptions:function(){return{}},_getCreateEventData:t.noop,_create:t.noop,_init:t.noop,destroy:function(){var e=this;this._destroy(),t.each(this.classesElementLookup,(function(t,i){e._removeClass(i,t)})),this.element.off(this.eventNamespace).removeData(this.widgetFullName),this.widget().off(this.eventNamespace).removeAttr("aria-disabled"),this.bindings.off(this.eventNamespace)},_destroy:t.noop,widget:function(){return this.element},option:function(e,i){var s,n,o,a=e;if(0===arguments.length)return t.widget.extend({},this.options);if("string"==typeof e)if(a={},s=e.split("."),e=s.shift(),s.length){for(n=a[e]=t.widget.extend({},this.options[e]),o=0;o<s.length-1;o++)n[s[o]]=n[s[o]]||{},n=n[s[o]];if(e=s.pop(),1===arguments.length)return void 0===n[e]?null:n[e];n[e]=i}else{if(1===arguments.length)return void 0===this.options[e]?null:this.options[e];a[e]=i}return this._setOptions(a),this},_setOptions:function(t){var e;for(e in t)this._setOption(e,t[e]);return this},_setOption:function(t,e){return"classes"===t&&this._setOptionClasses(e),this.options[t]=e,"disabled"===t&&this._setOptionDisabled(e),this},_setOptionClasses:function(e){var i,s,n;for(i in e)n=this.classesElementLookup[i],e[i]!==this.options.classes[i]&&n&&n.length&&(s=t(n.get()),this._removeClass(n,i),s.addClass(this._classes({element:s,keys:i,classes:e,add:!0})))},_setOptionDisabled:function(t){this._toggleClass(this.widget(),this.widgetFullName+"-disabled",null,!!t),t&&(this._removeClass(this.hoverable,null,"ui-state-hover"),this._removeClass(this.focusable,null,"ui-state-focus"))},enable:function(){return this._setOptions({disabled:!1})},disable:function(){return this._setOptions({disabled:!0})},_classes:function(e){var i=[],s=this;function n(){var i=[];e.element.each((function(e,n){t.map(s.classesElementLookup,(function(t){return t})).some((function(t){return t.is(n)}))||i.push(n)})),s._on(t(i),{remove:"_untrackClassesElement"})}function o(o,a){var r,l;for(l=0;l<o.length;l++)r=s.classesElementLookup[o[l]]||t(),e.add?(n(),r=t(t.uniqueSort(r.get().concat(e.element.get())))):r=t(r.not(e.element).get()),s.classesElementLookup[o[l]]=r,i.push(o[l]),a&&e.classes[o[l]]&&i.push(e.classes[o[l]])}return(e=t.extend({element:this.element,classes:this.options.classes||{}},e)).keys&&o(e.keys.match(/\S+/g)||[],!0),e.extra&&o(e.extra.match(/\S+/g)||[]),i.join(" ")},_untrackClassesElement:function(e){var i=this;t.each(i.classesElementLookup,(function(s,n){-1!==t.inArray(e.target,n)&&(i.classesElementLookup[s]=t(n.not(e.target).get()))})),this._off(t(e.target))},_removeClass:function(t,e,i){return this._toggleClass(t,e,i,!1)},_addClass:function(t,e,i){return this._toggleClass(t,e,i,!0)},_toggleClass:function(t,e,i,s){s="boolean"==typeof s?s:i;var n="string"==typeof t||null===t,o={extra:n?e:i,keys:n?t:e,element:n?this.element:t,add:s};return o.element.toggleClass(this._classes(o),s),this},_on:function(e,i,s){var n,o=this;"boolean"!=typeof e&&(s=i,i=e,e=!1),s?(i=n=t(i),this.bindings=this.bindings.add(i)):(s=i,i=this.element,n=this.widget()),t.each(s,(function(s,a){function r(){if(e||!0!==o.options.disabled&&!t(this).hasClass("ui-state-disabled"))return("string"==typeof a?o[a]:a).apply(o,arguments)}"string"!=typeof a&&(r.guid=a.guid=a.guid||r.guid||t.guid++);var l=s.match(/^([\w:-]*)\s*(.*)$/),u=l[1]+o.eventNamespace,h=l[2];h?n.on(u,h,r):i.on(u,r)}))},_off:function(e,i){i=(i||"").split(" ").join(this.eventNamespace+" ")+this.eventNamespace,e.off(i),this.bindings=t(this.bindings.not(e).get()),this.focusable=t(this.focusable.not(e).get()),this.hoverable=t(this.hoverable.not(e).get())},_delay:function(t,e){var i=this;return setTimeout((function(){return("string"==typeof t?i[t]:t).apply(i,arguments)}),e||0)},_hoverable:function(e){this.hoverable=this.hoverable.add(e),this._on(e,{mouseenter:function(e){this._addClass(t(e.currentTarget),null,"ui-state-hover")},mouseleave:function(e){this._removeClass(t(e.currentTarget),null,"ui-state-hover")}})},_focusable:function(e){this.focusable=this.focusable.add(e),this._on(e,{focusin:function(e){this._addClass(t(e.currentTarget),null,"ui-state-focus")},focusout:function(e){this._removeClass(t(e.currentTarget),null,"ui-state-focus")}})},_trigger:function(e,i,s){var n,o,a=this.options[e];if(s=s||{},(i=t.Event(i)).type=(e===this.widgetEventPrefix?e:this.widgetEventPrefix+e).toLowerCase(),i.target=this.element[0],o=i.originalEvent)for(n in o)n in i||(i[n]=o[n]);return this.element.trigger(i,s),!("function"==typeof a&&!1===a.apply(this.element[0],[i].concat(s))||i.isDefaultPrevented())}},t.each({show:"fadeIn",hide:"fadeOut"},(function(e,i){t.Widget.prototype["_"+e]=function(s,n,o){var a;"string"==typeof n&&(n={effect:n});var r=n?!0===n||"number"==typeof n?i:n.effect||i:e;"number"==typeof(n=n||{})?n={duration:n}:!0===n&&(n={}),a=!t.isEmptyObject(n),n.complete=o,n.delay&&s.delay(n.delay),a&&t.effects&&t.effects.effect[r]?s[e](n):r!==e&&s[r]?s[r](n.duration,n.easing,o):s.queue((function(i){t(this)[e](),o&&o.call(s[0]),i()}))}})),t.widget}));

/*!
 * jQuery UI :data 1.13.1
 * http://jqueryui.com
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 */
!function(e){"use strict";"function"==typeof define&&define.amd?define(["jquery","./version"],e):e(jQuery)}((function(e){"use strict";return e.extend(e.expr.pseudos,{data:e.expr.createPseudo?e.expr.createPseudo((function(n){return function(t){return!!e.data(t,n)}})):function(n,t,r){return!!e.data(n,r[3])}})}));

/*!
 * jQuery UI Disable Selection 1.13.1
 * http://jqueryui.com
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 */
!function(e){"use strict";"function"==typeof define&&define.amd?define(["jquery","./version"],e):e(jQuery)}((function(e){"use strict";return e.fn.extend({disableSelection:(n="onselectstart"in document.createElement("div")?"selectstart":"mousedown",function(){return this.on(n+".ui-disableSelection",(function(e){e.preventDefault()}))}),enableSelection:function(){return this.off(".ui-disableSelection")}});var n}));

/*!
 * jQuery UI Unique ID 1.13.1
 * http://jqueryui.com
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 */
!function(i){"use strict";"function"==typeof define&&define.amd?define(["jquery","./version"],i):i(jQuery)}((function(i){"use strict";return i.fn.extend({uniqueId:(e=0,function(){return this.each((function(){this.id||(this.id="ui-id-"+ ++e)}))}),removeUniqueId:function(){return this.each((function(){/^ui-id-\d+$/.test(this.id)&&i(this).removeAttr("id")}))}});var e}));

/*!
 * jQuery UI Controlgroup 1.13.1
 * http://jqueryui.com
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 */
!function(t){"use strict";"function"==typeof define&&define.amd?define(["jquery","../widget"],t):t(jQuery)}((function(t){"use strict";var e=/ui-corner-([a-z]){2,6}/g;return t.widget("ui.controlgroup",{version:"1.13.1",defaultElement:"<div>",options:{direction:"horizontal",disabled:null,onlyVisible:!0,items:{button:"input[type=button], input[type=submit], input[type=reset], button, a",controlgroupLabel:".ui-controlgroup-label",checkboxradio:"input[type='checkbox'], input[type='radio']",selectmenu:"select",spinner:".ui-spinner-input"}},_create:function(){this._enhance()},_enhance:function(){this.element.attr("role","toolbar"),this.refresh()},_destroy:function(){this._callChildMethod("destroy"),this.childWidgets.removeData("ui-controlgroup-data"),this.element.removeAttr("role"),this.options.items.controlgroupLabel&&this.element.find(this.options.items.controlgroupLabel).find(".ui-controlgroup-label-contents").contents().unwrap()},_initWidgets:function(){var e=this,i=[];t.each(this.options.items,(function(n,o){var s,l={};if(o)return"controlgroupLabel"===n?((s=e.element.find(o)).each((function(){var e=t(this);e.children(".ui-controlgroup-label-contents").length||e.contents().wrapAll("<span class='ui-controlgroup-label-contents'></span>")})),e._addClass(s,null,"ui-widget ui-widget-content ui-state-default"),void(i=i.concat(s.get()))):void(t.fn[n]&&(l=e["_"+n+"Options"]?e["_"+n+"Options"]("middle"):{classes:{}},e.element.find(o).each((function(){var o=t(this),s=o[n]("instance"),r=t.widget.extend({},l);if("button"!==n||!o.parent(".ui-spinner").length){s||(s=o[n]()[n]("instance")),s&&(r.classes=e._resolveClassesValues(r.classes,s)),o[n](r);var u=o[n]("widget");t.data(u[0],"ui-controlgroup-data",s||o[n]("instance")),i.push(u[0])}}))))})),this.childWidgets=t(t.uniqueSort(i)),this._addClass(this.childWidgets,"ui-controlgroup-item")},_callChildMethod:function(e){this.childWidgets.each((function(){var i=t(this).data("ui-controlgroup-data");i&&i[e]&&i[e]()}))},_updateCornerClass:function(t,e){var i=this._buildSimpleOptions(e,"label").classes.label;this._removeClass(t,null,"ui-corner-top ui-corner-bottom ui-corner-left ui-corner-right ui-corner-all"),this._addClass(t,null,i)},_buildSimpleOptions:function(t,e){var i="vertical"===this.options.direction,n={classes:{}};return n.classes[e]={middle:"",first:"ui-corner-"+(i?"top":"left"),last:"ui-corner-"+(i?"bottom":"right"),only:"ui-corner-all"}[t],n},_spinnerOptions:function(t){var e=this._buildSimpleOptions(t,"ui-spinner");return e.classes["ui-spinner-up"]="",e.classes["ui-spinner-down"]="",e},_buttonOptions:function(t){return this._buildSimpleOptions(t,"ui-button")},_checkboxradioOptions:function(t){return this._buildSimpleOptions(t,"ui-checkboxradio-label")},_selectmenuOptions:function(t){var e="vertical"===this.options.direction;return{width:!!e&&"auto",classes:{middle:{"ui-selectmenu-button-open":"","ui-selectmenu-button-closed":""},first:{"ui-selectmenu-button-open":"ui-corner-"+(e?"top":"tl"),"ui-selectmenu-button-closed":"ui-corner-"+(e?"top":"left")},last:{"ui-selectmenu-button-open":e?"":"ui-corner-tr","ui-selectmenu-button-closed":"ui-corner-"+(e?"bottom":"right")},only:{"ui-selectmenu-button-open":"ui-corner-top","ui-selectmenu-button-closed":"ui-corner-all"}}[t]}},_resolveClassesValues:function(i,n){var o={};return t.each(i,(function(t){var s=n.options.classes[t]||"";s=String.prototype.trim.call(s.replace(e,"")),o[t]=(s+" "+i[t]).replace(/\s+/g," ")})),o},_setOption:function(t,e){"direction"===t&&this._removeClass("ui-controlgroup-"+this.options.direction),this._super(t,e),"disabled"!==t?this.refresh():this._callChildMethod(e?"disable":"enable")},refresh:function(){var e,i=this;this._addClass("ui-controlgroup ui-controlgroup-"+this.options.direction),"horizontal"===this.options.direction&&this._addClass(null,"ui-helper-clearfix"),this._initWidgets(),e=this.childWidgets,this.options.onlyVisible&&(e=e.filter(":visible")),e.length&&(t.each(["first","last"],(function(t,n){var o=e[n]().data("ui-controlgroup-data");if(o&&i["_"+o.widgetName+"Options"]){var s=i["_"+o.widgetName+"Options"](1===e.length?"only":n);s.classes=i._resolveClassesValues(s.classes,o),o.element[o.widgetName](s)}else i._updateCornerClass(e[n](),n)})),this._callChildMethod("refresh"))}})}));

/*!
 * jQuery UI Form Reset Mixin 1.13.1
 * http://jqueryui.com
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 */
!function(e){"use strict";"function"==typeof define&&define.amd?define(["jquery","./form","./version"],e):e(jQuery)}((function(e){"use strict";return e.ui.formResetMixin={_formResetHandler:function(){var t=e(this);setTimeout((function(){var r=t.data("ui-form-reset-instances");e.each(r,(function(){this.refresh()}))}))},_bindFormResetHandler:function(){if(this.form=this.element._form(),this.form.length){var e=this.form.data("ui-form-reset-instances")||[];e.length||this.form.on("reset.ui-form-reset",this._formResetHandler),e.push(this),this.form.data("ui-form-reset-instances",e)}},_unbindFormResetHandler:function(){if(this.form.length){var t=this.form.data("ui-form-reset-instances");t.splice(e.inArray(this,t),1),t.length?this.form.data("ui-form-reset-instances",t):this.form.removeData("ui-form-reset-instances").off("reset.ui-form-reset")}}}}));

/*!
 * jQuery UI Labels 1.13.1
 * http://jqueryui.com
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 */
!function(t){"use strict";"function"==typeof define&&define.amd?define(["jquery","./version"],t):t(jQuery)}((function(t){"use strict";return t.fn.labels=function(){var e,s,i,n,a;return this.length?this[0].labels&&this[0].labels.length?this.pushStack(this[0].labels):(n=this.eq(0).parents("label"),(i=this.attr("id"))&&(a=(e=this.eq(0).parents().last()).add(e.length?e.siblings():this.siblings()),s="label[for='"+t.escapeSelector(i)+"']",n=n.add(a.find(s).addBack(s))),this.pushStack(n)):this.pushStack([])}}));

/*!
 * jQuery UI Mouse 1.13.1
 * http://jqueryui.com
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 */
!function(e){"use strict";"function"==typeof define&&define.amd?define(["jquery","../ie","../version","../widget"],e):e(jQuery)}((function(e){"use strict";var t=!1;return e(document).on("mouseup",(function(){t=!1})),e.widget("ui.mouse",{version:"1.13.1",options:{cancel:"input, textarea, button, select, option",distance:1,delay:0},_mouseInit:function(){var t=this;this.element.on("mousedown."+this.widgetName,(function(e){return t._mouseDown(e)})).on("click."+this.widgetName,(function(i){if(!0===e.data(i.target,t.widgetName+".preventClickEvent"))return e.removeData(i.target,t.widgetName+".preventClickEvent"),i.stopImmediatePropagation(),!1})),this.started=!1},_mouseDestroy:function(){this.element.off("."+this.widgetName),this._mouseMoveDelegate&&this.document.off("mousemove."+this.widgetName,this._mouseMoveDelegate).off("mouseup."+this.widgetName,this._mouseUpDelegate)},_mouseDown:function(i){if(!t){this._mouseMoved=!1,this._mouseStarted&&this._mouseUp(i),this._mouseDownEvent=i;var s=this,o=1===i.which,n=!("string"!=typeof this.options.cancel||!i.target.nodeName)&&e(i.target).closest(this.options.cancel).length;return!(o&&!n&&this._mouseCapture(i))||(this.mouseDelayMet=!this.options.delay,this.mouseDelayMet||(this._mouseDelayTimer=setTimeout((function(){s.mouseDelayMet=!0}),this.options.delay)),this._mouseDistanceMet(i)&&this._mouseDelayMet(i)&&(this._mouseStarted=!1!==this._mouseStart(i),!this._mouseStarted)?(i.preventDefault(),!0):(!0===e.data(i.target,this.widgetName+".preventClickEvent")&&e.removeData(i.target,this.widgetName+".preventClickEvent"),this._mouseMoveDelegate=function(e){return s._mouseMove(e)},this._mouseUpDelegate=function(e){return s._mouseUp(e)},this.document.on("mousemove."+this.widgetName,this._mouseMoveDelegate).on("mouseup."+this.widgetName,this._mouseUpDelegate),i.preventDefault(),t=!0,!0))}},_mouseMove:function(t){if(this._mouseMoved){if(e.ui.ie&&(!document.documentMode||document.documentMode<9)&&!t.button)return this._mouseUp(t);if(!t.which)if(t.originalEvent.altKey||t.originalEvent.ctrlKey||t.originalEvent.metaKey||t.originalEvent.shiftKey)this.ignoreMissingWhich=!0;else if(!this.ignoreMissingWhich)return this._mouseUp(t)}return(t.which||t.button)&&(this._mouseMoved=!0),this._mouseStarted?(this._mouseDrag(t),t.preventDefault()):(this._mouseDistanceMet(t)&&this._mouseDelayMet(t)&&(this._mouseStarted=!1!==this._mouseStart(this._mouseDownEvent,t),this._mouseStarted?this._mouseDrag(t):this._mouseUp(t)),!this._mouseStarted)},_mouseUp:function(i){this.document.off("mousemove."+this.widgetName,this._mouseMoveDelegate).off("mouseup."+this.widgetName,this._mouseUpDelegate),this._mouseStarted&&(this._mouseStarted=!1,i.target===this._mouseDownEvent.target&&e.data(i.target,this.widgetName+".preventClickEvent",!0),this._mouseStop(i)),this._mouseDelayTimer&&(clearTimeout(this._mouseDelayTimer),delete this._mouseDelayTimer),this.ignoreMissingWhich=!1,t=!1,i.preventDefault()},_mouseDistanceMet:function(e){return Math.max(Math.abs(this._mouseDownEvent.pageX-e.pageX),Math.abs(this._mouseDownEvent.pageY-e.pageY))>=this.options.distance},_mouseDelayMet:function(){return this.mouseDelayMet},_mouseStart:function(){},_mouseDrag:function(){},_mouseStop:function(){},_mouseCapture:function(){return!0}})}));

/*!
 * jQuery UI Draggable 1.13.1
 * http://jqueryui.com
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 */
!function(t){"use strict";"function"==typeof define&&define.amd?define(["jquery","./mouse","../data","../plugin","../safe-active-element","../safe-blur","../scroll-parent","../version","../widget"],t):t(jQuery)}((function(t){"use strict";return t.widget("ui.draggable",t.ui.mouse,{version:"1.13.1",widgetEventPrefix:"drag",options:{addClasses:!0,appendTo:"parent",axis:!1,connectToSortable:!1,containment:!1,cursor:"auto",cursorAt:!1,grid:!1,handle:!1,helper:"original",iframeFix:!1,opacity:!1,refreshPositions:!1,revert:!1,revertDuration:500,scope:"default",scroll:!0,scrollSensitivity:20,scrollSpeed:20,snap:!1,snapMode:"both",snapTolerance:20,stack:!1,zIndex:!1,drag:null,start:null,stop:null},_create:function(){"original"===this.options.helper&&this._setPositionRelative(),this.options.addClasses&&this._addClass("ui-draggable"),this._setHandleClassName(),this._mouseInit()},_setOption:function(t,e){this._super(t,e),"handle"===t&&(this._removeHandleClassName(),this._setHandleClassName())},_destroy:function(){(this.helper||this.element).is(".ui-draggable-dragging")?this.destroyOnClear=!0:(this._removeHandleClassName(),this._mouseDestroy())},_mouseCapture:function(e){var s=this.options;return!(this.helper||s.disabled||t(e.target).closest(".ui-resizable-handle").length>0)&&(this.handle=this._getHandle(e),!!this.handle&&(this._blurActiveElement(e),this._blockFrames(!0===s.iframeFix?"iframe":s.iframeFix),!0))},_blockFrames:function(e){this.iframeBlocks=this.document.find(e).map((function(){var e=t(this);return t("<div>").css("position","absolute").appendTo(e.parent()).outerWidth(e.outerWidth()).outerHeight(e.outerHeight()).offset(e.offset())[0]}))},_unblockFrames:function(){this.iframeBlocks&&(this.iframeBlocks.remove(),delete this.iframeBlocks)},_blurActiveElement:function(e){var s=t.ui.safeActiveElement(this.document[0]);t(e.target).closest(s).length||t.ui.safeBlur(s)},_mouseStart:function(e){var s=this.options;return this.helper=this._createHelper(e),this._addClass(this.helper,"ui-draggable-dragging"),this._cacheHelperProportions(),t.ui.ddmanager&&(t.ui.ddmanager.current=this),this._cacheMargins(),this.cssPosition=this.helper.css("position"),this.scrollParent=this.helper.scrollParent(!0),this.offsetParent=this.helper.offsetParent(),this.hasFixedAncestor=this.helper.parents().filter((function(){return"fixed"===t(this).css("position")})).length>0,this.positionAbs=this.element.offset(),this._refreshOffsets(e),this.originalPosition=this.position=this._generatePosition(e,!1),this.originalPageX=e.pageX,this.originalPageY=e.pageY,s.cursorAt&&this._adjustOffsetFromHelper(s.cursorAt),this._setContainment(),!1===this._trigger("start",e)?(this._clear(),!1):(this._cacheHelperProportions(),t.ui.ddmanager&&!s.dropBehaviour&&t.ui.ddmanager.prepareOffsets(this,e),this._mouseDrag(e,!0),t.ui.ddmanager&&t.ui.ddmanager.dragStart(this,e),!0)},_refreshOffsets:function(t){this.offset={top:this.positionAbs.top-this.margins.top,left:this.positionAbs.left-this.margins.left,scroll:!1,parent:this._getParentOffset(),relative:this._getRelativeOffset()},this.offset.click={left:t.pageX-this.offset.left,top:t.pageY-this.offset.top}},_mouseDrag:function(e,s){if(this.hasFixedAncestor&&(this.offset.parent=this._getParentOffset()),this.position=this._generatePosition(e,!0),this.positionAbs=this._convertPositionTo("absolute"),!s){var i=this._uiHash();if(!1===this._trigger("drag",e,i))return this._mouseUp(new t.Event("mouseup",e)),!1;this.position=i.position}return this.helper[0].style.left=this.position.left+"px",this.helper[0].style.top=this.position.top+"px",t.ui.ddmanager&&t.ui.ddmanager.drag(this,e),!1},_mouseStop:function(e){var s=this,i=!1;return t.ui.ddmanager&&!this.options.dropBehaviour&&(i=t.ui.ddmanager.drop(this,e)),this.dropped&&(i=this.dropped,this.dropped=!1),"invalid"===this.options.revert&&!i||"valid"===this.options.revert&&i||!0===this.options.revert||"function"==typeof this.options.revert&&this.options.revert.call(this.element,i)?t(this.helper).animate(this.originalPosition,parseInt(this.options.revertDuration,10),(function(){!1!==s._trigger("stop",e)&&s._clear()})):!1!==this._trigger("stop",e)&&this._clear(),!1},_mouseUp:function(e){return this._unblockFrames(),t.ui.ddmanager&&t.ui.ddmanager.dragStop(this,e),this.handleElement.is(e.target)&&this.element.trigger("focus"),t.ui.mouse.prototype._mouseUp.call(this,e)},cancel:function(){return this.helper.is(".ui-draggable-dragging")?this._mouseUp(new t.Event("mouseup",{target:this.element[0]})):this._clear(),this},_getHandle:function(e){return!this.options.handle||!!t(e.target).closest(this.element.find(this.options.handle)).length},_setHandleClassName:function(){this.handleElement=this.options.handle?this.element.find(this.options.handle):this.element,this._addClass(this.handleElement,"ui-draggable-handle")},_removeHandleClassName:function(){this._removeClass(this.handleElement,"ui-draggable-handle")},_createHelper:function(e){var s=this.options,i="function"==typeof s.helper,o=i?t(s.helper.apply(this.element[0],[e])):"clone"===s.helper?this.element.clone().removeAttr("id"):this.element;return o.parents("body").length||o.appendTo("parent"===s.appendTo?this.element[0].parentNode:s.appendTo),i&&o[0]===this.element[0]&&this._setPositionRelative(),o[0]===this.element[0]||/(fixed|absolute)/.test(o.css("position"))||o.css("position","absolute"),o},_setPositionRelative:function(){/^(?:r|a|f)/.test(this.element.css("position"))||(this.element[0].style.position="relative")},_adjustOffsetFromHelper:function(t){"string"==typeof t&&(t=t.split(" ")),Array.isArray(t)&&(t={left:+t[0],top:+t[1]||0}),"left"in t&&(this.offset.click.left=t.left+this.margins.left),"right"in t&&(this.offset.click.left=this.helperProportions.width-t.right+this.margins.left),"top"in t&&(this.offset.click.top=t.top+this.margins.top),"bottom"in t&&(this.offset.click.top=this.helperProportions.height-t.bottom+this.margins.top)},_isRootNode:function(t){return/(html|body)/i.test(t.tagName)||t===this.document[0]},_getParentOffset:function(){var e=this.offsetParent.offset(),s=this.document[0];return"absolute"===this.cssPosition&&this.scrollParent[0]!==s&&t.contains(this.scrollParent[0],this.offsetParent[0])&&(e.left+=this.scrollParent.scrollLeft(),e.top+=this.scrollParent.scrollTop()),this._isRootNode(this.offsetParent[0])&&(e={top:0,left:0}),{top:e.top+(parseInt(this.offsetParent.css("borderTopWidth"),10)||0),left:e.left+(parseInt(this.offsetParent.css("borderLeftWidth"),10)||0)}},_getRelativeOffset:function(){if("relative"!==this.cssPosition)return{top:0,left:0};var t=this.element.position(),e=this._isRootNode(this.scrollParent[0]);return{top:t.top-(parseInt(this.helper.css("top"),10)||0)+(e?0:this.scrollParent.scrollTop()),left:t.left-(parseInt(this.helper.css("left"),10)||0)+(e?0:this.scrollParent.scrollLeft())}},_cacheMargins:function(){this.margins={left:parseInt(this.element.css("marginLeft"),10)||0,top:parseInt(this.element.css("marginTop"),10)||0,right:parseInt(this.element.css("marginRight"),10)||0,bottom:parseInt(this.element.css("marginBottom"),10)||0}},_cacheHelperProportions:function(){this.helperProportions={width:this.helper.outerWidth(),height:this.helper.outerHeight()}},_setContainment:function(){var e,s,i,o=this.options,n=this.document[0];this.relativeContainer=null,o.containment?"window"!==o.containment?"document"!==o.containment?o.containment.constructor!==Array?("parent"===o.containment&&(o.containment=this.helper[0].parentNode),(i=(s=t(o.containment))[0])&&(e=/(scroll|auto)/.test(s.css("overflow")),this.containment=[(parseInt(s.css("borderLeftWidth"),10)||0)+(parseInt(s.css("paddingLeft"),10)||0),(parseInt(s.css("borderTopWidth"),10)||0)+(parseInt(s.css("paddingTop"),10)||0),(e?Math.max(i.scrollWidth,i.offsetWidth):i.offsetWidth)-(parseInt(s.css("borderRightWidth"),10)||0)-(parseInt(s.css("paddingRight"),10)||0)-this.helperProportions.width-this.margins.left-this.margins.right,(e?Math.max(i.scrollHeight,i.offsetHeight):i.offsetHeight)-(parseInt(s.css("borderBottomWidth"),10)||0)-(parseInt(s.css("paddingBottom"),10)||0)-this.helperProportions.height-this.margins.top-this.margins.bottom],this.relativeContainer=s)):this.containment=o.containment:this.containment=[0,0,t(n).width()-this.helperProportions.width-this.margins.left,(t(n).height()||n.body.parentNode.scrollHeight)-this.helperProportions.height-this.margins.top]:this.containment=[t(window).scrollLeft()-this.offset.relative.left-this.offset.parent.left,t(window).scrollTop()-this.offset.relative.top-this.offset.parent.top,t(window).scrollLeft()+t(window).width()-this.helperProportions.width-this.margins.left,t(window).scrollTop()+(t(window).height()||n.body.parentNode.scrollHeight)-this.helperProportions.height-this.margins.top]:this.containment=null},_convertPositionTo:function(t,e){e||(e=this.position);var s="absolute"===t?1:-1,i=this._isRootNode(this.scrollParent[0]);return{top:e.top+this.offset.relative.top*s+this.offset.parent.top*s-("fixed"===this.cssPosition?-this.offset.scroll.top:i?0:this.offset.scroll.top)*s,left:e.left+this.offset.relative.left*s+this.offset.parent.left*s-("fixed"===this.cssPosition?-this.offset.scroll.left:i?0:this.offset.scroll.left)*s}},_generatePosition:function(t,e){var s,i,o,n,r=this.options,l=this._isRootNode(this.scrollParent[0]),a=t.pageX,h=t.pageY;return l&&this.offset.scroll||(this.offset.scroll={top:this.scrollParent.scrollTop(),left:this.scrollParent.scrollLeft()}),e&&(this.containment&&(this.relativeContainer?(i=this.relativeContainer.offset(),s=[this.containment[0]+i.left,this.containment[1]+i.top,this.containment[2]+i.left,this.containment[3]+i.top]):s=this.containment,t.pageX-this.offset.click.left<s[0]&&(a=s[0]+this.offset.click.left),t.pageY-this.offset.click.top<s[1]&&(h=s[1]+this.offset.click.top),t.pageX-this.offset.click.left>s[2]&&(a=s[2]+this.offset.click.left),t.pageY-this.offset.click.top>s[3]&&(h=s[3]+this.offset.click.top)),r.grid&&(o=r.grid[1]?this.originalPageY+Math.round((h-this.originalPageY)/r.grid[1])*r.grid[1]:this.originalPageY,h=s?o-this.offset.click.top>=s[1]||o-this.offset.click.top>s[3]?o:o-this.offset.click.top>=s[1]?o-r.grid[1]:o+r.grid[1]:o,n=r.grid[0]?this.originalPageX+Math.round((a-this.originalPageX)/r.grid[0])*r.grid[0]:this.originalPageX,a=s?n-this.offset.click.left>=s[0]||n-this.offset.click.left>s[2]?n:n-this.offset.click.left>=s[0]?n-r.grid[0]:n+r.grid[0]:n),"y"===r.axis&&(a=this.originalPageX),"x"===r.axis&&(h=this.originalPageY)),{top:h-this.offset.click.top-this.offset.relative.top-this.offset.parent.top+("fixed"===this.cssPosition?-this.offset.scroll.top:l?0:this.offset.scroll.top),left:a-this.offset.click.left-this.offset.relative.left-this.offset.parent.left+("fixed"===this.cssPosition?-this.offset.scroll.left:l?0:this.offset.scroll.left)}},_clear:function(){this._removeClass(this.helper,"ui-draggable-dragging"),this.helper[0]===this.element[0]||this.cancelHelperRemoval||this.helper.remove(),this.helper=null,this.cancelHelperRemoval=!1,this.destroyOnClear&&this.destroy()},_trigger:function(e,s,i){return i=i||this._uiHash(),t.ui.plugin.call(this,e,[s,i,this],!0),/^(drag|start|stop)/.test(e)&&(this.positionAbs=this._convertPositionTo("absolute"),i.offset=this.positionAbs),t.Widget.prototype._trigger.call(this,e,s,i)},plugins:{},_uiHash:function(){return{helper:this.helper,position:this.position,originalPosition:this.originalPosition,offset:this.positionAbs}}}),t.ui.plugin.add("draggable","connectToSortable",{start:function(e,s,i){var o=t.extend({},s,{item:i.element});i.sortables=[],t(i.options.connectToSortable).each((function(){var s=t(this).sortable("instance");s&&!s.options.disabled&&(i.sortables.push(s),s.refreshPositions(),s._trigger("activate",e,o))}))},stop:function(e,s,i){var o=t.extend({},s,{item:i.element});i.cancelHelperRemoval=!1,t.each(i.sortables,(function(){var t=this;t.isOver?(t.isOver=0,i.cancelHelperRemoval=!0,t.cancelHelperRemoval=!1,t._storedCSS={position:t.placeholder.css("position"),top:t.placeholder.css("top"),left:t.placeholder.css("left")},t._mouseStop(e),t.options.helper=t.options._helper):(t.cancelHelperRemoval=!0,t._trigger("deactivate",e,o))}))},drag:function(e,s,i){t.each(i.sortables,(function(){var o=!1,n=this;n.positionAbs=i.positionAbs,n.helperProportions=i.helperProportions,n.offset.click=i.offset.click,n._intersectsWith(n.containerCache)&&(o=!0,t.each(i.sortables,(function(){return this.positionAbs=i.positionAbs,this.helperProportions=i.helperProportions,this.offset.click=i.offset.click,this!==n&&this._intersectsWith(this.containerCache)&&t.contains(n.element[0],this.element[0])&&(o=!1),o}))),o?(n.isOver||(n.isOver=1,i._parent=s.helper.parent(),n.currentItem=s.helper.appendTo(n.element).data("ui-sortable-item",!0),n.options._helper=n.options.helper,n.options.helper=function(){return s.helper[0]},e.target=n.currentItem[0],n._mouseCapture(e,!0),n._mouseStart(e,!0,!0),n.offset.click.top=i.offset.click.top,n.offset.click.left=i.offset.click.left,n.offset.parent.left-=i.offset.parent.left-n.offset.parent.left,n.offset.parent.top-=i.offset.parent.top-n.offset.parent.top,i._trigger("toSortable",e),i.dropped=n.element,t.each(i.sortables,(function(){this.refreshPositions()})),i.currentItem=i.element,n.fromOutside=i),n.currentItem&&(n._mouseDrag(e),s.position=n.position)):n.isOver&&(n.isOver=0,n.cancelHelperRemoval=!0,n.options._revert=n.options.revert,n.options.revert=!1,n._trigger("out",e,n._uiHash(n)),n._mouseStop(e,!0),n.options.revert=n.options._revert,n.options.helper=n.options._helper,n.placeholder&&n.placeholder.remove(),s.helper.appendTo(i._parent),i._refreshOffsets(e),s.position=i._generatePosition(e,!0),i._trigger("fromSortable",e),i.dropped=!1,t.each(i.sortables,(function(){this.refreshPositions()})))}))}}),t.ui.plugin.add("draggable","cursor",{start:function(e,s,i){var o=t("body"),n=i.options;o.css("cursor")&&(n._cursor=o.css("cursor")),o.css("cursor",n.cursor)},stop:function(e,s,i){var o=i.options;o._cursor&&t("body").css("cursor",o._cursor)}}),t.ui.plugin.add("draggable","opacity",{start:function(e,s,i){var o=t(s.helper),n=i.options;o.css("opacity")&&(n._opacity=o.css("opacity")),o.css("opacity",n.opacity)},stop:function(e,s,i){var o=i.options;o._opacity&&t(s.helper).css("opacity",o._opacity)}}),t.ui.plugin.add("draggable","scroll",{start:function(t,e,s){s.scrollParentNotHidden||(s.scrollParentNotHidden=s.helper.scrollParent(!1)),s.scrollParentNotHidden[0]!==s.document[0]&&"HTML"!==s.scrollParentNotHidden[0].tagName&&(s.overflowOffset=s.scrollParentNotHidden.offset())},drag:function(e,s,i){var o=i.options,n=!1,r=i.scrollParentNotHidden[0],l=i.document[0];r!==l&&"HTML"!==r.tagName?(o.axis&&"x"===o.axis||(i.overflowOffset.top+r.offsetHeight-e.pageY<o.scrollSensitivity?r.scrollTop=n=r.scrollTop+o.scrollSpeed:e.pageY-i.overflowOffset.top<o.scrollSensitivity&&(r.scrollTop=n=r.scrollTop-o.scrollSpeed)),o.axis&&"y"===o.axis||(i.overflowOffset.left+r.offsetWidth-e.pageX<o.scrollSensitivity?r.scrollLeft=n=r.scrollLeft+o.scrollSpeed:e.pageX-i.overflowOffset.left<o.scrollSensitivity&&(r.scrollLeft=n=r.scrollLeft-o.scrollSpeed))):(o.axis&&"x"===o.axis||(e.pageY-t(l).scrollTop()<o.scrollSensitivity?n=t(l).scrollTop(t(l).scrollTop()-o.scrollSpeed):t(window).height()-(e.pageY-t(l).scrollTop())<o.scrollSensitivity&&(n=t(l).scrollTop(t(l).scrollTop()+o.scrollSpeed))),o.axis&&"y"===o.axis||(e.pageX-t(l).scrollLeft()<o.scrollSensitivity?n=t(l).scrollLeft(t(l).scrollLeft()-o.scrollSpeed):t(window).width()-(e.pageX-t(l).scrollLeft())<o.scrollSensitivity&&(n=t(l).scrollLeft(t(l).scrollLeft()+o.scrollSpeed)))),!1!==n&&t.ui.ddmanager&&!o.dropBehaviour&&t.ui.ddmanager.prepareOffsets(i,e)}}),t.ui.plugin.add("draggable","snap",{start:function(e,s,i){var o=i.options;i.snapElements=[],t(o.snap.constructor!==String?o.snap.items||":data(ui-draggable)":o.snap).each((function(){var e=t(this),s=e.offset();this!==i.element[0]&&i.snapElements.push({item:this,width:e.outerWidth(),height:e.outerHeight(),top:s.top,left:s.left})}))},drag:function(e,s,i){var o,n,r,l,a,h,p,c,f,d,g=i.options,u=g.snapTolerance,m=s.offset.left,v=m+i.helperProportions.width,_=s.offset.top,P=_+i.helperProportions.height;for(f=i.snapElements.length-1;f>=0;f--)h=(a=i.snapElements[f].left-i.margins.left)+i.snapElements[f].width,c=(p=i.snapElements[f].top-i.margins.top)+i.snapElements[f].height,v<a-u||m>h+u||P<p-u||_>c+u||!t.contains(i.snapElements[f].item.ownerDocument,i.snapElements[f].item)?(i.snapElements[f].snapping&&i.options.snap.release&&i.options.snap.release.call(i.element,e,t.extend(i._uiHash(),{snapItem:i.snapElements[f].item})),i.snapElements[f].snapping=!1):("inner"!==g.snapMode&&(o=Math.abs(p-P)<=u,n=Math.abs(c-_)<=u,r=Math.abs(a-v)<=u,l=Math.abs(h-m)<=u,o&&(s.position.top=i._convertPositionTo("relative",{top:p-i.helperProportions.height,left:0}).top),n&&(s.position.top=i._convertPositionTo("relative",{top:c,left:0}).top),r&&(s.position.left=i._convertPositionTo("relative",{top:0,left:a-i.helperProportions.width}).left),l&&(s.position.left=i._convertPositionTo("relative",{top:0,left:h}).left)),d=o||n||r||l,"outer"!==g.snapMode&&(o=Math.abs(p-_)<=u,n=Math.abs(c-P)<=u,r=Math.abs(a-m)<=u,l=Math.abs(h-v)<=u,o&&(s.position.top=i._convertPositionTo("relative",{top:p,left:0}).top),n&&(s.position.top=i._convertPositionTo("relative",{top:c-i.helperProportions.height,left:0}).top),r&&(s.position.left=i._convertPositionTo("relative",{top:0,left:a}).left),l&&(s.position.left=i._convertPositionTo("relative",{top:0,left:h-i.helperProportions.width}).left)),!i.snapElements[f].snapping&&(o||n||r||l||d)&&i.options.snap.snap&&i.options.snap.snap.call(i.element,e,t.extend(i._uiHash(),{snapItem:i.snapElements[f].item})),i.snapElements[f].snapping=o||n||r||l||d)}}),t.ui.plugin.add("draggable","stack",{start:function(e,s,i){var o,n=i.options,r=t.makeArray(t(n.stack)).sort((function(e,s){return(parseInt(t(e).css("zIndex"),10)||0)-(parseInt(t(s).css("zIndex"),10)||0)}));r.length&&(o=parseInt(t(r[0]).css("zIndex"),10)||0,t(r).each((function(e){t(this).css("zIndex",o+e)})),this.css("zIndex",o+r.length))}}),t.ui.plugin.add("draggable","zIndex",{start:function(e,s,i){var o=t(s.helper),n=i.options;o.css("zIndex")&&(n._zIndex=o.css("zIndex")),o.css("zIndex",n.zIndex)},stop:function(e,s,i){var o=i.options;o._zIndex&&t(s.helper).css("zIndex",o._zIndex)}}),t.ui.draggable}));

/*!
 * jQuery UI Checkboxradio 1.13.1
 * http://jqueryui.com
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 */
!function(e){"use strict";"function"==typeof define&&define.amd?define(["jquery","../form-reset-mixin","../labels","../widget"],e):e(jQuery)}((function(e){"use strict";return e.widget("ui.checkboxradio",[e.ui.formResetMixin,{version:"1.13.1",options:{disabled:null,label:null,icon:!0,classes:{"ui-checkboxradio-label":"ui-corner-all","ui-checkboxradio-icon":"ui-corner-all"}},_getCreateOptions:function(){var i,t,s=this,o=this._super()||{};return this._readType(),t=this.element.labels(),this.label=e(t[t.length-1]),this.label.length||e.error("No label found for checkboxradio widget"),this.originalLabel="",this.label.contents().not(this.element[0]).each((function(){s.originalLabel+=3===this.nodeType?e(this).text():this.outerHTML})),this.originalLabel&&(o.label=this.originalLabel),null!=(i=this.element[0].disabled)&&(o.disabled=i),o},_create:function(){var e=this.element[0].checked;this._bindFormResetHandler(),null==this.options.disabled&&(this.options.disabled=this.element[0].disabled),this._setOption("disabled",this.options.disabled),this._addClass("ui-checkboxradio","ui-helper-hidden-accessible"),this._addClass(this.label,"ui-checkboxradio-label","ui-button ui-widget"),"radio"===this.type&&this._addClass(this.label,"ui-checkboxradio-radio-label"),this.options.label&&this.options.label!==this.originalLabel?this._updateLabel():this.originalLabel&&(this.options.label=this.originalLabel),this._enhance(),e&&this._addClass(this.label,"ui-checkboxradio-checked","ui-state-active"),this._on({change:"_toggleClasses",focus:function(){this._addClass(this.label,null,"ui-state-focus ui-visual-focus")},blur:function(){this._removeClass(this.label,null,"ui-state-focus ui-visual-focus")}})},_readType:function(){var i=this.element[0].nodeName.toLowerCase();this.type=this.element[0].type,"input"===i&&/radio|checkbox/.test(this.type)||e.error("Can't create checkboxradio on element.nodeName="+i+" and element.type="+this.type)},_enhance:function(){this._updateIcon(this.element[0].checked)},widget:function(){return this.label},_getRadioGroup:function(){var i=this.element[0].name,t="input[name='"+e.escapeSelector(i)+"']";return i?(this.form.length?e(this.form[0].elements).filter(t):e(t).filter((function(){return 0===e(this)._form().length}))).not(this.element):e([])},_toggleClasses:function(){var i=this.element[0].checked;this._toggleClass(this.label,"ui-checkboxradio-checked","ui-state-active",i),this.options.icon&&"checkbox"===this.type&&this._toggleClass(this.icon,null,"ui-icon-check ui-state-checked",i)._toggleClass(this.icon,null,"ui-icon-blank",!i),"radio"===this.type&&this._getRadioGroup().each((function(){var i=e(this).checkboxradio("instance");i&&i._removeClass(i.label,"ui-checkboxradio-checked","ui-state-active")}))},_destroy:function(){this._unbindFormResetHandler(),this.icon&&(this.icon.remove(),this.iconSpace.remove())},_setOption:function(e,i){if("label"!==e||i){if(this._super(e,i),"disabled"===e)return this._toggleClass(this.label,null,"ui-state-disabled",i),void(this.element[0].disabled=i);this.refresh()}},_updateIcon:function(i){var t="ui-icon ui-icon-background ";this.options.icon?(this.icon||(this.icon=e("<span>"),this.iconSpace=e("<span> </span>"),this._addClass(this.iconSpace,"ui-checkboxradio-icon-space")),"checkbox"===this.type?(t+=i?"ui-icon-check ui-state-checked":"ui-icon-blank",this._removeClass(this.icon,null,i?"ui-icon-blank":"ui-icon-check")):t+="ui-icon-blank",this._addClass(this.icon,"ui-checkboxradio-icon",t),i||this._removeClass(this.icon,null,"ui-icon-check ui-state-checked"),this.icon.prependTo(this.label).after(this.iconSpace)):void 0!==this.icon&&(this.icon.remove(),this.iconSpace.remove(),delete this.icon)},_updateLabel:function(){var e=this.label.contents().not(this.element[0]);this.icon&&(e=e.not(this.icon[0])),this.iconSpace&&(e=e.not(this.iconSpace[0])),e.remove(),this.label.append(this.options.label)},refresh:function(){var e=this.element[0].checked,i=this.element[0].disabled;this._updateIcon(e),this._toggleClass(this.label,"ui-checkboxradio-checked","ui-state-active",e),null!==this.options.label&&this._updateLabel(),i!==this.options.disabled&&this._setOptions({disabled:i})}}]),e.ui.checkboxradio}));

/*!
 * jQuery UI Resizable 1.13.1
 * http://jqueryui.com
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 */
!function(t){"use strict";"function"==typeof define&&define.amd?define(["jquery","./mouse","../disable-selection","../plugin","../version","../widget"],t):t(jQuery)}((function(t){"use strict";return t.widget("ui.resizable",t.ui.mouse,{version:"1.13.1",widgetEventPrefix:"resize",options:{alsoResize:!1,animate:!1,animateDuration:"slow",animateEasing:"swing",aspectRatio:!1,autoHide:!1,classes:{"ui-resizable-se":"ui-icon ui-icon-gripsmall-diagonal-se"},containment:!1,ghost:!1,grid:!1,handles:"e,s,se",helper:!1,maxHeight:null,maxWidth:null,minHeight:10,minWidth:10,zIndex:90,resize:null,start:null,stop:null},_num:function(t){return parseFloat(t)||0},_isNumber:function(t){return!isNaN(parseFloat(t))},_hasScroll:function(i,e){if("hidden"===t(i).css("overflow"))return!1;var s=e&&"left"===e?"scrollLeft":"scrollTop",h=!1;if(i[s]>0)return!0;try{i[s]=1,h=i[s]>0,i[s]=0}catch(t){}return h},_create:function(){var i,e=this.options,s=this;this._addClass("ui-resizable"),t.extend(this,{_aspectRatio:!!e.aspectRatio,aspectRatio:e.aspectRatio,originalElement:this.element,_proportionallyResizeElements:[],_helper:e.helper||e.ghost||e.animate?e.helper||"ui-resizable-helper":null}),this.element[0].nodeName.match(/^(canvas|textarea|input|select|button|img)$/i)&&(this.element.wrap(t("<div class='ui-wrapper'></div>").css({overflow:"hidden",position:this.element.css("position"),width:this.element.outerWidth(),height:this.element.outerHeight(),top:this.element.css("top"),left:this.element.css("left")})),this.element=this.element.parent().data("ui-resizable",this.element.resizable("instance")),this.elementIsWrapper=!0,i={marginTop:this.originalElement.css("marginTop"),marginRight:this.originalElement.css("marginRight"),marginBottom:this.originalElement.css("marginBottom"),marginLeft:this.originalElement.css("marginLeft")},this.element.css(i),this.originalElement.css("margin",0),this.originalResizeStyle=this.originalElement.css("resize"),this.originalElement.css("resize","none"),this._proportionallyResizeElements.push(this.originalElement.css({position:"static",zoom:1,display:"block"})),this.originalElement.css(i),this._proportionallyResize()),this._setupHandles(),e.autoHide&&t(this.element).on("mouseenter",(function(){e.disabled||(s._removeClass("ui-resizable-autohide"),s._handles.show())})).on("mouseleave",(function(){e.disabled||s.resizing||(s._addClass("ui-resizable-autohide"),s._handles.hide())})),this._mouseInit()},_destroy:function(){this._mouseDestroy(),this._addedHandles.remove();var i,e=function(i){t(i).removeData("resizable").removeData("ui-resizable").off(".resizable")};return this.elementIsWrapper&&(e(this.element),i=this.element,this.originalElement.css({position:i.css("position"),width:i.outerWidth(),height:i.outerHeight(),top:i.css("top"),left:i.css("left")}).insertAfter(i),i.remove()),this.originalElement.css("resize",this.originalResizeStyle),e(this.originalElement),this},_setOption:function(t,i){switch(this._super(t,i),t){case"handles":this._removeHandles(),this._setupHandles();break;case"aspectRatio":this._aspectRatio=!!i}},_setupHandles:function(){var i,e,s,h,n,o=this.options,a=this;if(this.handles=o.handles||(t(".ui-resizable-handle",this.element).length?{n:".ui-resizable-n",e:".ui-resizable-e",s:".ui-resizable-s",w:".ui-resizable-w",se:".ui-resizable-se",sw:".ui-resizable-sw",ne:".ui-resizable-ne",nw:".ui-resizable-nw"}:"e,s,se"),this._handles=t(),this._addedHandles=t(),this.handles.constructor===String)for("all"===this.handles&&(this.handles="n,e,s,w,se,sw,ne,nw"),s=this.handles.split(","),this.handles={},e=0;e<s.length;e++)h="ui-resizable-"+(i=String.prototype.trim.call(s[e])),n=t("<div>"),this._addClass(n,"ui-resizable-handle "+h),n.css({zIndex:o.zIndex}),this.handles[i]=".ui-resizable-"+i,this.element.children(this.handles[i]).length||(this.element.append(n),this._addedHandles=this._addedHandles.add(n));this._renderAxis=function(i){var e,s,h,n;for(e in i=i||this.element,this.handles)this.handles[e].constructor===String?this.handles[e]=this.element.children(this.handles[e]).first().show():(this.handles[e].jquery||this.handles[e].nodeType)&&(this.handles[e]=t(this.handles[e]),this._on(this.handles[e],{mousedown:a._mouseDown})),this.elementIsWrapper&&this.originalElement[0].nodeName.match(/^(textarea|input|select|button)$/i)&&(s=t(this.handles[e],this.element),n=/sw|ne|nw|se|n|s/.test(e)?s.outerHeight():s.outerWidth(),h=["padding",/ne|nw|n/.test(e)?"Top":/se|sw|s/.test(e)?"Bottom":/^e$/.test(e)?"Right":"Left"].join(""),i.css(h,n),this._proportionallyResize()),this._handles=this._handles.add(this.handles[e])},this._renderAxis(this.element),this._handles=this._handles.add(this.element.find(".ui-resizable-handle")),this._handles.disableSelection(),this._handles.on("mouseover",(function(){a.resizing||(this.className&&(n=this.className.match(/ui-resizable-(se|sw|ne|nw|n|e|s|w)/i)),a.axis=n&&n[1]?n[1]:"se")})),o.autoHide&&(this._handles.hide(),this._addClass("ui-resizable-autohide"))},_removeHandles:function(){this._addedHandles.remove()},_mouseCapture:function(i){var e,s,h=!1;for(e in this.handles)((s=t(this.handles[e])[0])===i.target||t.contains(s,i.target))&&(h=!0);return!this.options.disabled&&h},_mouseStart:function(i){var e,s,h,n=this.options,o=this.element;return this.resizing=!0,this._renderProxy(),e=this._num(this.helper.css("left")),s=this._num(this.helper.css("top")),n.containment&&(e+=t(n.containment).scrollLeft()||0,s+=t(n.containment).scrollTop()||0),this.offset=this.helper.offset(),this.position={left:e,top:s},this.size=this._helper?{width:this.helper.width(),height:this.helper.height()}:{width:o.width(),height:o.height()},this.originalSize=this._helper?{width:o.outerWidth(),height:o.outerHeight()}:{width:o.width(),height:o.height()},this.sizeDiff={width:o.outerWidth()-o.width(),height:o.outerHeight()-o.height()},this.originalPosition={left:e,top:s},this.originalMousePosition={left:i.pageX,top:i.pageY},this.aspectRatio="number"==typeof n.aspectRatio?n.aspectRatio:this.originalSize.width/this.originalSize.height||1,h=t(".ui-resizable-"+this.axis).css("cursor"),t("body").css("cursor","auto"===h?this.axis+"-resize":h),this._addClass("ui-resizable-resizing"),this._propagate("start",i),!0},_mouseDrag:function(i){var e,s,h=this.originalMousePosition,n=this.axis,o=i.pageX-h.left||0,a=i.pageY-h.top||0,l=this._change[n];return this._updatePrevProperties(),!!l&&(e=l.apply(this,[i,o,a]),this._updateVirtualBoundaries(i.shiftKey),(this._aspectRatio||i.shiftKey)&&(e=this._updateRatio(e,i)),e=this._respectSize(e,i),this._updateCache(e),this._propagate("resize",i),s=this._applyChanges(),!this._helper&&this._proportionallyResizeElements.length&&this._proportionallyResize(),t.isEmptyObject(s)||(this._updatePrevProperties(),this._trigger("resize",i,this.ui()),this._applyChanges()),!1)},_mouseStop:function(i){this.resizing=!1;var e,s,h,n,o,a,l,r=this.options,p=this;return this._helper&&(h=(s=(e=this._proportionallyResizeElements).length&&/textarea/i.test(e[0].nodeName))&&this._hasScroll(e[0],"left")?0:p.sizeDiff.height,n=s?0:p.sizeDiff.width,o={width:p.helper.width()-n,height:p.helper.height()-h},a=parseFloat(p.element.css("left"))+(p.position.left-p.originalPosition.left)||null,l=parseFloat(p.element.css("top"))+(p.position.top-p.originalPosition.top)||null,r.animate||this.element.css(t.extend(o,{top:l,left:a})),p.helper.height(p.size.height),p.helper.width(p.size.width),this._helper&&!r.animate&&this._proportionallyResize()),t("body").css("cursor","auto"),this._removeClass("ui-resizable-resizing"),this._propagate("stop",i),this._helper&&this.helper.remove(),!1},_updatePrevProperties:function(){this.prevPosition={top:this.position.top,left:this.position.left},this.prevSize={width:this.size.width,height:this.size.height}},_applyChanges:function(){var t={};return this.position.top!==this.prevPosition.top&&(t.top=this.position.top+"px"),this.position.left!==this.prevPosition.left&&(t.left=this.position.left+"px"),this.size.width!==this.prevSize.width&&(t.width=this.size.width+"px"),this.size.height!==this.prevSize.height&&(t.height=this.size.height+"px"),this.helper.css(t),t},_updateVirtualBoundaries:function(t){var i,e,s,h,n,o=this.options;n={minWidth:this._isNumber(o.minWidth)?o.minWidth:0,maxWidth:this._isNumber(o.maxWidth)?o.maxWidth:1/0,minHeight:this._isNumber(o.minHeight)?o.minHeight:0,maxHeight:this._isNumber(o.maxHeight)?o.maxHeight:1/0},(this._aspectRatio||t)&&(i=n.minHeight*this.aspectRatio,s=n.minWidth/this.aspectRatio,e=n.maxHeight*this.aspectRatio,h=n.maxWidth/this.aspectRatio,i>n.minWidth&&(n.minWidth=i),s>n.minHeight&&(n.minHeight=s),e<n.maxWidth&&(n.maxWidth=e),h<n.maxHeight&&(n.maxHeight=h)),this._vBoundaries=n},_updateCache:function(t){this.offset=this.helper.offset(),this._isNumber(t.left)&&(this.position.left=t.left),this._isNumber(t.top)&&(this.position.top=t.top),this._isNumber(t.height)&&(this.size.height=t.height),this._isNumber(t.width)&&(this.size.width=t.width)},_updateRatio:function(t){var i=this.position,e=this.size,s=this.axis;return this._isNumber(t.height)?t.width=t.height*this.aspectRatio:this._isNumber(t.width)&&(t.height=t.width/this.aspectRatio),"sw"===s&&(t.left=i.left+(e.width-t.width),t.top=null),"nw"===s&&(t.top=i.top+(e.height-t.height),t.left=i.left+(e.width-t.width)),t},_respectSize:function(t){var i=this._vBoundaries,e=this.axis,s=this._isNumber(t.width)&&i.maxWidth&&i.maxWidth<t.width,h=this._isNumber(t.height)&&i.maxHeight&&i.maxHeight<t.height,n=this._isNumber(t.width)&&i.minWidth&&i.minWidth>t.width,o=this._isNumber(t.height)&&i.minHeight&&i.minHeight>t.height,a=this.originalPosition.left+this.originalSize.width,l=this.originalPosition.top+this.originalSize.height,r=/sw|nw|w/.test(e),p=/nw|ne|n/.test(e);return n&&(t.width=i.minWidth),o&&(t.height=i.minHeight),s&&(t.width=i.maxWidth),h&&(t.height=i.maxHeight),n&&r&&(t.left=a-i.minWidth),s&&r&&(t.left=a-i.maxWidth),o&&p&&(t.top=l-i.minHeight),h&&p&&(t.top=l-i.maxHeight),t.width||t.height||t.left||!t.top?t.width||t.height||t.top||!t.left||(t.left=null):t.top=null,t},_getPaddingPlusBorderDimensions:function(t){for(var i=0,e=[],s=[t.css("borderTopWidth"),t.css("borderRightWidth"),t.css("borderBottomWidth"),t.css("borderLeftWidth")],h=[t.css("paddingTop"),t.css("paddingRight"),t.css("paddingBottom"),t.css("paddingLeft")];i<4;i++)e[i]=parseFloat(s[i])||0,e[i]+=parseFloat(h[i])||0;return{height:e[0]+e[2],width:e[1]+e[3]}},_proportionallyResize:function(){if(this._proportionallyResizeElements.length)for(var t,i=0,e=this.helper||this.element;i<this._proportionallyResizeElements.length;i++)t=this._proportionallyResizeElements[i],this.outerDimensions||(this.outerDimensions=this._getPaddingPlusBorderDimensions(t)),t.css({height:e.height()-this.outerDimensions.height||0,width:e.width()-this.outerDimensions.width||0})},_renderProxy:function(){var i=this.element,e=this.options;this.elementOffset=i.offset(),this._helper?(this.helper=this.helper||t("<div></div>").css({overflow:"hidden"}),this._addClass(this.helper,this._helper),this.helper.css({width:this.element.outerWidth(),height:this.element.outerHeight(),position:"absolute",left:this.elementOffset.left+"px",top:this.elementOffset.top+"px",zIndex:++e.zIndex}),this.helper.appendTo("body").disableSelection()):this.helper=this.element},_change:{e:function(t,i){return{width:this.originalSize.width+i}},w:function(t,i){var e=this.originalSize;return{left:this.originalPosition.left+i,width:e.width-i}},n:function(t,i,e){var s=this.originalSize;return{top:this.originalPosition.top+e,height:s.height-e}},s:function(t,i,e){return{height:this.originalSize.height+e}},se:function(i,e,s){return t.extend(this._change.s.apply(this,arguments),this._change.e.apply(this,[i,e,s]))},sw:function(i,e,s){return t.extend(this._change.s.apply(this,arguments),this._change.w.apply(this,[i,e,s]))},ne:function(i,e,s){return t.extend(this._change.n.apply(this,arguments),this._change.e.apply(this,[i,e,s]))},nw:function(i,e,s){return t.extend(this._change.n.apply(this,arguments),this._change.w.apply(this,[i,e,s]))}},_propagate:function(i,e){t.ui.plugin.call(this,i,[e,this.ui()]),"resize"!==i&&this._trigger(i,e,this.ui())},plugins:{},ui:function(){return{originalElement:this.originalElement,element:this.element,helper:this.helper,position:this.position,size:this.size,originalSize:this.originalSize,originalPosition:this.originalPosition}}}),t.ui.plugin.add("resizable","animate",{stop:function(i){var e=t(this).resizable("instance"),s=e.options,h=e._proportionallyResizeElements,n=h.length&&/textarea/i.test(h[0].nodeName),o=n&&e._hasScroll(h[0],"left")?0:e.sizeDiff.height,a=n?0:e.sizeDiff.width,l={width:e.size.width-a,height:e.size.height-o},r=parseFloat(e.element.css("left"))+(e.position.left-e.originalPosition.left)||null,p=parseFloat(e.element.css("top"))+(e.position.top-e.originalPosition.top)||null;e.element.animate(t.extend(l,p&&r?{top:p,left:r}:{}),{duration:s.animateDuration,easing:s.animateEasing,step:function(){var s={width:parseFloat(e.element.css("width")),height:parseFloat(e.element.css("height")),top:parseFloat(e.element.css("top")),left:parseFloat(e.element.css("left"))};h&&h.length&&t(h[0]).css({width:s.width,height:s.height}),e._updateCache(s),e._propagate("resize",i)}})}}),t.ui.plugin.add("resizable","containment",{start:function(){var i,e,s,h,n,o,a,l=t(this).resizable("instance"),r=l.options,p=l.element,d=r.containment,g=d instanceof t?d.get(0):/parent/.test(d)?p.parent().get(0):d;g&&(l.containerElement=t(g),/document/.test(d)||d===document?(l.containerOffset={left:0,top:0},l.containerPosition={left:0,top:0},l.parentData={element:t(document),left:0,top:0,width:t(document).width(),height:t(document).height()||document.body.parentNode.scrollHeight}):(i=t(g),e=[],t(["Top","Right","Left","Bottom"]).each((function(t,s){e[t]=l._num(i.css("padding"+s))})),l.containerOffset=i.offset(),l.containerPosition=i.position(),l.containerSize={height:i.innerHeight()-e[3],width:i.innerWidth()-e[1]},s=l.containerOffset,h=l.containerSize.height,n=l.containerSize.width,o=l._hasScroll(g,"left")?g.scrollWidth:n,a=l._hasScroll(g)?g.scrollHeight:h,l.parentData={element:g,left:s.left,top:s.top,width:o,height:a}))},resize:function(i){var e,s,h,n,o=t(this).resizable("instance"),a=o.options,l=o.containerOffset,r=o.position,p=o._aspectRatio||i.shiftKey,d={top:0,left:0},g=o.containerElement,u=!0;g[0]!==document&&/static/.test(g.css("position"))&&(d=l),r.left<(o._helper?l.left:0)&&(o.size.width=o.size.width+(o._helper?o.position.left-l.left:o.position.left-d.left),p&&(o.size.height=o.size.width/o.aspectRatio,u=!1),o.position.left=a.helper?l.left:0),r.top<(o._helper?l.top:0)&&(o.size.height=o.size.height+(o._helper?o.position.top-l.top:o.position.top),p&&(o.size.width=o.size.height*o.aspectRatio,u=!1),o.position.top=o._helper?l.top:0),h=o.containerElement.get(0)===o.element.parent().get(0),n=/relative|absolute/.test(o.containerElement.css("position")),h&&n?(o.offset.left=o.parentData.left+o.position.left,o.offset.top=o.parentData.top+o.position.top):(o.offset.left=o.element.offset().left,o.offset.top=o.element.offset().top),e=Math.abs(o.sizeDiff.width+(o._helper?o.offset.left-d.left:o.offset.left-l.left)),s=Math.abs(o.sizeDiff.height+(o._helper?o.offset.top-d.top:o.offset.top-l.top)),e+o.size.width>=o.parentData.width&&(o.size.width=o.parentData.width-e,p&&(o.size.height=o.size.width/o.aspectRatio,u=!1)),s+o.size.height>=o.parentData.height&&(o.size.height=o.parentData.height-s,p&&(o.size.width=o.size.height*o.aspectRatio,u=!1)),u||(o.position.left=o.prevPosition.left,o.position.top=o.prevPosition.top,o.size.width=o.prevSize.width,o.size.height=o.prevSize.height)},stop:function(){var i=t(this).resizable("instance"),e=i.options,s=i.containerOffset,h=i.containerPosition,n=i.containerElement,o=t(i.helper),a=o.offset(),l=o.outerWidth()-i.sizeDiff.width,r=o.outerHeight()-i.sizeDiff.height;i._helper&&!e.animate&&/relative/.test(n.css("position"))&&t(this).css({left:a.left-h.left-s.left,width:l,height:r}),i._helper&&!e.animate&&/static/.test(n.css("position"))&&t(this).css({left:a.left-h.left-s.left,width:l,height:r})}}),t.ui.plugin.add("resizable","alsoResize",{start:function(){var i=t(this).resizable("instance").options;t(i.alsoResize).each((function(){var i=t(this);i.data("ui-resizable-alsoresize",{width:parseFloat(i.width()),height:parseFloat(i.height()),left:parseFloat(i.css("left")),top:parseFloat(i.css("top"))})}))},resize:function(i,e){var s=t(this).resizable("instance"),h=s.options,n=s.originalSize,o=s.originalPosition,a={height:s.size.height-n.height||0,width:s.size.width-n.width||0,top:s.position.top-o.top||0,left:s.position.left-o.left||0};t(h.alsoResize).each((function(){var i=t(this),s=t(this).data("ui-resizable-alsoresize"),h={},n=i.parents(e.originalElement[0]).length?["width","height"]:["width","height","top","left"];t.each(n,(function(t,i){var e=(s[i]||0)+(a[i]||0);e&&e>=0&&(h[i]=e||null)})),i.css(h)}))},stop:function(){t(this).removeData("ui-resizable-alsoresize")}}),t.ui.plugin.add("resizable","ghost",{start:function(){var i=t(this).resizable("instance"),e=i.size;i.ghost=i.originalElement.clone(),i.ghost.css({opacity:.25,display:"block",position:"relative",height:e.height,width:e.width,margin:0,left:0,top:0}),i._addClass(i.ghost,"ui-resizable-ghost"),!1!==t.uiBackCompat&&"string"==typeof i.options.ghost&&i.ghost.addClass(this.options.ghost),i.ghost.appendTo(i.helper)},resize:function(){var i=t(this).resizable("instance");i.ghost&&i.ghost.css({position:"relative",height:i.size.height,width:i.size.width})},stop:function(){var i=t(this).resizable("instance");i.ghost&&i.helper&&i.helper.get(0).removeChild(i.ghost.get(0))}}),t.ui.plugin.add("resizable","grid",{resize:function(){var i,e=t(this).resizable("instance"),s=e.options,h=e.size,n=e.originalSize,o=e.originalPosition,a=e.axis,l="number"==typeof s.grid?[s.grid,s.grid]:s.grid,r=l[0]||1,p=l[1]||1,d=Math.round((h.width-n.width)/r)*r,g=Math.round((h.height-n.height)/p)*p,u=n.width+d,c=n.height+g,f=s.maxWidth&&s.maxWidth<u,m=s.maxHeight&&s.maxHeight<c,z=s.minWidth&&s.minWidth>u,w=s.minHeight&&s.minHeight>c;s.grid=l,z&&(u+=r),w&&(c+=p),f&&(u-=r),m&&(c-=p),/^(se|s|e)$/.test(a)?(e.size.width=u,e.size.height=c):/^(ne)$/.test(a)?(e.size.width=u,e.size.height=c,e.position.top=o.top-g):/^(sw)$/.test(a)?(e.size.width=u,e.size.height=c,e.position.left=o.left-d):((c-p<=0||u-r<=0)&&(i=e._getPaddingPlusBorderDimensions(this)),c-p>0?(e.size.height=c,e.position.top=o.top-g):(c=p-i.height,e.size.height=c,e.position.top=o.top+n.height-c),u-r>0?(e.size.width=u,e.position.left=o.left-d):(u=r-i.width,e.size.width=u,e.position.left=o.left+n.width-u))}}),t.ui.resizable}));

/*!
 * jQuery UI Button 1.13.1
 * http://jqueryui.com
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 */
!function(t){"use strict";"function"==typeof define&&define.amd?define(["jquery","./controlgroup","./checkboxradio","../keycode","../widget"],t):t(jQuery)}((function(t){"use strict";var i;return t.widget("ui.button",{version:"1.13.1",defaultElement:"<button>",options:{classes:{"ui-button":"ui-corner-all"},disabled:null,icon:null,iconPosition:"beginning",label:null,showLabel:!0},_getCreateOptions:function(){var t,i=this._super()||{};return this.isInput=this.element.is("input"),null!=(t=this.element[0].disabled)&&(i.disabled=t),this.originalLabel=this.isInput?this.element.val():this.element.html(),this.originalLabel&&(i.label=this.originalLabel),i},_create:function(){!this.option.showLabel&!this.options.icon&&(this.options.showLabel=!0),null==this.options.disabled&&(this.options.disabled=this.element[0].disabled||!1),this.hasTitle=!!this.element.attr("title"),this.options.label&&this.options.label!==this.originalLabel&&(this.isInput?this.element.val(this.options.label):this.element.html(this.options.label)),this._addClass("ui-button","ui-widget"),this._setOption("disabled",this.options.disabled),this._enhance(),this.element.is("a")&&this._on({keyup:function(i){i.keyCode===t.ui.keyCode.SPACE&&(i.preventDefault(),this.element[0].click?this.element[0].click():this.element.trigger("click"))}})},_enhance:function(){this.element.is("button")||this.element.attr("role","button"),this.options.icon&&(this._updateIcon("icon",this.options.icon),this._updateTooltip())},_updateTooltip:function(){this.title=this.element.attr("title"),this.options.showLabel||this.title||this.element.attr("title",this.options.label)},_updateIcon:function(i,o){var s="iconPosition"!==i,n=s?this.options.iconPosition:o,e="top"===n||"bottom"===n;this.icon?s&&this._removeClass(this.icon,null,this.options.icon):(this.icon=t("<span>"),this._addClass(this.icon,"ui-button-icon","ui-icon"),this.options.showLabel||this._addClass("ui-button-icon-only")),s&&this._addClass(this.icon,null,o),this._attachIcon(n),e?(this._addClass(this.icon,null,"ui-widget-icon-block"),this.iconSpace&&this.iconSpace.remove()):(this.iconSpace||(this.iconSpace=t("<span> </span>"),this._addClass(this.iconSpace,"ui-button-icon-space")),this._removeClass(this.icon,null,"ui-wiget-icon-block"),this._attachIconSpace(n))},_destroy:function(){this.element.removeAttr("role"),this.icon&&this.icon.remove(),this.iconSpace&&this.iconSpace.remove(),this.hasTitle||this.element.removeAttr("title")},_attachIconSpace:function(t){this.icon[/^(?:end|bottom)/.test(t)?"before":"after"](this.iconSpace)},_attachIcon:function(t){this.element[/^(?:end|bottom)/.test(t)?"append":"prepend"](this.icon)},_setOptions:function(t){var i=void 0===t.showLabel?this.options.showLabel:t.showLabel,o=void 0===t.icon?this.options.icon:t.icon;i||o||(t.showLabel=!0),this._super(t)},_setOption:function(t,i){"icon"===t&&(i?this._updateIcon(t,i):this.icon&&(this.icon.remove(),this.iconSpace&&this.iconSpace.remove())),"iconPosition"===t&&this._updateIcon(t,i),"showLabel"===t&&(this._toggleClass("ui-button-icon-only",null,!i),this._updateTooltip()),"label"===t&&(this.isInput?this.element.val(i):(this.element.html(i),this.icon&&(this._attachIcon(this.options.iconPosition),this._attachIconSpace(this.options.iconPosition)))),this._super(t,i),"disabled"===t&&(this._toggleClass(null,"ui-state-disabled",i),this.element[0].disabled=i,i&&this.element.trigger("blur"))},refresh:function(){var t=this.element.is("input, button")?this.element[0].disabled:this.element.hasClass("ui-button-disabled");t!==this.options.disabled&&this._setOptions({disabled:t}),this._updateTooltip()}}),!1!==t.uiBackCompat&&(t.widget("ui.button",t.ui.button,{options:{text:!0,icons:{primary:null,secondary:null}},_create:function(){this.options.showLabel&&!this.options.text&&(this.options.showLabel=this.options.text),!this.options.showLabel&&this.options.text&&(this.options.text=this.options.showLabel),this.options.icon||!this.options.icons.primary&&!this.options.icons.secondary?this.options.icon&&(this.options.icons.primary=this.options.icon):this.options.icons.primary?this.options.icon=this.options.icons.primary:(this.options.icon=this.options.icons.secondary,this.options.iconPosition="end"),this._super()},_setOption:function(t,i){"text"!==t?("showLabel"===t&&(this.options.text=i),"icon"===t&&(this.options.icons.primary=i),"icons"===t&&(i.primary?(this._super("icon",i.primary),this._super("iconPosition","beginning")):i.secondary&&(this._super("icon",i.secondary),this._super("iconPosition","end"))),this._superApply(arguments)):this._super("showLabel",i)}}),t.fn.button=(i=t.fn.button,function(o){var s="string"==typeof o,n=Array.prototype.slice.call(arguments,1),e=this;return s?this.length||"instance"!==o?this.each((function(){var i,s=t(this).attr("type"),h="checkbox"!==s&&"radio"!==s?"button":"checkboxradio",a=t.data(this,"ui-"+h);return"instance"===o?(e=a,!1):a?"function"!=typeof a[o]||"_"===o.charAt(0)?t.error("no such method '"+o+"' for button widget instance"):(i=a[o].apply(a,n))!==a&&void 0!==i?(e=i&&i.jquery?e.pushStack(i.get()):i,!1):void 0:t.error("cannot call methods on button prior to initialization; attempted to call method '"+o+"'")})):e=void 0:(n.length&&(o=t.widget.extend.apply(null,[o].concat(n))),this.each((function(){var s=t(this).attr("type"),n="checkbox"!==s&&"radio"!==s?"button":"checkboxradio",e=t.data(this,"ui-"+n);if(e)e.option(o||{}),e._init&&e._init();else{if("button"===n)return void i.call(t(this),o);t(this).checkboxradio(t.extend({icon:!1},o))}}))),e}),t.fn.buttonset=function(){return t.ui.controlgroup||t.error("Controlgroup widget missing"),"option"===arguments[0]&&"items"===arguments[1]&&arguments[2]?this.controlgroup.apply(this,[arguments[0],"items.button",arguments[2]]):"option"===arguments[0]&&"items"===arguments[1]?this.controlgroup.apply(this,[arguments[0],"items.button"]):("object"==typeof arguments[0]&&arguments[0].items&&(arguments[0].items={button:arguments[0].items}),this.controlgroup.apply(this,arguments))}),t.ui.button}));

/*!
 * jQuery UI Dialog 1.13.1
 * http://jqueryui.com
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 */
!function(i){"use strict";"function"==typeof define&&define.amd?define(["jquery","./button","./draggable","./mouse","./resizable","../focusable","../keycode","../position","../safe-active-element","../safe-blur","../tabbable","../unique-id","../version","../widget"],i):i(jQuery)}((function(i){"use strict";return i.widget("ui.dialog",{version:"1.13.1",options:{appendTo:"body",autoOpen:!0,buttons:[],classes:{"ui-dialog":"ui-corner-all","ui-dialog-titlebar":"ui-corner-all"},closeOnEscape:!0,closeText:"Close",draggable:!0,hide:null,height:"auto",maxHeight:null,maxWidth:null,minHeight:150,minWidth:150,modal:!1,position:{my:"center",at:"center",of:window,collision:"fit",using:function(t){var e=i(this).css(t).offset().top;e<0&&i(this).css("top",t.top-e)}},resizable:!0,show:null,title:null,width:300,beforeClose:null,close:null,drag:null,dragStart:null,dragStop:null,focus:null,open:null,resize:null,resizeStart:null,resizeStop:null},sizeRelatedOptions:{buttons:!0,height:!0,maxHeight:!0,maxWidth:!0,minHeight:!0,minWidth:!0,width:!0},resizableRelatedOptions:{maxHeight:!0,maxWidth:!0,minHeight:!0,minWidth:!0},_create:function(){this.originalCss={display:this.element[0].style.display,width:this.element[0].style.width,minHeight:this.element[0].style.minHeight,maxHeight:this.element[0].style.maxHeight,height:this.element[0].style.height},this.originalPosition={parent:this.element.parent(),index:this.element.parent().children().index(this.element)},this.originalTitle=this.element.attr("title"),null==this.options.title&&null!=this.originalTitle&&(this.options.title=this.originalTitle),this.options.disabled&&(this.options.disabled=!1),this._createWrapper(),this.element.show().removeAttr("title").appendTo(this.uiDialog),this._addClass("ui-dialog-content","ui-widget-content"),this._createTitlebar(),this._createButtonPane(),this.options.draggable&&i.fn.draggable&&this._makeDraggable(),this.options.resizable&&i.fn.resizable&&this._makeResizable(),this._isOpen=!1,this._trackFocus()},_init:function(){this.options.autoOpen&&this.open()},_appendTo:function(){var t=this.options.appendTo;return t&&(t.jquery||t.nodeType)?i(t):this.document.find(t||"body").eq(0)},_destroy:function(){var i,t=this.originalPosition;this._untrackInstance(),this._destroyOverlay(),this.element.removeUniqueId().css(this.originalCss).detach(),this.uiDialog.remove(),this.originalTitle&&this.element.attr("title",this.originalTitle),(i=t.parent.children().eq(t.index)).length&&i[0]!==this.element[0]?i.before(this.element):t.parent.append(this.element)},widget:function(){return this.uiDialog},disable:i.noop,enable:i.noop,close:function(t){var e=this;this._isOpen&&!1!==this._trigger("beforeClose",t)&&(this._isOpen=!1,this._focusedElement=null,this._destroyOverlay(),this._untrackInstance(),this.opener.filter(":focusable").trigger("focus").length||i.ui.safeBlur(i.ui.safeActiveElement(this.document[0])),this._hide(this.uiDialog,this.options.hide,(function(){e._trigger("close",t)})))},isOpen:function(){return this._isOpen},moveToTop:function(){this._moveToTop()},_moveToTop:function(t,e){var o=!1,s=this.uiDialog.siblings(".ui-front:visible").map((function(){return+i(this).css("z-index")})).get(),n=Math.max.apply(null,s);return n>=+this.uiDialog.css("z-index")&&(this.uiDialog.css("z-index",n+1),o=!0),o&&!e&&this._trigger("focus",t),o},open:function(){var t=this;this._isOpen?this._moveToTop()&&this._focusTabbable():(this._isOpen=!0,this.opener=i(i.ui.safeActiveElement(this.document[0])),this._size(),this._position(),this._createOverlay(),this._moveToTop(null,!0),this.overlay&&this.overlay.css("z-index",this.uiDialog.css("z-index")-1),this._show(this.uiDialog,this.options.show,(function(){t._focusTabbable(),t._trigger("focus")})),this._makeFocusTarget(),this._trigger("open"))},_focusTabbable:function(){var i=this._focusedElement;i||(i=this.element.find("[autofocus]")),i.length||(i=this.element.find(":tabbable")),i.length||(i=this.uiDialogButtonPane.find(":tabbable")),i.length||(i=this.uiDialogTitlebarClose.filter(":tabbable")),i.length||(i=this.uiDialog),i.eq(0).trigger("focus")},_restoreTabbableFocus:function(){var t=i.ui.safeActiveElement(this.document[0]);this.uiDialog[0]===t||i.contains(this.uiDialog[0],t)||this._focusTabbable()},_keepFocus:function(i){i.preventDefault(),this._restoreTabbableFocus(),this._delay(this._restoreTabbableFocus)},_createWrapper:function(){this.uiDialog=i("<div>").hide().attr({tabIndex:-1,role:"dialog"}).appendTo(this._appendTo()),this._addClass(this.uiDialog,"ui-dialog","ui-widget ui-widget-content ui-front"),this._on(this.uiDialog,{keydown:function(t){if(this.options.closeOnEscape&&!t.isDefaultPrevented()&&t.keyCode&&t.keyCode===i.ui.keyCode.ESCAPE)return t.preventDefault(),void this.close(t);if(t.keyCode===i.ui.keyCode.TAB&&!t.isDefaultPrevented()){var e=this.uiDialog.find(":tabbable"),o=e.first(),s=e.last();t.target!==s[0]&&t.target!==this.uiDialog[0]||t.shiftKey?t.target!==o[0]&&t.target!==this.uiDialog[0]||!t.shiftKey||(this._delay((function(){s.trigger("focus")})),t.preventDefault()):(this._delay((function(){o.trigger("focus")})),t.preventDefault())}},mousedown:function(i){this._moveToTop(i)&&this._focusTabbable()}}),this.element.find("[aria-describedby]").length||this.uiDialog.attr({"aria-describedby":this.element.uniqueId().attr("id")})},_createTitlebar:function(){var t;this.uiDialogTitlebar=i("<div>"),this._addClass(this.uiDialogTitlebar,"ui-dialog-titlebar","ui-widget-header ui-helper-clearfix"),this._on(this.uiDialogTitlebar,{mousedown:function(t){i(t.target).closest(".ui-dialog-titlebar-close")||this.uiDialog.trigger("focus")}}),this.uiDialogTitlebarClose=i("<button type='button'></button>").button({label:i("<a>").text(this.options.closeText).html(),icon:"ui-icon-closethick",showLabel:!1}).appendTo(this.uiDialogTitlebar),this._addClass(this.uiDialogTitlebarClose,"ui-dialog-titlebar-close"),this._on(this.uiDialogTitlebarClose,{click:function(i){i.preventDefault(),this.close(i)}}),t=i("<span>").uniqueId().prependTo(this.uiDialogTitlebar),this._addClass(t,"ui-dialog-title"),this._title(t),this.uiDialogTitlebar.prependTo(this.uiDialog),this.uiDialog.attr({"aria-labelledby":t.attr("id")})},_title:function(i){this.options.title?i.text(this.options.title):i.html("&#160;")},_createButtonPane:function(){this.uiDialogButtonPane=i("<div>"),this._addClass(this.uiDialogButtonPane,"ui-dialog-buttonpane","ui-widget-content ui-helper-clearfix"),this.uiButtonSet=i("<div>").appendTo(this.uiDialogButtonPane),this._addClass(this.uiButtonSet,"ui-dialog-buttonset"),this._createButtons()},_createButtons:function(){var t=this,e=this.options.buttons;this.uiDialogButtonPane.remove(),this.uiButtonSet.empty(),i.isEmptyObject(e)||Array.isArray(e)&&!e.length?this._removeClass(this.uiDialog,"ui-dialog-buttons"):(i.each(e,(function(e,o){var s,n;o="function"==typeof o?{click:o,text:e}:o,o=i.extend({type:"button"},o),s=o.click,n={icon:o.icon,iconPosition:o.iconPosition,showLabel:o.showLabel,icons:o.icons,text:o.text},delete o.click,delete o.icon,delete o.iconPosition,delete o.showLabel,delete o.icons,"boolean"==typeof o.text&&delete o.text,i("<button></button>",o).button(n).appendTo(t.uiButtonSet).on("click",(function(){s.apply(t.element[0],arguments)}))})),this._addClass(this.uiDialog,"ui-dialog-buttons"),this.uiDialogButtonPane.appendTo(this.uiDialog))},_makeDraggable:function(){var t=this,e=this.options;function o(i){return{position:i.position,offset:i.offset}}this.uiDialog.draggable({cancel:".ui-dialog-content, .ui-dialog-titlebar-close",handle:".ui-dialog-titlebar",containment:"document",start:function(e,s){t._addClass(i(this),"ui-dialog-dragging"),t._blockFrames(),t._trigger("dragStart",e,o(s))},drag:function(i,e){t._trigger("drag",i,o(e))},stop:function(s,n){var a=n.offset.left-t.document.scrollLeft(),l=n.offset.top-t.document.scrollTop();e.position={my:"left top",at:"left"+(a>=0?"+":"")+a+" top"+(l>=0?"+":"")+l,of:t.window},t._removeClass(i(this),"ui-dialog-dragging"),t._unblockFrames(),t._trigger("dragStop",s,o(n))}})},_makeResizable:function(){var t=this,e=this.options,o=e.resizable,s=this.uiDialog.css("position"),n="string"==typeof o?o:"n,e,s,w,se,sw,ne,nw";function a(i){return{originalPosition:i.originalPosition,originalSize:i.originalSize,position:i.position,size:i.size}}this.uiDialog.resizable({cancel:".ui-dialog-content",containment:"document",alsoResize:this.element,maxWidth:e.maxWidth,maxHeight:e.maxHeight,minWidth:e.minWidth,minHeight:this._minHeight(),handles:n,start:function(e,o){t._addClass(i(this),"ui-dialog-resizing"),t._blockFrames(),t._trigger("resizeStart",e,a(o))},resize:function(i,e){t._trigger("resize",i,a(e))},stop:function(o,s){var n=t.uiDialog.offset(),l=n.left-t.document.scrollLeft(),h=n.top-t.document.scrollTop();e.height=t.uiDialog.height(),e.width=t.uiDialog.width(),e.position={my:"left top",at:"left"+(l>=0?"+":"")+l+" top"+(h>=0?"+":"")+h,of:t.window},t._removeClass(i(this),"ui-dialog-resizing"),t._unblockFrames(),t._trigger("resizeStop",o,a(s))}}).css("position",s)},_trackFocus:function(){this._on(this.widget(),{focusin:function(t){this._makeFocusTarget(),this._focusedElement=i(t.target)}})},_makeFocusTarget:function(){this._untrackInstance(),this._trackingInstances().unshift(this)},_untrackInstance:function(){var t=this._trackingInstances(),e=i.inArray(this,t);-1!==e&&t.splice(e,1)},_trackingInstances:function(){var i=this.document.data("ui-dialog-instances");return i||(i=[],this.document.data("ui-dialog-instances",i)),i},_minHeight:function(){var i=this.options;return"auto"===i.height?i.minHeight:Math.min(i.minHeight,i.height)},_position:function(){var i=this.uiDialog.is(":visible");i||this.uiDialog.show(),this.uiDialog.position(this.options.position),i||this.uiDialog.hide()},_setOptions:function(t){var e=this,o=!1,s={};i.each(t,(function(i,t){e._setOption(i,t),i in e.sizeRelatedOptions&&(o=!0),i in e.resizableRelatedOptions&&(s[i]=t)})),o&&(this._size(),this._position()),this.uiDialog.is(":data(ui-resizable)")&&this.uiDialog.resizable("option",s)},_setOption:function(t,e){var o,s,n=this.uiDialog;"disabled"!==t&&(this._super(t,e),"appendTo"===t&&this.uiDialog.appendTo(this._appendTo()),"buttons"===t&&this._createButtons(),"closeText"===t&&this.uiDialogTitlebarClose.button({label:i("<a>").text(""+this.options.closeText).html()}),"draggable"===t&&((o=n.is(":data(ui-draggable)"))&&!e&&n.draggable("destroy"),!o&&e&&this._makeDraggable()),"position"===t&&this._position(),"resizable"===t&&((s=n.is(":data(ui-resizable)"))&&!e&&n.resizable("destroy"),s&&"string"==typeof e&&n.resizable("option","handles",e),s||!1===e||this._makeResizable()),"title"===t&&this._title(this.uiDialogTitlebar.find(".ui-dialog-title")))},_size:function(){var i,t,e,o=this.options;this.element.show().css({width:"auto",minHeight:0,maxHeight:"none",height:0}),o.minWidth>o.width&&(o.width=o.minWidth),i=this.uiDialog.css({height:"auto",width:o.width}).outerHeight(),t=Math.max(0,o.minHeight-i),e="number"==typeof o.maxHeight?Math.max(0,o.maxHeight-i):"none","auto"===o.height?this.element.css({minHeight:t,maxHeight:e,height:"auto"}):this.element.height(Math.max(0,o.height-i)),this.uiDialog.is(":data(ui-resizable)")&&this.uiDialog.resizable("option","minHeight",this._minHeight())},_blockFrames:function(){this.iframeBlocks=this.document.find("iframe").map((function(){var t=i(this);return i("<div>").css({position:"absolute",width:t.outerWidth(),height:t.outerHeight()}).appendTo(t.parent()).offset(t.offset())[0]}))},_unblockFrames:function(){this.iframeBlocks&&(this.iframeBlocks.remove(),delete this.iframeBlocks)},_allowInteraction:function(t){return!!i(t.target).closest(".ui-dialog").length||!!i(t.target).closest(".ui-datepicker").length},_createOverlay:function(){if(this.options.modal){var t=i.fn.jquery.substring(0,4),e=!0;this._delay((function(){e=!1})),this.document.data("ui-dialog-overlays")||this.document.on("focusin.ui-dialog",function(i){if(!e){var o=this._trackingInstances()[0];o._allowInteraction(i)||(i.preventDefault(),o._focusTabbable(),"3.4."!==t&&"3.5."!==t||o._delay(o._restoreTabbableFocus))}}.bind(this)),this.overlay=i("<div>").appendTo(this._appendTo()),this._addClass(this.overlay,null,"ui-widget-overlay ui-front"),this._on(this.overlay,{mousedown:"_keepFocus"}),this.document.data("ui-dialog-overlays",(this.document.data("ui-dialog-overlays")||0)+1)}},_destroyOverlay:function(){if(this.options.modal&&this.overlay){var i=this.document.data("ui-dialog-overlays")-1;i?this.document.data("ui-dialog-overlays",i):(this.document.off("focusin.ui-dialog"),this.document.removeData("ui-dialog-overlays")),this.overlay.remove(),this.overlay=null}}}),!1!==i.uiBackCompat&&i.widget("ui.dialog",i.ui.dialog,{options:{dialogClass:""},_createWrapper:function(){this._super(),this.uiDialog.addClass(this.options.dialogClass)},_setOption:function(i,t){"dialogClass"===i&&this.uiDialog.removeClass(this.options.dialogClass).addClass(t),this._superApply(arguments)}}),i.ui.dialog}));

/*!
* tabbable 5.2.1
* @license MIT, https://github.com/focus-trap/tabbable/blob/master/LICENSE
*/
!function(e,t){"object"==typeof exports&&"undefined"!=typeof module?t(exports):"function"==typeof define&&define.amd?define(["exports"],t):(e="undefined"!=typeof globalThis?globalThis:e||self,function(){var n=e.tabbable,r=e.tabbable={};t(r),r.noConflict=function(){return e.tabbable=n,r}}())}(this,(function(e){"use strict";var t=["input","select","textarea","a[href]","button","[tabindex]","audio[controls]","video[controls]",'[contenteditable]:not([contenteditable="false"])',"details>summary:first-of-type","details"],n=t.join(","),r="undefined"==typeof Element?function(){}:Element.prototype.matches||Element.prototype.msMatchesSelector||Element.prototype.webkitMatchesSelector,o=function(e,t,o){var i=Array.prototype.slice.apply(e.querySelectorAll(n));return t&&r.call(e,n)&&i.unshift(e),i=i.filter(o)},i=function(e){var t=parseInt(e.getAttribute("tabindex"),10);return isNaN(t)?function(e){return"true"===e.contentEditable}(e)?0:"AUDIO"!==e.nodeName&&"VIDEO"!==e.nodeName&&"DETAILS"!==e.nodeName||null!==e.getAttribute("tabindex")?e.tabIndex:0:t},a=function(e,t){return e.tabIndex===t.tabIndex?e.documentOrder-t.documentOrder:e.tabIndex-t.tabIndex},u=function(e){return"INPUT"===e.tagName},l=function(e){return function(e){return u(e)&&"radio"===e.type}(e)&&!function(e){if(!e.name)return!0;var t,n=e.form||e.ownerDocument,r=function(e){return n.querySelectorAll('input[type="radio"][name="'+e+'"]')};if("undefined"!=typeof window&&void 0!==window.CSS&&"function"==typeof window.CSS.escape)t=r(window.CSS.escape(e.name));else try{t=r(e.name)}catch(e){return console.error("Looks like you have a radio button with a name attribute containing invalid CSS selector characters and need the CSS.escape polyfill: %s",e.message),!1}var o=function(e,t){for(var n=0;n<e.length;n++)if(e[n].checked&&e[n].form===t)return e[n]}(t,e.form);return!o||o===e}(e)},c=function(e,t){return!(t.disabled||function(e){return u(e)&&"hidden"===e.type}(t)||function(e,t){if("hidden"===getComputedStyle(e).visibility)return!0;var n=r.call(e,"details>summary:first-of-type")?e.parentElement:e;if(r.call(n,"details:not([open]) *"))return!0;if(t&&"full"!==t){if("non-zero-area"===t){var o=e.getBoundingClientRect(),i=o.width,a=o.height;return 0===i&&0===a}}else for(;e;){if("none"===getComputedStyle(e).display)return!0;e=e.parentElement}return!1}(t,e.displayCheck)||function(e){return"DETAILS"===e.tagName&&Array.prototype.slice.apply(e.children).some((function(e){return"SUMMARY"===e.tagName}))}(t)||function(e){if(u(e)||"SELECT"===e.tagName||"TEXTAREA"===e.tagName||"BUTTON"===e.tagName)for(var t=e.parentElement;t;){if("FIELDSET"===t.tagName&&t.disabled){for(var n=0;n<t.children.length;n++){var r=t.children.item(n);if("LEGEND"===r.tagName)return!r.contains(e)}return!0}t=t.parentElement}return!1}(t))},d=function(e,t){return!(!c(e,t)||l(t)||i(t)<0)},f=t.concat("iframe").join(",");e.focusable=function(e,t){return o(e,(t=t||{}).includeContainer,c.bind(null,t))},e.isFocusable=function(e,t){if(t=t||{},!e)throw new Error("No node provided");return!1!==r.call(e,f)&&c(t,e)},e.isTabbable=function(e,t){if(t=t||{},!e)throw new Error("No node provided");return!1!==r.call(e,n)&&d(t,e)},e.tabbable=function(e,t){var n=[],r=[];return o(e,(t=t||{}).includeContainer,d.bind(null,t)).forEach((function(e,t){var o=i(e);0===o?n.push(e):r.push({documentOrder:t,tabIndex:o,node:e})})),r.sort(a).map((function(e){return e.node})).concat(n)},Object.defineProperty(e,"__esModule",{value:!0})}));

;
/*! DataTables 1.12.1
 * ©2008-2022 SpryMedia Ltd - datatables.net/license
 */

/**
 * @summary     DataTables
 * @description Paginate, search and order HTML tables
 * @version     1.12.1
 * @author      SpryMedia Ltd
 * @contact     www.datatables.net
 * @copyright   SpryMedia Ltd.
 *
 * This source file is free software, available under the following license:
 *   MIT license - http://datatables.net/license
 *
 * This source file is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the license files for details.
 *
 * For details please refer to: http://www.datatables.net
 */

/*jslint evil: true, undef: true, browser: true */
/*globals $,require,jQuery,define,_selector_run,_selector_opts,_selector_first,_selector_row_indexes,_ext,_Api,_api_register,_api_registerPlural,_re_new_lines,_re_html,_re_formatted_numeric,_re_escape_regex,_empty,_intVal,_numToDecimal,_isNumber,_isHtml,_htmlNumeric,_pluck,_pluck_order,_range,_stripHtml,_unique,_fnBuildAjax,_fnAjaxUpdate,_fnAjaxParameters,_fnAjaxUpdateDraw,_fnAjaxDataSrc,_fnAddColumn,_fnColumnOptions,_fnAdjustColumnSizing,_fnVisibleToColumnIndex,_fnColumnIndexToVisible,_fnVisbleColumns,_fnGetColumns,_fnColumnTypes,_fnApplyColumnDefs,_fnHungarianMap,_fnCamelToHungarian,_fnLanguageCompat,_fnBrowserDetect,_fnAddData,_fnAddTr,_fnNodeToDataIndex,_fnNodeToColumnIndex,_fnGetCellData,_fnSetCellData,_fnSplitObjNotation,_fnGetObjectDataFn,_fnSetObjectDataFn,_fnGetDataMaster,_fnClearTable,_fnDeleteIndex,_fnInvalidate,_fnGetRowElements,_fnCreateTr,_fnBuildHead,_fnDrawHead,_fnDraw,_fnReDraw,_fnAddOptionsHtml,_fnDetectHeader,_fnGetUniqueThs,_fnFeatureHtmlFilter,_fnFilterComplete,_fnFilterCustom,_fnFilterColumn,_fnFilter,_fnFilterCreateSearch,_fnEscapeRegex,_fnFilterData,_fnFeatureHtmlInfo,_fnUpdateInfo,_fnInfoMacros,_fnInitialise,_fnInitComplete,_fnLengthChange,_fnFeatureHtmlLength,_fnFeatureHtmlPaginate,_fnPageChange,_fnFeatureHtmlProcessing,_fnProcessingDisplay,_fnFeatureHtmlTable,_fnScrollDraw,_fnApplyToChildren,_fnCalculateColumnWidths,_fnThrottle,_fnConvertToWidth,_fnGetWidestNode,_fnGetMaxLenString,_fnStringToCss,_fnSortFlatten,_fnSort,_fnSortAria,_fnSortListener,_fnSortAttachListener,_fnSortingClasses,_fnSortData,_fnSaveState,_fnLoadState,_fnSettingsFromNode,_fnLog,_fnMap,_fnBindAction,_fnCallbackReg,_fnCallbackFire,_fnLengthOverflow,_fnRenderer,_fnDataSource,_fnRowAttributes*/

(function( factory ) {
  "use strict";

  if ( typeof define === 'function' && define.amd ) {
    // AMD
    define( ['jquery'], function ( $ ) {
      return factory( $, window, document );
    } );
  }
  else if ( typeof exports === 'object' ) {
    // CommonJS
    module.exports = function (root, $) {
      if ( ! root ) {
        // CommonJS environments without a window global must pass a
        // root. This will give an error otherwise
        root = window;
      }

      if ( ! $ ) {
        $ = typeof window !== 'undefined' ? // jQuery's factory checks for a global window
          require('jquery') :
          require('jquery')( root );
      }

      return factory( $, root, root.document );
    };
  }
  else {
    // Browser
    window.DataTable = factory( jQuery, window, document );
  }
}
(function( $, window, document, undefined ) {
  "use strict";


  var DataTable = function ( selector, options )
  {
    // When creating with `new`, create a new DataTable, returning the API instance
    if (this instanceof DataTable) {
      return $(selector).DataTable(options);
    }
    else {
      // Argument switching
      options = selector;
    }

    /**
     * Perform a jQuery selector action on the table's TR elements (from the tbody) and
     * return the resulting jQuery object.
     *  @param {string|node|jQuery} sSelector jQuery selector or node collection to act on
     *  @param {object} [oOpts] Optional parameters for modifying the rows to be included
     *  @param {string} [oOpts.filter=none] Select TR elements that meet the current filter
     *    criterion ("applied") or all TR elements (i.e. no filter).
     *  @param {string} [oOpts.order=current] Order of the TR elements in the processed array.
     *    Can be either 'current', whereby the current sorting of the table is used, or
     *    'original' whereby the original order the data was read into the table is used.
     *  @param {string} [oOpts.page=all] Limit the selection to the currently displayed page
     *    ("current") or not ("all"). If 'current' is given, then order is assumed to be
     *    'current' and filter is 'applied', regardless of what they might be given as.
     *  @returns {object} jQuery object, filtered by the given selector.
     *  @dtopt API
     *  @deprecated Since v1.10
     *
     *  @example
     *    $(document).ready(function() {
     *      var oTable = $('#example').dataTable();
     *
     *      // Highlight every second row
     *      oTable.$('tr:odd').css('backgroundColor', 'blue');
     *    } );
     *
     *  @example
     *    $(document).ready(function() {
     *      var oTable = $('#example').dataTable();
     *
     *      // Filter to rows with 'Webkit' in them, add a background colour and then
     *      // remove the filter, thus highlighting the 'Webkit' rows only.
     *      oTable.fnFilter('Webkit');
     *      oTable.$('tr', {"search": "applied"}).css('backgroundColor', 'blue');
     *      oTable.fnFilter('');
     *    } );
     */
    this.$ = function ( sSelector, oOpts )
    {
      return this.api(true).$( sSelector, oOpts );
    };


    /**
     * Almost identical to $ in operation, but in this case returns the data for the matched
     * rows - as such, the jQuery selector used should match TR row nodes or TD/TH cell nodes
     * rather than any descendants, so the data can be obtained for the row/cell. If matching
     * rows are found, the data returned is the original data array/object that was used to
     * create the row (or a generated array if from a DOM source).
     *
     * This method is often useful in-combination with $ where both functions are given the
     * same parameters and the array indexes will match identically.
     *  @param {string|node|jQuery} sSelector jQuery selector or node collection to act on
     *  @param {object} [oOpts] Optional parameters for modifying the rows to be included
     *  @param {string} [oOpts.filter=none] Select elements that meet the current filter
     *    criterion ("applied") or all elements (i.e. no filter).
     *  @param {string} [oOpts.order=current] Order of the data in the processed array.
     *    Can be either 'current', whereby the current sorting of the table is used, or
     *    'original' whereby the original order the data was read into the table is used.
     *  @param {string} [oOpts.page=all] Limit the selection to the currently displayed page
     *    ("current") or not ("all"). If 'current' is given, then order is assumed to be
     *    'current' and filter is 'applied', regardless of what they might be given as.
     *  @returns {array} Data for the matched elements. If any elements, as a result of the
     *    selector, were not TR, TD or TH elements in the DataTable, they will have a null
     *    entry in the array.
     *  @dtopt API
     *  @deprecated Since v1.10
     *
     *  @example
     *    $(document).ready(function() {
     *      var oTable = $('#example').dataTable();
     *
     *      // Get the data from the first row in the table
     *      var data = oTable._('tr:first');
     *
     *      // Do something useful with the data
     *      alert( "First cell is: "+data[0] );
     *    } );
     *
     *  @example
     *    $(document).ready(function() {
     *      var oTable = $('#example').dataTable();
     *
     *      // Filter to 'Webkit' and get all data for
     *      oTable.fnFilter('Webkit');
     *      var data = oTable._('tr', {"search": "applied"});
     *
     *      // Do something with the data
     *      alert( data.length+" rows matched the search" );
     *    } );
     */
    this._ = function ( sSelector, oOpts )
    {
      return this.api(true).rows( sSelector, oOpts ).data();
    };


    /**
     * Create a DataTables Api instance, with the currently selected tables for
     * the Api's context.
     * @param {boolean} [traditional=false] Set the API instance's context to be
     *   only the table referred to by the `DataTable.ext.iApiIndex` option, as was
     *   used in the API presented by DataTables 1.9- (i.e. the traditional mode),
     *   or if all tables captured in the jQuery object should be used.
     * @return {DataTables.Api}
     */
    this.api = function ( traditional )
    {
      return traditional ?
        new _Api(
          _fnSettingsFromNode( this[ _ext.iApiIndex ] )
        ) :
        new _Api( this );
    };


    /**
     * Add a single new row or multiple rows of data to the table. Please note
     * that this is suitable for client-side processing only - if you are using
     * server-side processing (i.e. "bServerSide": true), then to add data, you
     * must add it to the data source, i.e. the server-side, through an Ajax call.
     *  @param {array|object} data The data to be added to the table. This can be:
     *    <ul>
     *      <li>1D array of data - add a single row with the data provided</li>
     *      <li>2D array of arrays - add multiple rows in a single call</li>
     *      <li>object - data object when using <i>mData</i></li>
     *      <li>array of objects - multiple data objects when using <i>mData</i></li>
     *    </ul>
     *  @param {bool} [redraw=true] redraw the table or not
     *  @returns {array} An array of integers, representing the list of indexes in
     *    <i>aoData</i> ({@link DataTable.models.oSettings}) that have been added to
     *    the table.
     *  @dtopt API
     *  @deprecated Since v1.10
     *
     *  @example
     *    // Global var for counter
     *    var giCount = 2;
     *
     *    $(document).ready(function() {
     *      $('#example').dataTable();
     *    } );
     *
     *    function fnClickAddRow() {
     *      $('#example').dataTable().fnAddData( [
     *        giCount+".1",
     *        giCount+".2",
     *        giCount+".3",
     *        giCount+".4" ]
     *      );
     *
     *      giCount++;
     *    }
     */
    this.fnAddData = function( data, redraw )
    {
      var api = this.api( true );

      /* Check if we want to add multiple rows or not */
      var rows = Array.isArray(data) && ( Array.isArray(data[0]) || $.isPlainObject(data[0]) ) ?
        api.rows.add( data ) :
        api.row.add( data );

      if ( redraw === undefined || redraw ) {
        api.draw();
      }

      return rows.flatten().toArray();
    };


    /**
     * This function will make DataTables recalculate the column sizes, based on the data
     * contained in the table and the sizes applied to the columns (in the DOM, CSS or
     * through the sWidth parameter). This can be useful when the width of the table's
     * parent element changes (for example a window resize).
     *  @param {boolean} [bRedraw=true] Redraw the table or not, you will typically want to
     *  @dtopt API
     *  @deprecated Since v1.10
     *
     *  @example
     *    $(document).ready(function() {
     *      var oTable = $('#example').dataTable( {
     *        "sScrollY": "200px",
     *        "bPaginate": false
     *      } );
     *
     *      $(window).on('resize', function () {
     *        oTable.fnAdjustColumnSizing();
     *      } );
     *    } );
     */
    this.fnAdjustColumnSizing = function ( bRedraw )
    {
      var api = this.api( true ).columns.adjust();
      var settings = api.settings()[0];
      var scroll = settings.oScroll;

      if ( bRedraw === undefined || bRedraw ) {
        api.draw( false );
      }
      else if ( scroll.sX !== "" || scroll.sY !== "" ) {
        /* If not redrawing, but scrolling, we want to apply the new column sizes anyway */
        _fnScrollDraw( settings );
      }
    };


    /**
     * Quickly and simply clear a table
     *  @param {bool} [bRedraw=true] redraw the table or not
     *  @dtopt API
     *  @deprecated Since v1.10
     *
     *  @example
     *    $(document).ready(function() {
     *      var oTable = $('#example').dataTable();
     *
     *      // Immediately 'nuke' the current rows (perhaps waiting for an Ajax callback...)
     *      oTable.fnClearTable();
     *    } );
     */
    this.fnClearTable = function( bRedraw )
    {
      var api = this.api( true ).clear();

      if ( bRedraw === undefined || bRedraw ) {
        api.draw();
      }
    };


    /**
     * The exact opposite of 'opening' a row, this function will close any rows which
     * are currently 'open'.
     *  @param {node} nTr the table row to 'close'
     *  @returns {int} 0 on success, or 1 if failed (can't find the row)
     *  @dtopt API
     *  @deprecated Since v1.10
     *
     *  @example
     *    $(document).ready(function() {
     *      var oTable;
     *
     *      // 'open' an information row when a row is clicked on
     *      $('#example tbody tr').click( function () {
     *        if ( oTable.fnIsOpen(this) ) {
     *          oTable.fnClose( this );
     *        } else {
     *          oTable.fnOpen( this, "Temporary row opened", "info_row" );
     *        }
     *      } );
     *
     *      oTable = $('#example').dataTable();
     *    } );
     */
    this.fnClose = function( nTr )
    {
      this.api( true ).row( nTr ).child.hide();
    };


    /**
     * Remove a row for the table
     *  @param {mixed} target The index of the row from aoData to be deleted, or
     *    the TR element you want to delete
     *  @param {function|null} [callBack] Callback function
     *  @param {bool} [redraw=true] Redraw the table or not
     *  @returns {array} The row that was deleted
     *  @dtopt API
     *  @deprecated Since v1.10
     *
     *  @example
     *    $(document).ready(function() {
     *      var oTable = $('#example').dataTable();
     *
     *      // Immediately remove the first row
     *      oTable.fnDeleteRow( 0 );
     *    } );
     */
    this.fnDeleteRow = function( target, callback, redraw )
    {
      var api = this.api( true );
      var rows = api.rows( target );
      var settings = rows.settings()[0];
      var data = settings.aoData[ rows[0][0] ];

      rows.remove();

      if ( callback ) {
        callback.call( this, settings, data );
      }

      if ( redraw === undefined || redraw ) {
        api.draw();
      }

      return data;
    };


    /**
     * Restore the table to it's original state in the DOM by removing all of DataTables
     * enhancements, alterations to the DOM structure of the table and event listeners.
     *  @param {boolean} [remove=false] Completely remove the table from the DOM
     *  @dtopt API
     *  @deprecated Since v1.10
     *
     *  @example
     *    $(document).ready(function() {
     *      // This example is fairly pointless in reality, but shows how fnDestroy can be used
     *      var oTable = $('#example').dataTable();
     *      oTable.fnDestroy();
     *    } );
     */
    this.fnDestroy = function ( remove )
    {
      this.api( true ).destroy( remove );
    };


    /**
     * Redraw the table
     *  @param {bool} [complete=true] Re-filter and resort (if enabled) the table before the draw.
     *  @dtopt API
     *  @deprecated Since v1.10
     *
     *  @example
     *    $(document).ready(function() {
     *      var oTable = $('#example').dataTable();
     *
     *      // Re-draw the table - you wouldn't want to do it here, but it's an example :-)
     *      oTable.fnDraw();
     *    } );
     */
    this.fnDraw = function( complete )
    {
      // Note that this isn't an exact match to the old call to _fnDraw - it takes
      // into account the new data, but can hold position.
      this.api( true ).draw( complete );
    };


    /**
     * Filter the input based on data
     *  @param {string} sInput String to filter the table on
     *  @param {int|null} [iColumn] Column to limit filtering to
     *  @param {bool} [bRegex=false] Treat as regular expression or not
     *  @param {bool} [bSmart=true] Perform smart filtering or not
     *  @param {bool} [bShowGlobal=true] Show the input global filter in it's input box(es)
     *  @param {bool} [bCaseInsensitive=true] Do case-insensitive matching (true) or not (false)
     *  @dtopt API
     *  @deprecated Since v1.10
     *
     *  @example
     *    $(document).ready(function() {
     *      var oTable = $('#example').dataTable();
     *
     *      // Sometime later - filter...
     *      oTable.fnFilter( 'test string' );
     *    } );
     */
    this.fnFilter = function( sInput, iColumn, bRegex, bSmart, bShowGlobal, bCaseInsensitive )
    {
      var api = this.api( true );

      if ( iColumn === null || iColumn === undefined ) {
        api.search( sInput, bRegex, bSmart, bCaseInsensitive );
      }
      else {
        api.column( iColumn ).search( sInput, bRegex, bSmart, bCaseInsensitive );
      }

      api.draw();
    };


    /**
     * Get the data for the whole table, an individual row or an individual cell based on the
     * provided parameters.
     *  @param {int|node} [src] A TR row node, TD/TH cell node or an integer. If given as
     *    a TR node then the data source for the whole row will be returned. If given as a
     *    TD/TH cell node then iCol will be automatically calculated and the data for the
     *    cell returned. If given as an integer, then this is treated as the aoData internal
     *    data index for the row (see fnGetPosition) and the data for that row used.
     *  @param {int} [col] Optional column index that you want the data of.
     *  @returns {array|object|string} If mRow is undefined, then the data for all rows is
     *    returned. If mRow is defined, just data for that row, and is iCol is
     *    defined, only data for the designated cell is returned.
     *  @dtopt API
     *  @deprecated Since v1.10
     *
     *  @example
     *    // Row data
     *    $(document).ready(function() {
     *      oTable = $('#example').dataTable();
     *
     *      oTable.$('tr').click( function () {
     *        var data = oTable.fnGetData( this );
     *        // ... do something with the array / object of data for the row
     *      } );
     *    } );
     *
     *  @example
     *    // Individual cell data
     *    $(document).ready(function() {
     *      oTable = $('#example').dataTable();
     *
     *      oTable.$('td').click( function () {
     *        var sData = oTable.fnGetData( this );
     *        alert( 'The cell clicked on had the value of '+sData );
     *      } );
     *    } );
     */
    this.fnGetData = function( src, col )
    {
      var api = this.api( true );

      if ( src !== undefined ) {
        var type = src.nodeName ? src.nodeName.toLowerCase() : '';

        return col !== undefined || type == 'td' || type == 'th' ?
          api.cell( src, col ).data() :
          api.row( src ).data() || null;
      }

      return api.data().toArray();
    };


    /**
     * Get an array of the TR nodes that are used in the table's body. Note that you will
     * typically want to use the '$' API method in preference to this as it is more
     * flexible.
     *  @param {int} [iRow] Optional row index for the TR element you want
     *  @returns {array|node} If iRow is undefined, returns an array of all TR elements
     *    in the table's body, or iRow is defined, just the TR element requested.
     *  @dtopt API
     *  @deprecated Since v1.10
     *
     *  @example
     *    $(document).ready(function() {
     *      var oTable = $('#example').dataTable();
     *
     *      // Get the nodes from the table
     *      var nNodes = oTable.fnGetNodes( );
     *    } );
     */
    this.fnGetNodes = function( iRow )
    {
      var api = this.api( true );

      return iRow !== undefined ?
        api.row( iRow ).node() :
        api.rows().nodes().flatten().toArray();
    };


    /**
     * Get the array indexes of a particular cell from it's DOM element
     * and column index including hidden columns
     *  @param {node} node this can either be a TR, TD or TH in the table's body
     *  @returns {int} If nNode is given as a TR, then a single index is returned, or
     *    if given as a cell, an array of [row index, column index (visible),
     *    column index (all)] is given.
     *  @dtopt API
     *  @deprecated Since v1.10
     *
     *  @example
     *    $(document).ready(function() {
     *      $('#example tbody td').click( function () {
     *        // Get the position of the current data from the node
     *        var aPos = oTable.fnGetPosition( this );
     *
     *        // Get the data array for this row
     *        var aData = oTable.fnGetData( aPos[0] );
     *
     *        // Update the data array and return the value
     *        aData[ aPos[1] ] = 'clicked';
     *        this.innerHTML = 'clicked';
     *      } );
     *
     *      // Init DataTables
     *      oTable = $('#example').dataTable();
     *    } );
     */
    this.fnGetPosition = function( node )
    {
      var api = this.api( true );
      var nodeName = node.nodeName.toUpperCase();

      if ( nodeName == 'TR' ) {
        return api.row( node ).index();
      }
      else if ( nodeName == 'TD' || nodeName == 'TH' ) {
        var cell = api.cell( node ).index();

        return [
          cell.row,
          cell.columnVisible,
          cell.column
        ];
      }
      return null;
    };


    /**
     * Check to see if a row is 'open' or not.
     *  @param {node} nTr the table row to check
     *  @returns {boolean} true if the row is currently open, false otherwise
     *  @dtopt API
     *  @deprecated Since v1.10
     *
     *  @example
     *    $(document).ready(function() {
     *      var oTable;
     *
     *      // 'open' an information row when a row is clicked on
     *      $('#example tbody tr').click( function () {
     *        if ( oTable.fnIsOpen(this) ) {
     *          oTable.fnClose( this );
     *        } else {
     *          oTable.fnOpen( this, "Temporary row opened", "info_row" );
     *        }
     *      } );
     *
     *      oTable = $('#example').dataTable();
     *    } );
     */
    this.fnIsOpen = function( nTr )
    {
      return this.api( true ).row( nTr ).child.isShown();
    };


    /**
     * This function will place a new row directly after a row which is currently
     * on display on the page, with the HTML contents that is passed into the
     * function. This can be used, for example, to ask for confirmation that a
     * particular record should be deleted.
     *  @param {node} nTr The table row to 'open'
     *  @param {string|node|jQuery} mHtml The HTML to put into the row
     *  @param {string} sClass Class to give the new TD cell
     *  @returns {node} The row opened. Note that if the table row passed in as the
     *    first parameter, is not found in the table, this method will silently
     *    return.
     *  @dtopt API
     *  @deprecated Since v1.10
     *
     *  @example
     *    $(document).ready(function() {
     *      var oTable;
     *
     *      // 'open' an information row when a row is clicked on
     *      $('#example tbody tr').click( function () {
     *        if ( oTable.fnIsOpen(this) ) {
     *          oTable.fnClose( this );
     *        } else {
     *          oTable.fnOpen( this, "Temporary row opened", "info_row" );
     *        }
     *      } );
     *
     *      oTable = $('#example').dataTable();
     *    } );
     */
    this.fnOpen = function( nTr, mHtml, sClass )
    {
      return this.api( true )
        .row( nTr )
        .child( mHtml, sClass )
        .show()
        .child()[0];
    };


    /**
     * Change the pagination - provides the internal logic for pagination in a simple API
     * function. With this function you can have a DataTables table go to the next,
     * previous, first or last pages.
     *  @param {string|int} mAction Paging action to take: "first", "previous", "next" or "last"
     *    or page number to jump to (integer), note that page 0 is the first page.
     *  @param {bool} [bRedraw=true] Redraw the table or not
     *  @dtopt API
     *  @deprecated Since v1.10
     *
     *  @example
     *    $(document).ready(function() {
     *      var oTable = $('#example').dataTable();
     *      oTable.fnPageChange( 'next' );
     *    } );
     */
    this.fnPageChange = function ( mAction, bRedraw )
    {
      var api = this.api( true ).page( mAction );

      if ( bRedraw === undefined || bRedraw ) {
        api.draw(false);
      }
    };


    /**
     * Show a particular column
     *  @param {int} iCol The column whose display should be changed
     *  @param {bool} bShow Show (true) or hide (false) the column
     *  @param {bool} [bRedraw=true] Redraw the table or not
     *  @dtopt API
     *  @deprecated Since v1.10
     *
     *  @example
     *    $(document).ready(function() {
     *      var oTable = $('#example').dataTable();
     *
     *      // Hide the second column after initialisation
     *      oTable.fnSetColumnVis( 1, false );
     *    } );
     */
    this.fnSetColumnVis = function ( iCol, bShow, bRedraw )
    {
      var api = this.api( true ).column( iCol ).visible( bShow );

      if ( bRedraw === undefined || bRedraw ) {
        api.columns.adjust().draw();
      }
    };


    /**
     * Get the settings for a particular table for external manipulation
     *  @returns {object} DataTables settings object. See
     *    {@link DataTable.models.oSettings}
     *  @dtopt API
     *  @deprecated Since v1.10
     *
     *  @example
     *    $(document).ready(function() {
     *      var oTable = $('#example').dataTable();
     *      var oSettings = oTable.fnSettings();
     *
     *      // Show an example parameter from the settings
     *      alert( oSettings._iDisplayStart );
     *    } );
     */
    this.fnSettings = function()
    {
      return _fnSettingsFromNode( this[_ext.iApiIndex] );
    };


    /**
     * Sort the table by a particular column
     *  @param {int} iCol the data index to sort on. Note that this will not match the
     *    'display index' if you have hidden data entries
     *  @dtopt API
     *  @deprecated Since v1.10
     *
     *  @example
     *    $(document).ready(function() {
     *      var oTable = $('#example').dataTable();
     *
     *      // Sort immediately with columns 0 and 1
     *      oTable.fnSort( [ [0,'asc'], [1,'asc'] ] );
     *    } );
     */
    this.fnSort = function( aaSort )
    {
      this.api( true ).order( aaSort ).draw();
    };


    /**
     * Attach a sort listener to an element for a given column
     *  @param {node} nNode the element to attach the sort listener to
     *  @param {int} iColumn the column that a click on this node will sort on
     *  @param {function} [fnCallback] callback function when sort is run
     *  @dtopt API
     *  @deprecated Since v1.10
     *
     *  @example
     *    $(document).ready(function() {
     *      var oTable = $('#example').dataTable();
     *
     *      // Sort on column 1, when 'sorter' is clicked on
     *      oTable.fnSortListener( document.getElementById('sorter'), 1 );
     *    } );
     */
    this.fnSortListener = function( nNode, iColumn, fnCallback )
    {
      this.api( true ).order.listener( nNode, iColumn, fnCallback );
    };


    /**
     * Update a table cell or row - this method will accept either a single value to
     * update the cell with, an array of values with one element for each column or
     * an object in the same format as the original data source. The function is
     * self-referencing in order to make the multi column updates easier.
     *  @param {object|array|string} mData Data to update the cell/row with
     *  @param {node|int} mRow TR element you want to update or the aoData index
     *  @param {int} [iColumn] The column to update, give as null or undefined to
     *    update a whole row.
     *  @param {bool} [bRedraw=true] Redraw the table or not
     *  @param {bool} [bAction=true] Perform pre-draw actions or not
     *  @returns {int} 0 on success, 1 on error
     *  @dtopt API
     *  @deprecated Since v1.10
     *
     *  @example
     *    $(document).ready(function() {
     *      var oTable = $('#example').dataTable();
     *      oTable.fnUpdate( 'Example update', 0, 0 ); // Single cell
     *      oTable.fnUpdate( ['a', 'b', 'c', 'd', 'e'], $('tbody tr')[0] ); // Row
     *    } );
     */
    this.fnUpdate = function( mData, mRow, iColumn, bRedraw, bAction )
    {
      var api = this.api( true );

      if ( iColumn === undefined || iColumn === null ) {
        api.row( mRow ).data( mData );
      }
      else {
        api.cell( mRow, iColumn ).data( mData );
      }

      if ( bAction === undefined || bAction ) {
        api.columns.adjust();
      }

      if ( bRedraw === undefined || bRedraw ) {
        api.draw();
      }
      return 0;
    };


    /**
     * Provide a common method for plug-ins to check the version of DataTables being used, in order
     * to ensure compatibility.
     *  @param {string} sVersion Version string to check for, in the format "X.Y.Z". Note that the
     *    formats "X" and "X.Y" are also acceptable.
     *  @returns {boolean} true if this version of DataTables is greater or equal to the required
     *    version, or false if this version of DataTales is not suitable
     *  @method
     *  @dtopt API
     *  @deprecated Since v1.10
     *
     *  @example
     *    $(document).ready(function() {
     *      var oTable = $('#example').dataTable();
     *      alert( oTable.fnVersionCheck( '1.9.0' ) );
     *    } );
     */
    this.fnVersionCheck = _ext.fnVersionCheck;


    var _that = this;
    var emptyInit = options === undefined;
    var len = this.length;

    if ( emptyInit ) {
      options = {};
    }

    this.oApi = this.internal = _ext.internal;

    // Extend with old style plug-in API methods
    for ( var fn in DataTable.ext.internal ) {
      if ( fn ) {
        this[fn] = _fnExternApiFunc(fn);
      }
    }

    this.each(function() {
      // For each initialisation we want to give it a clean initialisation
      // object that can be bashed around
      var o = {};
      var oInit = len > 1 ? // optimisation for single table case
        _fnExtend( o, options, true ) :
        options;

      /*global oInit,_that,emptyInit*/
      var i=0, iLen, j, jLen, k, kLen;
      var sId = this.getAttribute( 'id' );
      var bInitHandedOff = false;
      var defaults = DataTable.defaults;
      var $this = $(this);


      /* Sanity check */
      if ( this.nodeName.toLowerCase() != 'table' )
      {
        _fnLog( null, 0, 'Non-table node initialisation ('+this.nodeName+')', 2 );
        return;
      }

      /* Backwards compatibility for the defaults */
      _fnCompatOpts( defaults );
      _fnCompatCols( defaults.column );

      /* Convert the camel-case defaults to Hungarian */
      _fnCamelToHungarian( defaults, defaults, true );
      _fnCamelToHungarian( defaults.column, defaults.column, true );

      /* Setting up the initialisation object */
      _fnCamelToHungarian( defaults, $.extend( oInit, $this.data() ), true );



      /* Check to see if we are re-initialising a table */
      var allSettings = DataTable.settings;
      for ( i=0, iLen=allSettings.length ; i<iLen ; i++ )
      {
        var s = allSettings[i];

        /* Base check on table node */
        if (
          s.nTable == this ||
          (s.nTHead && s.nTHead.parentNode == this) ||
          (s.nTFoot && s.nTFoot.parentNode == this)
        ) {
          var bRetrieve = oInit.bRetrieve !== undefined ? oInit.bRetrieve : defaults.bRetrieve;
          var bDestroy = oInit.bDestroy !== undefined ? oInit.bDestroy : defaults.bDestroy;

          if ( emptyInit || bRetrieve )
          {
            return s.oInstance;
          }
          else if ( bDestroy )
          {
            s.oInstance.fnDestroy();
            break;
          }
          else
          {
            _fnLog( s, 0, 'Cannot reinitialise DataTable', 3 );
            return;
          }
        }

        /* If the element we are initialising has the same ID as a table which was previously
				 * initialised, but the table nodes don't match (from before) then we destroy the old
				 * instance by simply deleting it. This is under the assumption that the table has been
				 * destroyed by other methods. Anyone using non-id selectors will need to do this manually
				 */
        if ( s.sTableId == this.id )
        {
          allSettings.splice( i, 1 );
          break;
        }
      }

      /* Ensure the table has an ID - required for accessibility */
      if ( sId === null || sId === "" )
      {
        sId = "DataTables_Table_"+(DataTable.ext._unique++);
        this.id = sId;
      }

      /* Create the settings object for this table and set some of the default parameters */
      var oSettings = $.extend( true, {}, DataTable.models.oSettings, {
        "sDestroyWidth": $this[0].style.width,
        "sInstance":     sId,
        "sTableId":      sId
      } );
      oSettings.nTable = this;
      oSettings.oApi   = _that.internal;
      oSettings.oInit  = oInit;

      allSettings.push( oSettings );

      // Need to add the instance after the instance after the settings object has been added
      // to the settings array, so we can self reference the table instance if more than one
      oSettings.oInstance = (_that.length===1) ? _that : $this.dataTable();

      // Backwards compatibility, before we apply all the defaults
      _fnCompatOpts( oInit );
      _fnLanguageCompat( oInit.oLanguage );

      // If the length menu is given, but the init display length is not, use the length menu
      if ( oInit.aLengthMenu && ! oInit.iDisplayLength )
      {
        oInit.iDisplayLength = Array.isArray( oInit.aLengthMenu[0] ) ?
          oInit.aLengthMenu[0][0] : oInit.aLengthMenu[0];
      }

      // Apply the defaults and init options to make a single init object will all
      // options defined from defaults and instance options.
      oInit = _fnExtend( $.extend( true, {}, defaults ), oInit );


      // Map the initialisation options onto the settings object
      _fnMap( oSettings.oFeatures, oInit, [
        "bPaginate",
        "bLengthChange",
        "bFilter",
        "bSort",
        "bSortMulti",
        "bInfo",
        "bProcessing",
        "bAutoWidth",
        "bSortClasses",
        "bServerSide",
        "bDeferRender"
      ] );
      _fnMap( oSettings, oInit, [
        "asStripeClasses",
        "ajax",
        "fnServerData",
        "fnFormatNumber",
        "sServerMethod",
        "aaSorting",
        "aaSortingFixed",
        "aLengthMenu",
        "sPaginationType",
        "sAjaxSource",
        "sAjaxDataProp",
        "iStateDuration",
        "sDom",
        "bSortCellsTop",
        "iTabIndex",
        "fnStateLoadCallback",
        "fnStateSaveCallback",
        "renderer",
        "searchDelay",
        "rowId",
        [ "iCookieDuration", "iStateDuration" ], // backwards compat
        [ "oSearch", "oPreviousSearch" ],
        [ "aoSearchCols", "aoPreSearchCols" ],
        [ "iDisplayLength", "_iDisplayLength" ]
      ] );
      _fnMap( oSettings.oScroll, oInit, [
        [ "sScrollX", "sX" ],
        [ "sScrollXInner", "sXInner" ],
        [ "sScrollY", "sY" ],
        [ "bScrollCollapse", "bCollapse" ]
      ] );
      _fnMap( oSettings.oLanguage, oInit, "fnInfoCallback" );

      /* Callback functions which are array driven */
      _fnCallbackReg( oSettings, 'aoDrawCallback',       oInit.fnDrawCallback,      'user' );
      _fnCallbackReg( oSettings, 'aoServerParams',       oInit.fnServerParams,      'user' );
      _fnCallbackReg( oSettings, 'aoStateSaveParams',    oInit.fnStateSaveParams,   'user' );
      _fnCallbackReg( oSettings, 'aoStateLoadParams',    oInit.fnStateLoadParams,   'user' );
      _fnCallbackReg( oSettings, 'aoStateLoaded',        oInit.fnStateLoaded,       'user' );
      _fnCallbackReg( oSettings, 'aoRowCallback',        oInit.fnRowCallback,       'user' );
      _fnCallbackReg( oSettings, 'aoRowCreatedCallback', oInit.fnCreatedRow,        'user' );
      _fnCallbackReg( oSettings, 'aoHeaderCallback',     oInit.fnHeaderCallback,    'user' );
      _fnCallbackReg( oSettings, 'aoFooterCallback',     oInit.fnFooterCallback,    'user' );
      _fnCallbackReg( oSettings, 'aoInitComplete',       oInit.fnInitComplete,      'user' );
      _fnCallbackReg( oSettings, 'aoPreDrawCallback',    oInit.fnPreDrawCallback,   'user' );

      oSettings.rowIdFn = _fnGetObjectDataFn( oInit.rowId );

      /* Browser support detection */
      _fnBrowserDetect( oSettings );

      var oClasses = oSettings.oClasses;

      $.extend( oClasses, DataTable.ext.classes, oInit.oClasses );
      $this.addClass( oClasses.sTable );


      if ( oSettings.iInitDisplayStart === undefined )
      {
        /* Display start point, taking into account the save saving */
        oSettings.iInitDisplayStart = oInit.iDisplayStart;
        oSettings._iDisplayStart = oInit.iDisplayStart;
      }

      if ( oInit.iDeferLoading !== null )
      {
        oSettings.bDeferLoading = true;
        var tmp = Array.isArray( oInit.iDeferLoading );
        oSettings._iRecordsDisplay = tmp ? oInit.iDeferLoading[0] : oInit.iDeferLoading;
        oSettings._iRecordsTotal = tmp ? oInit.iDeferLoading[1] : oInit.iDeferLoading;
      }

      /* Language definitions */
      var oLanguage = oSettings.oLanguage;
      $.extend( true, oLanguage, oInit.oLanguage );

      if ( oLanguage.sUrl )
      {
        /* Get the language definitions from a file - because this Ajax call makes the language
				 * get async to the remainder of this function we use bInitHandedOff to indicate that
				 * _fnInitialise will be fired by the returned Ajax handler, rather than the constructor
				 */
        $.ajax( {
          dataType: 'json',
          url: oLanguage.sUrl,
          success: function ( json ) {
            _fnCamelToHungarian( defaults.oLanguage, json );
            _fnLanguageCompat( json );
            $.extend( true, oLanguage, json, oSettings.oInit.oLanguage );

            _fnCallbackFire( oSettings, null, 'i18n', [oSettings]);
            _fnInitialise( oSettings );
          },
          error: function () {
            // Error occurred loading language file, continue on as best we can
            _fnInitialise( oSettings );
          }
        } );
        bInitHandedOff = true;
      }
      else {
        _fnCallbackFire( oSettings, null, 'i18n', [oSettings]);
      }

      /*
			 * Stripes
			 */
      if ( oInit.asStripeClasses === null )
      {
        oSettings.asStripeClasses =[
          oClasses.sStripeOdd,
          oClasses.sStripeEven
        ];
      }

      /* Remove row stripe classes if they are already on the table row */
      var stripeClasses = oSettings.asStripeClasses;
      var rowOne = $this.children('tbody').find('tr').eq(0);
      if ( $.inArray( true, $.map( stripeClasses, function(el, i) {
        return rowOne.hasClass(el);
      } ) ) !== -1 ) {
        $('tbody tr', this).removeClass( stripeClasses.join(' ') );
        oSettings.asDestroyStripes = stripeClasses.slice();
      }

      /*
			 * Columns
			 * See if we should load columns automatically or use defined ones
			 */
      var anThs = [];
      var aoColumnsInit;
      var nThead = this.getElementsByTagName('thead');
      if ( nThead.length !== 0 )
      {
        _fnDetectHeader( oSettings.aoHeader, nThead[0] );
        anThs = _fnGetUniqueThs( oSettings );
      }

      /* If not given a column array, generate one with nulls */
      if ( oInit.aoColumns === null )
      {
        aoColumnsInit = [];
        for ( i=0, iLen=anThs.length ; i<iLen ; i++ )
        {
          aoColumnsInit.push( null );
        }
      }
      else
      {
        aoColumnsInit = oInit.aoColumns;
      }

      /* Add the columns */
      for ( i=0, iLen=aoColumnsInit.length ; i<iLen ; i++ )
      {
        _fnAddColumn( oSettings, anThs ? anThs[i] : null );
      }

      /* Apply the column definitions */
      _fnApplyColumnDefs( oSettings, oInit.aoColumnDefs, aoColumnsInit, function (iCol, oDef) {
        _fnColumnOptions( oSettings, iCol, oDef );
      } );

      /* HTML5 attribute detection - build an mData object automatically if the
			 * attributes are found
			 */
      if ( rowOne.length ) {
        var a = function ( cell, name ) {
          return cell.getAttribute( 'data-'+name ) !== null ? name : null;
        };

        $( rowOne[0] ).children('th, td').each( function (i, cell) {
          var col = oSettings.aoColumns[i];

          if ( col.mData === i ) {
            var sort = a( cell, 'sort' ) || a( cell, 'order' );
            var filter = a( cell, 'filter' ) || a( cell, 'search' );

            if ( sort !== null || filter !== null ) {
              col.mData = {
                _:      i+'.display',
                sort:   sort !== null   ? i+'.@data-'+sort   : undefined,
                type:   sort !== null   ? i+'.@data-'+sort   : undefined,
                filter: filter !== null ? i+'.@data-'+filter : undefined
              };

              _fnColumnOptions( oSettings, i );
            }
          }
        } );
      }

      var features = oSettings.oFeatures;
      var loadedInit = function () {
        /*
				 * Sorting
				 * @todo For modularisation (1.11) this needs to do into a sort start up handler
				 */

        // If aaSorting is not defined, then we use the first indicator in asSorting
        // in case that has been altered, so the default sort reflects that option
        if ( oInit.aaSorting === undefined ) {
          var sorting = oSettings.aaSorting;
          for ( i=0, iLen=sorting.length ; i<iLen ; i++ ) {
            sorting[i][1] = oSettings.aoColumns[ i ].asSorting[0];
          }
        }

        /* Do a first pass on the sorting classes (allows any size changes to be taken into
				 * account, and also will apply sorting disabled classes if disabled
				 */
        _fnSortingClasses( oSettings );

        if ( features.bSort ) {
          _fnCallbackReg( oSettings, 'aoDrawCallback', function () {
            if ( oSettings.bSorted ) {
              var aSort = _fnSortFlatten( oSettings );
              var sortedColumns = {};

              $.each( aSort, function (i, val) {
                sortedColumns[ val.src ] = val.dir;
              } );

              _fnCallbackFire( oSettings, null, 'order', [oSettings, aSort, sortedColumns] );
              _fnSortAria( oSettings );
            }
          } );
        }

        _fnCallbackReg( oSettings, 'aoDrawCallback', function () {
          if ( oSettings.bSorted || _fnDataSource( oSettings ) === 'ssp' || features.bDeferRender ) {
            _fnSortingClasses( oSettings );
          }
        }, 'sc' );


        /*
				 * Final init
				 * Cache the header, body and footer as required, creating them if needed
				 */

        // Work around for Webkit bug 83867 - store the caption-side before removing from doc
        var captions = $this.children('caption').each( function () {
          this._captionSide = $(this).css('caption-side');
        } );

        var thead = $this.children('thead');
        if ( thead.length === 0 ) {
          thead = $('<thead/>').appendTo($this);
        }
        oSettings.nTHead = thead[0];

        var tbody = $this.children('tbody');
        if ( tbody.length === 0 ) {
          tbody = $('<tbody/>').insertAfter(thead);
        }
        oSettings.nTBody = tbody[0];

        var tfoot = $this.children('tfoot');
        if ( tfoot.length === 0 && captions.length > 0 && (oSettings.oScroll.sX !== "" || oSettings.oScroll.sY !== "") ) {
          // If we are a scrolling table, and no footer has been given, then we need to create
          // a tfoot element for the caption element to be appended to
          tfoot = $('<tfoot/>').appendTo($this);
        }

        if ( tfoot.length === 0 || tfoot.children().length === 0 ) {
          $this.addClass( oClasses.sNoFooter );
        }
        else if ( tfoot.length > 0 ) {
          oSettings.nTFoot = tfoot[0];
          _fnDetectHeader( oSettings.aoFooter, oSettings.nTFoot );
        }

        /* Check if there is data passing into the constructor */
        if ( oInit.aaData ) {
          for ( i=0 ; i<oInit.aaData.length ; i++ ) {
            _fnAddData( oSettings, oInit.aaData[ i ] );
          }
        }
        else if ( oSettings.bDeferLoading || _fnDataSource( oSettings ) == 'dom' ) {
          /* Grab the data from the page - only do this when deferred loading or no Ajax
					 * source since there is no point in reading the DOM data if we are then going
					 * to replace it with Ajax data
					 */
          _fnAddTr( oSettings, $(oSettings.nTBody).children('tr') );
        }

        /* Copy the data index array */
        oSettings.aiDisplay = oSettings.aiDisplayMaster.slice();

        /* Initialisation complete - table can be drawn */
        oSettings.bInitialised = true;

        /* Check if we need to initialise the table (it might not have been handed off to the
				 * language processor)
				 */
        if ( bInitHandedOff === false ) {
          _fnInitialise( oSettings );
        }
      };

      /* Must be done after everything which can be overridden by the state saving! */
      _fnCallbackReg( oSettings, 'aoDrawCallback', _fnSaveState, 'state_save' );

      if ( oInit.bStateSave )
      {
        features.bStateSave = true;
        _fnLoadState( oSettings, oInit, loadedInit );
      }
      else {
        loadedInit();
      }

    } );
    _that = null;
    return this;
  };


  /*
	 * It is useful to have variables which are scoped locally so only the
	 * DataTables functions can access them and they don't leak into global space.
	 * At the same time these functions are often useful over multiple files in the
	 * core and API, so we list, or at least document, all variables which are used
	 * by DataTables as private variables here. This also ensures that there is no
	 * clashing of variable names and that they can easily referenced for reuse.
	 */


  // Defined else where
  //  _selector_run
  //  _selector_opts
  //  _selector_first
  //  _selector_row_indexes

  var _ext; // DataTable.ext
  var _Api; // DataTable.Api
  var _api_register; // DataTable.Api.register
  var _api_registerPlural; // DataTable.Api.registerPlural

  var _re_dic = {};
  var _re_new_lines = /[\r\n\u2028]/g;
  var _re_html = /<.*?>/g;

  // This is not strict ISO8601 - Date.parse() is quite lax, although
  // implementations differ between browsers.
  var _re_date = /^\d{2,4}[\.\/\-]\d{1,2}[\.\/\-]\d{1,2}([T ]{1}\d{1,2}[:\.]\d{2}([\.:]\d{2})?)?$/;

  // Escape regular expression special characters
  var _re_escape_regex = new RegExp( '(\\' + [ '/', '.', '*', '+', '?', '|', '(', ')', '[', ']', '{', '}', '\\', '$', '^', '-' ].join('|\\') + ')', 'g' );

  // http://en.wikipedia.org/wiki/Foreign_exchange_market
  // - \u20BD - Russian ruble.
  // - \u20a9 - South Korean Won
  // - \u20BA - Turkish Lira
  // - \u20B9 - Indian Rupee
  // - R - Brazil (R$) and South Africa
  // - fr - Swiss Franc
  // - kr - Swedish krona, Norwegian krone and Danish krone
  // - \u2009 is thin space and \u202F is narrow no-break space, both used in many
  // - Ƀ - Bitcoin
  // - Ξ - Ethereum
  //   standards as thousands separators.
  var _re_formatted_numeric = /['\u00A0,$£€¥%\u2009\u202F\u20BD\u20a9\u20BArfkɃΞ]/gi;


  var _empty = function ( d ) {
    return !d || d === true || d === '-' ? true : false;
  };


  var _intVal = function ( s ) {
    var integer = parseInt( s, 10 );
    return !isNaN(integer) && isFinite(s) ? integer : null;
  };

  // Convert from a formatted number with characters other than `.` as the
  // decimal place, to a Javascript number
  var _numToDecimal = function ( num, decimalPoint ) {
    // Cache created regular expressions for speed as this function is called often
    if ( ! _re_dic[ decimalPoint ] ) {
      _re_dic[ decimalPoint ] = new RegExp( _fnEscapeRegex( decimalPoint ), 'g' );
    }
    return typeof num === 'string' && decimalPoint !== '.' ?
      num.replace( /\./g, '' ).replace( _re_dic[ decimalPoint ], '.' ) :
      num;
  };


  var _isNumber = function ( d, decimalPoint, formatted ) {
    var strType = typeof d === 'string';

    // If empty return immediately so there must be a number if it is a
    // formatted string (this stops the string "k", or "kr", etc being detected
    // as a formatted number for currency
    if ( _empty( d ) ) {
      return true;
    }

    if ( decimalPoint && strType ) {
      d = _numToDecimal( d, decimalPoint );
    }

    if ( formatted && strType ) {
      d = d.replace( _re_formatted_numeric, '' );
    }

    return !isNaN( parseFloat(d) ) && isFinite( d );
  };


  // A string without HTML in it can be considered to be HTML still
  var _isHtml = function ( d ) {
    return _empty( d ) || typeof d === 'string';
  };


  var _htmlNumeric = function ( d, decimalPoint, formatted ) {
    if ( _empty( d ) ) {
      return true;
    }

    var html = _isHtml( d );
    return ! html ?
      null :
      _isNumber( _stripHtml( d ), decimalPoint, formatted ) ?
        true :
        null;
  };


  var _pluck = function ( a, prop, prop2 ) {
    var out = [];
    var i=0, ien=a.length;

    // Could have the test in the loop for slightly smaller code, but speed
    // is essential here
    if ( prop2 !== undefined ) {
      for ( ; i<ien ; i++ ) {
        if ( a[i] && a[i][ prop ] ) {
          out.push( a[i][ prop ][ prop2 ] );
        }
      }
    }
    else {
      for ( ; i<ien ; i++ ) {
        if ( a[i] ) {
          out.push( a[i][ prop ] );
        }
      }
    }

    return out;
  };


  // Basically the same as _pluck, but rather than looping over `a` we use `order`
  // as the indexes to pick from `a`
  var _pluck_order = function ( a, order, prop, prop2 )
  {
    var out = [];
    var i=0, ien=order.length;

    // Could have the test in the loop for slightly smaller code, but speed
    // is essential here
    if ( prop2 !== undefined ) {
      for ( ; i<ien ; i++ ) {
        if ( a[ order[i] ][ prop ] ) {
          out.push( a[ order[i] ][ prop ][ prop2 ] );
        }
      }
    }
    else {
      for ( ; i<ien ; i++ ) {
        out.push( a[ order[i] ][ prop ] );
      }
    }

    return out;
  };


  var _range = function ( len, start )
  {
    var out = [];
    var end;

    if ( start === undefined ) {
      start = 0;
      end = len;
    }
    else {
      end = start;
      start = len;
    }

    for ( var i=start ; i<end ; i++ ) {
      out.push( i );
    }

    return out;
  };


  var _removeEmpty = function ( a )
  {
    var out = [];

    for ( var i=0, ien=a.length ; i<ien ; i++ ) {
      if ( a[i] ) { // careful - will remove all falsy values!
        out.push( a[i] );
      }
    }

    return out;
  };


  var _stripHtml = function ( d ) {
    return d.replace( _re_html, '' );
  };


  /**
   * Determine if all values in the array are unique. This means we can short
   * cut the _unique method at the cost of a single loop. A sorted array is used
   * to easily check the values.
   *
   * @param  {array} src Source array
   * @return {boolean} true if all unique, false otherwise
   * @ignore
   */
  var _areAllUnique = function ( src ) {
    if ( src.length < 2 ) {
      return true;
    }

    var sorted = src.slice().sort();
    var last = sorted[0];

    for ( var i=1, ien=sorted.length ; i<ien ; i++ ) {
      if ( sorted[i] === last ) {
        return false;
      }

      last = sorted[i];
    }

    return true;
  };


  /**
   * Find the unique elements in a source array.
   *
   * @param  {array} src Source array
   * @return {array} Array of unique items
   * @ignore
   */
  var _unique = function ( src )
  {
    if ( _areAllUnique( src ) ) {
      return src.slice();
    }

    // A faster unique method is to use object keys to identify used values,
    // but this doesn't work with arrays or objects, which we must also
    // consider. See jsperf.com/compare-array-unique-versions/4 for more
    // information.
    var
      out = [],
      val,
      i, ien=src.length,
      j, k=0;

    again: for ( i=0 ; i<ien ; i++ ) {
      val = src[i];

      for ( j=0 ; j<k ; j++ ) {
        if ( out[j] === val ) {
          continue again;
        }
      }

      out.push( val );
      k++;
    }

    return out;
  };

  // Surprisingly this is faster than [].concat.apply
  // https://jsperf.com/flatten-an-array-loop-vs-reduce/2
  var _flatten = function (out, val) {
    if (Array.isArray(val)) {
      for (var i=0 ; i<val.length ; i++) {
        _flatten(out, val[i]);
      }
    }
    else {
      out.push(val);
    }

    return out;
  }

  var _includes = function (search, start) {
    if (start === undefined) {
      start = 0;
    }

    return this.indexOf(search, start) !== -1;
  };

  // Array.isArray polyfill.
  // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/isArray
  if (! Array.isArray) {
    Array.isArray = function(arg) {
      return Object.prototype.toString.call(arg) === '[object Array]';
    };
  }

  if (! Array.prototype.includes) {
    Array.prototype.includes = _includes;
  }

  // .trim() polyfill
  // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/trim
  if (!String.prototype.trim) {
    String.prototype.trim = function () {
      return this.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '');
    };
  }

  if (! String.prototype.includes) {
    String.prototype.includes = _includes;
  }

  /**
   * DataTables utility methods
   *
   * This namespace provides helper methods that DataTables uses internally to
   * create a DataTable, but which are not exclusively used only for DataTables.
   * These methods can be used by extension authors to save the duplication of
   * code.
   *
   *  @namespace
   */
  DataTable.util = {
    /**
     * Throttle the calls to a function. Arguments and context are maintained
     * for the throttled function.
     *
     * @param {function} fn Function to be called
     * @param {integer} freq Call frequency in mS
     * @return {function} Wrapped function
     */
    throttle: function ( fn, freq ) {
      var
        frequency = freq !== undefined ? freq : 200,
        last,
        timer;

      return function () {
        var
          that = this,
          now  = +new Date(),
          args = arguments;

        if ( last && now < last + frequency ) {
          clearTimeout( timer );

          timer = setTimeout( function () {
            last = undefined;
            fn.apply( that, args );
          }, frequency );
        }
        else {
          last = now;
          fn.apply( that, args );
        }
      };
    },


    /**
     * Escape a string such that it can be used in a regular expression
     *
     *  @param {string} val string to escape
     *  @returns {string} escaped string
     */
    escapeRegex: function ( val ) {
      return val.replace( _re_escape_regex, '\\$1' );
    },

    /**
     * Create a function that will write to a nested object or array
     * @param {*} source JSON notation string
     * @returns Write function
     */
    set: function ( source ) {
      if ( $.isPlainObject( source ) ) {
        /* Unlike get, only the underscore (global) option is used for for
				 * setting data since we don't know the type here. This is why an object
				 * option is not documented for `mData` (which is read/write), but it is
				 * for `mRender` which is read only.
				 */
        return DataTable.util.set( source._ );
      }
      else if ( source === null ) {
        // Nothing to do when the data source is null
        return function () {};
      }
      else if ( typeof source === 'function' ) {
        return function (data, val, meta) {
          source( data, 'set', val, meta );
        };
      }
      else if ( typeof source === 'string' && (source.indexOf('.') !== -1 ||
        source.indexOf('[') !== -1 || source.indexOf('(') !== -1) )
      {
        // Like the get, we need to get data from a nested object
        var setData = function (data, val, src) {
          var a = _fnSplitObjNotation( src ), b;
          var aLast = a[a.length-1];
          var arrayNotation, funcNotation, o, innerSrc;

          for ( var i=0, iLen=a.length-1 ; i<iLen ; i++ ) {
            // Protect against prototype pollution
            if (a[i] === '__proto__' || a[i] === 'constructor') {
              throw new Error('Cannot set prototype values');
            }

            // Check if we are dealing with an array notation request
            arrayNotation = a[i].match(__reArray);
            funcNotation = a[i].match(__reFn);

            if ( arrayNotation ) {
              a[i] = a[i].replace(__reArray, '');
              data[ a[i] ] = [];

              // Get the remainder of the nested object to set so we can recurse
              b = a.slice();
              b.splice( 0, i+1 );
              innerSrc = b.join('.');

              // Traverse each entry in the array setting the properties requested
              if ( Array.isArray( val ) ) {
                for ( var j=0, jLen=val.length ; j<jLen ; j++ ) {
                  o = {};
                  setData( o, val[j], innerSrc );
                  data[ a[i] ].push( o );
                }
              }
              else {
                // We've been asked to save data to an array, but it
                // isn't array data to be saved. Best that can be done
                // is to just save the value.
                data[ a[i] ] = val;
              }

              // The inner call to setData has already traversed through the remainder
              // of the source and has set the data, thus we can exit here
              return;
            }
            else if ( funcNotation ) {
              // Function call
              a[i] = a[i].replace(__reFn, '');
              data = data[ a[i] ]( val );
            }

            // If the nested object doesn't currently exist - since we are
            // trying to set the value - create it
            if ( data[ a[i] ] === null || data[ a[i] ] === undefined ) {
              data[ a[i] ] = {};
            }
            data = data[ a[i] ];
          }

          // Last item in the input - i.e, the actual set
          if ( aLast.match(__reFn ) ) {
            // Function call
            data = data[ aLast.replace(__reFn, '') ]( val );
          }
          else {
            // If array notation is used, we just want to strip it and use the property name
            // and assign the value. If it isn't used, then we get the result we want anyway
            data[ aLast.replace(__reArray, '') ] = val;
          }
        };

        return function (data, val) { // meta is also passed in, but not used
          return setData( data, val, source );
        };
      }
      else {
        // Array or flat object mapping
        return function (data, val) { // meta is also passed in, but not used
          data[source] = val;
        };
      }
    },

    /**
     * Create a function that will read nested objects from arrays, based on JSON notation
     * @param {*} source JSON notation string
     * @returns Value read
     */
    get: function ( source ) {
      if ( $.isPlainObject( source ) ) {
        // Build an object of get functions, and wrap them in a single call
        var o = {};
        $.each( source, function (key, val) {
          if ( val ) {
            o[key] = DataTable.util.get( val );
          }
        } );

        return function (data, type, row, meta) {
          var t = o[type] || o._;
          return t !== undefined ?
            t(data, type, row, meta) :
            data;
        };
      }
      else if ( source === null ) {
        // Give an empty string for rendering / sorting etc
        return function (data) { // type, row and meta also passed, but not used
          return data;
        };
      }
      else if ( typeof source === 'function' ) {
        return function (data, type, row, meta) {
          return source( data, type, row, meta );
        };
      }
      else if ( typeof source === 'string' && (source.indexOf('.') !== -1 ||
        source.indexOf('[') !== -1 || source.indexOf('(') !== -1) )
      {
        /* If there is a . in the source string then the data source is in a
				 * nested object so we loop over the data for each level to get the next
				 * level down. On each loop we test for undefined, and if found immediately
				 * return. This allows entire objects to be missing and sDefaultContent to
				 * be used if defined, rather than throwing an error
				 */
        var fetchData = function (data, type, src) {
          var arrayNotation, funcNotation, out, innerSrc;

          if ( src !== "" ) {
            var a = _fnSplitObjNotation( src );

            for ( var i=0, iLen=a.length ; i<iLen ; i++ ) {
              // Check if we are dealing with special notation
              arrayNotation = a[i].match(__reArray);
              funcNotation = a[i].match(__reFn);

              if ( arrayNotation ) {
                // Array notation
                a[i] = a[i].replace(__reArray, '');

                // Condition allows simply [] to be passed in
                if ( a[i] !== "" ) {
                  data = data[ a[i] ];
                }
                out = [];

                // Get the remainder of the nested object to get
                a.splice( 0, i+1 );
                innerSrc = a.join('.');

                // Traverse each entry in the array getting the properties requested
                if ( Array.isArray( data ) ) {
                  for ( var j=0, jLen=data.length ; j<jLen ; j++ ) {
                    out.push( fetchData( data[j], type, innerSrc ) );
                  }
                }

                // If a string is given in between the array notation indicators, that
                // is used to join the strings together, otherwise an array is returned
                var join = arrayNotation[0].substring(1, arrayNotation[0].length-1);
                data = (join==="") ? out : out.join(join);

                // The inner call to fetchData has already traversed through the remainder
                // of the source requested, so we exit from the loop
                break;
              }
              else if ( funcNotation ) {
                // Function call
                a[i] = a[i].replace(__reFn, '');
                data = data[ a[i] ]();
                continue;
              }

              if ( data === null || data[ a[i] ] === undefined ) {
                return undefined;
              }

              data = data[ a[i] ];
            }
          }

          return data;
        };

        return function (data, type) { // row and meta also passed, but not used
          return fetchData( data, type, source );
        };
      }
      else {
        // Array or flat object mapping
        return function (data, type) { // row and meta also passed, but not used
          return data[source];
        };
      }
    }
  };



  /**
   * Create a mapping object that allows camel case parameters to be looked up
   * for their Hungarian counterparts. The mapping is stored in a private
   * parameter called `_hungarianMap` which can be accessed on the source object.
   *  @param {object} o
   *  @memberof DataTable#oApi
   */
  function _fnHungarianMap ( o )
  {
    var
      hungarian = 'a aa ai ao as b fn i m o s ',
      match,
      newKey,
      map = {};

    $.each( o, function (key, val) {
      match = key.match(/^([^A-Z]+?)([A-Z])/);

      if ( match && hungarian.indexOf(match[1]+' ') !== -1 )
      {
        newKey = key.replace( match[0], match[2].toLowerCase() );
        map[ newKey ] = key;

        if ( match[1] === 'o' )
        {
          _fnHungarianMap( o[key] );
        }
      }
    } );

    o._hungarianMap = map;
  }


  /**
   * Convert from camel case parameters to Hungarian, based on a Hungarian map
   * created by _fnHungarianMap.
   *  @param {object} src The model object which holds all parameters that can be
   *    mapped.
   *  @param {object} user The object to convert from camel case to Hungarian.
   *  @param {boolean} force When set to `true`, properties which already have a
   *    Hungarian value in the `user` object will be overwritten. Otherwise they
   *    won't be.
   *  @memberof DataTable#oApi
   */
  function _fnCamelToHungarian ( src, user, force )
  {
    if ( ! src._hungarianMap ) {
      _fnHungarianMap( src );
    }

    var hungarianKey;

    $.each( user, function (key, val) {
      hungarianKey = src._hungarianMap[ key ];

      if ( hungarianKey !== undefined && (force || user[hungarianKey] === undefined) )
      {
        // For objects, we need to buzz down into the object to copy parameters
        if ( hungarianKey.charAt(0) === 'o' )
        {
          // Copy the camelCase options over to the hungarian
          if ( ! user[ hungarianKey ] ) {
            user[ hungarianKey ] = {};
          }
          $.extend( true, user[hungarianKey], user[key] );

          _fnCamelToHungarian( src[hungarianKey], user[hungarianKey], force );
        }
        else {
          user[hungarianKey] = user[ key ];
        }
      }
    } );
  }


  /**
   * Language compatibility - when certain options are given, and others aren't, we
   * need to duplicate the values over, in order to provide backwards compatibility
   * with older language files.
   *  @param {object} oSettings dataTables settings object
   *  @memberof DataTable#oApi
   */
  function _fnLanguageCompat( lang )
  {
    // Note the use of the Hungarian notation for the parameters in this method as
    // this is called after the mapping of camelCase to Hungarian
    var defaults = DataTable.defaults.oLanguage;

    // Default mapping
    var defaultDecimal = defaults.sDecimal;
    if ( defaultDecimal ) {
      _addNumericSort( defaultDecimal );
    }

    if ( lang ) {
      var zeroRecords = lang.sZeroRecords;

      // Backwards compatibility - if there is no sEmptyTable given, then use the same as
      // sZeroRecords - assuming that is given.
      if ( ! lang.sEmptyTable && zeroRecords &&
        defaults.sEmptyTable === "No data available in table" )
      {
        _fnMap( lang, lang, 'sZeroRecords', 'sEmptyTable' );
      }

      // Likewise with loading records
      if ( ! lang.sLoadingRecords && zeroRecords &&
        defaults.sLoadingRecords === "Loading..." )
      {
        _fnMap( lang, lang, 'sZeroRecords', 'sLoadingRecords' );
      }

      // Old parameter name of the thousands separator mapped onto the new
      if ( lang.sInfoThousands ) {
        lang.sThousands = lang.sInfoThousands;
      }

      var decimal = lang.sDecimal;
      if ( decimal && defaultDecimal !== decimal ) {
        _addNumericSort( decimal );
      }
    }
  }


  /**
   * Map one parameter onto another
   *  @param {object} o Object to map
   *  @param {*} knew The new parameter name
   *  @param {*} old The old parameter name
   */
  var _fnCompatMap = function ( o, knew, old ) {
    if ( o[ knew ] !== undefined ) {
      o[ old ] = o[ knew ];
    }
  };


  /**
   * Provide backwards compatibility for the main DT options. Note that the new
   * options are mapped onto the old parameters, so this is an external interface
   * change only.
   *  @param {object} init Object to map
   */
  function _fnCompatOpts ( init )
  {
    _fnCompatMap( init, 'ordering',      'bSort' );
    _fnCompatMap( init, 'orderMulti',    'bSortMulti' );
    _fnCompatMap( init, 'orderClasses',  'bSortClasses' );
    _fnCompatMap( init, 'orderCellsTop', 'bSortCellsTop' );
    _fnCompatMap( init, 'order',         'aaSorting' );
    _fnCompatMap( init, 'orderFixed',    'aaSortingFixed' );
    _fnCompatMap( init, 'paging',        'bPaginate' );
    _fnCompatMap( init, 'pagingType',    'sPaginationType' );
    _fnCompatMap( init, 'pageLength',    'iDisplayLength' );
    _fnCompatMap( init, 'searching',     'bFilter' );

    // Boolean initialisation of x-scrolling
    if ( typeof init.sScrollX === 'boolean' ) {
      init.sScrollX = init.sScrollX ? '100%' : '';
    }
    if ( typeof init.scrollX === 'boolean' ) {
      init.scrollX = init.scrollX ? '100%' : '';
    }

    // Column search objects are in an array, so it needs to be converted
    // element by element
    var searchCols = init.aoSearchCols;

    if ( searchCols ) {
      for ( var i=0, ien=searchCols.length ; i<ien ; i++ ) {
        if ( searchCols[i] ) {
          _fnCamelToHungarian( DataTable.models.oSearch, searchCols[i] );
        }
      }
    }
  }


  /**
   * Provide backwards compatibility for column options. Note that the new options
   * are mapped onto the old parameters, so this is an external interface change
   * only.
   *  @param {object} init Object to map
   */
  function _fnCompatCols ( init )
  {
    _fnCompatMap( init, 'orderable',     'bSortable' );
    _fnCompatMap( init, 'orderData',     'aDataSort' );
    _fnCompatMap( init, 'orderSequence', 'asSorting' );
    _fnCompatMap( init, 'orderDataType', 'sortDataType' );

    // orderData can be given as an integer
    var dataSort = init.aDataSort;
    if ( typeof dataSort === 'number' && ! Array.isArray( dataSort ) ) {
      init.aDataSort = [ dataSort ];
    }
  }


  /**
   * Browser feature detection for capabilities, quirks
   *  @param {object} settings dataTables settings object
   *  @memberof DataTable#oApi
   */
  function _fnBrowserDetect( settings )
  {
    // We don't need to do this every time DataTables is constructed, the values
    // calculated are specific to the browser and OS configuration which we
    // don't expect to change between initialisations
    if ( ! DataTable.__browser ) {
      var browser = {};
      DataTable.__browser = browser;

      // Scrolling feature / quirks detection
      var n = $('<div/>')
        .css( {
          position: 'fixed',
          top: 0,
          left: $(window).scrollLeft()*-1, // allow for scrolling
          height: 1,
          width: 1,
          overflow: 'hidden'
        } )
        .append(
          $('<div/>')
            .css( {
              position: 'absolute',
              top: 1,
              left: 1,
              width: 100,
              overflow: 'scroll'
            } )
            .append(
              $('<div/>')
                .css( {
                  width: '100%',
                  height: 10
                } )
            )
        )
        .appendTo( 'body' );

      var outer = n.children();
      var inner = outer.children();

      // Numbers below, in order, are:
      // inner.offsetWidth, inner.clientWidth, outer.offsetWidth, outer.clientWidth
      //
      // IE6 XP:                           100 100 100  83
      // IE7 Vista:                        100 100 100  83
      // IE 8+ Windows:                     83  83 100  83
      // Evergreen Windows:                 83  83 100  83
      // Evergreen Mac with scrollbars:     85  85 100  85
      // Evergreen Mac without scrollbars: 100 100 100 100

      // Get scrollbar width
      browser.barWidth = outer[0].offsetWidth - outer[0].clientWidth;

      // IE6/7 will oversize a width 100% element inside a scrolling element, to
      // include the width of the scrollbar, while other browsers ensure the inner
      // element is contained without forcing scrolling
      browser.bScrollOversize = inner[0].offsetWidth === 100 && outer[0].clientWidth !== 100;

      // In rtl text layout, some browsers (most, but not all) will place the
      // scrollbar on the left, rather than the right.
      browser.bScrollbarLeft = Math.round( inner.offset().left ) !== 1;

      // IE8- don't provide height and width for getBoundingClientRect
      browser.bBounding = n[0].getBoundingClientRect().width ? true : false;

      n.remove();
    }

    $.extend( settings.oBrowser, DataTable.__browser );
    settings.oScroll.iBarWidth = DataTable.__browser.barWidth;
  }


  /**
   * Array.prototype reduce[Right] method, used for browsers which don't support
   * JS 1.6. Done this way to reduce code size, since we iterate either way
   *  @param {object} settings dataTables settings object
   *  @memberof DataTable#oApi
   */
  function _fnReduce ( that, fn, init, start, end, inc )
  {
    var
      i = start,
      value,
      isSet = false;

    if ( init !== undefined ) {
      value = init;
      isSet = true;
    }

    while ( i !== end ) {
      if ( ! that.hasOwnProperty(i) ) {
        continue;
      }

      value = isSet ?
        fn( value, that[i], i, that ) :
        that[i];

      isSet = true;
      i += inc;
    }

    return value;
  }

  /**
   * Add a column to the list used for the table with default values
   *  @param {object} oSettings dataTables settings object
   *  @param {node} nTh The th element for this column
   *  @memberof DataTable#oApi
   */
  function _fnAddColumn( oSettings, nTh )
  {
    // Add column to aoColumns array
    var oDefaults = DataTable.defaults.column;
    var iCol = oSettings.aoColumns.length;
    var oCol = $.extend( {}, DataTable.models.oColumn, oDefaults, {
      "nTh": nTh ? nTh : document.createElement('th'),
      "sTitle":    oDefaults.sTitle    ? oDefaults.sTitle    : nTh ? nTh.innerHTML : '',
      "aDataSort": oDefaults.aDataSort ? oDefaults.aDataSort : [iCol],
      "mData": oDefaults.mData ? oDefaults.mData : iCol,
      idx: iCol
    } );
    oSettings.aoColumns.push( oCol );

    // Add search object for column specific search. Note that the `searchCols[ iCol ]`
    // passed into extend can be undefined. This allows the user to give a default
    // with only some of the parameters defined, and also not give a default
    var searchCols = oSettings.aoPreSearchCols;
    searchCols[ iCol ] = $.extend( {}, DataTable.models.oSearch, searchCols[ iCol ] );

    // Use the default column options function to initialise classes etc
    _fnColumnOptions( oSettings, iCol, $(nTh).data() );
  }


  /**
   * Apply options for a column
   *  @param {object} oSettings dataTables settings object
   *  @param {int} iCol column index to consider
   *  @param {object} oOptions object with sType, bVisible and bSearchable etc
   *  @memberof DataTable#oApi
   */
  function _fnColumnOptions( oSettings, iCol, oOptions )
  {
    var oCol = oSettings.aoColumns[ iCol ];
    var oClasses = oSettings.oClasses;
    var th = $(oCol.nTh);

    // Try to get width information from the DOM. We can't get it from CSS
    // as we'd need to parse the CSS stylesheet. `width` option can override
    if ( ! oCol.sWidthOrig ) {
      // Width attribute
      oCol.sWidthOrig = th.attr('width') || null;

      // Style attribute
      var t = (th.attr('style') || '').match(/width:\s*(\d+[pxem%]+)/);
      if ( t ) {
        oCol.sWidthOrig = t[1];
      }
    }

    /* User specified column options */
    if ( oOptions !== undefined && oOptions !== null )
    {
      // Backwards compatibility
      _fnCompatCols( oOptions );

      // Map camel case parameters to their Hungarian counterparts
      _fnCamelToHungarian( DataTable.defaults.column, oOptions, true );

      /* Backwards compatibility for mDataProp */
      if ( oOptions.mDataProp !== undefined && !oOptions.mData )
      {
        oOptions.mData = oOptions.mDataProp;
      }

      if ( oOptions.sType )
      {
        oCol._sManualType = oOptions.sType;
      }

      // `class` is a reserved word in Javascript, so we need to provide
      // the ability to use a valid name for the camel case input
      if ( oOptions.className && ! oOptions.sClass )
      {
        oOptions.sClass = oOptions.className;
      }
      if ( oOptions.sClass ) {
        th.addClass( oOptions.sClass );
      }

      var origClass = oCol.sClass;

      $.extend( oCol, oOptions );
      _fnMap( oCol, oOptions, "sWidth", "sWidthOrig" );

      // Merge class from previously defined classes with this one, rather than just
      // overwriting it in the extend above
      if (origClass !== oCol.sClass) {
        oCol.sClass = origClass + ' ' + oCol.sClass;
      }

      /* iDataSort to be applied (backwards compatibility), but aDataSort will take
			 * priority if defined
			 */
      if ( oOptions.iDataSort !== undefined )
      {
        oCol.aDataSort = [ oOptions.iDataSort ];
      }
      _fnMap( oCol, oOptions, "aDataSort" );
    }

    /* Cache the data get and set functions for speed */
    var mDataSrc = oCol.mData;
    var mData = _fnGetObjectDataFn( mDataSrc );
    var mRender = oCol.mRender ? _fnGetObjectDataFn( oCol.mRender ) : null;

    var attrTest = function( src ) {
      return typeof src === 'string' && src.indexOf('@') !== -1;
    };
    oCol._bAttrSrc = $.isPlainObject( mDataSrc ) && (
      attrTest(mDataSrc.sort) || attrTest(mDataSrc.type) || attrTest(mDataSrc.filter)
    );
    oCol._setter = null;

    oCol.fnGetData = function (rowData, type, meta) {
      var innerData = mData( rowData, type, undefined, meta );

      return mRender && type ?
        mRender( innerData, type, rowData, meta ) :
        innerData;
    };
    oCol.fnSetData = function ( rowData, val, meta ) {
      return _fnSetObjectDataFn( mDataSrc )( rowData, val, meta );
    };

    // Indicate if DataTables should read DOM data as an object or array
    // Used in _fnGetRowElements
    if ( typeof mDataSrc !== 'number' ) {
      oSettings._rowReadObject = true;
    }

    /* Feature sorting overrides column specific when off */
    if ( !oSettings.oFeatures.bSort )
    {
      oCol.bSortable = false;
      th.addClass( oClasses.sSortableNone ); // Have to add class here as order event isn't called
    }

    /* Check that the class assignment is correct for sorting */
    var bAsc = $.inArray('asc', oCol.asSorting) !== -1;
    var bDesc = $.inArray('desc', oCol.asSorting) !== -1;
    if ( !oCol.bSortable || (!bAsc && !bDesc) )
    {
      oCol.sSortingClass = oClasses.sSortableNone;
      oCol.sSortingClassJUI = "";
    }
    else if ( bAsc && !bDesc )
    {
      oCol.sSortingClass = oClasses.sSortableAsc;
      oCol.sSortingClassJUI = oClasses.sSortJUIAscAllowed;
    }
    else if ( !bAsc && bDesc )
    {
      oCol.sSortingClass = oClasses.sSortableDesc;
      oCol.sSortingClassJUI = oClasses.sSortJUIDescAllowed;
    }
    else
    {
      oCol.sSortingClass = oClasses.sSortable;
      oCol.sSortingClassJUI = oClasses.sSortJUI;
    }
  }


  /**
   * Adjust the table column widths for new data. Note: you would probably want to
   * do a redraw after calling this function!
   *  @param {object} settings dataTables settings object
   *  @memberof DataTable#oApi
   */
  function _fnAdjustColumnSizing ( settings )
  {
    /* Not interested in doing column width calculation if auto-width is disabled */
    if ( settings.oFeatures.bAutoWidth !== false )
    {
      var columns = settings.aoColumns;

      _fnCalculateColumnWidths( settings );
      for ( var i=0 , iLen=columns.length ; i<iLen ; i++ )
      {
        columns[i].nTh.style.width = columns[i].sWidth;
      }
    }

    var scroll = settings.oScroll;
    if ( scroll.sY !== '' || scroll.sX !== '')
    {
      _fnScrollDraw( settings );
    }

    _fnCallbackFire( settings, null, 'column-sizing', [settings] );
  }


  /**
   * Convert the index of a visible column to the index in the data array (take account
   * of hidden columns)
   *  @param {object} oSettings dataTables settings object
   *  @param {int} iMatch Visible column index to lookup
   *  @returns {int} i the data index
   *  @memberof DataTable#oApi
   */
  function _fnVisibleToColumnIndex( oSettings, iMatch )
  {
    var aiVis = _fnGetColumns( oSettings, 'bVisible' );

    return typeof aiVis[iMatch] === 'number' ?
      aiVis[iMatch] :
      null;
  }


  /**
   * Convert the index of an index in the data array and convert it to the visible
   *   column index (take account of hidden columns)
   *  @param {int} iMatch Column index to lookup
   *  @param {object} oSettings dataTables settings object
   *  @returns {int} i the data index
   *  @memberof DataTable#oApi
   */
  function _fnColumnIndexToVisible( oSettings, iMatch )
  {
    var aiVis = _fnGetColumns( oSettings, 'bVisible' );
    var iPos = $.inArray( iMatch, aiVis );

    return iPos !== -1 ? iPos : null;
  }


  /**
   * Get the number of visible columns
   *  @param {object} oSettings dataTables settings object
   *  @returns {int} i the number of visible columns
   *  @memberof DataTable#oApi
   */
  function _fnVisbleColumns( oSettings )
  {
    var vis = 0;

    // No reduce in IE8, use a loop for now
    $.each( oSettings.aoColumns, function ( i, col ) {
      if ( col.bVisible && $(col.nTh).css('display') !== 'none' ) {
        vis++;
      }
    } );

    return vis;
  }


  /**
   * Get an array of column indexes that match a given property
   *  @param {object} oSettings dataTables settings object
   *  @param {string} sParam Parameter in aoColumns to look for - typically
   *    bVisible or bSearchable
   *  @returns {array} Array of indexes with matched properties
   *  @memberof DataTable#oApi
   */
  function _fnGetColumns( oSettings, sParam )
  {
    var a = [];

    $.map( oSettings.aoColumns, function(val, i) {
      if ( val[sParam] ) {
        a.push( i );
      }
    } );

    return a;
  }


  /**
   * Calculate the 'type' of a column
   *  @param {object} settings dataTables settings object
   *  @memberof DataTable#oApi
   */
  function _fnColumnTypes ( settings )
  {
    var columns = settings.aoColumns;
    var data = settings.aoData;
    var types = DataTable.ext.type.detect;
    var i, ien, j, jen, k, ken;
    var col, cell, detectedType, cache;

    // For each column, spin over the
    for ( i=0, ien=columns.length ; i<ien ; i++ ) {
      col = columns[i];
      cache = [];

      if ( ! col.sType && col._sManualType ) {
        col.sType = col._sManualType;
      }
      else if ( ! col.sType ) {
        for ( j=0, jen=types.length ; j<jen ; j++ ) {
          for ( k=0, ken=data.length ; k<ken ; k++ ) {
            // Use a cache array so we only need to get the type data
            // from the formatter once (when using multiple detectors)
            if ( cache[k] === undefined ) {
              cache[k] = _fnGetCellData( settings, k, i, 'type' );
            }

            detectedType = types[j]( cache[k], settings );

            // If null, then this type can't apply to this column, so
            // rather than testing all cells, break out. There is an
            // exception for the last type which is `html`. We need to
            // scan all rows since it is possible to mix string and HTML
            // types
            if ( ! detectedType && j !== types.length-1 ) {
              break;
            }

            // Only a single match is needed for html type since it is
            // bottom of the pile and very similar to string - but it
            // must not be empty
            if ( detectedType === 'html' && ! _empty(cache[k]) ) {
              break;
            }
          }

          // Type is valid for all data points in the column - use this
          // type
          if ( detectedType ) {
            col.sType = detectedType;
            break;
          }
        }

        // Fall back - if no type was detected, always use string
        if ( ! col.sType ) {
          col.sType = 'string';
        }
      }
    }
  }


  /**
   * Take the column definitions and static columns arrays and calculate how
   * they relate to column indexes. The callback function will then apply the
   * definition found for a column to a suitable configuration object.
   *  @param {object} oSettings dataTables settings object
   *  @param {array} aoColDefs The aoColumnDefs array that is to be applied
   *  @param {array} aoCols The aoColumns array that defines columns individually
   *  @param {function} fn Callback function - takes two parameters, the calculated
   *    column index and the definition for that column.
   *  @memberof DataTable#oApi
   */
  function _fnApplyColumnDefs( oSettings, aoColDefs, aoCols, fn )
  {
    var i, iLen, j, jLen, k, kLen, def;
    var columns = oSettings.aoColumns;

    // Column definitions with aTargets
    if ( aoColDefs )
    {
      /* Loop over the definitions array - loop in reverse so first instance has priority */
      for ( i=aoColDefs.length-1 ; i>=0 ; i-- )
      {
        def = aoColDefs[i];

        /* Each definition can target multiple columns, as it is an array */
        var aTargets = def.target !== undefined
          ? def.target
          : def.targets !== undefined
            ? def.targets
            : def.aTargets;

        if ( ! Array.isArray( aTargets ) )
        {
          aTargets = [ aTargets ];
        }

        for ( j=0, jLen=aTargets.length ; j<jLen ; j++ )
        {
          if ( typeof aTargets[j] === 'number' && aTargets[j] >= 0 )
          {
            /* Add columns that we don't yet know about */
            while( columns.length <= aTargets[j] )
            {
              _fnAddColumn( oSettings );
            }

            /* Integer, basic index */
            fn( aTargets[j], def );
          }
          else if ( typeof aTargets[j] === 'number' && aTargets[j] < 0 )
          {
            /* Negative integer, right to left column counting */
            fn( columns.length+aTargets[j], def );
          }
          else if ( typeof aTargets[j] === 'string' )
          {
            /* Class name matching on TH element */
            for ( k=0, kLen=columns.length ; k<kLen ; k++ )
            {
              if ( aTargets[j] == "_all" ||
                $(columns[k].nTh).hasClass( aTargets[j] ) )
              {
                fn( k, def );
              }
            }
          }
        }
      }
    }

    // Statically defined columns array
    if ( aoCols )
    {
      for ( i=0, iLen=aoCols.length ; i<iLen ; i++ )
      {
        fn( i, aoCols[i] );
      }
    }
  }

  /**
   * Add a data array to the table, creating DOM node etc. This is the parallel to
   * _fnGatherData, but for adding rows from a Javascript source, rather than a
   * DOM source.
   *  @param {object} oSettings dataTables settings object
   *  @param {array} aData data array to be added
   *  @param {node} [nTr] TR element to add to the table - optional. If not given,
   *    DataTables will create a row automatically
   *  @param {array} [anTds] Array of TD|TH elements for the row - must be given
   *    if nTr is.
   *  @returns {int} >=0 if successful (index of new aoData entry), -1 if failed
   *  @memberof DataTable#oApi
   */
  function _fnAddData ( oSettings, aDataIn, nTr, anTds )
  {
    /* Create the object for storing information about this new row */
    var iRow = oSettings.aoData.length;
    var oData = $.extend( true, {}, DataTable.models.oRow, {
      src: nTr ? 'dom' : 'data',
      idx: iRow
    } );

    oData._aData = aDataIn;
    oSettings.aoData.push( oData );

    /* Create the cells */
    var nTd, sThisType;
    var columns = oSettings.aoColumns;

    // Invalidate the column types as the new data needs to be revalidated
    for ( var i=0, iLen=columns.length ; i<iLen ; i++ )
    {
      columns[i].sType = null;
    }

    /* Add to the display array */
    oSettings.aiDisplayMaster.push( iRow );

    var id = oSettings.rowIdFn( aDataIn );
    if ( id !== undefined ) {
      oSettings.aIds[ id ] = oData;
    }

    /* Create the DOM information, or register it if already present */
    if ( nTr || ! oSettings.oFeatures.bDeferRender )
    {
      _fnCreateTr( oSettings, iRow, nTr, anTds );
    }

    return iRow;
  }


  /**
   * Add one or more TR elements to the table. Generally we'd expect to
   * use this for reading data from a DOM sourced table, but it could be
   * used for an TR element. Note that if a TR is given, it is used (i.e.
   * it is not cloned).
   *  @param {object} settings dataTables settings object
   *  @param {array|node|jQuery} trs The TR element(s) to add to the table
   *  @returns {array} Array of indexes for the added rows
   *  @memberof DataTable#oApi
   */
  function _fnAddTr( settings, trs )
  {
    var row;

    // Allow an individual node to be passed in
    if ( ! (trs instanceof $) ) {
      trs = $(trs);
    }

    return trs.map( function (i, el) {
      row = _fnGetRowElements( settings, el );
      return _fnAddData( settings, row.data, el, row.cells );
    } );
  }


  /**
   * Take a TR element and convert it to an index in aoData
   *  @param {object} oSettings dataTables settings object
   *  @param {node} n the TR element to find
   *  @returns {int} index if the node is found, null if not
   *  @memberof DataTable#oApi
   */
  function _fnNodeToDataIndex( oSettings, n )
  {
    return (n._DT_RowIndex!==undefined) ? n._DT_RowIndex : null;
  }


  /**
   * Take a TD element and convert it into a column data index (not the visible index)
   *  @param {object} oSettings dataTables settings object
   *  @param {int} iRow The row number the TD/TH can be found in
   *  @param {node} n The TD/TH element to find
   *  @returns {int} index if the node is found, -1 if not
   *  @memberof DataTable#oApi
   */
  function _fnNodeToColumnIndex( oSettings, iRow, n )
  {
    return $.inArray( n, oSettings.aoData[ iRow ].anCells );
  }


  /**
   * Get the data for a given cell from the internal cache, taking into account data mapping
   *  @param {object} settings dataTables settings object
   *  @param {int} rowIdx aoData row id
   *  @param {int} colIdx Column index
   *  @param {string} type data get type ('display', 'type' 'filter|search' 'sort|order')
   *  @returns {*} Cell data
   *  @memberof DataTable#oApi
   */
  function _fnGetCellData( settings, rowIdx, colIdx, type )
  {
    if (type === 'search') {
      type = 'filter';
    }
    else if (type === 'order') {
      type = 'sort';
    }

    var draw           = settings.iDraw;
    var col            = settings.aoColumns[colIdx];
    var rowData        = settings.aoData[rowIdx]._aData;
    var defaultContent = col.sDefaultContent;
    var cellData       = col.fnGetData( rowData, type, {
      settings: settings,
      row:      rowIdx,
      col:      colIdx
    } );

    if ( cellData === undefined ) {
      if ( settings.iDrawError != draw && defaultContent === null ) {
        _fnLog( settings, 0, "Requested unknown parameter "+
          (typeof col.mData=='function' ? '{function}' : "'"+col.mData+"'")+
          " for row "+rowIdx+", column "+colIdx, 4 );
        settings.iDrawError = draw;
      }
      return defaultContent;
    }

    // When the data source is null and a specific data type is requested (i.e.
    // not the original data), we can use default column data
    if ( (cellData === rowData || cellData === null) && defaultContent !== null && type !== undefined ) {
      cellData = defaultContent;
    }
    else if ( typeof cellData === 'function' ) {
      // If the data source is a function, then we run it and use the return,
      // executing in the scope of the data object (for instances)
      return cellData.call( rowData );
    }

    if ( cellData === null && type === 'display' ) {
      return '';
    }

    if ( type === 'filter' ) {
      var fomatters = DataTable.ext.type.search;

      if ( fomatters[ col.sType ] ) {
        cellData = fomatters[ col.sType ]( cellData );
      }
    }

    return cellData;
  }


  /**
   * Set the value for a specific cell, into the internal data cache
   *  @param {object} settings dataTables settings object
   *  @param {int} rowIdx aoData row id
   *  @param {int} colIdx Column index
   *  @param {*} val Value to set
   *  @memberof DataTable#oApi
   */
  function _fnSetCellData( settings, rowIdx, colIdx, val )
  {
    var col     = settings.aoColumns[colIdx];
    var rowData = settings.aoData[rowIdx]._aData;

    col.fnSetData( rowData, val, {
      settings: settings,
      row:      rowIdx,
      col:      colIdx
    }  );
  }


  // Private variable that is used to match action syntax in the data property object
  var __reArray = /\[.*?\]$/;
  var __reFn = /\(\)$/;

  /**
   * Split string on periods, taking into account escaped periods
   * @param  {string} str String to split
   * @return {array} Split string
   */
  function _fnSplitObjNotation( str )
  {
    return $.map( str.match(/(\\.|[^\.])+/g) || [''], function ( s ) {
      return s.replace(/\\\./g, '.');
    } );
  }


  /**
   * Return a function that can be used to get data from a source object, taking
   * into account the ability to use nested objects as a source
   *  @param {string|int|function} mSource The data source for the object
   *  @returns {function} Data get function
   *  @memberof DataTable#oApi
   */
  var _fnGetObjectDataFn = DataTable.util.get;


  /**
   * Return a function that can be used to set data from a source object, taking
   * into account the ability to use nested objects as a source
   *  @param {string|int|function} mSource The data source for the object
   *  @returns {function} Data set function
   *  @memberof DataTable#oApi
   */
  var _fnSetObjectDataFn = DataTable.util.set;


  /**
   * Return an array with the full table data
   *  @param {object} oSettings dataTables settings object
   *  @returns array {array} aData Master data array
   *  @memberof DataTable#oApi
   */
  function _fnGetDataMaster ( settings )
  {
    return _pluck( settings.aoData, '_aData' );
  }


  /**
   * Nuke the table
   *  @param {object} oSettings dataTables settings object
   *  @memberof DataTable#oApi
   */
  function _fnClearTable( settings )
  {
    settings.aoData.length = 0;
    settings.aiDisplayMaster.length = 0;
    settings.aiDisplay.length = 0;
    settings.aIds = {};
  }


  /**
   * Take an array of integers (index array) and remove a target integer (value - not
   * the key!)
   *  @param {array} a Index array to target
   *  @param {int} iTarget value to find
   *  @memberof DataTable#oApi
   */
  function _fnDeleteIndex( a, iTarget, splice )
  {
    var iTargetIndex = -1;

    for ( var i=0, iLen=a.length ; i<iLen ; i++ )
    {
      if ( a[i] == iTarget )
      {
        iTargetIndex = i;
      }
      else if ( a[i] > iTarget )
      {
        a[i]--;
      }
    }

    if ( iTargetIndex != -1 && splice === undefined )
    {
      a.splice( iTargetIndex, 1 );
    }
  }


  /**
   * Mark cached data as invalid such that a re-read of the data will occur when
   * the cached data is next requested. Also update from the data source object.
   *
   * @param {object} settings DataTables settings object
   * @param {int}    rowIdx   Row index to invalidate
   * @param {string} [src]    Source to invalidate from: undefined, 'auto', 'dom'
   *     or 'data'
   * @param {int}    [colIdx] Column index to invalidate. If undefined the whole
   *     row will be invalidated
   * @memberof DataTable#oApi
   *
   * @todo For the modularisation of v1.11 this will need to become a callback, so
   *   the sort and filter methods can subscribe to it. That will required
   *   initialisation options for sorting, which is why it is not already baked in
   */
  function _fnInvalidate( settings, rowIdx, src, colIdx )
  {
    var row = settings.aoData[ rowIdx ];
    var i, ien;
    var cellWrite = function ( cell, col ) {
      // This is very frustrating, but in IE if you just write directly
      // to innerHTML, and elements that are overwritten are GC'ed,
      // even if there is a reference to them elsewhere
      while ( cell.childNodes.length ) {
        cell.removeChild( cell.firstChild );
      }

      cell.innerHTML = _fnGetCellData( settings, rowIdx, col, 'display' );
    };

    // Are we reading last data from DOM or the data object?
    if ( src === 'dom' || ((! src || src === 'auto') && row.src === 'dom') ) {
      // Read the data from the DOM
      row._aData = _fnGetRowElements(
        settings, row, colIdx, colIdx === undefined ? undefined : row._aData
      )
        .data;
    }
    else {
      // Reading from data object, update the DOM
      var cells = row.anCells;

      if ( cells ) {
        if ( colIdx !== undefined ) {
          cellWrite( cells[colIdx], colIdx );
        }
        else {
          for ( i=0, ien=cells.length ; i<ien ; i++ ) {
            cellWrite( cells[i], i );
          }
        }
      }
    }

    // For both row and cell invalidation, the cached data for sorting and
    // filtering is nulled out
    row._aSortData = null;
    row._aFilterData = null;

    // Invalidate the type for a specific column (if given) or all columns since
    // the data might have changed
    var cols = settings.aoColumns;
    if ( colIdx !== undefined ) {
      cols[ colIdx ].sType = null;
    }
    else {
      for ( i=0, ien=cols.length ; i<ien ; i++ ) {
        cols[i].sType = null;
      }

      // Update DataTables special `DT_*` attributes for the row
      _fnRowAttributes( settings, row );
    }
  }


  /**
   * Build a data source object from an HTML row, reading the contents of the
   * cells that are in the row.
   *
   * @param {object} settings DataTables settings object
   * @param {node|object} TR element from which to read data or existing row
   *   object from which to re-read the data from the cells
   * @param {int} [colIdx] Optional column index
   * @param {array|object} [d] Data source object. If `colIdx` is given then this
   *   parameter should also be given and will be used to write the data into.
   *   Only the column in question will be written
   * @returns {object} Object with two parameters: `data` the data read, in
   *   document order, and `cells` and array of nodes (they can be useful to the
   *   caller, so rather than needing a second traversal to get them, just return
   *   them from here).
   * @memberof DataTable#oApi
   */
  function _fnGetRowElements( settings, row, colIdx, d )
  {
    var
      tds = [],
      td = row.firstChild,
      name, col, o, i=0, contents,
      columns = settings.aoColumns,
      objectRead = settings._rowReadObject;

    // Allow the data object to be passed in, or construct
    d = d !== undefined ?
      d :
      objectRead ?
        {} :
        [];

    var attr = function ( str, td  ) {
      if ( typeof str === 'string' ) {
        var idx = str.indexOf('@');

        if ( idx !== -1 ) {
          var attr = str.substring( idx+1 );
          var setter = _fnSetObjectDataFn( str );
          setter( d, td.getAttribute( attr ) );
        }
      }
    };

    // Read data from a cell and store into the data object
    var cellProcess = function ( cell ) {
      if ( colIdx === undefined || colIdx === i ) {
        col = columns[i];
        contents = (cell.innerHTML).trim();

        if ( col && col._bAttrSrc ) {
          var setter = _fnSetObjectDataFn( col.mData._ );
          setter( d, contents );

          attr( col.mData.sort, cell );
          attr( col.mData.type, cell );
          attr( col.mData.filter, cell );
        }
        else {
          // Depending on the `data` option for the columns the data can
          // be read to either an object or an array.
          if ( objectRead ) {
            if ( ! col._setter ) {
              // Cache the setter function
              col._setter = _fnSetObjectDataFn( col.mData );
            }
            col._setter( d, contents );
          }
          else {
            d[i] = contents;
          }
        }
      }

      i++;
    };

    if ( td ) {
      // `tr` element was passed in
      while ( td ) {
        name = td.nodeName.toUpperCase();

        if ( name == "TD" || name == "TH" ) {
          cellProcess( td );
          tds.push( td );
        }

        td = td.nextSibling;
      }
    }
    else {
      // Existing row object passed in
      tds = row.anCells;

      for ( var j=0, jen=tds.length ; j<jen ; j++ ) {
        cellProcess( tds[j] );
      }
    }

    // Read the ID from the DOM if present
    var rowNode = row.firstChild ? row : row.nTr;

    if ( rowNode ) {
      var id = rowNode.getAttribute( 'id' );

      if ( id ) {
        _fnSetObjectDataFn( settings.rowId )( d, id );
      }
    }

    return {
      data: d,
      cells: tds
    };
  }
  /**
   * Create a new TR element (and it's TD children) for a row
   *  @param {object} oSettings dataTables settings object
   *  @param {int} iRow Row to consider
   *  @param {node} [nTrIn] TR element to add to the table - optional. If not given,
   *    DataTables will create a row automatically
   *  @param {array} [anTds] Array of TD|TH elements for the row - must be given
   *    if nTr is.
   *  @memberof DataTable#oApi
   */
  function _fnCreateTr ( oSettings, iRow, nTrIn, anTds )
  {
    var
      row = oSettings.aoData[iRow],
      rowData = row._aData,
      cells = [],
      nTr, nTd, oCol,
      i, iLen, create;

    if ( row.nTr === null )
    {
      nTr = nTrIn || document.createElement('tr');

      row.nTr = nTr;
      row.anCells = cells;

      /* Use a private property on the node to allow reserve mapping from the node
			 * to the aoData array for fast look up
			 */
      nTr._DT_RowIndex = iRow;

      /* Special parameters can be given by the data source to be used on the row */
      _fnRowAttributes( oSettings, row );

      /* Process each column */
      for ( i=0, iLen=oSettings.aoColumns.length ; i<iLen ; i++ )
      {
        oCol = oSettings.aoColumns[i];
        create = nTrIn ? false : true;

        nTd = create ? document.createElement( oCol.sCellType ) : anTds[i];
        nTd._DT_CellIndex = {
          row: iRow,
          column: i
        };

        cells.push( nTd );

        // Need to create the HTML if new, or if a rendering function is defined
        if ( create || ((oCol.mRender || oCol.mData !== i) &&
          (!$.isPlainObject(oCol.mData) || oCol.mData._ !== i+'.display')
        )) {
          nTd.innerHTML = _fnGetCellData( oSettings, iRow, i, 'display' );
        }

        /* Add user defined class */
        if ( oCol.sClass )
        {
          nTd.className += ' '+oCol.sClass;
        }

        // Visibility - add or remove as required
        if ( oCol.bVisible && ! nTrIn )
        {
          nTr.appendChild( nTd );
        }
        else if ( ! oCol.bVisible && nTrIn )
        {
          nTd.parentNode.removeChild( nTd );
        }

        if ( oCol.fnCreatedCell )
        {
          oCol.fnCreatedCell.call( oSettings.oInstance,
            nTd, _fnGetCellData( oSettings, iRow, i ), rowData, iRow, i
          );
        }
      }

      _fnCallbackFire( oSettings, 'aoRowCreatedCallback', null, [nTr, rowData, iRow, cells] );
    }
  }


  /**
   * Add attributes to a row based on the special `DT_*` parameters in a data
   * source object.
   *  @param {object} settings DataTables settings object
   *  @param {object} DataTables row object for the row to be modified
   *  @memberof DataTable#oApi
   */
  function _fnRowAttributes( settings, row )
  {
    var tr = row.nTr;
    var data = row._aData;

    if ( tr ) {
      var id = settings.rowIdFn( data );

      if ( id ) {
        tr.id = id;
      }

      if ( data.DT_RowClass ) {
        // Remove any classes added by DT_RowClass before
        var a = data.DT_RowClass.split(' ');
        row.__rowc = row.__rowc ?
          _unique( row.__rowc.concat( a ) ) :
          a;

        $(tr)
          .removeClass( row.__rowc.join(' ') )
          .addClass( data.DT_RowClass );
      }

      if ( data.DT_RowAttr ) {
        $(tr).attr( data.DT_RowAttr );
      }

      if ( data.DT_RowData ) {
        $(tr).data( data.DT_RowData );
      }
    }
  }


  /**
   * Create the HTML header for the table
   *  @param {object} oSettings dataTables settings object
   *  @memberof DataTable#oApi
   */
  function _fnBuildHead( oSettings )
  {
    var i, ien, cell, row, column;
    var thead = oSettings.nTHead;
    var tfoot = oSettings.nTFoot;
    var createHeader = $('th, td', thead).length === 0;
    var classes = oSettings.oClasses;
    var columns = oSettings.aoColumns;

    if ( createHeader ) {
      row = $('<tr/>').appendTo( thead );
    }

    for ( i=0, ien=columns.length ; i<ien ; i++ ) {
      column = columns[i];
      cell = $( column.nTh ).addClass( column.sClass );

      if ( createHeader ) {
        cell.appendTo( row );
      }

      // 1.11 move into sorting
      if ( oSettings.oFeatures.bSort ) {
        cell.addClass( column.sSortingClass );

        if ( column.bSortable !== false ) {
          cell
            .attr( 'tabindex', oSettings.iTabIndex )
            .attr( 'aria-controls', oSettings.sTableId );

          _fnSortAttachListener( oSettings, column.nTh, i );
        }
      }

      if ( column.sTitle != cell[0].innerHTML ) {
        cell.html( column.sTitle );
      }

      _fnRenderer( oSettings, 'header' )(
        oSettings, cell, column, classes
      );
    }

    if ( createHeader ) {
      _fnDetectHeader( oSettings.aoHeader, thead );
    }

    /* Deal with the footer - add classes if required */
    $(thead).children('tr').children('th, td').addClass( classes.sHeaderTH );
    $(tfoot).children('tr').children('th, td').addClass( classes.sFooterTH );

    // Cache the footer cells. Note that we only take the cells from the first
    // row in the footer. If there is more than one row the user wants to
    // interact with, they need to use the table().foot() method. Note also this
    // allows cells to be used for multiple columns using colspan
    if ( tfoot !== null ) {
      var cells = oSettings.aoFooter[0];

      for ( i=0, ien=cells.length ; i<ien ; i++ ) {
        column = columns[i];
        column.nTf = cells[i].cell;

        if ( column.sClass ) {
          $(column.nTf).addClass( column.sClass );
        }
      }
    }
  }


  /**
   * Draw the header (or footer) element based on the column visibility states. The
   * methodology here is to use the layout array from _fnDetectHeader, modified for
   * the instantaneous column visibility, to construct the new layout. The grid is
   * traversed over cell at a time in a rows x columns grid fashion, although each
   * cell insert can cover multiple elements in the grid - which is tracks using the
   * aApplied array. Cell inserts in the grid will only occur where there isn't
   * already a cell in that position.
   *  @param {object} oSettings dataTables settings object
   *  @param array {objects} aoSource Layout array from _fnDetectHeader
   *  @param {boolean} [bIncludeHidden=false] If true then include the hidden columns in the calc,
   *  @memberof DataTable#oApi
   */
  function _fnDrawHead( oSettings, aoSource, bIncludeHidden )
  {
    var i, iLen, j, jLen, k, kLen, n, nLocalTr;
    var aoLocal = [];
    var aApplied = [];
    var iColumns = oSettings.aoColumns.length;
    var iRowspan, iColspan;

    if ( ! aoSource )
    {
      return;
    }

    if (  bIncludeHidden === undefined )
    {
      bIncludeHidden = false;
    }

    /* Make a copy of the master layout array, but without the visible columns in it */
    for ( i=0, iLen=aoSource.length ; i<iLen ; i++ )
    {
      aoLocal[i] = aoSource[i].slice();
      aoLocal[i].nTr = aoSource[i].nTr;

      /* Remove any columns which are currently hidden */
      for ( j=iColumns-1 ; j>=0 ; j-- )
      {
        if ( !oSettings.aoColumns[j].bVisible && !bIncludeHidden )
        {
          aoLocal[i].splice( j, 1 );
        }
      }

      /* Prep the applied array - it needs an element for each row */
      aApplied.push( [] );
    }

    for ( i=0, iLen=aoLocal.length ; i<iLen ; i++ )
    {
      nLocalTr = aoLocal[i].nTr;

      /* All cells are going to be replaced, so empty out the row */
      if ( nLocalTr )
      {
        while( (n = nLocalTr.firstChild) )
        {
          nLocalTr.removeChild( n );
        }
      }

      for ( j=0, jLen=aoLocal[i].length ; j<jLen ; j++ )
      {
        iRowspan = 1;
        iColspan = 1;

        /* Check to see if there is already a cell (row/colspan) covering our target
				 * insert point. If there is, then there is nothing to do.
				 */
        if ( aApplied[i][j] === undefined )
        {
          nLocalTr.appendChild( aoLocal[i][j].cell );
          aApplied[i][j] = 1;

          /* Expand the cell to cover as many rows as needed */
          while ( aoLocal[i+iRowspan] !== undefined &&
          aoLocal[i][j].cell == aoLocal[i+iRowspan][j].cell )
          {
            aApplied[i+iRowspan][j] = 1;
            iRowspan++;
          }

          /* Expand the cell to cover as many columns as needed */
          while ( aoLocal[i][j+iColspan] !== undefined &&
          aoLocal[i][j].cell == aoLocal[i][j+iColspan].cell )
          {
            /* Must update the applied array over the rows for the columns */
            for ( k=0 ; k<iRowspan ; k++ )
            {
              aApplied[i+k][j+iColspan] = 1;
            }
            iColspan++;
          }

          /* Do the actual expansion in the DOM */
          $(aoLocal[i][j].cell)
            .attr('rowspan', iRowspan)
            .attr('colspan', iColspan);
        }
      }
    }
  }


  /**
   * Insert the required TR nodes into the table for display
   *  @param {object} oSettings dataTables settings object
   *  @param ajaxComplete true after ajax call to complete rendering
   *  @memberof DataTable#oApi
   */
  function _fnDraw( oSettings, ajaxComplete )
  {
    // Allow for state saving and a custom start position
    _fnStart( oSettings );

    /* Provide a pre-callback function which can be used to cancel the draw is false is returned */
    var aPreDraw = _fnCallbackFire( oSettings, 'aoPreDrawCallback', 'preDraw', [oSettings] );
    if ( $.inArray( false, aPreDraw ) !== -1 )
    {
      _fnProcessingDisplay( oSettings, false );
      return;
    }

    var anRows = [];
    var iRowCount = 0;
    var asStripeClasses = oSettings.asStripeClasses;
    var iStripes = asStripeClasses.length;
    var oLang = oSettings.oLanguage;
    var bServerSide = _fnDataSource( oSettings ) == 'ssp';
    var aiDisplay = oSettings.aiDisplay;
    var iDisplayStart = oSettings._iDisplayStart;
    var iDisplayEnd = oSettings.fnDisplayEnd();

    oSettings.bDrawing = true;

    /* Server-side processing draw intercept */
    if ( oSettings.bDeferLoading )
    {
      oSettings.bDeferLoading = false;
      oSettings.iDraw++;
      _fnProcessingDisplay( oSettings, false );
    }
    else if ( !bServerSide )
    {
      oSettings.iDraw++;
    }
    else if ( !oSettings.bDestroying && !ajaxComplete)
    {
      _fnAjaxUpdate( oSettings );
      return;
    }

    if ( aiDisplay.length !== 0 )
    {
      var iStart = bServerSide ? 0 : iDisplayStart;
      var iEnd = bServerSide ? oSettings.aoData.length : iDisplayEnd;

      for ( var j=iStart ; j<iEnd ; j++ )
      {
        var iDataIndex = aiDisplay[j];
        var aoData = oSettings.aoData[ iDataIndex ];
        if ( aoData.nTr === null )
        {
          _fnCreateTr( oSettings, iDataIndex );
        }

        var nRow = aoData.nTr;

        /* Remove the old striping classes and then add the new one */
        if ( iStripes !== 0 )
        {
          var sStripe = asStripeClasses[ iRowCount % iStripes ];
          if ( aoData._sRowStripe != sStripe )
          {
            $(nRow).removeClass( aoData._sRowStripe ).addClass( sStripe );
            aoData._sRowStripe = sStripe;
          }
        }

        // Row callback functions - might want to manipulate the row
        // iRowCount and j are not currently documented. Are they at all
        // useful?
        _fnCallbackFire( oSettings, 'aoRowCallback', null,
          [nRow, aoData._aData, iRowCount, j, iDataIndex] );

        anRows.push( nRow );
        iRowCount++;
      }
    }
    else
    {
      /* Table is empty - create a row with an empty message in it */
      var sZero = oLang.sZeroRecords;
      if ( oSettings.iDraw == 1 &&  _fnDataSource( oSettings ) == 'ajax' )
      {
        sZero = oLang.sLoadingRecords;
      }
      else if ( oLang.sEmptyTable && oSettings.fnRecordsTotal() === 0 )
      {
        sZero = oLang.sEmptyTable;
      }

      anRows[ 0 ] = $( '<tr/>', { 'class': iStripes ? asStripeClasses[0] : '' } )
        .append( $('<td />', {
          'valign':  'top',
          'colSpan': _fnVisbleColumns( oSettings ),
          'class':   oSettings.oClasses.sRowEmpty
        } ).html( sZero ) )[0];
    }

    /* Header and footer callbacks */
    _fnCallbackFire( oSettings, 'aoHeaderCallback', 'header', [ $(oSettings.nTHead).children('tr')[0],
      _fnGetDataMaster( oSettings ), iDisplayStart, iDisplayEnd, aiDisplay ] );

    _fnCallbackFire( oSettings, 'aoFooterCallback', 'footer', [ $(oSettings.nTFoot).children('tr')[0],
      _fnGetDataMaster( oSettings ), iDisplayStart, iDisplayEnd, aiDisplay ] );

    var body = $(oSettings.nTBody);

    body.children().detach();
    body.append( $(anRows) );

    /* Call all required callback functions for the end of a draw */
    _fnCallbackFire( oSettings, 'aoDrawCallback', 'draw', [oSettings] );

    /* Draw is complete, sorting and filtering must be as well */
    oSettings.bSorted = false;
    oSettings.bFiltered = false;
    oSettings.bDrawing = false;
  }


  /**
   * Redraw the table - taking account of the various features which are enabled
   *  @param {object} oSettings dataTables settings object
   *  @param {boolean} [holdPosition] Keep the current paging position. By default
   *    the paging is reset to the first page
   *  @memberof DataTable#oApi
   */
  function _fnReDraw( settings, holdPosition )
  {
    var
      features = settings.oFeatures,
      sort     = features.bSort,
      filter   = features.bFilter;

    if ( sort ) {
      _fnSort( settings );
    }

    if ( filter ) {
      _fnFilterComplete( settings, settings.oPreviousSearch );
    }
    else {
      // No filtering, so we want to just use the display master
      settings.aiDisplay = settings.aiDisplayMaster.slice();
    }

    if ( holdPosition !== true ) {
      settings._iDisplayStart = 0;
    }

    // Let any modules know about the draw hold position state (used by
    // scrolling internally)
    settings._drawHold = holdPosition;

    _fnDraw( settings );

    settings._drawHold = false;
  }


  /**
   * Add the options to the page HTML for the table
   *  @param {object} oSettings dataTables settings object
   *  @memberof DataTable#oApi
   */
  function _fnAddOptionsHtml ( oSettings )
  {
    var classes = oSettings.oClasses;
    var table = $(oSettings.nTable);
    var holding = $('<div/>').insertBefore( table ); // Holding element for speed
    var features = oSettings.oFeatures;

    // All DataTables are wrapped in a div
    var insert = $('<div/>', {
      id:      oSettings.sTableId+'_wrapper',
      'class': classes.sWrapper + (oSettings.nTFoot ? '' : ' '+classes.sNoFooter)
    } );

    oSettings.nHolding = holding[0];
    oSettings.nTableWrapper = insert[0];
    oSettings.nTableReinsertBefore = oSettings.nTable.nextSibling;

    /* Loop over the user set positioning and place the elements as needed */
    var aDom = oSettings.sDom.split('');
    var featureNode, cOption, nNewNode, cNext, sAttr, j;
    for ( var i=0 ; i<aDom.length ; i++ )
    {
      featureNode = null;
      cOption = aDom[i];

      if ( cOption == '<' )
      {
        /* New container div */
        nNewNode = $('<div/>')[0];

        /* Check to see if we should append an id and/or a class name to the container */
        cNext = aDom[i+1];
        if ( cNext == "'" || cNext == '"' )
        {
          sAttr = "";
          j = 2;
          while ( aDom[i+j] != cNext )
          {
            sAttr += aDom[i+j];
            j++;
          }

          /* Replace jQuery UI constants @todo depreciated */
          if ( sAttr == "H" )
          {
            sAttr = classes.sJUIHeader;
          }
          else if ( sAttr == "F" )
          {
            sAttr = classes.sJUIFooter;
          }

          /* The attribute can be in the format of "#id.class", "#id" or "class" This logic
					 * breaks the string into parts and applies them as needed
					 */
          if ( sAttr.indexOf('.') != -1 )
          {
            var aSplit = sAttr.split('.');
            nNewNode.id = aSplit[0].substr(1, aSplit[0].length-1);
            nNewNode.className = aSplit[1];
          }
          else if ( sAttr.charAt(0) == "#" )
          {
            nNewNode.id = sAttr.substr(1, sAttr.length-1);
          }
          else
          {
            nNewNode.className = sAttr;
          }

          i += j; /* Move along the position array */
        }

        insert.append( nNewNode );
        insert = $(nNewNode);
      }
      else if ( cOption == '>' )
      {
        /* End container div */
        insert = insert.parent();
      }
      // @todo Move options into their own plugins?
      else if ( cOption == 'l' && features.bPaginate && features.bLengthChange )
      {
        /* Length */
        featureNode = _fnFeatureHtmlLength( oSettings );
      }
      else if ( cOption == 'f' && features.bFilter )
      {
        /* Filter */
        featureNode = _fnFeatureHtmlFilter( oSettings );
      }
      else if ( cOption == 'r' && features.bProcessing )
      {
        /* pRocessing */
        featureNode = _fnFeatureHtmlProcessing( oSettings );
      }
      else if ( cOption == 't' )
      {
        /* Table */
        featureNode = _fnFeatureHtmlTable( oSettings );
      }
      else if ( cOption ==  'i' && features.bInfo )
      {
        /* Info */
        featureNode = _fnFeatureHtmlInfo( oSettings );
      }
      else if ( cOption == 'p' && features.bPaginate )
      {
        /* Pagination */
        featureNode = _fnFeatureHtmlPaginate( oSettings );
      }
      else if ( DataTable.ext.feature.length !== 0 )
      {
        /* Plug-in features */
        var aoFeatures = DataTable.ext.feature;
        for ( var k=0, kLen=aoFeatures.length ; k<kLen ; k++ )
        {
          if ( cOption == aoFeatures[k].cFeature )
          {
            featureNode = aoFeatures[k].fnInit( oSettings );
            break;
          }
        }
      }

      /* Add to the 2D features array */
      if ( featureNode )
      {
        var aanFeatures = oSettings.aanFeatures;

        if ( ! aanFeatures[cOption] )
        {
          aanFeatures[cOption] = [];
        }

        aanFeatures[cOption].push( featureNode );
        insert.append( featureNode );
      }
    }

    /* Built our DOM structure - replace the holding div with what we want */
    holding.replaceWith( insert );
    oSettings.nHolding = null;
  }


  /**
   * Use the DOM source to create up an array of header cells. The idea here is to
   * create a layout grid (array) of rows x columns, which contains a reference
   * to the cell that that point in the grid (regardless of col/rowspan), such that
   * any column / row could be removed and the new grid constructed
   *  @param array {object} aLayout Array to store the calculated layout in
   *  @param {node} nThead The header/footer element for the table
   *  @memberof DataTable#oApi
   */
  function _fnDetectHeader ( aLayout, nThead )
  {
    var nTrs = $(nThead).children('tr');
    var nTr, nCell;
    var i, k, l, iLen, jLen, iColShifted, iColumn, iColspan, iRowspan;
    var bUnique;
    var fnShiftCol = function ( a, i, j ) {
      var k = a[i];
      while ( k[j] ) {
        j++;
      }
      return j;
    };

    aLayout.splice( 0, aLayout.length );

    /* We know how many rows there are in the layout - so prep it */
    for ( i=0, iLen=nTrs.length ; i<iLen ; i++ )
    {
      aLayout.push( [] );
    }

    /* Calculate a layout array */
    for ( i=0, iLen=nTrs.length ; i<iLen ; i++ )
    {
      nTr = nTrs[i];
      iColumn = 0;

      /* For every cell in the row... */
      nCell = nTr.firstChild;
      while ( nCell ) {
        if ( nCell.nodeName.toUpperCase() == "TD" ||
          nCell.nodeName.toUpperCase() == "TH" )
        {
          /* Get the col and rowspan attributes from the DOM and sanitise them */
          iColspan = nCell.getAttribute('colspan') * 1;
          iRowspan = nCell.getAttribute('rowspan') * 1;
          iColspan = (!iColspan || iColspan===0 || iColspan===1) ? 1 : iColspan;
          iRowspan = (!iRowspan || iRowspan===0 || iRowspan===1) ? 1 : iRowspan;

          /* There might be colspan cells already in this row, so shift our target
					 * accordingly
					 */
          iColShifted = fnShiftCol( aLayout, i, iColumn );

          /* Cache calculation for unique columns */
          bUnique = iColspan === 1 ? true : false;

          /* If there is col / rowspan, copy the information into the layout grid */
          for ( l=0 ; l<iColspan ; l++ )
          {
            for ( k=0 ; k<iRowspan ; k++ )
            {
              aLayout[i+k][iColShifted+l] = {
                "cell": nCell,
                "unique": bUnique
              };
              aLayout[i+k].nTr = nTr;
            }
          }
        }
        nCell = nCell.nextSibling;
      }
    }
  }


  /**
   * Get an array of unique th elements, one for each column
   *  @param {object} oSettings dataTables settings object
   *  @param {node} nHeader automatically detect the layout from this node - optional
   *  @param {array} aLayout thead/tfoot layout from _fnDetectHeader - optional
   *  @returns array {node} aReturn list of unique th's
   *  @memberof DataTable#oApi
   */
  function _fnGetUniqueThs ( oSettings, nHeader, aLayout )
  {
    var aReturn = [];
    if ( !aLayout )
    {
      aLayout = oSettings.aoHeader;
      if ( nHeader )
      {
        aLayout = [];
        _fnDetectHeader( aLayout, nHeader );
      }
    }

    for ( var i=0, iLen=aLayout.length ; i<iLen ; i++ )
    {
      for ( var j=0, jLen=aLayout[i].length ; j<jLen ; j++ )
      {
        if ( aLayout[i][j].unique &&
          (!aReturn[j] || !oSettings.bSortCellsTop) )
        {
          aReturn[j] = aLayout[i][j].cell;
        }
      }
    }

    return aReturn;
  }

  /**
   * Set the start position for draw
   *  @param {object} oSettings dataTables settings object
   */
  function _fnStart( oSettings )
  {
    var bServerSide = _fnDataSource( oSettings ) == 'ssp';
    var iInitDisplayStart = oSettings.iInitDisplayStart;

    // Check and see if we have an initial draw position from state saving
    if ( iInitDisplayStart !== undefined && iInitDisplayStart !== -1 )
    {
      oSettings._iDisplayStart = bServerSide ?
        iInitDisplayStart :
        iInitDisplayStart >= oSettings.fnRecordsDisplay() ?
          0 :
          iInitDisplayStart;

      oSettings.iInitDisplayStart = -1;
    }
  }

  /**
   * Create an Ajax call based on the table's settings, taking into account that
   * parameters can have multiple forms, and backwards compatibility.
   *
   * @param {object} oSettings dataTables settings object
   * @param {array} data Data to send to the server, required by
   *     DataTables - may be augmented by developer callbacks
   * @param {function} fn Callback function to run when data is obtained
   */
  function _fnBuildAjax( oSettings, data, fn )
  {
    // Compatibility with 1.9-, allow fnServerData and event to manipulate
    _fnCallbackFire( oSettings, 'aoServerParams', 'serverParams', [data] );

    // Convert to object based for 1.10+ if using the old array scheme which can
    // come from server-side processing or serverParams
    if ( data && Array.isArray(data) ) {
      var tmp = {};
      var rbracket = /(.*?)\[\]$/;

      $.each( data, function (key, val) {
        var match = val.name.match(rbracket);

        if ( match ) {
          // Support for arrays
          var name = match[0];

          if ( ! tmp[ name ] ) {
            tmp[ name ] = [];
          }
          tmp[ name ].push( val.value );
        }
        else {
          tmp[val.name] = val.value;
        }
      } );
      data = tmp;
    }

    var ajaxData;
    var ajax = oSettings.ajax;
    var instance = oSettings.oInstance;
    var callback = function ( json ) {
      var status = oSettings.jqXHR
        ? oSettings.jqXHR.status
        : null;

      if ( json === null || (typeof status === 'number' && status == 204 ) ) {
        json = {};
        _fnAjaxDataSrc( oSettings, json, [] );
      }

      var error = json.error || json.sError;
      if ( error ) {
        _fnLog( oSettings, 0, error );
      }

      oSettings.json = json;

      _fnCallbackFire( oSettings, null, 'xhr', [oSettings, json, oSettings.jqXHR] );
      fn( json );
    };

    if ( $.isPlainObject( ajax ) && ajax.data )
    {
      ajaxData = ajax.data;

      var newData = typeof ajaxData === 'function' ?
        ajaxData( data, oSettings ) :  // fn can manipulate data or return
        ajaxData;                      // an object object or array to merge

      // If the function returned something, use that alone
      data = typeof ajaxData === 'function' && newData ?
        newData :
        $.extend( true, data, newData );

      // Remove the data property as we've resolved it already and don't want
      // jQuery to do it again (it is restored at the end of the function)
      delete ajax.data;
    }

    var baseAjax = {
      "data": data,
      "success": callback,
      "dataType": "json",
      "cache": false,
      "type": oSettings.sServerMethod,
      "error": function (xhr, error, thrown) {
        var ret = _fnCallbackFire( oSettings, null, 'xhr', [oSettings, null, oSettings.jqXHR] );

        if ( $.inArray( true, ret ) === -1 ) {
          if ( error == "parsererror" ) {
            _fnLog( oSettings, 0, 'Invalid JSON response', 1 );
          }
          else if ( xhr.readyState === 4 ) {
            _fnLog( oSettings, 0, 'Ajax error', 7 );
          }
        }

        _fnProcessingDisplay( oSettings, false );
      }
    };

    // Store the data submitted for the API
    oSettings.oAjaxData = data;

    // Allow plug-ins and external processes to modify the data
    _fnCallbackFire( oSettings, null, 'preXhr', [oSettings, data] );

    if ( oSettings.fnServerData )
    {
      // DataTables 1.9- compatibility
      oSettings.fnServerData.call( instance,
        oSettings.sAjaxSource,
        $.map( data, function (val, key) { // Need to convert back to 1.9 trad format
          return { name: key, value: val };
        } ),
        callback,
        oSettings
      );
    }
    else if ( oSettings.sAjaxSource || typeof ajax === 'string' )
    {
      // DataTables 1.9- compatibility
      oSettings.jqXHR = $.ajax( $.extend( baseAjax, {
        url: ajax || oSettings.sAjaxSource
      } ) );
    }
    else if ( typeof ajax === 'function' )
    {
      // Is a function - let the caller define what needs to be done
      oSettings.jqXHR = ajax.call( instance, data, callback, oSettings );
    }
    else
    {
      // Object to extend the base settings
      oSettings.jqXHR = $.ajax( $.extend( baseAjax, ajax ) );

      // Restore for next time around
      ajax.data = ajaxData;
    }
  }


  /**
   * Update the table using an Ajax call
   *  @param {object} settings dataTables settings object
   *  @returns {boolean} Block the table drawing or not
   *  @memberof DataTable#oApi
   */
  function _fnAjaxUpdate( settings )
  {
    settings.iDraw++;
    _fnProcessingDisplay( settings, true );

    _fnBuildAjax(
      settings,
      _fnAjaxParameters( settings ),
      function(json) {
        _fnAjaxUpdateDraw( settings, json );
      }
    );
  }


  /**
   * Build up the parameters in an object needed for a server-side processing
   * request. Note that this is basically done twice, is different ways - a modern
   * method which is used by default in DataTables 1.10 which uses objects and
   * arrays, or the 1.9- method with is name / value pairs. 1.9 method is used if
   * the sAjaxSource option is used in the initialisation, or the legacyAjax
   * option is set.
   *  @param {object} oSettings dataTables settings object
   *  @returns {bool} block the table drawing or not
   *  @memberof DataTable#oApi
   */
  function _fnAjaxParameters( settings )
  {
    var
      columns = settings.aoColumns,
      columnCount = columns.length,
      features = settings.oFeatures,
      preSearch = settings.oPreviousSearch,
      preColSearch = settings.aoPreSearchCols,
      i, data = [], dataProp, column, columnSearch,
      sort = _fnSortFlatten( settings ),
      displayStart = settings._iDisplayStart,
      displayLength = features.bPaginate !== false ?
        settings._iDisplayLength :
        -1;

    var param = function ( name, value ) {
      data.push( { 'name': name, 'value': value } );
    };

    // DataTables 1.9- compatible method
    param( 'sEcho',          settings.iDraw );
    param( 'iColumns',       columnCount );
    param( 'sColumns',       _pluck( columns, 'sName' ).join(',') );
    param( 'iDisplayStart',  displayStart );
    param( 'iDisplayLength', displayLength );

    // DataTables 1.10+ method
    var d = {
      draw:    settings.iDraw,
      columns: [],
      order:   [],
      start:   displayStart,
      length:  displayLength,
      search:  {
        value: preSearch.sSearch,
        regex: preSearch.bRegex
      }
    };

    for ( i=0 ; i<columnCount ; i++ ) {
      column = columns[i];
      columnSearch = preColSearch[i];
      dataProp = typeof column.mData=="function" ? 'function' : column.mData ;

      d.columns.push( {
        data:       dataProp,
        name:       column.sName,
        searchable: column.bSearchable,
        orderable:  column.bSortable,
        search:     {
          value: columnSearch.sSearch,
          regex: columnSearch.bRegex
        }
      } );

      param( "mDataProp_"+i, dataProp );

      if ( features.bFilter ) {
        param( 'sSearch_'+i,     columnSearch.sSearch );
        param( 'bRegex_'+i,      columnSearch.bRegex );
        param( 'bSearchable_'+i, column.bSearchable );
      }

      if ( features.bSort ) {
        param( 'bSortable_'+i, column.bSortable );
      }
    }

    if ( features.bFilter ) {
      param( 'sSearch', preSearch.sSearch );
      param( 'bRegex', preSearch.bRegex );
    }

    if ( features.bSort ) {
      $.each( sort, function ( i, val ) {
        d.order.push( { column: val.col, dir: val.dir } );

        param( 'iSortCol_'+i, val.col );
        param( 'sSortDir_'+i, val.dir );
      } );

      param( 'iSortingCols', sort.length );
    }

    // If the legacy.ajax parameter is null, then we automatically decide which
    // form to use, based on sAjaxSource
    var legacy = DataTable.ext.legacy.ajax;
    if ( legacy === null ) {
      return settings.sAjaxSource ? data : d;
    }

    // Otherwise, if legacy has been specified then we use that to decide on the
    // form
    return legacy ? data : d;
  }


  /**
   * Data the data from the server (nuking the old) and redraw the table
   *  @param {object} oSettings dataTables settings object
   *  @param {object} json json data return from the server.
   *  @param {string} json.sEcho Tracking flag for DataTables to match requests
   *  @param {int} json.iTotalRecords Number of records in the data set, not accounting for filtering
   *  @param {int} json.iTotalDisplayRecords Number of records in the data set, accounting for filtering
   *  @param {array} json.aaData The data to display on this page
   *  @param {string} [json.sColumns] Column ordering (sName, comma separated)
   *  @memberof DataTable#oApi
   */
  function _fnAjaxUpdateDraw ( settings, json )
  {
    // v1.10 uses camelCase variables, while 1.9 uses Hungarian notation.
    // Support both
    var compat = function ( old, modern ) {
      return json[old] !== undefined ? json[old] : json[modern];
    };

    var data = _fnAjaxDataSrc( settings, json );
    var draw            = compat( 'sEcho',                'draw' );
    var recordsTotal    = compat( 'iTotalRecords',        'recordsTotal' );
    var recordsFiltered = compat( 'iTotalDisplayRecords', 'recordsFiltered' );

    if ( draw !== undefined ) {
      // Protect against out of sequence returns
      if ( draw*1 < settings.iDraw ) {
        return;
      }
      settings.iDraw = draw * 1;
    }

    // No data in returned object, so rather than an array, we show an empty table
    if ( ! data ) {
      data = [];
    }

    _fnClearTable( settings );
    settings._iRecordsTotal   = parseInt(recordsTotal, 10);
    settings._iRecordsDisplay = parseInt(recordsFiltered, 10);

    for ( var i=0, ien=data.length ; i<ien ; i++ ) {
      _fnAddData( settings, data[i] );
    }
    settings.aiDisplay = settings.aiDisplayMaster.slice();

    _fnDraw( settings, true );

    if ( ! settings._bInitComplete ) {
      _fnInitComplete( settings, json );
    }

    _fnProcessingDisplay( settings, false );
  }


  /**
   * Get the data from the JSON data source to use for drawing a table. Using
   * `_fnGetObjectDataFn` allows the data to be sourced from a property of the
   * source object, or from a processing function.
   *  @param {object} oSettings dataTables settings object
   *  @param  {object} json Data source object / array from the server
   *  @return {array} Array of data to use
   */
  function _fnAjaxDataSrc ( oSettings, json, write )
  {
    var dataSrc = $.isPlainObject( oSettings.ajax ) && oSettings.ajax.dataSrc !== undefined ?
      oSettings.ajax.dataSrc :
      oSettings.sAjaxDataProp; // Compatibility with 1.9-.

    if ( ! write ) {
      if ( dataSrc === 'data' ) {
        // If the default, then we still want to support the old style, and safely ignore
        // it if possible
        return json.aaData || json[dataSrc];
      }

      return dataSrc !== "" ?
        _fnGetObjectDataFn( dataSrc )( json ) :
        json;
    }

    // set
    _fnSetObjectDataFn( dataSrc )( json, write );
  }

  /**
   * Generate the node required for filtering text
   *  @returns {node} Filter control element
   *  @param {object} oSettings dataTables settings object
   *  @memberof DataTable#oApi
   */
  function _fnFeatureHtmlFilter ( settings )
  {
    var classes = settings.oClasses;
    var tableId = settings.sTableId;
    var language = settings.oLanguage;
    var previousSearch = settings.oPreviousSearch;
    var features = settings.aanFeatures;
    var input = '<input type="search" class="'+classes.sFilterInput+'"/>';

    var str = language.sSearch;
    str = str.match(/_INPUT_/) ?
      str.replace('_INPUT_', input) :
      str+input;

    var filter = $('<div/>', {
      'id': ! features.f ? tableId+'_filter' : null,
      'class': classes.sFilter
    } )
      .append( $('<label/>' ).append( str ) );

    var searchFn = function(event) {
      /* Update all other filter input elements for the new display */
      var n = features.f;
      var val = !this.value ? "" : this.value; // mental IE8 fix :-(
      if(previousSearch.return && event.key !== "Enter") {
        return;
      }
      /* Now do the filter */
      if ( val != previousSearch.sSearch ) {
        _fnFilterComplete( settings, {
          "sSearch": val,
          "bRegex": previousSearch.bRegex,
          "bSmart": previousSearch.bSmart ,
          "bCaseInsensitive": previousSearch.bCaseInsensitive,
          "return": previousSearch.return
        } );

        // Need to redraw, without resorting
        settings._iDisplayStart = 0;
        _fnDraw( settings );
      }
    };

    var searchDelay = settings.searchDelay !== null ?
      settings.searchDelay :
      _fnDataSource( settings ) === 'ssp' ?
        400 :
        0;

    var jqFilter = $('input', filter)
      .val( previousSearch.sSearch )
      .attr( 'placeholder', language.sSearchPlaceholder )
      .on(
        'keyup.DT search.DT input.DT paste.DT cut.DT',
        searchDelay ?
          _fnThrottle( searchFn, searchDelay ) :
          searchFn
      )
      .on( 'mouseup', function(e) {
        // Edge fix! Edge 17 does not trigger anything other than mouse events when clicking
        // on the clear icon (Edge bug 17584515). This is safe in other browsers as `searchFn`
        // checks the value to see if it has changed. In other browsers it won't have.
        setTimeout( function () {
          searchFn.call(jqFilter[0], e);
        }, 10);
      } )
      .on( 'keypress.DT', function(e) {
        /* Prevent form submission */
        if ( e.keyCode == 13 ) {
          return false;
        }
      } )
      .attr('aria-controls', tableId);

    // Update the input elements whenever the table is filtered
    $(settings.nTable).on( 'search.dt.DT', function ( ev, s ) {
      if ( settings === s ) {
        // IE9 throws an 'unknown error' if document.activeElement is used
        // inside an iframe or frame...
        try {
          if ( jqFilter[0] !== document.activeElement ) {
            jqFilter.val( previousSearch.sSearch );
          }
        }
        catch ( e ) {}
      }
    } );

    return filter[0];
  }


  /**
   * Filter the table using both the global filter and column based filtering
   *  @param {object} oSettings dataTables settings object
   *  @param {object} oSearch search information
   *  @param {int} [iForce] force a research of the master array (1) or not (undefined or 0)
   *  @memberof DataTable#oApi
   */
  function _fnFilterComplete ( oSettings, oInput, iForce )
  {
    var oPrevSearch = oSettings.oPreviousSearch;
    var aoPrevSearch = oSettings.aoPreSearchCols;
    var fnSaveFilter = function ( oFilter ) {
      /* Save the filtering values */
      oPrevSearch.sSearch = oFilter.sSearch;
      oPrevSearch.bRegex = oFilter.bRegex;
      oPrevSearch.bSmart = oFilter.bSmart;
      oPrevSearch.bCaseInsensitive = oFilter.bCaseInsensitive;
      oPrevSearch.return = oFilter.return;
    };
    var fnRegex = function ( o ) {
      // Backwards compatibility with the bEscapeRegex option
      return o.bEscapeRegex !== undefined ? !o.bEscapeRegex : o.bRegex;
    };

    // Resolve any column types that are unknown due to addition or invalidation
    // @todo As per sort - can this be moved into an event handler?
    _fnColumnTypes( oSettings );

    /* In server-side processing all filtering is done by the server, so no point hanging around here */
    if ( _fnDataSource( oSettings ) != 'ssp' )
    {
      /* Global filter */
      _fnFilter( oSettings, oInput.sSearch, iForce, fnRegex(oInput), oInput.bSmart, oInput.bCaseInsensitive, oInput.return );
      fnSaveFilter( oInput );

      /* Now do the individual column filter */
      for ( var i=0 ; i<aoPrevSearch.length ; i++ )
      {
        _fnFilterColumn( oSettings, aoPrevSearch[i].sSearch, i, fnRegex(aoPrevSearch[i]),
          aoPrevSearch[i].bSmart, aoPrevSearch[i].bCaseInsensitive );
      }

      /* Custom filtering */
      _fnFilterCustom( oSettings );
    }
    else
    {
      fnSaveFilter( oInput );
    }

    /* Tell the draw function we have been filtering */
    oSettings.bFiltered = true;
    _fnCallbackFire( oSettings, null, 'search', [oSettings] );
  }


  /**
   * Apply custom filtering functions
   *  @param {object} oSettings dataTables settings object
   *  @memberof DataTable#oApi
   */
  function _fnFilterCustom( settings )
  {
    var filters = DataTable.ext.search;
    var displayRows = settings.aiDisplay;
    var row, rowIdx;

    for ( var i=0, ien=filters.length ; i<ien ; i++ ) {
      var rows = [];

      // Loop over each row and see if it should be included
      for ( var j=0, jen=displayRows.length ; j<jen ; j++ ) {
        rowIdx = displayRows[ j ];
        row = settings.aoData[ rowIdx ];

        if ( filters[i]( settings, row._aFilterData, rowIdx, row._aData, j ) ) {
          rows.push( rowIdx );
        }
      }

      // So the array reference doesn't break set the results into the
      // existing array
      displayRows.length = 0;
      $.merge( displayRows, rows );
    }
  }


  /**
   * Filter the table on a per-column basis
   *  @param {object} oSettings dataTables settings object
   *  @param {string} sInput string to filter on
   *  @param {int} iColumn column to filter
   *  @param {bool} bRegex treat search string as a regular expression or not
   *  @param {bool} bSmart use smart filtering or not
   *  @param {bool} bCaseInsensitive Do case insensitive matching or not
   *  @memberof DataTable#oApi
   */
  function _fnFilterColumn ( settings, searchStr, colIdx, regex, smart, caseInsensitive )
  {
    if ( searchStr === '' ) {
      return;
    }

    var data;
    var out = [];
    var display = settings.aiDisplay;
    var rpSearch = _fnFilterCreateSearch( searchStr, regex, smart, caseInsensitive );

    for ( var i=0 ; i<display.length ; i++ ) {
      data = settings.aoData[ display[i] ]._aFilterData[ colIdx ];

      if ( rpSearch.test( data ) ) {
        out.push( display[i] );
      }
    }

    settings.aiDisplay = out;
  }


  /**
   * Filter the data table based on user input and draw the table
   *  @param {object} settings dataTables settings object
   *  @param {string} input string to filter on
   *  @param {int} force optional - force a research of the master array (1) or not (undefined or 0)
   *  @param {bool} regex treat as a regular expression or not
   *  @param {bool} smart perform smart filtering or not
   *  @param {bool} caseInsensitive Do case insensitive matching or not
   *  @memberof DataTable#oApi
   */
  function _fnFilter( settings, input, force, regex, smart, caseInsensitive )
  {
    var rpSearch = _fnFilterCreateSearch( input, regex, smart, caseInsensitive );
    var prevSearch = settings.oPreviousSearch.sSearch;
    var displayMaster = settings.aiDisplayMaster;
    var display, invalidated, i;
    var filtered = [];

    // Need to take account of custom filtering functions - always filter
    if ( DataTable.ext.search.length !== 0 ) {
      force = true;
    }

    // Check if any of the rows were invalidated
    invalidated = _fnFilterData( settings );

    // If the input is blank - we just want the full data set
    if ( input.length <= 0 ) {
      settings.aiDisplay = displayMaster.slice();
    }
    else {
      // New search - start from the master array
      if ( invalidated ||
        force ||
        regex ||
        prevSearch.length > input.length ||
        input.indexOf(prevSearch) !== 0 ||
        settings.bSorted // On resort, the display master needs to be
                         // re-filtered since indexes will have changed
      ) {
        settings.aiDisplay = displayMaster.slice();
      }

      // Search the display array
      display = settings.aiDisplay;

      for ( i=0 ; i<display.length ; i++ ) {
        if ( rpSearch.test( settings.aoData[ display[i] ]._sFilterRow ) ) {
          filtered.push( display[i] );
        }
      }

      settings.aiDisplay = filtered;
    }
  }


  /**
   * Build a regular expression object suitable for searching a table
   *  @param {string} sSearch string to search for
   *  @param {bool} bRegex treat as a regular expression or not
   *  @param {bool} bSmart perform smart filtering or not
   *  @param {bool} bCaseInsensitive Do case insensitive matching or not
   *  @returns {RegExp} constructed object
   *  @memberof DataTable#oApi
   */
  function _fnFilterCreateSearch( search, regex, smart, caseInsensitive )
  {
    search = regex ?
      search :
      _fnEscapeRegex( search );

    if ( smart ) {
      /* For smart filtering we want to allow the search to work regardless of
			 * word order. We also want double quoted text to be preserved, so word
			 * order is important - a la google. So this is what we want to
			 * generate:
			 *
			 * ^(?=.*?\bone\b)(?=.*?\btwo three\b)(?=.*?\bfour\b).*$
			 */
      var a = $.map( search.match( /"[^"]+"|[^ ]+/g ) || [''], function ( word ) {
        if ( word.charAt(0) === '"' ) {
          var m = word.match( /^"(.*)"$/ );
          word = m ? m[1] : word;
        }

        return word.replace('"', '');
      } );

      search = '^(?=.*?'+a.join( ')(?=.*?' )+').*$';
    }

    return new RegExp( search, caseInsensitive ? 'i' : '' );
  }


  /**
   * Escape a string such that it can be used in a regular expression
   *  @param {string} sVal string to escape
   *  @returns {string} escaped string
   *  @memberof DataTable#oApi
   */
  var _fnEscapeRegex = DataTable.util.escapeRegex;

  var __filter_div = $('<div>')[0];
  var __filter_div_textContent = __filter_div.textContent !== undefined;

  // Update the filtering data for each row if needed (by invalidation or first run)
  function _fnFilterData ( settings )
  {
    var columns = settings.aoColumns;
    var column;
    var i, j, ien, jen, filterData, cellData, row;
    var wasInvalidated = false;

    for ( i=0, ien=settings.aoData.length ; i<ien ; i++ ) {
      row = settings.aoData[i];

      if ( ! row._aFilterData ) {
        filterData = [];

        for ( j=0, jen=columns.length ; j<jen ; j++ ) {
          column = columns[j];

          if ( column.bSearchable ) {
            cellData = _fnGetCellData( settings, i, j, 'filter' );

            // Search in DataTables 1.10 is string based. In 1.11 this
            // should be altered to also allow strict type checking.
            if ( cellData === null ) {
              cellData = '';
            }

            if ( typeof cellData !== 'string' && cellData.toString ) {
              cellData = cellData.toString();
            }
          }
          else {
            cellData = '';
          }

          // If it looks like there is an HTML entity in the string,
          // attempt to decode it so sorting works as expected. Note that
          // we could use a single line of jQuery to do this, but the DOM
          // method used here is much faster http://jsperf.com/html-decode
          if ( cellData.indexOf && cellData.indexOf('&') !== -1 ) {
            __filter_div.innerHTML = cellData;
            cellData = __filter_div_textContent ?
              __filter_div.textContent :
              __filter_div.innerText;
          }

          if ( cellData.replace ) {
            cellData = cellData.replace(/[\r\n\u2028]/g, '');
          }

          filterData.push( cellData );
        }

        row._aFilterData = filterData;
        row._sFilterRow = filterData.join('  ');
        wasInvalidated = true;
      }
    }

    return wasInvalidated;
  }


  /**
   * Convert from the internal Hungarian notation to camelCase for external
   * interaction
   *  @param {object} obj Object to convert
   *  @returns {object} Inverted object
   *  @memberof DataTable#oApi
   */
  function _fnSearchToCamel ( obj )
  {
    return {
      search:          obj.sSearch,
      smart:           obj.bSmart,
      regex:           obj.bRegex,
      caseInsensitive: obj.bCaseInsensitive
    };
  }



  /**
   * Convert from camelCase notation to the internal Hungarian. We could use the
   * Hungarian convert function here, but this is cleaner
   *  @param {object} obj Object to convert
   *  @returns {object} Inverted object
   *  @memberof DataTable#oApi
   */
  function _fnSearchToHung ( obj )
  {
    return {
      sSearch:          obj.search,
      bSmart:           obj.smart,
      bRegex:           obj.regex,
      bCaseInsensitive: obj.caseInsensitive
    };
  }

  /**
   * Generate the node required for the info display
   *  @param {object} oSettings dataTables settings object
   *  @returns {node} Information element
   *  @memberof DataTable#oApi
   */
  function _fnFeatureHtmlInfo ( settings )
  {
    var
      tid = settings.sTableId,
      nodes = settings.aanFeatures.i,
      n = $('<div/>', {
        'class': settings.oClasses.sInfo,
        'id': ! nodes ? tid+'_info' : null
      } );

    if ( ! nodes ) {
      // Update display on each draw
      settings.aoDrawCallback.push( {
        "fn": _fnUpdateInfo,
        "sName": "information"
      } );

      n
        .attr( 'role', 'status' )
        .attr( 'aria-live', 'polite' );

      // Table is described by our info div
      $(settings.nTable).attr( 'aria-describedby', tid+'_info' );
    }

    return n[0];
  }


  /**
   * Update the information elements in the display
   *  @param {object} settings dataTables settings object
   *  @memberof DataTable#oApi
   */
  function _fnUpdateInfo ( settings )
  {
    /* Show information about the table */
    var nodes = settings.aanFeatures.i;
    if ( nodes.length === 0 ) {
      return;
    }

    var
      lang  = settings.oLanguage,
      start = settings._iDisplayStart+1,
      end   = settings.fnDisplayEnd(),
      max   = settings.fnRecordsTotal(),
      total = settings.fnRecordsDisplay(),
      out   = total ?
        lang.sInfo :
        lang.sInfoEmpty;

    if ( total !== max ) {
      /* Record set after filtering */
      out += ' ' + lang.sInfoFiltered;
    }

    // Convert the macros
    out += lang.sInfoPostFix;
    out = _fnInfoMacros( settings, out );

    var callback = lang.fnInfoCallback;
    if ( callback !== null ) {
      out = callback.call( settings.oInstance,
        settings, start, end, max, total, out
      );
    }

    $(nodes).html( out );
  }


  function _fnInfoMacros ( settings, str )
  {
    // When infinite scrolling, we are always starting at 1. _iDisplayStart is used only
    // internally
    var
      formatter  = settings.fnFormatNumber,
      start      = settings._iDisplayStart+1,
      len        = settings._iDisplayLength,
      vis        = settings.fnRecordsDisplay(),
      all        = len === -1;

    return str.
    replace(/_START_/g, formatter.call( settings, start ) ).
    replace(/_END_/g,   formatter.call( settings, settings.fnDisplayEnd() ) ).
    replace(/_MAX_/g,   formatter.call( settings, settings.fnRecordsTotal() ) ).
    replace(/_TOTAL_/g, formatter.call( settings, vis ) ).
    replace(/_PAGE_/g,  formatter.call( settings, all ? 1 : Math.ceil( start / len ) ) ).
    replace(/_PAGES_/g, formatter.call( settings, all ? 1 : Math.ceil( vis / len ) ) );
  }



  /**
   * Draw the table for the first time, adding all required features
   *  @param {object} settings dataTables settings object
   *  @memberof DataTable#oApi
   */
  function _fnInitialise ( settings )
  {
    var i, iLen, iAjaxStart=settings.iInitDisplayStart;
    var columns = settings.aoColumns, column;
    var features = settings.oFeatures;
    var deferLoading = settings.bDeferLoading; // value modified by the draw

    /* Ensure that the table data is fully initialised */
    if ( ! settings.bInitialised ) {
      setTimeout( function(){ _fnInitialise( settings ); }, 200 );
      return;
    }

    /* Show the display HTML options */
    _fnAddOptionsHtml( settings );

    /* Build and draw the header / footer for the table */
    _fnBuildHead( settings );
    _fnDrawHead( settings, settings.aoHeader );
    _fnDrawHead( settings, settings.aoFooter );

    /* Okay to show that something is going on now */
    _fnProcessingDisplay( settings, true );

    /* Calculate sizes for columns */
    if ( features.bAutoWidth ) {
      _fnCalculateColumnWidths( settings );
    }

    for ( i=0, iLen=columns.length ; i<iLen ; i++ ) {
      column = columns[i];

      if ( column.sWidth ) {
        column.nTh.style.width = _fnStringToCss( column.sWidth );
      }
    }

    _fnCallbackFire( settings, null, 'preInit', [settings] );

    // If there is default sorting required - let's do it. The sort function
    // will do the drawing for us. Otherwise we draw the table regardless of the
    // Ajax source - this allows the table to look initialised for Ajax sourcing
    // data (show 'loading' message possibly)
    _fnReDraw( settings );

    // Server-side processing init complete is done by _fnAjaxUpdateDraw
    var dataSrc = _fnDataSource( settings );
    if ( dataSrc != 'ssp' || deferLoading ) {
      // if there is an ajax source load the data
      if ( dataSrc == 'ajax' ) {
        _fnBuildAjax( settings, [], function(json) {
          var aData = _fnAjaxDataSrc( settings, json );

          // Got the data - add it to the table
          for ( i=0 ; i<aData.length ; i++ ) {
            _fnAddData( settings, aData[i] );
          }

          // Reset the init display for cookie saving. We've already done
          // a filter, and therefore cleared it before. So we need to make
          // it appear 'fresh'
          settings.iInitDisplayStart = iAjaxStart;

          _fnReDraw( settings );

          _fnProcessingDisplay( settings, false );
          _fnInitComplete( settings, json );
        }, settings );
      }
      else {
        _fnProcessingDisplay( settings, false );
        _fnInitComplete( settings );
      }
    }
  }


  /**
   * Draw the table for the first time, adding all required features
   *  @param {object} oSettings dataTables settings object
   *  @param {object} [json] JSON from the server that completed the table, if using Ajax source
   *    with client-side processing (optional)
   *  @memberof DataTable#oApi
   */
  function _fnInitComplete ( settings, json )
  {
    settings._bInitComplete = true;

    // When data was added after the initialisation (data or Ajax) we need to
    // calculate the column sizing
    if ( json || settings.oInit.aaData ) {
      _fnAdjustColumnSizing( settings );
    }

    _fnCallbackFire( settings, null, 'plugin-init', [settings, json] );
    _fnCallbackFire( settings, 'aoInitComplete', 'init', [settings, json] );
  }


  function _fnLengthChange ( settings, val )
  {
    var len = parseInt( val, 10 );
    settings._iDisplayLength = len;

    _fnLengthOverflow( settings );

    // Fire length change event
    _fnCallbackFire( settings, null, 'length', [settings, len] );
  }


  /**
   * Generate the node required for user display length changing
   *  @param {object} settings dataTables settings object
   *  @returns {node} Display length feature node
   *  @memberof DataTable#oApi
   */
  function _fnFeatureHtmlLength ( settings )
  {
    var
      classes  = settings.oClasses,
      tableId  = settings.sTableId,
      menu     = settings.aLengthMenu,
      d2       = Array.isArray( menu[0] ),
      lengths  = d2 ? menu[0] : menu,
      language = d2 ? menu[1] : menu;

    var select = $('<select/>', {
      'name':          tableId+'_length',
      'aria-controls': tableId,
      'class':         classes.sLengthSelect
    } );

    for ( var i=0, ien=lengths.length ; i<ien ; i++ ) {
      select[0][ i ] = new Option(
        typeof language[i] === 'number' ?
          settings.fnFormatNumber( language[i] ) :
          language[i],
        lengths[i]
      );
    }

    var div = $('<div><label/></div>').addClass( classes.sLength );
    if ( ! settings.aanFeatures.l ) {
      div[0].id = tableId+'_length';
    }

    div.children().append(
      settings.oLanguage.sLengthMenu.replace( '_MENU_', select[0].outerHTML )
    );

    // Can't use `select` variable as user might provide their own and the
    // reference is broken by the use of outerHTML
    $('select', div)
      .val( settings._iDisplayLength )
      .on( 'change.DT', function(e) {
        _fnLengthChange( settings, $(this).val() );
        _fnDraw( settings );
      } );

    // Update node value whenever anything changes the table's length
    $(settings.nTable).on( 'length.dt.DT', function (e, s, len) {
      if ( settings === s ) {
        $('select', div).val( len );
      }
    } );

    return div[0];
  }



  /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	 * Note that most of the paging logic is done in
	 * DataTable.ext.pager
	 */

  /**
   * Generate the node required for default pagination
   *  @param {object} oSettings dataTables settings object
   *  @returns {node} Pagination feature node
   *  @memberof DataTable#oApi
   */
  function _fnFeatureHtmlPaginate ( settings )
  {
    var
      type   = settings.sPaginationType,
      plugin = DataTable.ext.pager[ type ],
      modern = typeof plugin === 'function',
      redraw = function( settings ) {
        _fnDraw( settings );
      },
      node = $('<div/>').addClass( settings.oClasses.sPaging + type )[0],
      features = settings.aanFeatures;

    if ( ! modern ) {
      plugin.fnInit( settings, node, redraw );
    }

    /* Add a draw callback for the pagination on first instance, to update the paging display */
    if ( ! features.p )
    {
      node.id = settings.sTableId+'_paginate';

      settings.aoDrawCallback.push( {
        "fn": function( settings ) {
          if ( modern ) {
            var
              start      = settings._iDisplayStart,
              len        = settings._iDisplayLength,
              visRecords = settings.fnRecordsDisplay(),
              all        = len === -1,
              page = all ? 0 : Math.ceil( start / len ),
              pages = all ? 1 : Math.ceil( visRecords / len ),
              buttons = plugin(page, pages),
              i, ien;

            for ( i=0, ien=features.p.length ; i<ien ; i++ ) {
              _fnRenderer( settings, 'pageButton' )(
                settings, features.p[i], i, buttons, page, pages
              );
            }
          }
          else {
            plugin.fnUpdate( settings, redraw );
          }
        },
        "sName": "pagination"
      } );
    }

    return node;
  }


  /**
   * Alter the display settings to change the page
   *  @param {object} settings DataTables settings object
   *  @param {string|int} action Paging action to take: "first", "previous",
   *    "next" or "last" or page number to jump to (integer)
   *  @param [bool] redraw Automatically draw the update or not
   *  @returns {bool} true page has changed, false - no change
   *  @memberof DataTable#oApi
   */
  function _fnPageChange ( settings, action, redraw )
  {
    var
      start     = settings._iDisplayStart,
      len       = settings._iDisplayLength,
      records   = settings.fnRecordsDisplay();

    if ( records === 0 || len === -1 )
    {
      start = 0;
    }
    else if ( typeof action === "number" )
    {
      start = action * len;

      if ( start > records )
      {
        start = 0;
      }
    }
    else if ( action == "first" )
    {
      start = 0;
    }
    else if ( action == "previous" )
    {
      start = len >= 0 ?
        start - len :
        0;

      if ( start < 0 )
      {
        start = 0;
      }
    }
    else if ( action == "next" )
    {
      if ( start + len < records )
      {
        start += len;
      }
    }
    else if ( action == "last" )
    {
      start = Math.floor( (records-1) / len) * len;
    }
    else
    {
      _fnLog( settings, 0, "Unknown paging action: "+action, 5 );
    }

    var changed = settings._iDisplayStart !== start;
    settings._iDisplayStart = start;

    if ( changed ) {
      _fnCallbackFire( settings, null, 'page', [settings] );

      if ( redraw ) {
        _fnDraw( settings );
      }
    }

    return changed;
  }



  /**
   * Generate the node required for the processing node
   *  @param {object} settings dataTables settings object
   *  @returns {node} Processing element
   *  @memberof DataTable#oApi
   */
  function _fnFeatureHtmlProcessing ( settings )
  {
    return $('<div/>', {
      'id': ! settings.aanFeatures.r ? settings.sTableId+'_processing' : null,
      'class': settings.oClasses.sProcessing
    } )
      .html( settings.oLanguage.sProcessing )
      .append('<div><div></div><div></div><div></div><div></div></div>')
      .insertBefore( settings.nTable )[0];
  }


  /**
   * Display or hide the processing indicator
   *  @param {object} settings dataTables settings object
   *  @param {bool} show Show the processing indicator (true) or not (false)
   *  @memberof DataTable#oApi
   */
  function _fnProcessingDisplay ( settings, show )
  {
    if ( settings.oFeatures.bProcessing ) {
      $(settings.aanFeatures.r).css( 'display', show ? 'block' : 'none' );
    }

    _fnCallbackFire( settings, null, 'processing', [settings, show] );
  }

  /**
   * Add any control elements for the table - specifically scrolling
   *  @param {object} settings dataTables settings object
   *  @returns {node} Node to add to the DOM
   *  @memberof DataTable#oApi
   */
  function _fnFeatureHtmlTable ( settings )
  {
    var table = $(settings.nTable);

    // Add the ARIA grid role to the table
    table.attr( 'role', 'grid' );

    // Scrolling from here on in
    var scroll = settings.oScroll;

    if ( scroll.sX === '' && scroll.sY === '' ) {
      return settings.nTable;
    }

    var scrollX = scroll.sX;
    var scrollY = scroll.sY;
    var classes = settings.oClasses;
    var caption = table.children('caption');
    var captionSide = caption.length ? caption[0]._captionSide : null;
    var headerClone = $( table[0].cloneNode(false) );
    var footerClone = $( table[0].cloneNode(false) );
    var footer = table.children('tfoot');
    var _div = '<div/>';
    var size = function ( s ) {
      return !s ? null : _fnStringToCss( s );
    };

    if ( ! footer.length ) {
      footer = null;
    }

    /*
		 * The HTML structure that we want to generate in this function is:
		 *  div - scroller
		 *    div - scroll head
		 *      div - scroll head inner
		 *        table - scroll head table
		 *          thead - thead
		 *    div - scroll body
		 *      table - table (master table)
		 *        thead - thead clone for sizing
		 *        tbody - tbody
		 *    div - scroll foot
		 *      div - scroll foot inner
		 *        table - scroll foot table
		 *          tfoot - tfoot
		 */
    var scroller = $( _div, { 'class': classes.sScrollWrapper } )
      .append(
        $(_div, { 'class': classes.sScrollHead } )
          .css( {
            overflow: 'hidden',
            position: 'relative',
            border: 0,
            width: scrollX ? size(scrollX) : '100%'
          } )
          .append(
            $(_div, { 'class': classes.sScrollHeadInner } )
              .css( {
                'box-sizing': 'content-box',
                width: scroll.sXInner || '100%'
              } )
              .append(
                headerClone
                  .removeAttr('id')
                  .css( 'margin-left', 0 )
                  .append( captionSide === 'top' ? caption : null )
                  .append(
                    table.children('thead')
                  )
              )
          )
      )
      .append(
        $(_div, { 'class': classes.sScrollBody } )
          .css( {
            position: 'relative',
            overflow: 'auto',
            width: size( scrollX )
          } )
          .append( table )
      );

    if ( footer ) {
      scroller.append(
        $(_div, { 'class': classes.sScrollFoot } )
          .css( {
            overflow: 'hidden',
            border: 0,
            width: scrollX ? size(scrollX) : '100%'
          } )
          .append(
            $(_div, { 'class': classes.sScrollFootInner } )
              .append(
                footerClone
                  .removeAttr('id')
                  .css( 'margin-left', 0 )
                  .append( captionSide === 'bottom' ? caption : null )
                  .append(
                    table.children('tfoot')
                  )
              )
          )
      );
    }

    var children = scroller.children();
    var scrollHead = children[0];
    var scrollBody = children[1];
    var scrollFoot = footer ? children[2] : null;

    // When the body is scrolled, then we also want to scroll the headers
    if ( scrollX ) {
      $(scrollBody).on( 'scroll.DT', function (e) {
        var scrollLeft = this.scrollLeft;

        scrollHead.scrollLeft = scrollLeft;

        if ( footer ) {
          scrollFoot.scrollLeft = scrollLeft;
        }
      } );
    }

    $(scrollBody).css('max-height', scrollY);
    if (! scroll.bCollapse) {
      $(scrollBody).css('height', scrollY);
    }

    settings.nScrollHead = scrollHead;
    settings.nScrollBody = scrollBody;
    settings.nScrollFoot = scrollFoot;

    // On redraw - align columns
    settings.aoDrawCallback.push( {
      "fn": _fnScrollDraw,
      "sName": "scrolling"
    } );

    return scroller[0];
  }



  /**
   * Update the header, footer and body tables for resizing - i.e. column
   * alignment.
   *
   * Welcome to the most horrible function DataTables. The process that this
   * function follows is basically:
   *   1. Re-create the table inside the scrolling div
   *   2. Take live measurements from the DOM
   *   3. Apply the measurements to align the columns
   *   4. Clean up
   *
   *  @param {object} settings dataTables settings object
   *  @memberof DataTable#oApi
   */
  function _fnScrollDraw ( settings )
  {
    // Given that this is such a monster function, a lot of variables are use
    // to try and keep the minimised size as small as possible
    var
      scroll         = settings.oScroll,
      scrollX        = scroll.sX,
      scrollXInner   = scroll.sXInner,
      scrollY        = scroll.sY,
      barWidth       = scroll.iBarWidth,
      divHeader      = $(settings.nScrollHead),
      divHeaderStyle = divHeader[0].style,
      divHeaderInner = divHeader.children('div'),
      divHeaderInnerStyle = divHeaderInner[0].style,
      divHeaderTable = divHeaderInner.children('table'),
      divBodyEl      = settings.nScrollBody,
      divBody        = $(divBodyEl),
      divBodyStyle   = divBodyEl.style,
      divFooter      = $(settings.nScrollFoot),
      divFooterInner = divFooter.children('div'),
      divFooterTable = divFooterInner.children('table'),
      header         = $(settings.nTHead),
      table          = $(settings.nTable),
      tableEl        = table[0],
      tableStyle     = tableEl.style,
      footer         = settings.nTFoot ? $(settings.nTFoot) : null,
      browser        = settings.oBrowser,
      ie67           = browser.bScrollOversize,
      dtHeaderCells  = _pluck( settings.aoColumns, 'nTh' ),
      headerTrgEls, footerTrgEls,
      headerSrcEls, footerSrcEls,
      headerCopy, footerCopy,
      headerWidths=[], footerWidths=[],
      headerContent=[], footerContent=[],
      idx, correction, sanityWidth,
      zeroOut = function(nSizer) {
        var style = nSizer.style;
        style.paddingTop = "0";
        style.paddingBottom = "0";
        style.borderTopWidth = "0";
        style.borderBottomWidth = "0";
        style.height = 0;
      };

    // If the scrollbar visibility has changed from the last draw, we need to
    // adjust the column sizes as the table width will have changed to account
    // for the scrollbar
    var scrollBarVis = divBodyEl.scrollHeight > divBodyEl.clientHeight;

    if ( settings.scrollBarVis !== scrollBarVis && settings.scrollBarVis !== undefined ) {
      settings.scrollBarVis = scrollBarVis;
      _fnAdjustColumnSizing( settings );
      return; // adjust column sizing will call this function again
    }
    else {
      settings.scrollBarVis = scrollBarVis;
    }

    /*
		 * 1. Re-create the table inside the scrolling div
		 */

    // Remove the old minimised thead and tfoot elements in the inner table
    table.children('thead, tfoot').remove();

    if ( footer ) {
      footerCopy = footer.clone().prependTo( table );
      footerTrgEls = footer.find('tr'); // the original tfoot is in its own table and must be sized
      footerSrcEls = footerCopy.find('tr');
      footerCopy.find('[id]').removeAttr('id');
    }

    // Clone the current header and footer elements and then place it into the inner table
    headerCopy = header.clone().prependTo( table );
    headerTrgEls = header.find('tr'); // original header is in its own table
    headerSrcEls = headerCopy.find('tr');
    headerCopy.find('th, td').removeAttr('tabindex');
    headerCopy.find('[id]').removeAttr('id');


    /*
		 * 2. Take live measurements from the DOM - do not alter the DOM itself!
		 */

    // Remove old sizing and apply the calculated column widths
    // Get the unique column headers in the newly created (cloned) header. We want to apply the
    // calculated sizes to this header
    if ( ! scrollX )
    {
      divBodyStyle.width = '100%';
      divHeader[0].style.width = '100%';
    }

    $.each( _fnGetUniqueThs( settings, headerCopy ), function ( i, el ) {
      idx = _fnVisibleToColumnIndex( settings, i );
      el.style.width = settings.aoColumns[idx].sWidth;
    } );

    if ( footer ) {
      _fnApplyToChildren( function(n) {
        n.style.width = "";
      }, footerSrcEls );
    }

    // Size the table as a whole
    sanityWidth = table.outerWidth();
    if ( scrollX === "" ) {
      // No x scrolling
      tableStyle.width = "100%";

      // IE7 will make the width of the table when 100% include the scrollbar
      // - which is shouldn't. When there is a scrollbar we need to take this
      // into account.
      if ( ie67 && (table.find('tbody').height() > divBodyEl.offsetHeight ||
        divBody.css('overflow-y') == "scroll")
      ) {
        tableStyle.width = _fnStringToCss( table.outerWidth() - barWidth);
      }

      // Recalculate the sanity width
      sanityWidth = table.outerWidth();
    }
    else if ( scrollXInner !== "" ) {
      // legacy x scroll inner has been given - use it
      tableStyle.width = _fnStringToCss(scrollXInner);

      // Recalculate the sanity width
      sanityWidth = table.outerWidth();
    }

    // Hidden header should have zero height, so remove padding and borders. Then
    // set the width based on the real headers

    // Apply all styles in one pass
    _fnApplyToChildren( zeroOut, headerSrcEls );

    // Read all widths in next pass
    _fnApplyToChildren( function(nSizer) {
      var style = window.getComputedStyle ?
        window.getComputedStyle(nSizer).width :
        _fnStringToCss( $(nSizer).width() );

      headerContent.push( nSizer.innerHTML );
      headerWidths.push( style );
    }, headerSrcEls );

    // Apply all widths in final pass
    _fnApplyToChildren( function(nToSize, i) {
      nToSize.style.width = headerWidths[i];
    }, headerTrgEls );

    $(headerSrcEls).css('height', 0);

    /* Same again with the footer if we have one */
    if ( footer )
    {
      _fnApplyToChildren( zeroOut, footerSrcEls );

      _fnApplyToChildren( function(nSizer) {
        footerContent.push( nSizer.innerHTML );
        footerWidths.push( _fnStringToCss( $(nSizer).css('width') ) );
      }, footerSrcEls );

      _fnApplyToChildren( function(nToSize, i) {
        nToSize.style.width = footerWidths[i];
      }, footerTrgEls );

      $(footerSrcEls).height(0);
    }


    /*
		 * 3. Apply the measurements
		 */

    // "Hide" the header and footer that we used for the sizing. We need to keep
    // the content of the cell so that the width applied to the header and body
    // both match, but we want to hide it completely. We want to also fix their
    // width to what they currently are
    _fnApplyToChildren( function(nSizer, i) {
      nSizer.innerHTML = '<div class="dataTables_sizing">'+headerContent[i]+'</div>';
      nSizer.childNodes[0].style.height = "0";
      nSizer.childNodes[0].style.overflow = "hidden";
      nSizer.style.width = headerWidths[i];
    }, headerSrcEls );

    if ( footer )
    {
      _fnApplyToChildren( function(nSizer, i) {
        nSizer.innerHTML = '<div class="dataTables_sizing">'+footerContent[i]+'</div>';
        nSizer.childNodes[0].style.height = "0";
        nSizer.childNodes[0].style.overflow = "hidden";
        nSizer.style.width = footerWidths[i];
      }, footerSrcEls );
    }

    // Sanity check that the table is of a sensible width. If not then we are going to get
    // misalignment - try to prevent this by not allowing the table to shrink below its min width
    if ( Math.round(table.outerWidth()) < Math.round(sanityWidth) )
    {
      // The min width depends upon if we have a vertical scrollbar visible or not */
      correction = ((divBodyEl.scrollHeight > divBodyEl.offsetHeight ||
        divBody.css('overflow-y') == "scroll")) ?
        sanityWidth+barWidth :
        sanityWidth;

      // IE6/7 are a law unto themselves...
      if ( ie67 && (divBodyEl.scrollHeight >
        divBodyEl.offsetHeight || divBody.css('overflow-y') == "scroll")
      ) {
        tableStyle.width = _fnStringToCss( correction-barWidth );
      }

      // And give the user a warning that we've stopped the table getting too small
      if ( scrollX === "" || scrollXInner !== "" ) {
        _fnLog( settings, 1, 'Possible column misalignment', 6 );
      }
    }
    else
    {
      correction = '100%';
    }

    // Apply to the container elements
    divBodyStyle.width = _fnStringToCss( correction );
    divHeaderStyle.width = _fnStringToCss( correction );

    if ( footer ) {
      settings.nScrollFoot.style.width = _fnStringToCss( correction );
    }


    /*
		 * 4. Clean up
		 */
    if ( ! scrollY ) {
      /* IE7< puts a vertical scrollbar in place (when it shouldn't be) due to subtracting
			 * the scrollbar height from the visible display, rather than adding it on. We need to
			 * set the height in order to sort this. Don't want to do it in any other browsers.
			 */
      if ( ie67 ) {
        divBodyStyle.height = _fnStringToCss( tableEl.offsetHeight+barWidth );
      }
    }

    /* Finally set the width's of the header and footer tables */
    var iOuterWidth = table.outerWidth();
    divHeaderTable[0].style.width = _fnStringToCss( iOuterWidth );
    divHeaderInnerStyle.width = _fnStringToCss( iOuterWidth );

    // Figure out if there are scrollbar present - if so then we need a the header and footer to
    // provide a bit more space to allow "overflow" scrolling (i.e. past the scrollbar)
    var bScrolling = table.height() > divBodyEl.clientHeight || divBody.css('overflow-y') == "scroll";
    var padding = 'padding' + (browser.bScrollbarLeft ? 'Left' : 'Right' );
    divHeaderInnerStyle[ padding ] = bScrolling ? barWidth+"px" : "0px";

    if ( footer ) {
      divFooterTable[0].style.width = _fnStringToCss( iOuterWidth );
      divFooterInner[0].style.width = _fnStringToCss( iOuterWidth );
      divFooterInner[0].style[padding] = bScrolling ? barWidth+"px" : "0px";
    }

    // Correct DOM ordering for colgroup - comes before the thead
    table.children('colgroup').insertBefore( table.children('thead') );

    /* Adjust the position of the header in case we loose the y-scrollbar */
    divBody.trigger('scroll');

    // If sorting or filtering has occurred, jump the scrolling back to the top
    // only if we aren't holding the position
    if ( (settings.bSorted || settings.bFiltered) && ! settings._drawHold ) {
      divBodyEl.scrollTop = 0;
    }
  }



  /**
   * Apply a given function to the display child nodes of an element array (typically
   * TD children of TR rows
   *  @param {function} fn Method to apply to the objects
   *  @param array {nodes} an1 List of elements to look through for display children
   *  @param array {nodes} an2 Another list (identical structure to the first) - optional
   *  @memberof DataTable#oApi
   */
  function _fnApplyToChildren( fn, an1, an2 )
  {
    var index=0, i=0, iLen=an1.length;
    var nNode1, nNode2;

    while ( i < iLen ) {
      nNode1 = an1[i].firstChild;
      nNode2 = an2 ? an2[i].firstChild : null;

      while ( nNode1 ) {
        if ( nNode1.nodeType === 1 ) {
          if ( an2 ) {
            fn( nNode1, nNode2, index );
          }
          else {
            fn( nNode1, index );
          }

          index++;
        }

        nNode1 = nNode1.nextSibling;
        nNode2 = an2 ? nNode2.nextSibling : null;
      }

      i++;
    }
  }



  var __re_html_remove = /<.*?>/g;


  /**
   * Calculate the width of columns for the table
   *  @param {object} oSettings dataTables settings object
   *  @memberof DataTable#oApi
   */
  function _fnCalculateColumnWidths ( oSettings )
  {
    var
      table = oSettings.nTable,
      columns = oSettings.aoColumns,
      scroll = oSettings.oScroll,
      scrollY = scroll.sY,
      scrollX = scroll.sX,
      scrollXInner = scroll.sXInner,
      columnCount = columns.length,
      visibleColumns = _fnGetColumns( oSettings, 'bVisible' ),
      headerCells = $('th', oSettings.nTHead),
      tableWidthAttr = table.getAttribute('width'), // from DOM element
      tableContainer = table.parentNode,
      userInputs = false,
      i, column, columnIdx, width, outerWidth,
      browser = oSettings.oBrowser,
      ie67 = browser.bScrollOversize;

    var styleWidth = table.style.width;
    if ( styleWidth && styleWidth.indexOf('%') !== -1 ) {
      tableWidthAttr = styleWidth;
    }

    /* Convert any user input sizes into pixel sizes */
    for ( i=0 ; i<visibleColumns.length ; i++ ) {
      column = columns[ visibleColumns[i] ];

      if ( column.sWidth !== null ) {
        column.sWidth = _fnConvertToWidth( column.sWidthOrig, tableContainer );

        userInputs = true;
      }
    }

    /* If the number of columns in the DOM equals the number that we have to
		 * process in DataTables, then we can use the offsets that are created by
		 * the web- browser. No custom sizes can be set in order for this to happen,
		 * nor scrolling used
		 */
    if ( ie67 || ! userInputs && ! scrollX && ! scrollY &&
      columnCount == _fnVisbleColumns( oSettings ) &&
      columnCount == headerCells.length
    ) {
      for ( i=0 ; i<columnCount ; i++ ) {
        var colIdx = _fnVisibleToColumnIndex( oSettings, i );

        if ( colIdx !== null ) {
          columns[ colIdx ].sWidth = _fnStringToCss( headerCells.eq(i).width() );
        }
      }
    }
    else
    {
      // Otherwise construct a single row, worst case, table with the widest
      // node in the data, assign any user defined widths, then insert it into
      // the DOM and allow the browser to do all the hard work of calculating
      // table widths
      var tmpTable = $(table).clone() // don't use cloneNode - IE8 will remove events on the main table
        .css( 'visibility', 'hidden' )
        .removeAttr( 'id' );

      // Clean up the table body
      tmpTable.find('tbody tr').remove();
      var tr = $('<tr/>').appendTo( tmpTable.find('tbody') );

      // Clone the table header and footer - we can't use the header / footer
      // from the cloned table, since if scrolling is active, the table's
      // real header and footer are contained in different table tags
      tmpTable.find('thead, tfoot').remove();
      tmpTable
        .append( $(oSettings.nTHead).clone() )
        .append( $(oSettings.nTFoot).clone() );

      // Remove any assigned widths from the footer (from scrolling)
      tmpTable.find('tfoot th, tfoot td').css('width', '');

      // Apply custom sizing to the cloned header
      headerCells = _fnGetUniqueThs( oSettings, tmpTable.find('thead')[0] );

      for ( i=0 ; i<visibleColumns.length ; i++ ) {
        column = columns[ visibleColumns[i] ];

        headerCells[i].style.width = column.sWidthOrig !== null && column.sWidthOrig !== '' ?
          _fnStringToCss( column.sWidthOrig ) :
          '';

        // For scrollX we need to force the column width otherwise the
        // browser will collapse it. If this width is smaller than the
        // width the column requires, then it will have no effect
        if ( column.sWidthOrig && scrollX ) {
          $( headerCells[i] ).append( $('<div/>').css( {
            width: column.sWidthOrig,
            margin: 0,
            padding: 0,
            border: 0,
            height: 1
          } ) );
        }
      }

      // Find the widest cell for each column and put it into the table
      if ( oSettings.aoData.length ) {
        for ( i=0 ; i<visibleColumns.length ; i++ ) {
          columnIdx = visibleColumns[i];
          column = columns[ columnIdx ];

          $( _fnGetWidestNode( oSettings, columnIdx ) )
            .clone( false )
            .append( column.sContentPadding )
            .appendTo( tr );
        }
      }

      // Tidy the temporary table - remove name attributes so there aren't
      // duplicated in the dom (radio elements for example)
      $('[name]', tmpTable).removeAttr('name');

      // Table has been built, attach to the document so we can work with it.
      // A holding element is used, positioned at the top of the container
      // with minimal height, so it has no effect on if the container scrolls
      // or not. Otherwise it might trigger scrolling when it actually isn't
      // needed
      var holder = $('<div/>').css( scrollX || scrollY ?
        {
          position: 'absolute',
          top: 0,
          left: 0,
          height: 1,
          right: 0,
          overflow: 'hidden'
        } :
        {}
      )
        .append( tmpTable )
        .appendTo( tableContainer );

      // When scrolling (X or Y) we want to set the width of the table as
      // appropriate. However, when not scrolling leave the table width as it
      // is. This results in slightly different, but I think correct behaviour
      if ( scrollX && scrollXInner ) {
        tmpTable.width( scrollXInner );
      }
      else if ( scrollX ) {
        tmpTable.css( 'width', 'auto' );
        tmpTable.removeAttr('width');

        // If there is no width attribute or style, then allow the table to
        // collapse
        if ( tmpTable.width() < tableContainer.clientWidth && tableWidthAttr ) {
          tmpTable.width( tableContainer.clientWidth );
        }
      }
      else if ( scrollY ) {
        tmpTable.width( tableContainer.clientWidth );
      }
      else if ( tableWidthAttr ) {
        tmpTable.width( tableWidthAttr );
      }

      // Get the width of each column in the constructed table - we need to
      // know the inner width (so it can be assigned to the other table's
      // cells) and the outer width so we can calculate the full width of the
      // table. This is safe since DataTables requires a unique cell for each
      // column, but if ever a header can span multiple columns, this will
      // need to be modified.
      var total = 0;
      for ( i=0 ; i<visibleColumns.length ; i++ ) {
        var cell = $(headerCells[i]);
        var border = cell.outerWidth() - cell.width();

        // Use getBounding... where possible (not IE8-) because it can give
        // sub-pixel accuracy, which we then want to round up!
        var bounding = browser.bBounding ?
          Math.ceil( headerCells[i].getBoundingClientRect().width ) :
          cell.outerWidth();

        // Total is tracked to remove any sub-pixel errors as the outerWidth
        // of the table might not equal the total given here (IE!).
        total += bounding;

        // Width for each column to use
        columns[ visibleColumns[i] ].sWidth = _fnStringToCss( bounding - border );
      }

      table.style.width = _fnStringToCss( total );

      // Finished with the table - ditch it
      holder.remove();
    }

    // If there is a width attr, we want to attach an event listener which
    // allows the table sizing to automatically adjust when the window is
    // resized. Use the width attr rather than CSS, since we can't know if the
    // CSS is a relative value or absolute - DOM read is always px.
    if ( tableWidthAttr ) {
      table.style.width = _fnStringToCss( tableWidthAttr );
    }

    if ( (tableWidthAttr || scrollX) && ! oSettings._reszEvt ) {
      var bindResize = function () {
        $(window).on('resize.DT-'+oSettings.sInstance, _fnThrottle( function () {
          _fnAdjustColumnSizing( oSettings );
        } ) );
      };

      // IE6/7 will crash if we bind a resize event handler on page load.
      // To be removed in 1.11 which drops IE6/7 support
      if ( ie67 ) {
        setTimeout( bindResize, 1000 );
      }
      else {
        bindResize();
      }

      oSettings._reszEvt = true;
    }
  }


  /**
   * Throttle the calls to a function. Arguments and context are maintained for
   * the throttled function
   *  @param {function} fn Function to be called
   *  @param {int} [freq=200] call frequency in mS
   *  @returns {function} wrapped function
   *  @memberof DataTable#oApi
   */
  var _fnThrottle = DataTable.util.throttle;


  /**
   * Convert a CSS unit width to pixels (e.g. 2em)
   *  @param {string} width width to be converted
   *  @param {node} parent parent to get the with for (required for relative widths) - optional
   *  @returns {int} width in pixels
   *  @memberof DataTable#oApi
   */
  function _fnConvertToWidth ( width, parent )
  {
    if ( ! width ) {
      return 0;
    }

    var n = $('<div/>')
      .css( 'width', _fnStringToCss( width ) )
      .appendTo( parent || document.body );

    var val = n[0].offsetWidth;
    n.remove();

    return val;
  }


  /**
   * Get the widest node
   *  @param {object} settings dataTables settings object
   *  @param {int} colIdx column of interest
   *  @returns {node} widest table node
   *  @memberof DataTable#oApi
   */
  function _fnGetWidestNode( settings, colIdx )
  {
    var idx = _fnGetMaxLenString( settings, colIdx );
    if ( idx < 0 ) {
      return null;
    }

    var data = settings.aoData[ idx ];
    return ! data.nTr ? // Might not have been created when deferred rendering
      $('<td/>').html( _fnGetCellData( settings, idx, colIdx, 'display' ) )[0] :
      data.anCells[ colIdx ];
  }


  /**
   * Get the maximum strlen for each data column
   *  @param {object} settings dataTables settings object
   *  @param {int} colIdx column of interest
   *  @returns {string} max string length for each column
   *  @memberof DataTable#oApi
   */
  function _fnGetMaxLenString( settings, colIdx )
  {
    var s, max=-1, maxIdx = -1;

    for ( var i=0, ien=settings.aoData.length ; i<ien ; i++ ) {
      s = _fnGetCellData( settings, i, colIdx, 'display' )+'';
      s = s.replace( __re_html_remove, '' );
      s = s.replace( /&nbsp;/g, ' ' );

      if ( s.length > max ) {
        max = s.length;
        maxIdx = i;
      }
    }

    return maxIdx;
  }


  /**
   * Append a CSS unit (only if required) to a string
   *  @param {string} value to css-ify
   *  @returns {string} value with css unit
   *  @memberof DataTable#oApi
   */
  function _fnStringToCss( s )
  {
    if ( s === null ) {
      return '0px';
    }

    if ( typeof s == 'number' ) {
      return s < 0 ?
        '0px' :
        s+'px';
    }

    // Check it has a unit character already
    return s.match(/\d$/) ?
      s+'px' :
      s;
  }



  function _fnSortFlatten ( settings )
  {
    var
      i, iLen, k, kLen,
      aSort = [],
      aiOrig = [],
      aoColumns = settings.aoColumns,
      aDataSort, iCol, sType, srcCol,
      fixed = settings.aaSortingFixed,
      fixedObj = $.isPlainObject( fixed ),
      nestedSort = [],
      add = function ( a ) {
        if ( a.length && ! Array.isArray( a[0] ) ) {
          // 1D array
          nestedSort.push( a );
        }
        else {
          // 2D array
          $.merge( nestedSort, a );
        }
      };

    // Build the sort array, with pre-fix and post-fix options if they have been
    // specified
    if ( Array.isArray( fixed ) ) {
      add( fixed );
    }

    if ( fixedObj && fixed.pre ) {
      add( fixed.pre );
    }

    add( settings.aaSorting );

    if (fixedObj && fixed.post ) {
      add( fixed.post );
    }

    for ( i=0 ; i<nestedSort.length ; i++ )
    {
      srcCol = nestedSort[i][0];
      aDataSort = aoColumns[ srcCol ].aDataSort;

      for ( k=0, kLen=aDataSort.length ; k<kLen ; k++ )
      {
        iCol = aDataSort[k];
        sType = aoColumns[ iCol ].sType || 'string';

        if ( nestedSort[i]._idx === undefined ) {
          nestedSort[i]._idx = $.inArray( nestedSort[i][1], aoColumns[iCol].asSorting );
        }

        aSort.push( {
          src:       srcCol,
          col:       iCol,
          dir:       nestedSort[i][1],
          index:     nestedSort[i]._idx,
          type:      sType,
          formatter: DataTable.ext.type.order[ sType+"-pre" ]
        } );
      }
    }

    return aSort;
  }

  /**
   * Change the order of the table
   *  @param {object} oSettings dataTables settings object
   *  @memberof DataTable#oApi
   *  @todo This really needs split up!
   */
  function _fnSort ( oSettings )
  {
    var
      i, ien, iLen, j, jLen, k, kLen,
      sDataType, nTh,
      aiOrig = [],
      oExtSort = DataTable.ext.type.order,
      aoData = oSettings.aoData,
      aoColumns = oSettings.aoColumns,
      aDataSort, data, iCol, sType, oSort,
      formatters = 0,
      sortCol,
      displayMaster = oSettings.aiDisplayMaster,
      aSort;

    // Resolve any column types that are unknown due to addition or invalidation
    // @todo Can this be moved into a 'data-ready' handler which is called when
    //   data is going to be used in the table?
    _fnColumnTypes( oSettings );

    aSort = _fnSortFlatten( oSettings );

    for ( i=0, ien=aSort.length ; i<ien ; i++ ) {
      sortCol = aSort[i];

      // Track if we can use the fast sort algorithm
      if ( sortCol.formatter ) {
        formatters++;
      }

      // Load the data needed for the sort, for each cell
      _fnSortData( oSettings, sortCol.col );
    }

    /* No sorting required if server-side or no sorting array */
    if ( _fnDataSource( oSettings ) != 'ssp' && aSort.length !== 0 )
    {
      // Create a value - key array of the current row positions such that we can use their
      // current position during the sort, if values match, in order to perform stable sorting
      for ( i=0, iLen=displayMaster.length ; i<iLen ; i++ ) {
        aiOrig[ displayMaster[i] ] = i;
      }

      /* Do the sort - here we want multi-column sorting based on a given data source (column)
			 * and sorting function (from oSort) in a certain direction. It's reasonably complex to
			 * follow on it's own, but this is what we want (example two column sorting):
			 *  fnLocalSorting = function(a,b){
			 *    var iTest;
			 *    iTest = oSort['string-asc']('data11', 'data12');
			 *      if (iTest !== 0)
			 *        return iTest;
			 *    iTest = oSort['numeric-desc']('data21', 'data22');
			 *    if (iTest !== 0)
			 *      return iTest;
			 *    return oSort['numeric-asc']( aiOrig[a], aiOrig[b] );
			 *  }
			 * Basically we have a test for each sorting column, if the data in that column is equal,
			 * test the next column. If all columns match, then we use a numeric sort on the row
			 * positions in the original data array to provide a stable sort.
			 *
			 * Note - I know it seems excessive to have two sorting methods, but the first is around
			 * 15% faster, so the second is only maintained for backwards compatibility with sorting
			 * methods which do not have a pre-sort formatting function.
			 */
      if ( formatters === aSort.length ) {
        // All sort types have formatting functions
        displayMaster.sort( function ( a, b ) {
          var
            x, y, k, test, sort,
            len=aSort.length,
            dataA = aoData[a]._aSortData,
            dataB = aoData[b]._aSortData;

          for ( k=0 ; k<len ; k++ ) {
            sort = aSort[k];

            x = dataA[ sort.col ];
            y = dataB[ sort.col ];

            test = x<y ? -1 : x>y ? 1 : 0;
            if ( test !== 0 ) {
              return sort.dir === 'asc' ? test : -test;
            }
          }

          x = aiOrig[a];
          y = aiOrig[b];
          return x<y ? -1 : x>y ? 1 : 0;
        } );
      }
      else {
        // Depreciated - remove in 1.11 (providing a plug-in option)
        // Not all sort types have formatting methods, so we have to call their sorting
        // methods.
        displayMaster.sort( function ( a, b ) {
          var
            x, y, k, l, test, sort, fn,
            len=aSort.length,
            dataA = aoData[a]._aSortData,
            dataB = aoData[b]._aSortData;

          for ( k=0 ; k<len ; k++ ) {
            sort = aSort[k];

            x = dataA[ sort.col ];
            y = dataB[ sort.col ];

            fn = oExtSort[ sort.type+"-"+sort.dir ] || oExtSort[ "string-"+sort.dir ];
            test = fn( x, y );
            if ( test !== 0 ) {
              return test;
            }
          }

          x = aiOrig[a];
          y = aiOrig[b];
          return x<y ? -1 : x>y ? 1 : 0;
        } );
      }
    }

    /* Tell the draw function that we have sorted the data */
    oSettings.bSorted = true;
  }


  function _fnSortAria ( settings )
  {
    var label;
    var nextSort;
    var columns = settings.aoColumns;
    var aSort = _fnSortFlatten( settings );
    var oAria = settings.oLanguage.oAria;

    // ARIA attributes - need to loop all columns, to update all (removing old
    // attributes as needed)
    for ( var i=0, iLen=columns.length ; i<iLen ; i++ )
    {
      var col = columns[i];
      var asSorting = col.asSorting;
      var sTitle = col.ariaTitle || col.sTitle.replace( /<.*?>/g, "" );
      var th = col.nTh;

      // IE7 is throwing an error when setting these properties with jQuery's
      // attr() and removeAttr() methods...
      th.removeAttribute('aria-sort');

      /* In ARIA only the first sorting column can be marked as sorting - no multi-sort option */
      if ( col.bSortable ) {
        if ( aSort.length > 0 && aSort[0].col == i ) {
          th.setAttribute('aria-sort', aSort[0].dir=="asc" ? "ascending" : "descending" );
          nextSort = asSorting[ aSort[0].index+1 ] || asSorting[0];
        }
        else {
          nextSort = asSorting[0];
        }

        label = sTitle + ( nextSort === "asc" ?
            oAria.sSortAscending :
            oAria.sSortDescending
        );
      }
      else {
        label = sTitle;
      }

      th.setAttribute('aria-label', label);
    }
  }


  /**
   * Function to run on user sort request
   *  @param {object} settings dataTables settings object
   *  @param {node} attachTo node to attach the handler to
   *  @param {int} colIdx column sorting index
   *  @param {boolean} [append=false] Append the requested sort to the existing
   *    sort if true (i.e. multi-column sort)
   *  @param {function} [callback] callback function
   *  @memberof DataTable#oApi
   */
  function _fnSortListener ( settings, colIdx, append, callback )
  {
    var col = settings.aoColumns[ colIdx ];
    var sorting = settings.aaSorting;
    var asSorting = col.asSorting;
    var nextSortIdx;
    var next = function ( a, overflow ) {
      var idx = a._idx;
      if ( idx === undefined ) {
        idx = $.inArray( a[1], asSorting );
      }

      return idx+1 < asSorting.length ?
        idx+1 :
        overflow ?
          null :
          0;
    };

    // Convert to 2D array if needed
    if ( typeof sorting[0] === 'number' ) {
      sorting = settings.aaSorting = [ sorting ];
    }

    // If appending the sort then we are multi-column sorting
    if ( append && settings.oFeatures.bSortMulti ) {
      // Are we already doing some kind of sort on this column?
      var sortIdx = $.inArray( colIdx, _pluck(sorting, '0') );

      if ( sortIdx !== -1 ) {
        // Yes, modify the sort
        nextSortIdx = next( sorting[sortIdx], true );

        if ( nextSortIdx === null && sorting.length === 1 ) {
          nextSortIdx = 0; // can't remove sorting completely
        }

        if ( nextSortIdx === null ) {
          sorting.splice( sortIdx, 1 );
        }
        else {
          sorting[sortIdx][1] = asSorting[ nextSortIdx ];
          sorting[sortIdx]._idx = nextSortIdx;
        }
      }
      else {
        // No sort on this column yet
        sorting.push( [ colIdx, asSorting[0], 0 ] );
        sorting[sorting.length-1]._idx = 0;
      }
    }
    else if ( sorting.length && sorting[0][0] == colIdx ) {
      // Single column - already sorting on this column, modify the sort
      nextSortIdx = next( sorting[0] );

      sorting.length = 1;
      sorting[0][1] = asSorting[ nextSortIdx ];
      sorting[0]._idx = nextSortIdx;
    }
    else {
      // Single column - sort only on this column
      sorting.length = 0;
      sorting.push( [ colIdx, asSorting[0] ] );
      sorting[0]._idx = 0;
    }

    // Run the sort by calling a full redraw
    _fnReDraw( settings );

    // callback used for async user interaction
    if ( typeof callback == 'function' ) {
      callback( settings );
    }
  }


  /**
   * Attach a sort handler (click) to a node
   *  @param {object} settings dataTables settings object
   *  @param {node} attachTo node to attach the handler to
   *  @param {int} colIdx column sorting index
   *  @param {function} [callback] callback function
   *  @memberof DataTable#oApi
   */
  function _fnSortAttachListener ( settings, attachTo, colIdx, callback )
  {
    var col = settings.aoColumns[ colIdx ];

    _fnBindAction( attachTo, {}, function (e) {
      /* If the column is not sortable - don't to anything */
      if ( col.bSortable === false ) {
        return;
      }

      // If processing is enabled use a timeout to allow the processing
      // display to be shown - otherwise to it synchronously
      if ( settings.oFeatures.bProcessing ) {
        _fnProcessingDisplay( settings, true );

        setTimeout( function() {
          _fnSortListener( settings, colIdx, e.shiftKey, callback );

          // In server-side processing, the draw callback will remove the
          // processing display
          if ( _fnDataSource( settings ) !== 'ssp' ) {
            _fnProcessingDisplay( settings, false );
          }
        }, 0 );
      }
      else {
        _fnSortListener( settings, colIdx, e.shiftKey, callback );
      }
    } );
  }


  /**
   * Set the sorting classes on table's body, Note: it is safe to call this function
   * when bSort and bSortClasses are false
   *  @param {object} oSettings dataTables settings object
   *  @memberof DataTable#oApi
   */
  function _fnSortingClasses( settings )
  {
    var oldSort = settings.aLastSort;
    var sortClass = settings.oClasses.sSortColumn;
    var sort = _fnSortFlatten( settings );
    var features = settings.oFeatures;
    var i, ien, colIdx;

    if ( features.bSort && features.bSortClasses ) {
      // Remove old sorting classes
      for ( i=0, ien=oldSort.length ; i<ien ; i++ ) {
        colIdx = oldSort[i].src;

        // Remove column sorting
        $( _pluck( settings.aoData, 'anCells', colIdx ) )
          .removeClass( sortClass + (i<2 ? i+1 : 3) );
      }

      // Add new column sorting
      for ( i=0, ien=sort.length ; i<ien ; i++ ) {
        colIdx = sort[i].src;

        $( _pluck( settings.aoData, 'anCells', colIdx ) )
          .addClass( sortClass + (i<2 ? i+1 : 3) );
      }
    }

    settings.aLastSort = sort;
  }


  // Get the data to sort a column, be it from cache, fresh (populating the
  // cache), or from a sort formatter
  function _fnSortData( settings, idx )
  {
    // Custom sorting function - provided by the sort data type
    var column = settings.aoColumns[ idx ];
    var customSort = DataTable.ext.order[ column.sSortDataType ];
    var customData;

    if ( customSort ) {
      customData = customSort.call( settings.oInstance, settings, idx,
        _fnColumnIndexToVisible( settings, idx )
      );
    }

    // Use / populate cache
    var row, cellData;
    var formatter = DataTable.ext.type.order[ column.sType+"-pre" ];

    for ( var i=0, ien=settings.aoData.length ; i<ien ; i++ ) {
      row = settings.aoData[i];

      if ( ! row._aSortData ) {
        row._aSortData = [];
      }

      if ( ! row._aSortData[idx] || customSort ) {
        cellData = customSort ?
          customData[i] : // If there was a custom sort function, use data from there
          _fnGetCellData( settings, i, idx, 'sort' );

        row._aSortData[ idx ] = formatter ?
          formatter( cellData ) :
          cellData;
      }
    }
  }



  /**
   * Save the state of a table
   *  @param {object} oSettings dataTables settings object
   *  @memberof DataTable#oApi
   */
  function _fnSaveState ( settings )
  {
    if (settings._bLoadingState) {
      return;
    }

    /* Store the interesting variables */
    var state = {
      time:    +new Date(),
      start:   settings._iDisplayStart,
      length:  settings._iDisplayLength,
      order:   $.extend( true, [], settings.aaSorting ),
      search:  _fnSearchToCamel( settings.oPreviousSearch ),
      columns: $.map( settings.aoColumns, function ( col, i ) {
        return {
          visible: col.bVisible,
          search: _fnSearchToCamel( settings.aoPreSearchCols[i] )
        };
      } )
    };

    settings.oSavedState = state;
    _fnCallbackFire( settings, "aoStateSaveParams", 'stateSaveParams', [settings, state] );

    if ( settings.oFeatures.bStateSave && !settings.bDestroying )
    {
      settings.fnStateSaveCallback.call( settings.oInstance, settings, state );
    }
  }


  /**
   * Attempt to load a saved table state
   *  @param {object} oSettings dataTables settings object
   *  @param {object} oInit DataTables init object so we can override settings
   *  @param {function} callback Callback to execute when the state has been loaded
   *  @memberof DataTable#oApi
   */
  function _fnLoadState ( settings, oInit, callback )
  {
    if ( ! settings.oFeatures.bStateSave ) {
      callback();
      return;
    }

    var loaded = function(state) {
      _fnImplementState(settings, state, callback);
    }

    var state = settings.fnStateLoadCallback.call( settings.oInstance, settings, loaded );

    if ( state !== undefined ) {
      _fnImplementState( settings, state, callback );
    }
    // otherwise, wait for the loaded callback to be executed

    return true;
  }

  function _fnImplementState ( settings, s, callback) {
    var i, ien;
    var columns = settings.aoColumns;
    settings._bLoadingState = true;

    // When StateRestore was introduced the state could now be implemented at any time
    // Not just initialisation. To do this an api instance is required in some places
    var api = settings._bInitComplete ? new DataTable.Api(settings) : null;

    if ( ! s || ! s.time ) {
      settings._bLoadingState = false;
      callback();
      return;
    }

    // Allow custom and plug-in manipulation functions to alter the saved data set and
    // cancelling of loading by returning false
    var abStateLoad = _fnCallbackFire( settings, 'aoStateLoadParams', 'stateLoadParams', [settings, s] );
    if ( $.inArray( false, abStateLoad ) !== -1 ) {
      settings._bLoadingState = false;
      callback();
      return;
    }

    // Reject old data
    var duration = settings.iStateDuration;
    if ( duration > 0 && s.time < +new Date() - (duration*1000) ) {
      settings._bLoadingState = false;
      callback();
      return;
    }

    // Number of columns have changed - all bets are off, no restore of settings
    if ( s.columns && columns.length !== s.columns.length ) {
      settings._bLoadingState = false;
      callback();
      return;
    }

    // Store the saved state so it might be accessed at any time
    settings.oLoadedState = $.extend( true, {}, s );

    // Page Length
    if ( s.length !== undefined ) {
      // If already initialised just set the value directly so that the select element is also updated
      if (api) {
        api.page.len(s.length)
      }
      else {
        settings._iDisplayLength   = s.length;
      }
    }

    // Restore key features - todo - for 1.11 this needs to be done by
    // subscribed events
    if ( s.start !== undefined ) {
      if(api === null) {
        settings._iDisplayStart    = s.start;
        settings.iInitDisplayStart = s.start;
      }
      else {
        _fnPageChange(settings, s.start/settings._iDisplayLength);
      }
    }

    // Order
    if ( s.order !== undefined ) {
      settings.aaSorting = [];
      $.each( s.order, function ( i, col ) {
        settings.aaSorting.push( col[0] >= columns.length ?
          [ 0, col[1] ] :
          col
        );
      } );
    }

    // Search
    if ( s.search !== undefined ) {
      $.extend( settings.oPreviousSearch, _fnSearchToHung( s.search ) );
    }

    // Columns
    if ( s.columns ) {
      for ( i=0, ien=s.columns.length ; i<ien ; i++ ) {
        var col = s.columns[i];

        // Visibility
        if ( col.visible !== undefined ) {
          // If the api is defined, the table has been initialised so we need to use it rather than internal settings
          if (api) {
            // Don't redraw the columns on every iteration of this loop, we will do this at the end instead
            api.column(i).visible(col.visible, false);
          }
          else {
            columns[i].bVisible = col.visible;
          }
        }

        // Search
        if ( col.search !== undefined ) {
          $.extend( settings.aoPreSearchCols[i], _fnSearchToHung( col.search ) );
        }
      }

      // If the api is defined then we need to adjust the columns once the visibility has been changed
      if (api) {
        api.columns.adjust();
      }
    }

    settings._bLoadingState = false;
    _fnCallbackFire( settings, 'aoStateLoaded', 'stateLoaded', [settings, s] );
    callback();
  };


  /**
   * Return the settings object for a particular table
   *  @param {node} table table we are using as a dataTable
   *  @returns {object} Settings object - or null if not found
   *  @memberof DataTable#oApi
   */
  function _fnSettingsFromNode ( table )
  {
    var settings = DataTable.settings;
    var idx = $.inArray( table, _pluck( settings, 'nTable' ) );

    return idx !== -1 ?
      settings[ idx ] :
      null;
  }


  /**
   * Log an error message
   *  @param {object} settings dataTables settings object
   *  @param {int} level log error messages, or display them to the user
   *  @param {string} msg error message
   *  @param {int} tn Technical note id to get more information about the error.
   *  @memberof DataTable#oApi
   */
  function _fnLog( settings, level, msg, tn )
  {
    msg = 'DataTables warning: '+
      (settings ? 'table id='+settings.sTableId+' - ' : '')+msg;

    if ( tn ) {
      msg += '. For more information about this error, please see '+
        'http://datatables.net/tn/'+tn;
    }

    if ( ! level  ) {
      // Backwards compatibility pre 1.10
      var ext = DataTable.ext;
      var type = ext.sErrMode || ext.errMode;

      if ( settings ) {
        _fnCallbackFire( settings, null, 'error', [ settings, tn, msg ] );
      }

      if ( type == 'alert' ) {
        alert( msg );
      }
      else if ( type == 'throw' ) {
        throw new Error(msg);
      }
      else if ( typeof type == 'function' ) {
        type( settings, tn, msg );
      }
    }
    else if ( window.console && console.log ) {
      console.log( msg );
    }
  }


  /**
   * See if a property is defined on one object, if so assign it to the other object
   *  @param {object} ret target object
   *  @param {object} src source object
   *  @param {string} name property
   *  @param {string} [mappedName] name to map too - optional, name used if not given
   *  @memberof DataTable#oApi
   */
  function _fnMap( ret, src, name, mappedName )
  {
    if ( Array.isArray( name ) ) {
      $.each( name, function (i, val) {
        if ( Array.isArray( val ) ) {
          _fnMap( ret, src, val[0], val[1] );
        }
        else {
          _fnMap( ret, src, val );
        }
      } );

      return;
    }

    if ( mappedName === undefined ) {
      mappedName = name;
    }

    if ( src[name] !== undefined ) {
      ret[mappedName] = src[name];
    }
  }


  /**
   * Extend objects - very similar to jQuery.extend, but deep copy objects, and
   * shallow copy arrays. The reason we need to do this, is that we don't want to
   * deep copy array init values (such as aaSorting) since the dev wouldn't be
   * able to override them, but we do want to deep copy arrays.
   *  @param {object} out Object to extend
   *  @param {object} extender Object from which the properties will be applied to
   *      out
   *  @param {boolean} breakRefs If true, then arrays will be sliced to take an
   *      independent copy with the exception of the `data` or `aaData` parameters
   *      if they are present. This is so you can pass in a collection to
   *      DataTables and have that used as your data source without breaking the
   *      references
   *  @returns {object} out Reference, just for convenience - out === the return.
   *  @memberof DataTable#oApi
   *  @todo This doesn't take account of arrays inside the deep copied objects.
   */
  function _fnExtend( out, extender, breakRefs )
  {
    var val;

    for ( var prop in extender ) {
      if ( extender.hasOwnProperty(prop) ) {
        val = extender[prop];

        if ( $.isPlainObject( val ) ) {
          if ( ! $.isPlainObject( out[prop] ) ) {
            out[prop] = {};
          }
          $.extend( true, out[prop], val );
        }
        else if ( breakRefs && prop !== 'data' && prop !== 'aaData' && Array.isArray(val) ) {
          out[prop] = val.slice();
        }
        else {
          out[prop] = val;
        }
      }
    }

    return out;
  }


  /**
   * Bind an event handers to allow a click or return key to activate the callback.
   * This is good for accessibility since a return on the keyboard will have the
   * same effect as a click, if the element has focus.
   *  @param {element} n Element to bind the action to
   *  @param {object} oData Data object to pass to the triggered function
   *  @param {function} fn Callback function for when the event is triggered
   *  @memberof DataTable#oApi
   */
  function _fnBindAction( n, oData, fn )
  {
    $(n)
      .on( 'click.DT', oData, function (e) {
        $(n).trigger('blur'); // Remove focus outline for mouse users
        fn(e);
      } )
      .on( 'keypress.DT', oData, function (e){
        if ( e.which === 13 ) {
          e.preventDefault();
          fn(e);
        }
      } )
      .on( 'selectstart.DT', function () {
        /* Take the brutal approach to cancelling text selection */
        return false;
      } );
  }


  /**
   * Register a callback function. Easily allows a callback function to be added to
   * an array store of callback functions that can then all be called together.
   *  @param {object} oSettings dataTables settings object
   *  @param {string} sStore Name of the array storage for the callbacks in oSettings
   *  @param {function} fn Function to be called back
   *  @param {string} sName Identifying name for the callback (i.e. a label)
   *  @memberof DataTable#oApi
   */
  function _fnCallbackReg( oSettings, sStore, fn, sName )
  {
    if ( fn )
    {
      oSettings[sStore].push( {
        "fn": fn,
        "sName": sName
      } );
    }
  }


  /**
   * Fire callback functions and trigger events. Note that the loop over the
   * callback array store is done backwards! Further note that you do not want to
   * fire off triggers in time sensitive applications (for example cell creation)
   * as its slow.
   *  @param {object} settings dataTables settings object
   *  @param {string} callbackArr Name of the array storage for the callbacks in
   *      oSettings
   *  @param {string} eventName Name of the jQuery custom event to trigger. If
   *      null no trigger is fired
   *  @param {array} args Array of arguments to pass to the callback function /
   *      trigger
   *  @memberof DataTable#oApi
   */
  function _fnCallbackFire( settings, callbackArr, eventName, args )
  {
    var ret = [];

    if ( callbackArr ) {
      ret = $.map( settings[callbackArr].slice().reverse(), function (val, i) {
        return val.fn.apply( settings.oInstance, args );
      } );
    }

    if ( eventName !== null ) {
      var e = $.Event( eventName+'.dt' );

      $(settings.nTable).trigger( e, args );

      ret.push( e.result );
    }

    return ret;
  }


  function _fnLengthOverflow ( settings )
  {
    var
      start = settings._iDisplayStart,
      end = settings.fnDisplayEnd(),
      len = settings._iDisplayLength;

    /* If we have space to show extra rows (backing up from the end point - then do so */
    if ( start >= end )
    {
      start = end - len;
    }

    // Keep the start record on the current page
    start -= (start % len);

    if ( len === -1 || start < 0 )
    {
      start = 0;
    }

    settings._iDisplayStart = start;
  }


  function _fnRenderer( settings, type )
  {
    var renderer = settings.renderer;
    var host = DataTable.ext.renderer[type];

    if ( $.isPlainObject( renderer ) && renderer[type] ) {
      // Specific renderer for this type. If available use it, otherwise use
      // the default.
      return host[renderer[type]] || host._;
    }
    else if ( typeof renderer === 'string' ) {
      // Common renderer - if there is one available for this type use it,
      // otherwise use the default
      return host[renderer] || host._;
    }

    // Use the default
    return host._;
  }


  /**
   * Detect the data source being used for the table. Used to simplify the code
   * a little (ajax) and to make it compress a little smaller.
   *
   *  @param {object} settings dataTables settings object
   *  @returns {string} Data source
   *  @memberof DataTable#oApi
   */
  function _fnDataSource ( settings )
  {
    if ( settings.oFeatures.bServerSide ) {
      return 'ssp';
    }
    else if ( settings.ajax || settings.sAjaxSource ) {
      return 'ajax';
    }
    return 'dom';
  }




  /**
   * Computed structure of the DataTables API, defined by the options passed to
   * `DataTable.Api.register()` when building the API.
   *
   * The structure is built in order to speed creation and extension of the Api
   * objects since the extensions are effectively pre-parsed.
   *
   * The array is an array of objects with the following structure, where this
   * base array represents the Api prototype base:
   *
   *     [
   *       {
   *         name:      'data'                -- string   - Property name
   *         val:       function () {},       -- function - Api method (or undefined if just an object
   *         methodExt: [ ... ],              -- array    - Array of Api object definitions to extend the method result
   *         propExt:   [ ... ]               -- array    - Array of Api object definitions to extend the property
   *       },
   *       {
   *         name:     'row'
   *         val:       {},
   *         methodExt: [ ... ],
   *         propExt:   [
   *           {
   *             name:      'data'
   *             val:       function () {},
   *             methodExt: [ ... ],
   *             propExt:   [ ... ]
   *           },
   *           ...
   *         ]
   *       }
   *     ]
   *
   * @type {Array}
   * @ignore
   */
  var __apiStruct = [];


  /**
   * `Array.prototype` reference.
   *
   * @type object
   * @ignore
   */
  var __arrayProto = Array.prototype;


  /**
   * Abstraction for `context` parameter of the `Api` constructor to allow it to
   * take several different forms for ease of use.
   *
   * Each of the input parameter types will be converted to a DataTables settings
   * object where possible.
   *
   * @param  {string|node|jQuery|object} mixed DataTable identifier. Can be one
   *   of:
   *
   *   * `string` - jQuery selector. Any DataTables' matching the given selector
   *     with be found and used.
   *   * `node` - `TABLE` node which has already been formed into a DataTable.
   *   * `jQuery` - A jQuery object of `TABLE` nodes.
   *   * `object` - DataTables settings object
   *   * `DataTables.Api` - API instance
   * @return {array|null} Matching DataTables settings objects. `null` or
   *   `undefined` is returned if no matching DataTable is found.
   * @ignore
   */
  var _toSettings = function ( mixed )
  {
    var idx, jq;
    var settings = DataTable.settings;
    var tables = $.map( settings, function (el, i) {
      return el.nTable;
    } );

    if ( ! mixed ) {
      return [];
    }
    else if ( mixed.nTable && mixed.oApi ) {
      // DataTables settings object
      return [ mixed ];
    }
    else if ( mixed.nodeName && mixed.nodeName.toLowerCase() === 'table' ) {
      // Table node
      idx = $.inArray( mixed, tables );
      return idx !== -1 ? [ settings[idx] ] : null;
    }
    else if ( mixed && typeof mixed.settings === 'function' ) {
      return mixed.settings().toArray();
    }
    else if ( typeof mixed === 'string' ) {
      // jQuery selector
      jq = $(mixed);
    }
    else if ( mixed instanceof $ ) {
      // jQuery object (also DataTables instance)
      jq = mixed;
    }

    if ( jq ) {
      return jq.map( function(i) {
        idx = $.inArray( this, tables );
        return idx !== -1 ? settings[idx] : null;
      } ).toArray();
    }
  };


  /**
   * DataTables API class - used to control and interface with  one or more
   * DataTables enhanced tables.
   *
   * The API class is heavily based on jQuery, presenting a chainable interface
   * that you can use to interact with tables. Each instance of the API class has
   * a "context" - i.e. the tables that it will operate on. This could be a single
   * table, all tables on a page or a sub-set thereof.
   *
   * Additionally the API is designed to allow you to easily work with the data in
   * the tables, retrieving and manipulating it as required. This is done by
   * presenting the API class as an array like interface. The contents of the
   * array depend upon the actions requested by each method (for example
   * `rows().nodes()` will return an array of nodes, while `rows().data()` will
   * return an array of objects or arrays depending upon your table's
   * configuration). The API object has a number of array like methods (`push`,
   * `pop`, `reverse` etc) as well as additional helper methods (`each`, `pluck`,
   * `unique` etc) to assist your working with the data held in a table.
   *
   * Most methods (those which return an Api instance) are chainable, which means
   * the return from a method call also has all of the methods available that the
   * top level object had. For example, these two calls are equivalent:
   *
   *     // Not chained
   *     api.row.add( {...} );
   *     api.draw();
   *
   *     // Chained
   *     api.row.add( {...} ).draw();
   *
   * @class DataTable.Api
   * @param {array|object|string|jQuery} context DataTable identifier. This is
   *   used to define which DataTables enhanced tables this API will operate on.
   *   Can be one of:
   *
   *   * `string` - jQuery selector. Any DataTables' matching the given selector
   *     with be found and used.
   *   * `node` - `TABLE` node which has already been formed into a DataTable.
   *   * `jQuery` - A jQuery object of `TABLE` nodes.
   *   * `object` - DataTables settings object
   * @param {array} [data] Data to initialise the Api instance with.
   *
   * @example
   *   // Direct initialisation during DataTables construction
   *   var api = $('#example').DataTable();
   *
   * @example
   *   // Initialisation using a DataTables jQuery object
   *   var api = $('#example').dataTable().api();
   *
   * @example
   *   // Initialisation as a constructor
   *   var api = new $.fn.DataTable.Api( 'table.dataTable' );
   */
  _Api = function ( context, data )
  {
    if ( ! (this instanceof _Api) ) {
      return new _Api( context, data );
    }

    var settings = [];
    var ctxSettings = function ( o ) {
      var a = _toSettings( o );
      if ( a ) {
        settings.push.apply( settings, a );
      }
    };

    if ( Array.isArray( context ) ) {
      for ( var i=0, ien=context.length ; i<ien ; i++ ) {
        ctxSettings( context[i] );
      }
    }
    else {
      ctxSettings( context );
    }

    // Remove duplicates
    this.context = _unique( settings );

    // Initial data
    if ( data ) {
      $.merge( this, data );
    }

    // selector
    this.selector = {
      rows: null,
      cols: null,
      opts: null
    };

    _Api.extend( this, this, __apiStruct );
  };

  DataTable.Api = _Api;

  // Don't destroy the existing prototype, just extend it. Required for jQuery 2's
  // isPlainObject.
  $.extend( _Api.prototype, {
    any: function ()
    {
      return this.count() !== 0;
    },


    concat:  __arrayProto.concat,


    context: [], // array of table settings objects


    count: function ()
    {
      return this.flatten().length;
    },


    each: function ( fn )
    {
      for ( var i=0, ien=this.length ; i<ien; i++ ) {
        fn.call( this, this[i], i, this );
      }

      return this;
    },


    eq: function ( idx )
    {
      var ctx = this.context;

      return ctx.length > idx ?
        new _Api( ctx[idx], this[idx] ) :
        null;
    },


    filter: function ( fn )
    {
      var a = [];

      if ( __arrayProto.filter ) {
        a = __arrayProto.filter.call( this, fn, this );
      }
      else {
        // Compatibility for browsers without EMCA-252-5 (JS 1.6)
        for ( var i=0, ien=this.length ; i<ien ; i++ ) {
          if ( fn.call( this, this[i], i, this ) ) {
            a.push( this[i] );
          }
        }
      }

      return new _Api( this.context, a );
    },


    flatten: function ()
    {
      var a = [];
      return new _Api( this.context, a.concat.apply( a, this.toArray() ) );
    },


    join:    __arrayProto.join,


    indexOf: __arrayProto.indexOf || function (obj, start)
    {
      for ( var i=(start || 0), ien=this.length ; i<ien ; i++ ) {
        if ( this[i] === obj ) {
          return i;
        }
      }
      return -1;
    },

    iterator: function ( flatten, type, fn, alwaysNew ) {
      var
        a = [], ret,
        i, ien, j, jen,
        context = this.context,
        rows, items, item,
        selector = this.selector;

      // Argument shifting
      if ( typeof flatten === 'string' ) {
        alwaysNew = fn;
        fn = type;
        type = flatten;
        flatten = false;
      }

      for ( i=0, ien=context.length ; i<ien ; i++ ) {
        var apiInst = new _Api( context[i] );

        if ( type === 'table' ) {
          ret = fn.call( apiInst, context[i], i );

          if ( ret !== undefined ) {
            a.push( ret );
          }
        }
        else if ( type === 'columns' || type === 'rows' ) {
          // this has same length as context - one entry for each table
          ret = fn.call( apiInst, context[i], this[i], i );

          if ( ret !== undefined ) {
            a.push( ret );
          }
        }
        else if ( type === 'column' || type === 'column-rows' || type === 'row' || type === 'cell' ) {
          // columns and rows share the same structure.
          // 'this' is an array of column indexes for each context
          items = this[i];

          if ( type === 'column-rows' ) {
            rows = _selector_row_indexes( context[i], selector.opts );
          }

          for ( j=0, jen=items.length ; j<jen ; j++ ) {
            item = items[j];

            if ( type === 'cell' ) {
              ret = fn.call( apiInst, context[i], item.row, item.column, i, j );
            }
            else {
              ret = fn.call( apiInst, context[i], item, i, j, rows );
            }

            if ( ret !== undefined ) {
              a.push( ret );
            }
          }
        }
      }

      if ( a.length || alwaysNew ) {
        var api = new _Api( context, flatten ? a.concat.apply( [], a ) : a );
        var apiSelector = api.selector;
        apiSelector.rows = selector.rows;
        apiSelector.cols = selector.cols;
        apiSelector.opts = selector.opts;
        return api;
      }
      return this;
    },


    lastIndexOf: __arrayProto.lastIndexOf || function (obj, start)
    {
      // Bit cheeky...
      return this.indexOf.apply( this.toArray.reverse(), arguments );
    },


    length:  0,


    map: function ( fn )
    {
      var a = [];

      if ( __arrayProto.map ) {
        a = __arrayProto.map.call( this, fn, this );
      }
      else {
        // Compatibility for browsers without EMCA-252-5 (JS 1.6)
        for ( var i=0, ien=this.length ; i<ien ; i++ ) {
          a.push( fn.call( this, this[i], i ) );
        }
      }

      return new _Api( this.context, a );
    },


    pluck: function ( prop )
    {
      let fn = DataTable.util.get(prop);

      return this.map( function ( el ) {
        return fn(el);
      } );
    },

    pop:     __arrayProto.pop,


    push:    __arrayProto.push,


    // Does not return an API instance
    reduce: __arrayProto.reduce || function ( fn, init )
    {
      return _fnReduce( this, fn, init, 0, this.length, 1 );
    },


    reduceRight: __arrayProto.reduceRight || function ( fn, init )
    {
      return _fnReduce( this, fn, init, this.length-1, -1, -1 );
    },


    reverse: __arrayProto.reverse,


    // Object with rows, columns and opts
    selector: null,


    shift:   __arrayProto.shift,


    slice: function () {
      return new _Api( this.context, this );
    },


    sort:    __arrayProto.sort, // ? name - order?


    splice:  __arrayProto.splice,


    toArray: function ()
    {
      return __arrayProto.slice.call( this );
    },


    to$: function ()
    {
      return $( this );
    },


    toJQuery: function ()
    {
      return $( this );
    },


    unique: function ()
    {
      return new _Api( this.context, _unique(this) );
    },


    unshift: __arrayProto.unshift
  } );


  _Api.extend = function ( scope, obj, ext )
  {
    // Only extend API instances and static properties of the API
    if ( ! ext.length || ! obj || ( ! (obj instanceof _Api) && ! obj.__dt_wrapper ) ) {
      return;
    }

    var
      i, ien,
      struct,
      methodScoping = function ( scope, fn, struc ) {
        return function () {
          var ret = fn.apply( scope, arguments );

          // Method extension
          _Api.extend( ret, ret, struc.methodExt );
          return ret;
        };
      };

    for ( i=0, ien=ext.length ; i<ien ; i++ ) {
      struct = ext[i];

      // Value
      obj[ struct.name ] = struct.type === 'function' ?
        methodScoping( scope, struct.val, struct ) :
        struct.type === 'object' ?
          {} :
          struct.val;

      obj[ struct.name ].__dt_wrapper = true;

      // Property extension
      _Api.extend( scope, obj[ struct.name ], struct.propExt );
    }
  };


  // @todo - Is there need for an augment function?
  // _Api.augment = function ( inst, name )
  // {
  // 	// Find src object in the structure from the name
  // 	var parts = name.split('.');

  // 	_Api.extend( inst, obj );
  // };


  //     [
  //       {
  //         name:      'data'                -- string   - Property name
  //         val:       function () {},       -- function - Api method (or undefined if just an object
  //         methodExt: [ ... ],              -- array    - Array of Api object definitions to extend the method result
  //         propExt:   [ ... ]               -- array    - Array of Api object definitions to extend the property
  //       },
  //       {
  //         name:     'row'
  //         val:       {},
  //         methodExt: [ ... ],
  //         propExt:   [
  //           {
  //             name:      'data'
  //             val:       function () {},
  //             methodExt: [ ... ],
  //             propExt:   [ ... ]
  //           },
  //           ...
  //         ]
  //       }
  //     ]

  _Api.register = _api_register = function ( name, val )
  {
    if ( Array.isArray( name ) ) {
      for ( var j=0, jen=name.length ; j<jen ; j++ ) {
        _Api.register( name[j], val );
      }
      return;
    }

    var
      i, ien,
      heir = name.split('.'),
      struct = __apiStruct,
      key, method;

    var find = function ( src, name ) {
      for ( var i=0, ien=src.length ; i<ien ; i++ ) {
        if ( src[i].name === name ) {
          return src[i];
        }
      }
      return null;
    };

    for ( i=0, ien=heir.length ; i<ien ; i++ ) {
      method = heir[i].indexOf('()') !== -1;
      key = method ?
        heir[i].replace('()', '') :
        heir[i];

      var src = find( struct, key );
      if ( ! src ) {
        src = {
          name:      key,
          val:       {},
          methodExt: [],
          propExt:   [],
          type:      'object'
        };
        struct.push( src );
      }

      if ( i === ien-1 ) {
        src.val = val;
        src.type = typeof val === 'function' ?
          'function' :
          $.isPlainObject( val ) ?
            'object' :
            'other';
      }
      else {
        struct = method ?
          src.methodExt :
          src.propExt;
      }
    }
  };

  _Api.registerPlural = _api_registerPlural = function ( pluralName, singularName, val ) {
    _Api.register( pluralName, val );

    _Api.register( singularName, function () {
      var ret = val.apply( this, arguments );

      if ( ret === this ) {
        // Returned item is the API instance that was passed in, return it
        return this;
      }
      else if ( ret instanceof _Api ) {
        // New API instance returned, want the value from the first item
        // in the returned array for the singular result.
        return ret.length ?
          Array.isArray( ret[0] ) ?
            new _Api( ret.context, ret[0] ) : // Array results are 'enhanced'
            ret[0] :
          undefined;
      }

      // Non-API return - just fire it back
      return ret;
    } );
  };


  /**
   * Selector for HTML tables. Apply the given selector to the give array of
   * DataTables settings objects.
   *
   * @param {string|integer} [selector] jQuery selector string or integer
   * @param  {array} Array of DataTables settings objects to be filtered
   * @return {array}
   * @ignore
   */
  var __table_selector = function ( selector, a )
  {
    if ( Array.isArray(selector) ) {
      return $.map( selector, function (item) {
        return __table_selector(item, a);
      } );
    }

    // Integer is used to pick out a table by index
    if ( typeof selector === 'number' ) {
      return [ a[ selector ] ];
    }

    // Perform a jQuery selector on the table nodes
    var nodes = $.map( a, function (el, i) {
      return el.nTable;
    } );

    return $(nodes)
      .filter( selector )
      .map( function (i) {
        // Need to translate back from the table node to the settings
        var idx = $.inArray( this, nodes );
        return a[ idx ];
      } )
      .toArray();
  };



  /**
   * Context selector for the API's context (i.e. the tables the API instance
   * refers to.
   *
   * @name    DataTable.Api#tables
   * @param {string|integer} [selector] Selector to pick which tables the iterator
   *   should operate on. If not given, all tables in the current context are
   *   used. This can be given as a jQuery selector (for example `':gt(0)'`) to
   *   select multiple tables or as an integer to select a single table.
   * @returns {DataTable.Api} Returns a new API instance if a selector is given.
   */
  _api_register( 'tables()', function ( selector ) {
    // A new instance is created if there was a selector specified
    return selector !== undefined && selector !== null ?
      new _Api( __table_selector( selector, this.context ) ) :
      this;
  } );


  _api_register( 'table()', function ( selector ) {
    var tables = this.tables( selector );
    var ctx = tables.context;

    // Truncate to the first matched table
    return ctx.length ?
      new _Api( ctx[0] ) :
      tables;
  } );


  _api_registerPlural( 'tables().nodes()', 'table().node()' , function () {
    return this.iterator( 'table', function ( ctx ) {
      return ctx.nTable;
    }, 1 );
  } );


  _api_registerPlural( 'tables().body()', 'table().body()' , function () {
    return this.iterator( 'table', function ( ctx ) {
      return ctx.nTBody;
    }, 1 );
  } );


  _api_registerPlural( 'tables().header()', 'table().header()' , function () {
    return this.iterator( 'table', function ( ctx ) {
      return ctx.nTHead;
    }, 1 );
  } );


  _api_registerPlural( 'tables().footer()', 'table().footer()' , function () {
    return this.iterator( 'table', function ( ctx ) {
      return ctx.nTFoot;
    }, 1 );
  } );


  _api_registerPlural( 'tables().containers()', 'table().container()' , function () {
    return this.iterator( 'table', function ( ctx ) {
      return ctx.nTableWrapper;
    }, 1 );
  } );



  /**
   * Redraw the tables in the current context.
   */
  _api_register( 'draw()', function ( paging ) {
    return this.iterator( 'table', function ( settings ) {
      if ( paging === 'page' ) {
        _fnDraw( settings );
      }
      else {
        if ( typeof paging === 'string' ) {
          paging = paging === 'full-hold' ?
            false :
            true;
        }

        _fnReDraw( settings, paging===false );
      }
    } );
  } );



  /**
   * Get the current page index.
   *
   * @return {integer} Current page index (zero based)
   *//**
   * Set the current page.
   *
   * Note that if you attempt to show a page which does not exist, DataTables will
   * not throw an error, but rather reset the paging.
   *
   * @param {integer|string} action The paging action to take. This can be one of:
   *  * `integer` - The page index to jump to
   *  * `string` - An action to take:
   *    * `first` - Jump to first page.
   *    * `next` - Jump to the next page
   *    * `previous` - Jump to previous page
   *    * `last` - Jump to the last page.
   * @returns {DataTables.Api} this
   */
  _api_register( 'page()', function ( action ) {
    if ( action === undefined ) {
      return this.page.info().page; // not an expensive call
    }

    // else, have an action to take on all tables
    return this.iterator( 'table', function ( settings ) {
      _fnPageChange( settings, action );
    } );
  } );


  /**
   * Paging information for the first table in the current context.
   *
   * If you require paging information for another table, use the `table()` method
   * with a suitable selector.
   *
   * @return {object} Object with the following properties set:
   *  * `page` - Current page index (zero based - i.e. the first page is `0`)
   *  * `pages` - Total number of pages
   *  * `start` - Display index for the first record shown on the current page
   *  * `end` - Display index for the last record shown on the current page
   *  * `length` - Display length (number of records). Note that generally `start
   *    + length = end`, but this is not always true, for example if there are
   *    only 2 records to show on the final page, with a length of 10.
   *  * `recordsTotal` - Full data set length
   *  * `recordsDisplay` - Data set length once the current filtering criterion
   *    are applied.
   */
  _api_register( 'page.info()', function ( action ) {
    if ( this.context.length === 0 ) {
      return undefined;
    }

    var
      settings   = this.context[0],
      start      = settings._iDisplayStart,
      len        = settings.oFeatures.bPaginate ? settings._iDisplayLength : -1,
      visRecords = settings.fnRecordsDisplay(),
      all        = len === -1;

    return {
      "page":           all ? 0 : Math.floor( start / len ),
      "pages":          all ? 1 : Math.ceil( visRecords / len ),
      "start":          start,
      "end":            settings.fnDisplayEnd(),
      "length":         len,
      "recordsTotal":   settings.fnRecordsTotal(),
      "recordsDisplay": visRecords,
      "serverSide":     _fnDataSource( settings ) === 'ssp'
    };
  } );


  /**
   * Get the current page length.
   *
   * @return {integer} Current page length. Note `-1` indicates that all records
   *   are to be shown.
   *//**
   * Set the current page length.
   *
   * @param {integer} Page length to set. Use `-1` to show all records.
   * @returns {DataTables.Api} this
   */
  _api_register( 'page.len()', function ( len ) {
    // Note that we can't call this function 'length()' because `length`
    // is a Javascript property of functions which defines how many arguments
    // the function expects.
    if ( len === undefined ) {
      return this.context.length !== 0 ?
        this.context[0]._iDisplayLength :
        undefined;
    }

    // else, set the page length
    return this.iterator( 'table', function ( settings ) {
      _fnLengthChange( settings, len );
    } );
  } );



  var __reload = function ( settings, holdPosition, callback ) {
    // Use the draw event to trigger a callback
    if ( callback ) {
      var api = new _Api( settings );

      api.one( 'draw', function () {
        callback( api.ajax.json() );
      } );
    }

    if ( _fnDataSource( settings ) == 'ssp' ) {
      _fnReDraw( settings, holdPosition );
    }
    else {
      _fnProcessingDisplay( settings, true );

      // Cancel an existing request
      var xhr = settings.jqXHR;
      if ( xhr && xhr.readyState !== 4 ) {
        xhr.abort();
      }

      // Trigger xhr
      _fnBuildAjax( settings, [], function( json ) {
        _fnClearTable( settings );

        var data = _fnAjaxDataSrc( settings, json );
        for ( var i=0, ien=data.length ; i<ien ; i++ ) {
          _fnAddData( settings, data[i] );
        }

        _fnReDraw( settings, holdPosition );
        _fnProcessingDisplay( settings, false );
      } );
    }
  };


  /**
   * Get the JSON response from the last Ajax request that DataTables made to the
   * server. Note that this returns the JSON from the first table in the current
   * context.
   *
   * @return {object} JSON received from the server.
   */
  _api_register( 'ajax.json()', function () {
    var ctx = this.context;

    if ( ctx.length > 0 ) {
      return ctx[0].json;
    }

    // else return undefined;
  } );


  /**
   * Get the data submitted in the last Ajax request
   */
  _api_register( 'ajax.params()', function () {
    var ctx = this.context;

    if ( ctx.length > 0 ) {
      return ctx[0].oAjaxData;
    }

    // else return undefined;
  } );


  /**
   * Reload tables from the Ajax data source. Note that this function will
   * automatically re-draw the table when the remote data has been loaded.
   *
   * @param {boolean} [reset=true] Reset (default) or hold the current paging
   *   position. A full re-sort and re-filter is performed when this method is
   *   called, which is why the pagination reset is the default action.
   * @returns {DataTables.Api} this
   */
  _api_register( 'ajax.reload()', function ( callback, resetPaging ) {
    return this.iterator( 'table', function (settings) {
      __reload( settings, resetPaging===false, callback );
    } );
  } );


  /**
   * Get the current Ajax URL. Note that this returns the URL from the first
   * table in the current context.
   *
   * @return {string} Current Ajax source URL
   *//**
   * Set the Ajax URL. Note that this will set the URL for all tables in the
   * current context.
   *
   * @param {string} url URL to set.
   * @returns {DataTables.Api} this
   */
  _api_register( 'ajax.url()', function ( url ) {
    var ctx = this.context;

    if ( url === undefined ) {
      // get
      if ( ctx.length === 0 ) {
        return undefined;
      }
      ctx = ctx[0];

      return ctx.ajax ?
        $.isPlainObject( ctx.ajax ) ?
          ctx.ajax.url :
          ctx.ajax :
        ctx.sAjaxSource;
    }

    // set
    return this.iterator( 'table', function ( settings ) {
      if ( $.isPlainObject( settings.ajax ) ) {
        settings.ajax.url = url;
      }
      else {
        settings.ajax = url;
      }
      // No need to consider sAjaxSource here since DataTables gives priority
      // to `ajax` over `sAjaxSource`. So setting `ajax` here, renders any
      // value of `sAjaxSource` redundant.
    } );
  } );


  /**
   * Load data from the newly set Ajax URL. Note that this method is only
   * available when `ajax.url()` is used to set a URL. Additionally, this method
   * has the same effect as calling `ajax.reload()` but is provided for
   * convenience when setting a new URL. Like `ajax.reload()` it will
   * automatically redraw the table once the remote data has been loaded.
   *
   * @returns {DataTables.Api} this
   */
  _api_register( 'ajax.url().load()', function ( callback, resetPaging ) {
    // Same as a reload, but makes sense to present it for easy access after a
    // url change
    return this.iterator( 'table', function ( ctx ) {
      __reload( ctx, resetPaging===false, callback );
    } );
  } );




  var _selector_run = function ( type, selector, selectFn, settings, opts )
  {
    var
      out = [], res,
      a, i, ien, j, jen,
      selectorType = typeof selector;

    // Can't just check for isArray here, as an API or jQuery instance might be
    // given with their array like look
    if ( ! selector || selectorType === 'string' || selectorType === 'function' || selector.length === undefined ) {
      selector = [ selector ];
    }

    for ( i=0, ien=selector.length ; i<ien ; i++ ) {
      // Only split on simple strings - complex expressions will be jQuery selectors
      a = selector[i] && selector[i].split && ! selector[i].match(/[\[\(:]/) ?
        selector[i].split(',') :
        [ selector[i] ];

      for ( j=0, jen=a.length ; j<jen ; j++ ) {
        res = selectFn( typeof a[j] === 'string' ? (a[j]).trim() : a[j] );

        if ( res && res.length ) {
          out = out.concat( res );
        }
      }
    }

    // selector extensions
    var ext = _ext.selector[ type ];
    if ( ext.length ) {
      for ( i=0, ien=ext.length ; i<ien ; i++ ) {
        out = ext[i]( settings, opts, out );
      }
    }

    return _unique( out );
  };


  var _selector_opts = function ( opts )
  {
    if ( ! opts ) {
      opts = {};
    }

    // Backwards compatibility for 1.9- which used the terminology filter rather
    // than search
    if ( opts.filter && opts.search === undefined ) {
      opts.search = opts.filter;
    }

    return $.extend( {
      search: 'none',
      order: 'current',
      page: 'all'
    }, opts );
  };


  var _selector_first = function ( inst )
  {
    // Reduce the API instance to the first item found
    for ( var i=0, ien=inst.length ; i<ien ; i++ ) {
      if ( inst[i].length > 0 ) {
        // Assign the first element to the first item in the instance
        // and truncate the instance and context
        inst[0] = inst[i];
        inst[0].length = 1;
        inst.length = 1;
        inst.context = [ inst.context[i] ];

        return inst;
      }
    }

    // Not found - return an empty instance
    inst.length = 0;
    return inst;
  };


  var _selector_row_indexes = function ( settings, opts )
  {
    var
      i, ien, tmp, a=[],
      displayFiltered = settings.aiDisplay,
      displayMaster = settings.aiDisplayMaster;

    var
      search = opts.search,  // none, applied, removed
      order  = opts.order,   // applied, current, index (original - compatibility with 1.9)
      page   = opts.page;    // all, current

    if ( _fnDataSource( settings ) == 'ssp' ) {
      // In server-side processing mode, most options are irrelevant since
      // rows not shown don't exist and the index order is the applied order
      // Removed is a special case - for consistency just return an empty
      // array
      return search === 'removed' ?
        [] :
        _range( 0, displayMaster.length );
    }
    else if ( page == 'current' ) {
      // Current page implies that order=current and filter=applied, since it is
      // fairly senseless otherwise, regardless of what order and search actually
      // are
      for ( i=settings._iDisplayStart, ien=settings.fnDisplayEnd() ; i<ien ; i++ ) {
        a.push( displayFiltered[i] );
      }
    }
    else if ( order == 'current' || order == 'applied' ) {
      if ( search == 'none') {
        a = displayMaster.slice();
      }
      else if ( search == 'applied' ) {
        a = displayFiltered.slice();
      }
      else if ( search == 'removed' ) {
        // O(n+m) solution by creating a hash map
        var displayFilteredMap = {};

        for ( var i=0, ien=displayFiltered.length ; i<ien ; i++ ) {
          displayFilteredMap[displayFiltered[i]] = null;
        }

        a = $.map( displayMaster, function (el) {
          return ! displayFilteredMap.hasOwnProperty(el) ?
            el :
            null;
        } );
      }
    }
    else if ( order == 'index' || order == 'original' ) {
      for ( i=0, ien=settings.aoData.length ; i<ien ; i++ ) {
        if ( search == 'none' ) {
          a.push( i );
        }
        else { // applied | removed
          tmp = $.inArray( i, displayFiltered );

          if ((tmp === -1 && search == 'removed') ||
            (tmp >= 0   && search == 'applied') )
          {
            a.push( i );
          }
        }
      }
    }

    return a;
  };


  /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	 * Rows
	 *
	 * {}          - no selector - use all available rows
	 * {integer}   - row aoData index
	 * {node}      - TR node
	 * {string}    - jQuery selector to apply to the TR elements
	 * {array}     - jQuery array of nodes, or simply an array of TR nodes
	 *
	 */
  var __row_selector = function ( settings, selector, opts )
  {
    var rows;
    var run = function ( sel ) {
      var selInt = _intVal( sel );
      var i, ien;
      var aoData = settings.aoData;

      // Short cut - selector is a number and no options provided (default is
      // all records, so no need to check if the index is in there, since it
      // must be - dev error if the index doesn't exist).
      if ( selInt !== null && ! opts ) {
        return [ selInt ];
      }

      if ( ! rows ) {
        rows = _selector_row_indexes( settings, opts );
      }

      if ( selInt !== null && $.inArray( selInt, rows ) !== -1 ) {
        // Selector - integer
        return [ selInt ];
      }
      else if ( sel === null || sel === undefined || sel === '' ) {
        // Selector - none
        return rows;
      }

      // Selector - function
      if ( typeof sel === 'function' ) {
        return $.map( rows, function (idx) {
          var row = aoData[ idx ];
          return sel( idx, row._aData, row.nTr ) ? idx : null;
        } );
      }

      // Selector - node
      if ( sel.nodeName ) {
        var rowIdx = sel._DT_RowIndex;  // Property added by DT for fast lookup
        var cellIdx = sel._DT_CellIndex;

        if ( rowIdx !== undefined ) {
          // Make sure that the row is actually still present in the table
          return aoData[ rowIdx ] && aoData[ rowIdx ].nTr === sel ?
            [ rowIdx ] :
            [];
        }
        else if ( cellIdx ) {
          return aoData[ cellIdx.row ] && aoData[ cellIdx.row ].nTr === sel.parentNode ?
            [ cellIdx.row ] :
            [];
        }
        else {
          var host = $(sel).closest('*[data-dt-row]');
          return host.length ?
            [ host.data('dt-row') ] :
            [];
        }
      }

      // ID selector. Want to always be able to select rows by id, regardless
      // of if the tr element has been created or not, so can't rely upon
      // jQuery here - hence a custom implementation. This does not match
      // Sizzle's fast selector or HTML4 - in HTML5 the ID can be anything,
      // but to select it using a CSS selector engine (like Sizzle or
      // querySelect) it would need to need to be escaped for some characters.
      // DataTables simplifies this for row selectors since you can select
      // only a row. A # indicates an id any anything that follows is the id -
      // unescaped.
      if ( typeof sel === 'string' && sel.charAt(0) === '#' ) {
        // get row index from id
        var rowObj = settings.aIds[ sel.replace( /^#/, '' ) ];
        if ( rowObj !== undefined ) {
          return [ rowObj.idx ];
        }

        // need to fall through to jQuery in case there is DOM id that
        // matches
      }

      // Get nodes in the order from the `rows` array with null values removed
      var nodes = _removeEmpty(
        _pluck_order( settings.aoData, rows, 'nTr' )
      );

      // Selector - jQuery selector string, array of nodes or jQuery object/
      // As jQuery's .filter() allows jQuery objects to be passed in filter,
      // it also allows arrays, so this will cope with all three options
      return $(nodes)
        .filter( sel )
        .map( function () {
          return this._DT_RowIndex;
        } )
        .toArray();
    };

    return _selector_run( 'row', selector, run, settings, opts );
  };


  _api_register( 'rows()', function ( selector, opts ) {
    // argument shifting
    if ( selector === undefined ) {
      selector = '';
    }
    else if ( $.isPlainObject( selector ) ) {
      opts = selector;
      selector = '';
    }

    opts = _selector_opts( opts );

    var inst = this.iterator( 'table', function ( settings ) {
      return __row_selector( settings, selector, opts );
    }, 1 );

    // Want argument shifting here and in __row_selector?
    inst.selector.rows = selector;
    inst.selector.opts = opts;

    return inst;
  } );

  _api_register( 'rows().nodes()', function () {
    return this.iterator( 'row', function ( settings, row ) {
      return settings.aoData[ row ].nTr || undefined;
    }, 1 );
  } );

  _api_register( 'rows().data()', function () {
    return this.iterator( true, 'rows', function ( settings, rows ) {
      return _pluck_order( settings.aoData, rows, '_aData' );
    }, 1 );
  } );

  _api_registerPlural( 'rows().cache()', 'row().cache()', function ( type ) {
    return this.iterator( 'row', function ( settings, row ) {
      var r = settings.aoData[ row ];
      return type === 'search' ? r._aFilterData : r._aSortData;
    }, 1 );
  } );

  _api_registerPlural( 'rows().invalidate()', 'row().invalidate()', function ( src ) {
    return this.iterator( 'row', function ( settings, row ) {
      _fnInvalidate( settings, row, src );
    } );
  } );

  _api_registerPlural( 'rows().indexes()', 'row().index()', function () {
    return this.iterator( 'row', function ( settings, row ) {
      return row;
    }, 1 );
  } );

  _api_registerPlural( 'rows().ids()', 'row().id()', function ( hash ) {
    var a = [];
    var context = this.context;

    // `iterator` will drop undefined values, but in this case we want them
    for ( var i=0, ien=context.length ; i<ien ; i++ ) {
      for ( var j=0, jen=this[i].length ; j<jen ; j++ ) {
        var id = context[i].rowIdFn( context[i].aoData[ this[i][j] ]._aData );
        a.push( (hash === true ? '#' : '' )+ id );
      }
    }

    return new _Api( context, a );
  } );

  _api_registerPlural( 'rows().remove()', 'row().remove()', function () {
    var that = this;

    this.iterator( 'row', function ( settings, row, thatIdx ) {
      var data = settings.aoData;
      var rowData = data[ row ];
      var i, ien, j, jen;
      var loopRow, loopCells;

      data.splice( row, 1 );

      // Update the cached indexes
      for ( i=0, ien=data.length ; i<ien ; i++ ) {
        loopRow = data[i];
        loopCells = loopRow.anCells;

        // Rows
        if ( loopRow.nTr !== null ) {
          loopRow.nTr._DT_RowIndex = i;
        }

        // Cells
        if ( loopCells !== null ) {
          for ( j=0, jen=loopCells.length ; j<jen ; j++ ) {
            loopCells[j]._DT_CellIndex.row = i;
          }
        }
      }

      // Delete from the display arrays
      _fnDeleteIndex( settings.aiDisplayMaster, row );
      _fnDeleteIndex( settings.aiDisplay, row );
      _fnDeleteIndex( that[ thatIdx ], row, false ); // maintain local indexes

      // For server-side processing tables - subtract the deleted row from the count
      if ( settings._iRecordsDisplay > 0 ) {
        settings._iRecordsDisplay--;
      }

      // Check for an 'overflow' they case for displaying the table
      _fnLengthOverflow( settings );

      // Remove the row's ID reference if there is one
      var id = settings.rowIdFn( rowData._aData );
      if ( id !== undefined ) {
        delete settings.aIds[ id ];
      }
    } );

    this.iterator( 'table', function ( settings ) {
      for ( var i=0, ien=settings.aoData.length ; i<ien ; i++ ) {
        settings.aoData[i].idx = i;
      }
    } );

    return this;
  } );


  _api_register( 'rows.add()', function ( rows ) {
    var newRows = this.iterator( 'table', function ( settings ) {
      var row, i, ien;
      var out = [];

      for ( i=0, ien=rows.length ; i<ien ; i++ ) {
        row = rows[i];

        if ( row.nodeName && row.nodeName.toUpperCase() === 'TR' ) {
          out.push( _fnAddTr( settings, row )[0] );
        }
        else {
          out.push( _fnAddData( settings, row ) );
        }
      }

      return out;
    }, 1 );

    // Return an Api.rows() extended instance, so rows().nodes() etc can be used
    var modRows = this.rows( -1 );
    modRows.pop();
    $.merge( modRows, newRows );

    return modRows;
  } );





  /**
   *
   */
  _api_register( 'row()', function ( selector, opts ) {
    return _selector_first( this.rows( selector, opts ) );
  } );


  _api_register( 'row().data()', function ( data ) {
    var ctx = this.context;

    if ( data === undefined ) {
      // Get
      return ctx.length && this.length ?
        ctx[0].aoData[ this[0] ]._aData :
        undefined;
    }

    // Set
    var row = ctx[0].aoData[ this[0] ];
    row._aData = data;

    // If the DOM has an id, and the data source is an array
    if ( Array.isArray( data ) && row.nTr && row.nTr.id ) {
      _fnSetObjectDataFn( ctx[0].rowId )( data, row.nTr.id );
    }

    // Automatically invalidate
    _fnInvalidate( ctx[0], this[0], 'data' );

    return this;
  } );


  _api_register( 'row().node()', function () {
    var ctx = this.context;

    return ctx.length && this.length ?
      ctx[0].aoData[ this[0] ].nTr || null :
      null;
  } );


  _api_register( 'row.add()', function ( row ) {
    // Allow a jQuery object to be passed in - only a single row is added from
    // it though - the first element in the set
    if ( row instanceof $ && row.length ) {
      row = row[0];
    }

    var rows = this.iterator( 'table', function ( settings ) {
      if ( row.nodeName && row.nodeName.toUpperCase() === 'TR' ) {
        return _fnAddTr( settings, row )[0];
      }
      return _fnAddData( settings, row );
    } );

    // Return an Api.rows() extended instance, with the newly added row selected
    return this.row( rows[0] );
  } );


  $(document).on('plugin-init.dt', function (e, context) {
    var api = new _Api( context );

    api.on( 'stateSaveParams', function ( e, settings, d ) {
      // This could be more compact with the API, but it is a lot faster as a simple
      // internal loop
      var idFn = settings.rowIdFn;
      var data = settings.aoData;
      var ids = [];

      for (var i=0 ; i<data.length ; i++) {
        if (data[i]._detailsShow) {
          ids.push( '#' + idFn(data[i]._aData) );
        }
      }

      d.childRows = ids;
    })

    var loaded = api.state.loaded();

    if ( loaded && loaded.childRows ) {
      api
        .rows( $.map(loaded.childRows, function (id){
          return id.replace(/:/g, '\\:')
        }) )
        .every( function () {
          _fnCallbackFire( context, null, 'requestChild', [ this ] )
        });
    }
  });

  var __details_add = function ( ctx, row, data, klass )
  {
    // Convert to array of TR elements
    var rows = [];
    var addRow = function ( r, k ) {
      // Recursion to allow for arrays of jQuery objects
      if ( Array.isArray( r ) || r instanceof $ ) {
        for ( var i=0, ien=r.length ; i<ien ; i++ ) {
          addRow( r[i], k );
        }
        return;
      }

      // If we get a TR element, then just add it directly - up to the dev
      // to add the correct number of columns etc
      if ( r.nodeName && r.nodeName.toLowerCase() === 'tr' ) {
        rows.push( r );
      }
      else {
        // Otherwise create a row with a wrapper
        var created = $('<tr><td></td></tr>').addClass( k );
        $('td', created)
          .addClass( k )
          .html( r )
          [0].colSpan = _fnVisbleColumns( ctx );

        rows.push( created[0] );
      }
    };

    addRow( data, klass );

    if ( row._details ) {
      row._details.detach();
    }

    row._details = $(rows);

    // If the children were already shown, that state should be retained
    if ( row._detailsShow ) {
      row._details.insertAfter( row.nTr );
    }
  };


  // Make state saving of child row details async to allow them to be batch processed
  var __details_state = DataTable.util.throttle(
    function (ctx) {
      _fnSaveState( ctx[0] )
    },
    500
  );


  var __details_remove = function ( api, idx )
  {
    var ctx = api.context;

    if ( ctx.length ) {
      var row = ctx[0].aoData[ idx !== undefined ? idx : api[0] ];

      if ( row && row._details ) {
        row._details.remove();

        row._detailsShow = undefined;
        row._details = undefined;
        $( row.nTr ).removeClass( 'dt-hasChild' );
        __details_state( ctx );
      }
    }
  };


  var __details_display = function ( api, show ) {
    var ctx = api.context;

    if ( ctx.length && api.length ) {
      var row = ctx[0].aoData[ api[0] ];

      if ( row._details ) {
        row._detailsShow = show;

        if ( show ) {
          row._details.insertAfter( row.nTr );
          $( row.nTr ).addClass( 'dt-hasChild' );
        }
        else {
          row._details.detach();
          $( row.nTr ).removeClass( 'dt-hasChild' );
        }

        _fnCallbackFire( ctx[0], null, 'childRow', [ show, api.row( api[0] ) ] )

        __details_events( ctx[0] );
        __details_state( ctx );
      }
    }
  };


  var __details_events = function ( settings )
  {
    var api = new _Api( settings );
    var namespace = '.dt.DT_details';
    var drawEvent = 'draw'+namespace;
    var colvisEvent = 'column-sizing'+namespace;
    var destroyEvent = 'destroy'+namespace;
    var data = settings.aoData;

    api.off( drawEvent +' '+ colvisEvent +' '+ destroyEvent );

    if ( _pluck( data, '_details' ).length > 0 ) {
      // On each draw, insert the required elements into the document
      api.on( drawEvent, function ( e, ctx ) {
        if ( settings !== ctx ) {
          return;
        }

        api.rows( {page:'current'} ).eq(0).each( function (idx) {
          // Internal data grab
          var row = data[ idx ];

          if ( row._detailsShow ) {
            row._details.insertAfter( row.nTr );
          }
        } );
      } );

      // Column visibility change - update the colspan
      api.on( colvisEvent, function ( e, ctx, idx, vis ) {
        if ( settings !== ctx ) {
          return;
        }

        // Update the colspan for the details rows (note, only if it already has
        // a colspan)
        var row, visible = _fnVisbleColumns( ctx );

        for ( var i=0, ien=data.length ; i<ien ; i++ ) {
          row = data[i];

          if ( row._details ) {
            row._details.children('td[colspan]').attr('colspan', visible );
          }
        }
      } );

      // Table destroyed - nuke any child rows
      api.on( destroyEvent, function ( e, ctx ) {
        if ( settings !== ctx ) {
          return;
        }

        for ( var i=0, ien=data.length ; i<ien ; i++ ) {
          if ( data[i]._details ) {
            __details_remove( api, i );
          }
        }
      } );
    }
  };

  // Strings for the method names to help minification
  var _emp = '';
  var _child_obj = _emp+'row().child';
  var _child_mth = _child_obj+'()';

  // data can be:
  //  tr
  //  string
  //  jQuery or array of any of the above
  _api_register( _child_mth, function ( data, klass ) {
    var ctx = this.context;

    if ( data === undefined ) {
      // get
      return ctx.length && this.length ?
        ctx[0].aoData[ this[0] ]._details :
        undefined;
    }
    else if ( data === true ) {
      // show
      this.child.show();
    }
    else if ( data === false ) {
      // remove
      __details_remove( this );
    }
    else if ( ctx.length && this.length ) {
      // set
      __details_add( ctx[0], ctx[0].aoData[ this[0] ], data, klass );
    }

    return this;
  } );


  _api_register( [
    _child_obj+'.show()',
    _child_mth+'.show()' // only when `child()` was called with parameters (without
  ], function ( show ) {   // it returns an object and this method is not executed)
    __details_display( this, true );
    return this;
  } );


  _api_register( [
    _child_obj+'.hide()',
    _child_mth+'.hide()' // only when `child()` was called with parameters (without
  ], function () {         // it returns an object and this method is not executed)
    __details_display( this, false );
    return this;
  } );


  _api_register( [
    _child_obj+'.remove()',
    _child_mth+'.remove()' // only when `child()` was called with parameters (without
  ], function () {           // it returns an object and this method is not executed)
    __details_remove( this );
    return this;
  } );


  _api_register( _child_obj+'.isShown()', function () {
    var ctx = this.context;

    if ( ctx.length && this.length ) {
      // _detailsShown as false or undefined will fall through to return false
      return ctx[0].aoData[ this[0] ]._detailsShow || false;
    }
    return false;
  } );



  /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	 * Columns
	 *
	 * {integer}           - column index (>=0 count from left, <0 count from right)
	 * "{integer}:visIdx"  - visible column index (i.e. translate to column index)  (>=0 count from left, <0 count from right)
	 * "{integer}:visible" - alias for {integer}:visIdx  (>=0 count from left, <0 count from right)
	 * "{string}:name"     - column name
	 * "{string}"          - jQuery selector on column header nodes
	 *
	 */

  // can be an array of these items, comma separated list, or an array of comma
  // separated lists

  var __re_column_selector = /^([^:]+):(name|visIdx|visible)$/;


  // r1 and r2 are redundant - but it means that the parameters match for the
  // iterator callback in columns().data()
  var __columnData = function ( settings, column, r1, r2, rows ) {
    var a = [];
    for ( var row=0, ien=rows.length ; row<ien ; row++ ) {
      a.push( _fnGetCellData( settings, rows[row], column ) );
    }
    return a;
  };


  var __column_selector = function ( settings, selector, opts )
  {
    var
      columns = settings.aoColumns,
      names = _pluck( columns, 'sName' ),
      nodes = _pluck( columns, 'nTh' );

    var run = function ( s ) {
      var selInt = _intVal( s );

      // Selector - all
      if ( s === '' ) {
        return _range( columns.length );
      }

      // Selector - index
      if ( selInt !== null ) {
        return [ selInt >= 0 ?
          selInt : // Count from left
          columns.length + selInt // Count from right (+ because its a negative value)
        ];
      }

      // Selector = function
      if ( typeof s === 'function' ) {
        var rows = _selector_row_indexes( settings, opts );

        return $.map( columns, function (col, idx) {
          return s(
            idx,
            __columnData( settings, idx, 0, 0, rows ),
            nodes[ idx ]
          ) ? idx : null;
        } );
      }

      // jQuery or string selector
      var match = typeof s === 'string' ?
        s.match( __re_column_selector ) :
        '';

      if ( match ) {
        switch( match[2] ) {
          case 'visIdx':
          case 'visible':
            var idx = parseInt( match[1], 10 );
            // Visible index given, convert to column index
            if ( idx < 0 ) {
              // Counting from the right
              var visColumns = $.map( columns, function (col,i) {
                return col.bVisible ? i : null;
              } );
              return [ visColumns[ visColumns.length + idx ] ];
            }
            // Counting from the left
            return [ _fnVisibleToColumnIndex( settings, idx ) ];

          case 'name':
            // match by name. `names` is column index complete and in order
            return $.map( names, function (name, i) {
              return name === match[1] ? i : null;
            } );

          default:
            return [];
        }
      }

      // Cell in the table body
      if ( s.nodeName && s._DT_CellIndex ) {
        return [ s._DT_CellIndex.column ];
      }

      // jQuery selector on the TH elements for the columns
      var jqResult = $( nodes )
        .filter( s )
        .map( function () {
          return $.inArray( this, nodes ); // `nodes` is column index complete and in order
        } )
        .toArray();

      if ( jqResult.length || ! s.nodeName ) {
        return jqResult;
      }

      // Otherwise a node which might have a `dt-column` data attribute, or be
      // a child or such an element
      var host = $(s).closest('*[data-dt-column]');
      return host.length ?
        [ host.data('dt-column') ] :
        [];
    };

    return _selector_run( 'column', selector, run, settings, opts );
  };


  var __setColumnVis = function ( settings, column, vis ) {
    var
      cols = settings.aoColumns,
      col  = cols[ column ],
      data = settings.aoData,
      row, cells, i, ien, tr;

    // Get
    if ( vis === undefined ) {
      return col.bVisible;
    }

    // Set
    // No change
    if ( col.bVisible === vis ) {
      return;
    }

    if ( vis ) {
      // Insert column
      // Need to decide if we should use appendChild or insertBefore
      var insertBefore = $.inArray( true, _pluck(cols, 'bVisible'), column+1 );

      for ( i=0, ien=data.length ; i<ien ; i++ ) {
        tr = data[i].nTr;
        cells = data[i].anCells;

        if ( tr ) {
          // insertBefore can act like appendChild if 2nd arg is null
          tr.insertBefore( cells[ column ], cells[ insertBefore ] || null );
        }
      }
    }
    else {
      // Remove column
      $( _pluck( settings.aoData, 'anCells', column ) ).detach();
    }

    // Common actions
    col.bVisible = vis;
  };


  _api_register( 'columns()', function ( selector, opts ) {
    // argument shifting
    if ( selector === undefined ) {
      selector = '';
    }
    else if ( $.isPlainObject( selector ) ) {
      opts = selector;
      selector = '';
    }

    opts = _selector_opts( opts );

    var inst = this.iterator( 'table', function ( settings ) {
      return __column_selector( settings, selector, opts );
    }, 1 );

    // Want argument shifting here and in _row_selector?
    inst.selector.cols = selector;
    inst.selector.opts = opts;

    return inst;
  } );

  _api_registerPlural( 'columns().header()', 'column().header()', function ( selector, opts ) {
    return this.iterator( 'column', function ( settings, column ) {
      return settings.aoColumns[column].nTh;
    }, 1 );
  } );

  _api_registerPlural( 'columns().footer()', 'column().footer()', function ( selector, opts ) {
    return this.iterator( 'column', function ( settings, column ) {
      return settings.aoColumns[column].nTf;
    }, 1 );
  } );

  _api_registerPlural( 'columns().data()', 'column().data()', function () {
    return this.iterator( 'column-rows', __columnData, 1 );
  } );

  _api_registerPlural( 'columns().dataSrc()', 'column().dataSrc()', function () {
    return this.iterator( 'column', function ( settings, column ) {
      return settings.aoColumns[column].mData;
    }, 1 );
  } );

  _api_registerPlural( 'columns().cache()', 'column().cache()', function ( type ) {
    return this.iterator( 'column-rows', function ( settings, column, i, j, rows ) {
      return _pluck_order( settings.aoData, rows,
        type === 'search' ? '_aFilterData' : '_aSortData', column
      );
    }, 1 );
  } );

  _api_registerPlural( 'columns().nodes()', 'column().nodes()', function () {
    return this.iterator( 'column-rows', function ( settings, column, i, j, rows ) {
      return _pluck_order( settings.aoData, rows, 'anCells', column ) ;
    }, 1 );
  } );

  _api_registerPlural( 'columns().visible()', 'column().visible()', function ( vis, calc ) {
    var that = this;
    var ret = this.iterator( 'column', function ( settings, column ) {
      if ( vis === undefined ) {
        return settings.aoColumns[ column ].bVisible;
      } // else
      __setColumnVis( settings, column, vis );
    } );

    // Group the column visibility changes
    if ( vis !== undefined ) {
      this.iterator( 'table', function ( settings ) {
        // Redraw the header after changes
        _fnDrawHead( settings, settings.aoHeader );
        _fnDrawHead( settings, settings.aoFooter );

        // Update colspan for no records display. Child rows and extensions will use their own
        // listeners to do this - only need to update the empty table item here
        if ( ! settings.aiDisplay.length ) {
          $(settings.nTBody).find('td[colspan]').attr('colspan', _fnVisbleColumns(settings));
        }

        _fnSaveState( settings );

        // Second loop once the first is done for events
        that.iterator( 'column', function ( settings, column ) {
          _fnCallbackFire( settings, null, 'column-visibility', [settings, column, vis, calc] );
        } );

        if ( calc === undefined || calc ) {
          that.columns.adjust();
        }
      });
    }

    return ret;
  } );

  _api_registerPlural( 'columns().indexes()', 'column().index()', function ( type ) {
    return this.iterator( 'column', function ( settings, column ) {
      return type === 'visible' ?
        _fnColumnIndexToVisible( settings, column ) :
        column;
    }, 1 );
  } );

  _api_register( 'columns.adjust()', function () {
    return this.iterator( 'table', function ( settings ) {
      _fnAdjustColumnSizing( settings );
    }, 1 );
  } );

  _api_register( 'column.index()', function ( type, idx ) {
    if ( this.context.length !== 0 ) {
      var ctx = this.context[0];

      if ( type === 'fromVisible' || type === 'toData' ) {
        return _fnVisibleToColumnIndex( ctx, idx );
      }
      else if ( type === 'fromData' || type === 'toVisible' ) {
        return _fnColumnIndexToVisible( ctx, idx );
      }
    }
  } );

  _api_register( 'column()', function ( selector, opts ) {
    return _selector_first( this.columns( selector, opts ) );
  } );

  var __cell_selector = function ( settings, selector, opts )
  {
    var data = settings.aoData;
    var rows = _selector_row_indexes( settings, opts );
    var cells = _removeEmpty( _pluck_order( data, rows, 'anCells' ) );
    var allCells = $(_flatten( [], cells ));
    var row;
    var columns = settings.aoColumns.length;
    var a, i, ien, j, o, host;

    var run = function ( s ) {
      var fnSelector = typeof s === 'function';

      if ( s === null || s === undefined || fnSelector ) {
        // All cells and function selectors
        a = [];

        for ( i=0, ien=rows.length ; i<ien ; i++ ) {
          row = rows[i];

          for ( j=0 ; j<columns ; j++ ) {
            o = {
              row: row,
              column: j
            };

            if ( fnSelector ) {
              // Selector - function
              host = data[ row ];

              if ( s( o, _fnGetCellData(settings, row, j), host.anCells ? host.anCells[j] : null ) ) {
                a.push( o );
              }
            }
            else {
              // Selector - all
              a.push( o );
            }
          }
        }

        return a;
      }

      // Selector - index
      if ( $.isPlainObject( s ) ) {
        // Valid cell index and its in the array of selectable rows
        return s.column !== undefined && s.row !== undefined && $.inArray( s.row, rows ) !== -1 ?
          [s] :
          [];
      }

      // Selector - jQuery filtered cells
      var jqResult = allCells
        .filter( s )
        .map( function (i, el) {
          return { // use a new object, in case someone changes the values
            row:    el._DT_CellIndex.row,
            column: el._DT_CellIndex.column
          };
        } )
        .toArray();

      if ( jqResult.length || ! s.nodeName ) {
        return jqResult;
      }

      // Otherwise the selector is a node, and there is one last option - the
      // element might be a child of an element which has dt-row and dt-column
      // data attributes
      host = $(s).closest('*[data-dt-row]');
      return host.length ?
        [ {
          row: host.data('dt-row'),
          column: host.data('dt-column')
        } ] :
        [];
    };

    return _selector_run( 'cell', selector, run, settings, opts );
  };




  _api_register( 'cells()', function ( rowSelector, columnSelector, opts ) {
    // Argument shifting
    if ( $.isPlainObject( rowSelector ) ) {
      // Indexes
      if ( rowSelector.row === undefined ) {
        // Selector options in first parameter
        opts = rowSelector;
        rowSelector = null;
      }
      else {
        // Cell index objects in first parameter
        opts = columnSelector;
        columnSelector = null;
      }
    }
    if ( $.isPlainObject( columnSelector ) ) {
      opts = columnSelector;
      columnSelector = null;
    }

    // Cell selector
    if ( columnSelector === null || columnSelector === undefined ) {
      return this.iterator( 'table', function ( settings ) {
        return __cell_selector( settings, rowSelector, _selector_opts( opts ) );
      } );
    }

    // The default built in options need to apply to row and columns
    var internalOpts = opts ? {
      page: opts.page,
      order: opts.order,
      search: opts.search
    } : {};

    // Row + column selector
    var columns = this.columns( columnSelector, internalOpts );
    var rows = this.rows( rowSelector, internalOpts );
    var i, ien, j, jen;

    var cellsNoOpts = this.iterator( 'table', function ( settings, idx ) {
      var a = [];

      for ( i=0, ien=rows[idx].length ; i<ien ; i++ ) {
        for ( j=0, jen=columns[idx].length ; j<jen ; j++ ) {
          a.push( {
            row:    rows[idx][i],
            column: columns[idx][j]
          } );
        }
      }

      return a;
    }, 1 );

    // There is currently only one extension which uses a cell selector extension
    // It is a _major_ performance drag to run this if it isn't needed, so this is
    // an extension specific check at the moment
    var cells = opts && opts.selected ?
      this.cells( cellsNoOpts, opts ) :
      cellsNoOpts;

    $.extend( cells.selector, {
      cols: columnSelector,
      rows: rowSelector,
      opts: opts
    } );

    return cells;
  } );


  _api_registerPlural( 'cells().nodes()', 'cell().node()', function () {
    return this.iterator( 'cell', function ( settings, row, column ) {
      var data = settings.aoData[ row ];

      return data && data.anCells ?
        data.anCells[ column ] :
        undefined;
    }, 1 );
  } );


  _api_register( 'cells().data()', function () {
    return this.iterator( 'cell', function ( settings, row, column ) {
      return _fnGetCellData( settings, row, column );
    }, 1 );
  } );


  _api_registerPlural( 'cells().cache()', 'cell().cache()', function ( type ) {
    type = type === 'search' ? '_aFilterData' : '_aSortData';

    return this.iterator( 'cell', function ( settings, row, column ) {
      return settings.aoData[ row ][ type ][ column ];
    }, 1 );
  } );


  _api_registerPlural( 'cells().render()', 'cell().render()', function ( type ) {
    return this.iterator( 'cell', function ( settings, row, column ) {
      return _fnGetCellData( settings, row, column, type );
    }, 1 );
  } );


  _api_registerPlural( 'cells().indexes()', 'cell().index()', function () {
    return this.iterator( 'cell', function ( settings, row, column ) {
      return {
        row: row,
        column: column,
        columnVisible: _fnColumnIndexToVisible( settings, column )
      };
    }, 1 );
  } );


  _api_registerPlural( 'cells().invalidate()', 'cell().invalidate()', function ( src ) {
    return this.iterator( 'cell', function ( settings, row, column ) {
      _fnInvalidate( settings, row, src, column );
    } );
  } );



  _api_register( 'cell()', function ( rowSelector, columnSelector, opts ) {
    return _selector_first( this.cells( rowSelector, columnSelector, opts ) );
  } );


  _api_register( 'cell().data()', function ( data ) {
    var ctx = this.context;
    var cell = this[0];

    if ( data === undefined ) {
      // Get
      return ctx.length && cell.length ?
        _fnGetCellData( ctx[0], cell[0].row, cell[0].column ) :
        undefined;
    }

    // Set
    _fnSetCellData( ctx[0], cell[0].row, cell[0].column, data );
    _fnInvalidate( ctx[0], cell[0].row, 'data', cell[0].column );

    return this;
  } );



  /**
   * Get current ordering (sorting) that has been applied to the table.
   *
   * @returns {array} 2D array containing the sorting information for the first
   *   table in the current context. Each element in the parent array represents
   *   a column being sorted upon (i.e. multi-sorting with two columns would have
   *   2 inner arrays). The inner arrays may have 2 or 3 elements. The first is
   *   the column index that the sorting condition applies to, the second is the
   *   direction of the sort (`desc` or `asc`) and, optionally, the third is the
   *   index of the sorting order from the `column.sorting` initialisation array.
   *//**
   * Set the ordering for the table.
   *
   * @param {integer} order Column index to sort upon.
   * @param {string} direction Direction of the sort to be applied (`asc` or `desc`)
   * @returns {DataTables.Api} this
   *//**
   * Set the ordering for the table.
   *
   * @param {array} order 1D array of sorting information to be applied.
   * @param {array} [...] Optional additional sorting conditions
   * @returns {DataTables.Api} this
   *//**
   * Set the ordering for the table.
   *
   * @param {array} order 2D array of sorting information to be applied.
   * @returns {DataTables.Api} this
   */
  _api_register( 'order()', function ( order, dir ) {
    var ctx = this.context;

    if ( order === undefined ) {
      // get
      return ctx.length !== 0 ?
        ctx[0].aaSorting :
        undefined;
    }

    // set
    if ( typeof order === 'number' ) {
      // Simple column / direction passed in
      order = [ [ order, dir ] ];
    }
    else if ( order.length && ! Array.isArray( order[0] ) ) {
      // Arguments passed in (list of 1D arrays)
      order = Array.prototype.slice.call( arguments );
    }
    // otherwise a 2D array was passed in

    return this.iterator( 'table', function ( settings ) {
      settings.aaSorting = order.slice();
    } );
  } );


  /**
   * Attach a sort listener to an element for a given column
   *
   * @param {node|jQuery|string} node Identifier for the element(s) to attach the
   *   listener to. This can take the form of a single DOM node, a jQuery
   *   collection of nodes or a jQuery selector which will identify the node(s).
   * @param {integer} column the column that a click on this node will sort on
   * @param {function} [callback] callback function when sort is run
   * @returns {DataTables.Api} this
   */
  _api_register( 'order.listener()', function ( node, column, callback ) {
    return this.iterator( 'table', function ( settings ) {
      _fnSortAttachListener( settings, node, column, callback );
    } );
  } );


  _api_register( 'order.fixed()', function ( set ) {
    if ( ! set ) {
      var ctx = this.context;
      var fixed = ctx.length ?
        ctx[0].aaSortingFixed :
        undefined;

      return Array.isArray( fixed ) ?
        { pre: fixed } :
        fixed;
    }

    return this.iterator( 'table', function ( settings ) {
      settings.aaSortingFixed = $.extend( true, {}, set );
    } );
  } );


  // Order by the selected column(s)
  _api_register( [
    'columns().order()',
    'column().order()'
  ], function ( dir ) {
    var that = this;

    return this.iterator( 'table', function ( settings, i ) {
      var sort = [];

      $.each( that[i], function (j, col) {
        sort.push( [ col, dir ] );
      } );

      settings.aaSorting = sort;
    } );
  } );



  _api_register( 'search()', function ( input, regex, smart, caseInsen ) {
    var ctx = this.context;

    if ( input === undefined ) {
      // get
      return ctx.length !== 0 ?
        ctx[0].oPreviousSearch.sSearch :
        undefined;
    }

    // set
    return this.iterator( 'table', function ( settings ) {
      if ( ! settings.oFeatures.bFilter ) {
        return;
      }

      _fnFilterComplete( settings, $.extend( {}, settings.oPreviousSearch, {
        "sSearch": input+"",
        "bRegex":  regex === null ? false : regex,
        "bSmart":  smart === null ? true  : smart,
        "bCaseInsensitive": caseInsen === null ? true : caseInsen
      } ), 1 );
    } );
  } );


  _api_registerPlural(
    'columns().search()',
    'column().search()',
    function ( input, regex, smart, caseInsen ) {
      return this.iterator( 'column', function ( settings, column ) {
        var preSearch = settings.aoPreSearchCols;

        if ( input === undefined ) {
          // get
          return preSearch[ column ].sSearch;
        }

        // set
        if ( ! settings.oFeatures.bFilter ) {
          return;
        }

        $.extend( preSearch[ column ], {
          "sSearch": input+"",
          "bRegex":  regex === null ? false : regex,
          "bSmart":  smart === null ? true  : smart,
          "bCaseInsensitive": caseInsen === null ? true : caseInsen
        } );

        _fnFilterComplete( settings, settings.oPreviousSearch, 1 );
      } );
    }
  );

  /*
	 * State API methods
	 */

  _api_register( 'state()', function () {
    return this.context.length ?
      this.context[0].oSavedState :
      null;
  } );


  _api_register( 'state.clear()', function () {
    return this.iterator( 'table', function ( settings ) {
      // Save an empty object
      settings.fnStateSaveCallback.call( settings.oInstance, settings, {} );
    } );
  } );


  _api_register( 'state.loaded()', function () {
    return this.context.length ?
      this.context[0].oLoadedState :
      null;
  } );


  _api_register( 'state.save()', function () {
    return this.iterator( 'table', function ( settings ) {
      _fnSaveState( settings );
    } );
  } );



  /**
   * Provide a common method for plug-ins to check the version of DataTables being
   * used, in order to ensure compatibility.
   *
   *  @param {string} version Version string to check for, in the format "X.Y.Z".
   *    Note that the formats "X" and "X.Y" are also acceptable.
   *  @returns {boolean} true if this version of DataTables is greater or equal to
   *    the required version, or false if this version of DataTales is not
   *    suitable
   *  @static
   *  @dtopt API-Static
   *
   *  @example
   *    alert( $.fn.dataTable.versionCheck( '1.9.0' ) );
   */
  DataTable.versionCheck = DataTable.fnVersionCheck = function( version )
  {
    var aThis = DataTable.version.split('.');
    var aThat = version.split('.');
    var iThis, iThat;

    for ( var i=0, iLen=aThat.length ; i<iLen ; i++ ) {
      iThis = parseInt( aThis[i], 10 ) || 0;
      iThat = parseInt( aThat[i], 10 ) || 0;

      // Parts are the same, keep comparing
      if (iThis === iThat) {
        continue;
      }

      // Parts are different, return immediately
      return iThis > iThat;
    }

    return true;
  };


  /**
   * Check if a `<table>` node is a DataTable table already or not.
   *
   *  @param {node|jquery|string} table Table node, jQuery object or jQuery
   *      selector for the table to test. Note that if more than more than one
   *      table is passed on, only the first will be checked
   *  @returns {boolean} true the table given is a DataTable, or false otherwise
   *  @static
   *  @dtopt API-Static
   *
   *  @example
   *    if ( ! $.fn.DataTable.isDataTable( '#example' ) ) {
   *      $('#example').dataTable();
   *    }
   */
  DataTable.isDataTable = DataTable.fnIsDataTable = function ( table )
  {
    var t = $(table).get(0);
    var is = false;

    if ( table instanceof DataTable.Api ) {
      return true;
    }

    $.each( DataTable.settings, function (i, o) {
      var head = o.nScrollHead ? $('table', o.nScrollHead)[0] : null;
      var foot = o.nScrollFoot ? $('table', o.nScrollFoot)[0] : null;

      if ( o.nTable === t || head === t || foot === t ) {
        is = true;
      }
    } );

    return is;
  };


  /**
   * Get all DataTable tables that have been initialised - optionally you can
   * select to get only currently visible tables.
   *
   *  @param {boolean} [visible=false] Flag to indicate if you want all (default)
   *    or visible tables only.
   *  @returns {array} Array of `table` nodes (not DataTable instances) which are
   *    DataTables
   *  @static
   *  @dtopt API-Static
   *
   *  @example
   *    $.each( $.fn.dataTable.tables(true), function () {
   *      $(table).DataTable().columns.adjust();
   *    } );
   */
  DataTable.tables = DataTable.fnTables = function ( visible )
  {
    var api = false;

    if ( $.isPlainObject( visible ) ) {
      api = visible.api;
      visible = visible.visible;
    }

    var a = $.map( DataTable.settings, function (o) {
      if ( !visible || (visible && $(o.nTable).is(':visible')) ) {
        return o.nTable;
      }
    } );

    return api ?
      new _Api( a ) :
      a;
  };


  /**
   * Convert from camel case parameters to Hungarian notation. This is made public
   * for the extensions to provide the same ability as DataTables core to accept
   * either the 1.9 style Hungarian notation, or the 1.10+ style camelCase
   * parameters.
   *
   *  @param {object} src The model object which holds all parameters that can be
   *    mapped.
   *  @param {object} user The object to convert from camel case to Hungarian.
   *  @param {boolean} force When set to `true`, properties which already have a
   *    Hungarian value in the `user` object will be overwritten. Otherwise they
   *    won't be.
   */
  DataTable.camelToHungarian = _fnCamelToHungarian;



  /**
   *
   */
  _api_register( '$()', function ( selector, opts ) {
    var
      rows   = this.rows( opts ).nodes(), // Get all rows
      jqRows = $(rows);

    return $( [].concat(
      jqRows.filter( selector ).toArray(),
      jqRows.find( selector ).toArray()
    ) );
  } );


  // jQuery functions to operate on the tables
  $.each( [ 'on', 'one', 'off' ], function (i, key) {
    _api_register( key+'()', function ( /* event, handler */ ) {
      var args = Array.prototype.slice.call(arguments);

      // Add the `dt` namespace automatically if it isn't already present
      args[0] = $.map( args[0].split( /\s/ ), function ( e ) {
        return ! e.match(/\.dt\b/) ?
          e+'.dt' :
          e;
      } ).join( ' ' );

      var inst = $( this.tables().nodes() );
      inst[key].apply( inst, args );
      return this;
    } );
  } );


  _api_register( 'clear()', function () {
    return this.iterator( 'table', function ( settings ) {
      _fnClearTable( settings );
    } );
  } );


  _api_register( 'settings()', function () {
    return new _Api( this.context, this.context );
  } );


  _api_register( 'init()', function () {
    var ctx = this.context;
    return ctx.length ? ctx[0].oInit : null;
  } );


  _api_register( 'data()', function () {
    return this.iterator( 'table', function ( settings ) {
      return _pluck( settings.aoData, '_aData' );
    } ).flatten();
  } );


  _api_register( 'destroy()', function ( remove ) {
    remove = remove || false;

    return this.iterator( 'table', function ( settings ) {
      var classes   = settings.oClasses;
      var table     = settings.nTable;
      var tbody     = settings.nTBody;
      var thead     = settings.nTHead;
      var tfoot     = settings.nTFoot;
      var jqTable   = $(table);
      var jqTbody   = $(tbody);
      var jqWrapper = $(settings.nTableWrapper);
      var rows      = $.map( settings.aoData, function (r) { return r.nTr; } );
      var i, ien;

      // Flag to note that the table is currently being destroyed - no action
      // should be taken
      settings.bDestroying = true;

      // Fire off the destroy callbacks for plug-ins etc
      _fnCallbackFire( settings, "aoDestroyCallback", "destroy", [settings] );

      // If not being removed from the document, make all columns visible
      if ( ! remove ) {
        new _Api( settings ).columns().visible( true );
      }

      // Blitz all `DT` namespaced events (these are internal events, the
      // lowercase, `dt` events are user subscribed and they are responsible
      // for removing them
      jqWrapper.off('.DT').find(':not(tbody *)').off('.DT');
      $(window).off('.DT-'+settings.sInstance);

      // When scrolling we had to break the table up - restore it
      if ( table != thead.parentNode ) {
        jqTable.children('thead').detach();
        jqTable.append( thead );
      }

      if ( tfoot && table != tfoot.parentNode ) {
        jqTable.children('tfoot').detach();
        jqTable.append( tfoot );
      }

      settings.aaSorting = [];
      settings.aaSortingFixed = [];
      _fnSortingClasses( settings );

      $( rows ).removeClass( settings.asStripeClasses.join(' ') );

      $('th, td', thead).removeClass( classes.sSortable+' '+
        classes.sSortableAsc+' '+classes.sSortableDesc+' '+classes.sSortableNone
      );

      // Add the TR elements back into the table in their original order
      jqTbody.children().detach();
      jqTbody.append( rows );

      var orig = settings.nTableWrapper.parentNode;

      // Remove the DataTables generated nodes, events and classes
      var removedMethod = remove ? 'remove' : 'detach';
      jqTable[ removedMethod ]();
      jqWrapper[ removedMethod ]();

      // If we need to reattach the table to the document
      if ( ! remove && orig ) {
        // insertBefore acts like appendChild if !arg[1]
        orig.insertBefore( table, settings.nTableReinsertBefore );

        // Restore the width of the original table - was read from the style property,
        // so we can restore directly to that
        jqTable
          .css( 'width', settings.sDestroyWidth )
          .removeClass( classes.sTable );

        // If the were originally stripe classes - then we add them back here.
        // Note this is not fool proof (for example if not all rows had stripe
        // classes - but it's a good effort without getting carried away
        ien = settings.asDestroyStripes.length;

        if ( ien ) {
          jqTbody.children().each( function (i) {
            $(this).addClass( settings.asDestroyStripes[i % ien] );
          } );
        }
      }

      /* Remove the settings object from the settings array */
      var idx = $.inArray( settings, DataTable.settings );
      if ( idx !== -1 ) {
        DataTable.settings.splice( idx, 1 );
      }
    } );
  } );


  // Add the `every()` method for rows, columns and cells in a compact form
  $.each( [ 'column', 'row', 'cell' ], function ( i, type ) {
    _api_register( type+'s().every()', function ( fn ) {
      var opts = this.selector.opts;
      var api = this;

      return this.iterator( type, function ( settings, arg1, arg2, arg3, arg4 ) {
        // Rows and columns:
        //  arg1 - index
        //  arg2 - table counter
        //  arg3 - loop counter
        //  arg4 - undefined
        // Cells:
        //  arg1 - row index
        //  arg2 - column index
        //  arg3 - table counter
        //  arg4 - loop counter
        fn.call(
          api[ type ](
            arg1,
            type==='cell' ? arg2 : opts,
            type==='cell' ? opts : undefined
          ),
          arg1, arg2, arg3, arg4
        );
      } );
    } );
  } );


  // i18n method for extensions to be able to use the language object from the
  // DataTable
  _api_register( 'i18n()', function ( token, def, plural ) {
    var ctx = this.context[0];
    var resolved = _fnGetObjectDataFn( token )( ctx.oLanguage );

    if ( resolved === undefined ) {
      resolved = def;
    }

    if ( plural !== undefined && $.isPlainObject( resolved ) ) {
      resolved = resolved[ plural ] !== undefined ?
        resolved[ plural ] :
        resolved._;
    }

    return resolved.replace( '%d', plural ); // nb: plural might be undefined,
  } );
  /**
   * Version string for plug-ins to check compatibility. Allowed format is
   * `a.b.c-d` where: a:int, b:int, c:int, d:string(dev|beta|alpha). `d` is used
   * only for non-release builds. See http://semver.org/ for more information.
   *  @member
   *  @type string
   *  @default Version number
   */
  DataTable.version = "1.12.1";

  /**
   * Private data store, containing all of the settings objects that are
   * created for the tables on a given page.
   *
   * Note that the `DataTable.settings` object is aliased to
   * `jQuery.fn.dataTableExt` through which it may be accessed and
   * manipulated, or `jQuery.fn.dataTable.settings`.
   *  @member
   *  @type array
   *  @default []
   *  @private
   */
  DataTable.settings = [];

  /**
   * Object models container, for the various models that DataTables has
   * available to it. These models define the objects that are used to hold
   * the active state and configuration of the table.
   *  @namespace
   */
  DataTable.models = {};



  /**
   * Template object for the way in which DataTables holds information about
   * search information for the global filter and individual column filters.
   *  @namespace
   */
  DataTable.models.oSearch = {
    /**
     * Flag to indicate if the filtering should be case insensitive or not
     *  @type boolean
     *  @default true
     */
    "bCaseInsensitive": true,

    /**
     * Applied search term
     *  @type string
     *  @default <i>Empty string</i>
     */
    "sSearch": "",

    /**
     * Flag to indicate if the search term should be interpreted as a
     * regular expression (true) or not (false) and therefore and special
     * regex characters escaped.
     *  @type boolean
     *  @default false
     */
    "bRegex": false,

    /**
     * Flag to indicate if DataTables is to use its smart filtering or not.
     *  @type boolean
     *  @default true
     */
    "bSmart": true,

    /**
     * Flag to indicate if DataTables should only trigger a search when
     * the return key is pressed.
     *  @type boolean
     *  @default false
     */
    "return": false
  };




  /**
   * Template object for the way in which DataTables holds information about
   * each individual row. This is the object format used for the settings
   * aoData array.
   *  @namespace
   */
  DataTable.models.oRow = {
    /**
     * TR element for the row
     *  @type node
     *  @default null
     */
    "nTr": null,

    /**
     * Array of TD elements for each row. This is null until the row has been
     * created.
     *  @type array nodes
     *  @default []
     */
    "anCells": null,

    /**
     * Data object from the original data source for the row. This is either
     * an array if using the traditional form of DataTables, or an object if
     * using mData options. The exact type will depend on the passed in
     * data from the data source, or will be an array if using DOM a data
     * source.
     *  @type array|object
     *  @default []
     */
    "_aData": [],

    /**
     * Sorting data cache - this array is ostensibly the same length as the
     * number of columns (although each index is generated only as it is
     * needed), and holds the data that is used for sorting each column in the
     * row. We do this cache generation at the start of the sort in order that
     * the formatting of the sort data need be done only once for each cell
     * per sort. This array should not be read from or written to by anything
     * other than the master sorting methods.
     *  @type array
     *  @default null
     *  @private
     */
    "_aSortData": null,

    /**
     * Per cell filtering data cache. As per the sort data cache, used to
     * increase the performance of the filtering in DataTables
     *  @type array
     *  @default null
     *  @private
     */
    "_aFilterData": null,

    /**
     * Filtering data cache. This is the same as the cell filtering cache, but
     * in this case a string rather than an array. This is easily computed with
     * a join on `_aFilterData`, but is provided as a cache so the join isn't
     * needed on every search (memory traded for performance)
     *  @type array
     *  @default null
     *  @private
     */
    "_sFilterRow": null,

    /**
     * Cache of the class name that DataTables has applied to the row, so we
     * can quickly look at this variable rather than needing to do a DOM check
     * on className for the nTr property.
     *  @type string
     *  @default <i>Empty string</i>
     *  @private
     */
    "_sRowStripe": "",

    /**
     * Denote if the original data source was from the DOM, or the data source
     * object. This is used for invalidating data, so DataTables can
     * automatically read data from the original source, unless uninstructed
     * otherwise.
     *  @type string
     *  @default null
     *  @private
     */
    "src": null,

    /**
     * Index in the aoData array. This saves an indexOf lookup when we have the
     * object, but want to know the index
     *  @type integer
     *  @default -1
     *  @private
     */
    "idx": -1
  };


  /**
   * Template object for the column information object in DataTables. This object
   * is held in the settings aoColumns array and contains all the information that
   * DataTables needs about each individual column.
   *
   * Note that this object is related to {@link DataTable.defaults.column}
   * but this one is the internal data store for DataTables's cache of columns.
   * It should NOT be manipulated outside of DataTables. Any configuration should
   * be done through the initialisation options.
   *  @namespace
   */
  DataTable.models.oColumn = {
    /**
     * Column index. This could be worked out on-the-fly with $.inArray, but it
     * is faster to just hold it as a variable
     *  @type integer
     *  @default null
     */
    "idx": null,

    /**
     * A list of the columns that sorting should occur on when this column
     * is sorted. That this property is an array allows multi-column sorting
     * to be defined for a column (for example first name / last name columns
     * would benefit from this). The values are integers pointing to the
     * columns to be sorted on (typically it will be a single integer pointing
     * at itself, but that doesn't need to be the case).
     *  @type array
     */
    "aDataSort": null,

    /**
     * Define the sorting directions that are applied to the column, in sequence
     * as the column is repeatedly sorted upon - i.e. the first value is used
     * as the sorting direction when the column if first sorted (clicked on).
     * Sort it again (click again) and it will move on to the next index.
     * Repeat until loop.
     *  @type array
     */
    "asSorting": null,

    /**
     * Flag to indicate if the column is searchable, and thus should be included
     * in the filtering or not.
     *  @type boolean
     */
    "bSearchable": null,

    /**
     * Flag to indicate if the column is sortable or not.
     *  @type boolean
     */
    "bSortable": null,

    /**
     * Flag to indicate if the column is currently visible in the table or not
     *  @type boolean
     */
    "bVisible": null,

    /**
     * Store for manual type assignment using the `column.type` option. This
     * is held in store so we can manipulate the column's `sType` property.
     *  @type string
     *  @default null
     *  @private
     */
    "_sManualType": null,

    /**
     * Flag to indicate if HTML5 data attributes should be used as the data
     * source for filtering or sorting. True is either are.
     *  @type boolean
     *  @default false
     *  @private
     */
    "_bAttrSrc": false,

    /**
     * Developer definable function that is called whenever a cell is created (Ajax source,
     * etc) or processed for input (DOM source). This can be used as a compliment to mRender
     * allowing you to modify the DOM element (add background colour for example) when the
     * element is available.
     *  @type function
     *  @param {element} nTd The TD node that has been created
     *  @param {*} sData The Data for the cell
     *  @param {array|object} oData The data for the whole row
     *  @param {int} iRow The row index for the aoData data store
     *  @default null
     */
    "fnCreatedCell": null,

    /**
     * Function to get data from a cell in a column. You should <b>never</b>
     * access data directly through _aData internally in DataTables - always use
     * the method attached to this property. It allows mData to function as
     * required. This function is automatically assigned by the column
     * initialisation method
     *  @type function
     *  @param {array|object} oData The data array/object for the array
     *    (i.e. aoData[]._aData)
     *  @param {string} sSpecific The specific data type you want to get -
     *    'display', 'type' 'filter' 'sort'
     *  @returns {*} The data for the cell from the given row's data
     *  @default null
     */
    "fnGetData": null,

    /**
     * Function to set data for a cell in the column. You should <b>never</b>
     * set the data directly to _aData internally in DataTables - always use
     * this method. It allows mData to function as required. This function
     * is automatically assigned by the column initialisation method
     *  @type function
     *  @param {array|object} oData The data array/object for the array
     *    (i.e. aoData[]._aData)
     *  @param {*} sValue Value to set
     *  @default null
     */
    "fnSetData": null,

    /**
     * Property to read the value for the cells in the column from the data
     * source array / object. If null, then the default content is used, if a
     * function is given then the return from the function is used.
     *  @type function|int|string|null
     *  @default null
     */
    "mData": null,

    /**
     * Partner property to mData which is used (only when defined) to get
     * the data - i.e. it is basically the same as mData, but without the
     * 'set' option, and also the data fed to it is the result from mData.
     * This is the rendering method to match the data method of mData.
     *  @type function|int|string|null
     *  @default null
     */
    "mRender": null,

    /**
     * Unique header TH/TD element for this column - this is what the sorting
     * listener is attached to (if sorting is enabled.)
     *  @type node
     *  @default null
     */
    "nTh": null,

    /**
     * Unique footer TH/TD element for this column (if there is one). Not used
     * in DataTables as such, but can be used for plug-ins to reference the
     * footer for each column.
     *  @type node
     *  @default null
     */
    "nTf": null,

    /**
     * The class to apply to all TD elements in the table's TBODY for the column
     *  @type string
     *  @default null
     */
    "sClass": null,

    /**
     * When DataTables calculates the column widths to assign to each column,
     * it finds the longest string in each column and then constructs a
     * temporary table and reads the widths from that. The problem with this
     * is that "mmm" is much wider then "iiii", but the latter is a longer
     * string - thus the calculation can go wrong (doing it properly and putting
     * it into an DOM object and measuring that is horribly(!) slow). Thus as
     * a "work around" we provide this option. It will append its value to the
     * text that is found to be the longest string for the column - i.e. padding.
     *  @type string
     */
    "sContentPadding": null,

    /**
     * Allows a default value to be given for a column's data, and will be used
     * whenever a null data source is encountered (this can be because mData
     * is set to null, or because the data source itself is null).
     *  @type string
     *  @default null
     */
    "sDefaultContent": null,

    /**
     * Name for the column, allowing reference to the column by name as well as
     * by index (needs a lookup to work by name).
     *  @type string
     */
    "sName": null,

    /**
     * Custom sorting data type - defines which of the available plug-ins in
     * afnSortData the custom sorting will use - if any is defined.
     *  @type string
     *  @default std
     */
    "sSortDataType": 'std',

    /**
     * Class to be applied to the header element when sorting on this column
     *  @type string
     *  @default null
     */
    "sSortingClass": null,

    /**
     * Class to be applied to the header element when sorting on this column -
     * when jQuery UI theming is used.
     *  @type string
     *  @default null
     */
    "sSortingClassJUI": null,

    /**
     * Title of the column - what is seen in the TH element (nTh).
     *  @type string
     */
    "sTitle": null,

    /**
     * Column sorting and filtering type
     *  @type string
     *  @default null
     */
    "sType": null,

    /**
     * Width of the column
     *  @type string
     *  @default null
     */
    "sWidth": null,

    /**
     * Width of the column when it was first "encountered"
     *  @type string
     *  @default null
     */
    "sWidthOrig": null
  };


  /*
	 * Developer note: The properties of the object below are given in Hungarian
	 * notation, that was used as the interface for DataTables prior to v1.10, however
	 * from v1.10 onwards the primary interface is camel case. In order to avoid
	 * breaking backwards compatibility utterly with this change, the Hungarian
	 * version is still, internally the primary interface, but is is not documented
	 * - hence the @name tags in each doc comment. This allows a Javascript function
	 * to create a map from Hungarian notation to camel case (going the other direction
	 * would require each property to be listed, which would add around 3K to the size
	 * of DataTables, while this method is about a 0.5K hit).
	 *
	 * Ultimately this does pave the way for Hungarian notation to be dropped
	 * completely, but that is a massive amount of work and will break current
	 * installs (therefore is on-hold until v2).
	 */

  /**
   * Initialisation options that can be given to DataTables at initialisation
   * time.
   *  @namespace
   */
  DataTable.defaults = {
    /**
     * An array of data to use for the table, passed in at initialisation which
     * will be used in preference to any data which is already in the DOM. This is
     * particularly useful for constructing tables purely in Javascript, for
     * example with a custom Ajax call.
     *  @type array
     *  @default null
     *
     *  @dtopt Option
     *  @name DataTable.defaults.data
     *
     *  @example
     *    // Using a 2D array data source
     *    $(document).ready( function () {
     *      $('#example').dataTable( {
     *        "data": [
     *          ['Trident', 'Internet Explorer 4.0', 'Win 95+', 4, 'X'],
     *          ['Trident', 'Internet Explorer 5.0', 'Win 95+', 5, 'C'],
     *        ],
     *        "columns": [
     *          { "title": "Engine" },
     *          { "title": "Browser" },
     *          { "title": "Platform" },
     *          { "title": "Version" },
     *          { "title": "Grade" }
     *        ]
     *      } );
     *    } );
     *
     *  @example
     *    // Using an array of objects as a data source (`data`)
     *    $(document).ready( function () {
     *      $('#example').dataTable( {
     *        "data": [
     *          {
     *            "engine":   "Trident",
     *            "browser":  "Internet Explorer 4.0",
     *            "platform": "Win 95+",
     *            "version":  4,
     *            "grade":    "X"
     *          },
     *          {
     *            "engine":   "Trident",
     *            "browser":  "Internet Explorer 5.0",
     *            "platform": "Win 95+",
     *            "version":  5,
     *            "grade":    "C"
     *          }
     *        ],
     *        "columns": [
     *          { "title": "Engine",   "data": "engine" },
     *          { "title": "Browser",  "data": "browser" },
     *          { "title": "Platform", "data": "platform" },
     *          { "title": "Version",  "data": "version" },
     *          { "title": "Grade",    "data": "grade" }
     *        ]
     *      } );
     *    } );
     */
    "aaData": null,


    /**
     * If ordering is enabled, then DataTables will perform a first pass sort on
     * initialisation. You can define which column(s) the sort is performed
     * upon, and the sorting direction, with this variable. The `sorting` array
     * should contain an array for each column to be sorted initially containing
     * the column's index and a direction string ('asc' or 'desc').
     *  @type array
     *  @default [[0,'asc']]
     *
     *  @dtopt Option
     *  @name DataTable.defaults.order
     *
     *  @example
     *    // Sort by 3rd column first, and then 4th column
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "order": [[2,'asc'], [3,'desc']]
     *      } );
     *    } );
     *
     *    // No initial sorting
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "order": []
     *      } );
     *    } );
     */
    "aaSorting": [[0,'asc']],


    /**
     * This parameter is basically identical to the `sorting` parameter, but
     * cannot be overridden by user interaction with the table. What this means
     * is that you could have a column (visible or hidden) which the sorting
     * will always be forced on first - any sorting after that (from the user)
     * will then be performed as required. This can be useful for grouping rows
     * together.
     *  @type array
     *  @default null
     *
     *  @dtopt Option
     *  @name DataTable.defaults.orderFixed
     *
     *  @example
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "orderFixed": [[0,'asc']]
     *      } );
     *    } )
     */
    "aaSortingFixed": [],


    /**
     * DataTables can be instructed to load data to display in the table from a
     * Ajax source. This option defines how that Ajax call is made and where to.
     *
     * The `ajax` property has three different modes of operation, depending on
     * how it is defined. These are:
     *
     * * `string` - Set the URL from where the data should be loaded from.
     * * `object` - Define properties for `jQuery.ajax`.
     * * `function` - Custom data get function
     *
     * `string`
     * --------
     *
     * As a string, the `ajax` property simply defines the URL from which
     * DataTables will load data.
     *
     * `object`
     * --------
     *
     * As an object, the parameters in the object are passed to
     * [jQuery.ajax](http://api.jquery.com/jQuery.ajax/) allowing fine control
     * of the Ajax request. DataTables has a number of default parameters which
     * you can override using this option. Please refer to the jQuery
     * documentation for a full description of the options available, although
     * the following parameters provide additional options in DataTables or
     * require special consideration:
     *
     * * `data` - As with jQuery, `data` can be provided as an object, but it
     *   can also be used as a function to manipulate the data DataTables sends
     *   to the server. The function takes a single parameter, an object of
     *   parameters with the values that DataTables has readied for sending. An
     *   object may be returned which will be merged into the DataTables
     *   defaults, or you can add the items to the object that was passed in and
     *   not return anything from the function. This supersedes `fnServerParams`
     *   from DataTables 1.9-.
     *
     * * `dataSrc` - By default DataTables will look for the property `data` (or
     *   `aaData` for compatibility with DataTables 1.9-) when obtaining data
     *   from an Ajax source or for server-side processing - this parameter
     *   allows that property to be changed. You can use Javascript dotted
     *   object notation to get a data source for multiple levels of nesting, or
     *   it my be used as a function. As a function it takes a single parameter,
     *   the JSON returned from the server, which can be manipulated as
     *   required, with the returned value being that used by DataTables as the
     *   data source for the table. This supersedes `sAjaxDataProp` from
     *   DataTables 1.9-.
     *
     * * `success` - Should not be overridden it is used internally in
     *   DataTables. To manipulate / transform the data returned by the server
     *   use `ajax.dataSrc`, or use `ajax` as a function (see below).
     *
     * `function`
     * ----------
     *
     * As a function, making the Ajax call is left up to yourself allowing
     * complete control of the Ajax request. Indeed, if desired, a method other
     * than Ajax could be used to obtain the required data, such as Web storage
     * or an AIR database.
     *
     * The function is given four parameters and no return is required. The
     * parameters are:
     *
     * 1. _object_ - Data to send to the server
     * 2. _function_ - Callback function that must be executed when the required
     *    data has been obtained. That data should be passed into the callback
     *    as the only parameter
     * 3. _object_ - DataTables settings object for the table
     *
     * Note that this supersedes `fnServerData` from DataTables 1.9-.
     *
     *  @type string|object|function
     *  @default null
     *
     *  @dtopt Option
     *  @name DataTable.defaults.ajax
     *  @since 1.10.0
     *
     * @example
     *   // Get JSON data from a file via Ajax.
     *   // Note DataTables expects data in the form `{ data: [ ...data... ] }` by default).
     *   $('#example').dataTable( {
     *     "ajax": "data.json"
     *   } );
     *
     * @example
     *   // Get JSON data from a file via Ajax, using `dataSrc` to change
     *   // `data` to `tableData` (i.e. `{ tableData: [ ...data... ] }`)
     *   $('#example').dataTable( {
     *     "ajax": {
     *       "url": "data.json",
     *       "dataSrc": "tableData"
     *     }
     *   } );
     *
     * @example
     *   // Get JSON data from a file via Ajax, using `dataSrc` to read data
     *   // from a plain array rather than an array in an object
     *   $('#example').dataTable( {
     *     "ajax": {
     *       "url": "data.json",
     *       "dataSrc": ""
     *     }
     *   } );
     *
     * @example
     *   // Manipulate the data returned from the server - add a link to data
     *   // (note this can, should, be done using `render` for the column - this
     *   // is just a simple example of how the data can be manipulated).
     *   $('#example').dataTable( {
     *     "ajax": {
     *       "url": "data.json",
     *       "dataSrc": function ( json ) {
     *         for ( var i=0, ien=json.length ; i<ien ; i++ ) {
     *           json[i][0] = '<a href="/message/'+json[i][0]+'>View message</a>';
     *         }
     *         return json;
     *       }
     *     }
     *   } );
     *
     * @example
     *   // Add data to the request
     *   $('#example').dataTable( {
     *     "ajax": {
     *       "url": "data.json",
     *       "data": function ( d ) {
     *         return {
     *           "extra_search": $('#extra').val()
     *         };
     *       }
     *     }
     *   } );
     *
     * @example
     *   // Send request as POST
     *   $('#example').dataTable( {
     *     "ajax": {
     *       "url": "data.json",
     *       "type": "POST"
     *     }
     *   } );
     *
     * @example
     *   // Get the data from localStorage (could interface with a form for
     *   // adding, editing and removing rows).
     *   $('#example').dataTable( {
     *     "ajax": function (data, callback, settings) {
     *       callback(
     *         JSON.parse( localStorage.getItem('dataTablesData') )
     *       );
     *     }
     *   } );
     */
    "ajax": null,


    /**
     * This parameter allows you to readily specify the entries in the length drop
     * down menu that DataTables shows when pagination is enabled. It can be
     * either a 1D array of options which will be used for both the displayed
     * option and the value, or a 2D array which will use the array in the first
     * position as the value, and the array in the second position as the
     * displayed options (useful for language strings such as 'All').
     *
     * Note that the `pageLength` property will be automatically set to the
     * first value given in this array, unless `pageLength` is also provided.
     *  @type array
     *  @default [ 10, 25, 50, 100 ]
     *
     *  @dtopt Option
     *  @name DataTable.defaults.lengthMenu
     *
     *  @example
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
     *      } );
     *    } );
     */
    "aLengthMenu": [ 10, 25, 50, 100 ],


    /**
     * The `columns` option in the initialisation parameter allows you to define
     * details about the way individual columns behave. For a full list of
     * column options that can be set, please see
     * {@link DataTable.defaults.column}. Note that if you use `columns` to
     * define your columns, you must have an entry in the array for every single
     * column that you have in your table (these can be null if you don't which
     * to specify any options).
     *  @member
     *
     *  @name DataTable.defaults.column
     */
    "aoColumns": null,

    /**
     * Very similar to `columns`, `columnDefs` allows you to target a specific
     * column, multiple columns, or all columns, using the `targets` property of
     * each object in the array. This allows great flexibility when creating
     * tables, as the `columnDefs` arrays can be of any length, targeting the
     * columns you specifically want. `columnDefs` may use any of the column
     * options available: {@link DataTable.defaults.column}, but it _must_
     * have `targets` defined in each object in the array. Values in the `targets`
     * array may be:
     *   <ul>
     *     <li>a string - class name will be matched on the TH for the column</li>
     *     <li>0 or a positive integer - column index counting from the left</li>
     *     <li>a negative integer - column index counting from the right</li>
     *     <li>the string "_all" - all columns (i.e. assign a default)</li>
     *   </ul>
     *  @member
     *
     *  @name DataTable.defaults.columnDefs
     */
    "aoColumnDefs": null,


    /**
     * Basically the same as `search`, this parameter defines the individual column
     * filtering state at initialisation time. The array must be of the same size
     * as the number of columns, and each element be an object with the parameters
     * `search` and `escapeRegex` (the latter is optional). 'null' is also
     * accepted and the default will be used.
     *  @type array
     *  @default []
     *
     *  @dtopt Option
     *  @name DataTable.defaults.searchCols
     *
     *  @example
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "searchCols": [
     *          null,
     *          { "search": "My filter" },
     *          null,
     *          { "search": "^[0-9]", "escapeRegex": false }
     *        ]
     *      } );
     *    } )
     */
    "aoSearchCols": [],


    /**
     * An array of CSS classes that should be applied to displayed rows. This
     * array may be of any length, and DataTables will apply each class
     * sequentially, looping when required.
     *  @type array
     *  @default null <i>Will take the values determined by the `oClasses.stripe*`
     *    options</i>
     *
     *  @dtopt Option
     *  @name DataTable.defaults.stripeClasses
     *
     *  @example
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "stripeClasses": [ 'strip1', 'strip2', 'strip3' ]
     *      } );
     *    } )
     */
    "asStripeClasses": null,


    /**
     * Enable or disable automatic column width calculation. This can be disabled
     * as an optimisation (it takes some time to calculate the widths) if the
     * tables widths are passed in using `columns`.
     *  @type boolean
     *  @default true
     *
     *  @dtopt Features
     *  @name DataTable.defaults.autoWidth
     *
     *  @example
     *    $(document).ready( function () {
     *      $('#example').dataTable( {
     *        "autoWidth": false
     *      } );
     *    } );
     */
    "bAutoWidth": true,


    /**
     * Deferred rendering can provide DataTables with a huge speed boost when you
     * are using an Ajax or JS data source for the table. This option, when set to
     * true, will cause DataTables to defer the creation of the table elements for
     * each row until they are needed for a draw - saving a significant amount of
     * time.
     *  @type boolean
     *  @default false
     *
     *  @dtopt Features
     *  @name DataTable.defaults.deferRender
     *
     *  @example
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "ajax": "sources/arrays.txt",
     *        "deferRender": true
     *      } );
     *    } );
     */
    "bDeferRender": false,


    /**
     * Replace a DataTable which matches the given selector and replace it with
     * one which has the properties of the new initialisation object passed. If no
     * table matches the selector, then the new DataTable will be constructed as
     * per normal.
     *  @type boolean
     *  @default false
     *
     *  @dtopt Options
     *  @name DataTable.defaults.destroy
     *
     *  @example
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "srollY": "200px",
     *        "paginate": false
     *      } );
     *
     *      // Some time later....
     *      $('#example').dataTable( {
     *        "filter": false,
     *        "destroy": true
     *      } );
     *    } );
     */
    "bDestroy": false,


    /**
     * Enable or disable filtering of data. Filtering in DataTables is "smart" in
     * that it allows the end user to input multiple words (space separated) and
     * will match a row containing those words, even if not in the order that was
     * specified (this allow matching across multiple columns). Note that if you
     * wish to use filtering in DataTables this must remain 'true' - to remove the
     * default filtering input box and retain filtering abilities, please use
     * {@link DataTable.defaults.dom}.
     *  @type boolean
     *  @default true
     *
     *  @dtopt Features
     *  @name DataTable.defaults.searching
     *
     *  @example
     *    $(document).ready( function () {
     *      $('#example').dataTable( {
     *        "searching": false
     *      } );
     *    } );
     */
    "bFilter": true,


    /**
     * Enable or disable the table information display. This shows information
     * about the data that is currently visible on the page, including information
     * about filtered data if that action is being performed.
     *  @type boolean
     *  @default true
     *
     *  @dtopt Features
     *  @name DataTable.defaults.info
     *
     *  @example
     *    $(document).ready( function () {
     *      $('#example').dataTable( {
     *        "info": false
     *      } );
     *    } );
     */
    "bInfo": true,


    /**
     * Allows the end user to select the size of a formatted page from a select
     * menu (sizes are 10, 25, 50 and 100). Requires pagination (`paginate`).
     *  @type boolean
     *  @default true
     *
     *  @dtopt Features
     *  @name DataTable.defaults.lengthChange
     *
     *  @example
     *    $(document).ready( function () {
     *      $('#example').dataTable( {
     *        "lengthChange": false
     *      } );
     *    } );
     */
    "bLengthChange": true,


    /**
     * Enable or disable pagination.
     *  @type boolean
     *  @default true
     *
     *  @dtopt Features
     *  @name DataTable.defaults.paging
     *
     *  @example
     *    $(document).ready( function () {
     *      $('#example').dataTable( {
     *        "paging": false
     *      } );
     *    } );
     */
    "bPaginate": true,


    /**
     * Enable or disable the display of a 'processing' indicator when the table is
     * being processed (e.g. a sort). This is particularly useful for tables with
     * large amounts of data where it can take a noticeable amount of time to sort
     * the entries.
     *  @type boolean
     *  @default false
     *
     *  @dtopt Features
     *  @name DataTable.defaults.processing
     *
     *  @example
     *    $(document).ready( function () {
     *      $('#example').dataTable( {
     *        "processing": true
     *      } );
     *    } );
     */
    "bProcessing": false,


    /**
     * Retrieve the DataTables object for the given selector. Note that if the
     * table has already been initialised, this parameter will cause DataTables
     * to simply return the object that has already been set up - it will not take
     * account of any changes you might have made to the initialisation object
     * passed to DataTables (setting this parameter to true is an acknowledgement
     * that you understand this). `destroy` can be used to reinitialise a table if
     * you need.
     *  @type boolean
     *  @default false
     *
     *  @dtopt Options
     *  @name DataTable.defaults.retrieve
     *
     *  @example
     *    $(document).ready( function() {
     *      initTable();
     *      tableActions();
     *    } );
     *
     *    function initTable ()
     *    {
     *      return $('#example').dataTable( {
     *        "scrollY": "200px",
     *        "paginate": false,
     *        "retrieve": true
     *      } );
     *    }
     *
     *    function tableActions ()
     *    {
     *      var table = initTable();
     *      // perform API operations with oTable
     *    }
     */
    "bRetrieve": false,


    /**
     * When vertical (y) scrolling is enabled, DataTables will force the height of
     * the table's viewport to the given height at all times (useful for layout).
     * However, this can look odd when filtering data down to a small data set,
     * and the footer is left "floating" further down. This parameter (when
     * enabled) will cause DataTables to collapse the table's viewport down when
     * the result set will fit within the given Y height.
     *  @type boolean
     *  @default false
     *
     *  @dtopt Options
     *  @name DataTable.defaults.scrollCollapse
     *
     *  @example
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "scrollY": "200",
     *        "scrollCollapse": true
     *      } );
     *    } );
     */
    "bScrollCollapse": false,


    /**
     * Configure DataTables to use server-side processing. Note that the
     * `ajax` parameter must also be given in order to give DataTables a
     * source to obtain the required data for each draw.
     *  @type boolean
     *  @default false
     *
     *  @dtopt Features
     *  @dtopt Server-side
     *  @name DataTable.defaults.serverSide
     *
     *  @example
     *    $(document).ready( function () {
     *      $('#example').dataTable( {
     *        "serverSide": true,
     *        "ajax": "xhr.php"
     *      } );
     *    } );
     */
    "bServerSide": false,


    /**
     * Enable or disable sorting of columns. Sorting of individual columns can be
     * disabled by the `sortable` option for each column.
     *  @type boolean
     *  @default true
     *
     *  @dtopt Features
     *  @name DataTable.defaults.ordering
     *
     *  @example
     *    $(document).ready( function () {
     *      $('#example').dataTable( {
     *        "ordering": false
     *      } );
     *    } );
     */
    "bSort": true,


    /**
     * Enable or display DataTables' ability to sort multiple columns at the
     * same time (activated by shift-click by the user).
     *  @type boolean
     *  @default true
     *
     *  @dtopt Options
     *  @name DataTable.defaults.orderMulti
     *
     *  @example
     *    // Disable multiple column sorting ability
     *    $(document).ready( function () {
     *      $('#example').dataTable( {
     *        "orderMulti": false
     *      } );
     *    } );
     */
    "bSortMulti": true,


    /**
     * Allows control over whether DataTables should use the top (true) unique
     * cell that is found for a single column, or the bottom (false - default).
     * This is useful when using complex headers.
     *  @type boolean
     *  @default false
     *
     *  @dtopt Options
     *  @name DataTable.defaults.orderCellsTop
     *
     *  @example
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "orderCellsTop": true
     *      } );
     *    } );
     */
    "bSortCellsTop": false,


    /**
     * Enable or disable the addition of the classes `sorting\_1`, `sorting\_2` and
     * `sorting\_3` to the columns which are currently being sorted on. This is
     * presented as a feature switch as it can increase processing time (while
     * classes are removed and added) so for large data sets you might want to
     * turn this off.
     *  @type boolean
     *  @default true
     *
     *  @dtopt Features
     *  @name DataTable.defaults.orderClasses
     *
     *  @example
     *    $(document).ready( function () {
     *      $('#example').dataTable( {
     *        "orderClasses": false
     *      } );
     *    } );
     */
    "bSortClasses": true,


    /**
     * Enable or disable state saving. When enabled HTML5 `localStorage` will be
     * used to save table display information such as pagination information,
     * display length, filtering and sorting. As such when the end user reloads
     * the page the display display will match what thy had previously set up.
     *
     * Due to the use of `localStorage` the default state saving is not supported
     * in IE6 or 7. If state saving is required in those browsers, use
     * `stateSaveCallback` to provide a storage solution such as cookies.
     *  @type boolean
     *  @default false
     *
     *  @dtopt Features
     *  @name DataTable.defaults.stateSave
     *
     *  @example
     *    $(document).ready( function () {
     *      $('#example').dataTable( {
     *        "stateSave": true
     *      } );
     *    } );
     */
    "bStateSave": false,


    /**
     * This function is called when a TR element is created (and all TD child
     * elements have been inserted), or registered if using a DOM source, allowing
     * manipulation of the TR element (adding classes etc).
     *  @type function
     *  @param {node} row "TR" element for the current row
     *  @param {array} data Raw data array for this row
     *  @param {int} dataIndex The index of this row in the internal aoData array
     *
     *  @dtopt Callbacks
     *  @name DataTable.defaults.createdRow
     *
     *  @example
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "createdRow": function( row, data, dataIndex ) {
     *          // Bold the grade for all 'A' grade browsers
     *          if ( data[4] == "A" )
     *          {
     *            $('td:eq(4)', row).html( '<b>A</b>' );
     *          }
     *        }
     *      } );
     *    } );
     */
    "fnCreatedRow": null,


    /**
     * This function is called on every 'draw' event, and allows you to
     * dynamically modify any aspect you want about the created DOM.
     *  @type function
     *  @param {object} settings DataTables settings object
     *
     *  @dtopt Callbacks
     *  @name DataTable.defaults.drawCallback
     *
     *  @example
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "drawCallback": function( settings ) {
     *          alert( 'DataTables has redrawn the table' );
     *        }
     *      } );
     *    } );
     */
    "fnDrawCallback": null,


    /**
     * Identical to fnHeaderCallback() but for the table footer this function
     * allows you to modify the table footer on every 'draw' event.
     *  @type function
     *  @param {node} foot "TR" element for the footer
     *  @param {array} data Full table data (as derived from the original HTML)
     *  @param {int} start Index for the current display starting point in the
     *    display array
     *  @param {int} end Index for the current display ending point in the
     *    display array
     *  @param {array int} display Index array to translate the visual position
     *    to the full data array
     *
     *  @dtopt Callbacks
     *  @name DataTable.defaults.footerCallback
     *
     *  @example
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "footerCallback": function( tfoot, data, start, end, display ) {
     *          tfoot.getElementsByTagName('th')[0].innerHTML = "Starting index is "+start;
     *        }
     *      } );
     *    } )
     */
    "fnFooterCallback": null,


    /**
     * When rendering large numbers in the information element for the table
     * (i.e. "Showing 1 to 10 of 57 entries") DataTables will render large numbers
     * to have a comma separator for the 'thousands' units (e.g. 1 million is
     * rendered as "1,000,000") to help readability for the end user. This
     * function will override the default method DataTables uses.
     *  @type function
     *  @member
     *  @param {int} toFormat number to be formatted
     *  @returns {string} formatted string for DataTables to show the number
     *
     *  @dtopt Callbacks
     *  @name DataTable.defaults.formatNumber
     *
     *  @example
     *    // Format a number using a single quote for the separator (note that
     *    // this can also be done with the language.thousands option)
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "formatNumber": function ( toFormat ) {
     *          return toFormat.toString().replace(
     *            /\B(?=(\d{3})+(?!\d))/g, "'"
     *          );
     *        };
     *      } );
     *    } );
     */
    "fnFormatNumber": function ( toFormat ) {
      return toFormat.toString().replace(
        /\B(?=(\d{3})+(?!\d))/g,
        this.oLanguage.sThousands
      );
    },


    /**
     * This function is called on every 'draw' event, and allows you to
     * dynamically modify the header row. This can be used to calculate and
     * display useful information about the table.
     *  @type function
     *  @param {node} head "TR" element for the header
     *  @param {array} data Full table data (as derived from the original HTML)
     *  @param {int} start Index for the current display starting point in the
     *    display array
     *  @param {int} end Index for the current display ending point in the
     *    display array
     *  @param {array int} display Index array to translate the visual position
     *    to the full data array
     *
     *  @dtopt Callbacks
     *  @name DataTable.defaults.headerCallback
     *
     *  @example
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "fheaderCallback": function( head, data, start, end, display ) {
     *          head.getElementsByTagName('th')[0].innerHTML = "Displaying "+(end-start)+" records";
     *        }
     *      } );
     *    } )
     */
    "fnHeaderCallback": null,


    /**
     * The information element can be used to convey information about the current
     * state of the table. Although the internationalisation options presented by
     * DataTables are quite capable of dealing with most customisations, there may
     * be times where you wish to customise the string further. This callback
     * allows you to do exactly that.
     *  @type function
     *  @param {object} oSettings DataTables settings object
     *  @param {int} start Starting position in data for the draw
     *  @param {int} end End position in data for the draw
     *  @param {int} max Total number of rows in the table (regardless of
     *    filtering)
     *  @param {int} total Total number of rows in the data set, after filtering
     *  @param {string} pre The string that DataTables has formatted using it's
     *    own rules
     *  @returns {string} The string to be displayed in the information element.
     *
     *  @dtopt Callbacks
     *  @name DataTable.defaults.infoCallback
     *
     *  @example
     *    $('#example').dataTable( {
     *      "infoCallback": function( settings, start, end, max, total, pre ) {
     *        return start +" to "+ end;
     *      }
     *    } );
     */
    "fnInfoCallback": null,


    /**
     * Called when the table has been initialised. Normally DataTables will
     * initialise sequentially and there will be no need for this function,
     * however, this does not hold true when using external language information
     * since that is obtained using an async XHR call.
     *  @type function
     *  @param {object} settings DataTables settings object
     *  @param {object} json The JSON object request from the server - only
     *    present if client-side Ajax sourced data is used
     *
     *  @dtopt Callbacks
     *  @name DataTable.defaults.initComplete
     *
     *  @example
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "initComplete": function(settings, json) {
     *          alert( 'DataTables has finished its initialisation.' );
     *        }
     *      } );
     *    } )
     */
    "fnInitComplete": null,


    /**
     * Called at the very start of each table draw and can be used to cancel the
     * draw by returning false, any other return (including undefined) results in
     * the full draw occurring).
     *  @type function
     *  @param {object} settings DataTables settings object
     *  @returns {boolean} False will cancel the draw, anything else (including no
     *    return) will allow it to complete.
     *
     *  @dtopt Callbacks
     *  @name DataTable.defaults.preDrawCallback
     *
     *  @example
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "preDrawCallback": function( settings ) {
     *          if ( $('#test').val() == 1 ) {
     *            return false;
     *          }
     *        }
     *      } );
     *    } );
     */
    "fnPreDrawCallback": null,


    /**
     * This function allows you to 'post process' each row after it have been
     * generated for each table draw, but before it is rendered on screen. This
     * function might be used for setting the row class name etc.
     *  @type function
     *  @param {node} row "TR" element for the current row
     *  @param {array} data Raw data array for this row
     *  @param {int} displayIndex The display index for the current table draw
     *  @param {int} displayIndexFull The index of the data in the full list of
     *    rows (after filtering)
     *
     *  @dtopt Callbacks
     *  @name DataTable.defaults.rowCallback
     *
     *  @example
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "rowCallback": function( row, data, displayIndex, displayIndexFull ) {
     *          // Bold the grade for all 'A' grade browsers
     *          if ( data[4] == "A" ) {
     *            $('td:eq(4)', row).html( '<b>A</b>' );
     *          }
     *        }
     *      } );
     *    } );
     */
    "fnRowCallback": null,


    /**
     * __Deprecated__ The functionality provided by this parameter has now been
     * superseded by that provided through `ajax`, which should be used instead.
     *
     * This parameter allows you to override the default function which obtains
     * the data from the server so something more suitable for your application.
     * For example you could use POST data, or pull information from a Gears or
     * AIR database.
     *  @type function
     *  @member
     *  @param {string} source HTTP source to obtain the data from (`ajax`)
     *  @param {array} data A key/value pair object containing the data to send
     *    to the server
     *  @param {function} callback to be called on completion of the data get
     *    process that will draw the data on the page.
     *  @param {object} settings DataTables settings object
     *
     *  @dtopt Callbacks
     *  @dtopt Server-side
     *  @name DataTable.defaults.serverData
     *
     *  @deprecated 1.10. Please use `ajax` for this functionality now.
     */
    "fnServerData": null,


    /**
     * __Deprecated__ The functionality provided by this parameter has now been
     * superseded by that provided through `ajax`, which should be used instead.
     *
     *  It is often useful to send extra data to the server when making an Ajax
     * request - for example custom filtering information, and this callback
     * function makes it trivial to send extra information to the server. The
     * passed in parameter is the data set that has been constructed by
     * DataTables, and you can add to this or modify it as you require.
     *  @type function
     *  @param {array} data Data array (array of objects which are name/value
     *    pairs) that has been constructed by DataTables and will be sent to the
     *    server. In the case of Ajax sourced data with server-side processing
     *    this will be an empty array, for server-side processing there will be a
     *    significant number of parameters!
     *  @returns {undefined} Ensure that you modify the data array passed in,
     *    as this is passed by reference.
     *
     *  @dtopt Callbacks
     *  @dtopt Server-side
     *  @name DataTable.defaults.serverParams
     *
     *  @deprecated 1.10. Please use `ajax` for this functionality now.
     */
    "fnServerParams": null,


    /**
     * Load the table state. With this function you can define from where, and how, the
     * state of a table is loaded. By default DataTables will load from `localStorage`
     * but you might wish to use a server-side database or cookies.
     *  @type function
     *  @member
     *  @param {object} settings DataTables settings object
     *  @param {object} callback Callback that can be executed when done. It
     *    should be passed the loaded state object.
     *  @return {object} The DataTables state object to be loaded
     *
     *  @dtopt Callbacks
     *  @name DataTable.defaults.stateLoadCallback
     *
     *  @example
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "stateSave": true,
     *        "stateLoadCallback": function (settings, callback) {
     *          $.ajax( {
     *            "url": "/state_load",
     *            "dataType": "json",
     *            "success": function (json) {
     *              callback( json );
     *            }
     *          } );
     *        }
     *      } );
     *    } );
     */
    "fnStateLoadCallback": function ( settings ) {
      try {
        return JSON.parse(
          (settings.iStateDuration === -1 ? sessionStorage : localStorage).getItem(
            'DataTables_'+settings.sInstance+'_'+location.pathname
          )
        );
      } catch (e) {
        return {};
      }
    },


    /**
     * Callback which allows modification of the saved state prior to loading that state.
     * This callback is called when the table is loading state from the stored data, but
     * prior to the settings object being modified by the saved state. Note that for
     * plug-in authors, you should use the `stateLoadParams` event to load parameters for
     * a plug-in.
     *  @type function
     *  @param {object} settings DataTables settings object
     *  @param {object} data The state object that is to be loaded
     *
     *  @dtopt Callbacks
     *  @name DataTable.defaults.stateLoadParams
     *
     *  @example
     *    // Remove a saved filter, so filtering is never loaded
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "stateSave": true,
     *        "stateLoadParams": function (settings, data) {
     *          data.oSearch.sSearch = "";
     *        }
     *      } );
     *    } );
     *
     *  @example
     *    // Disallow state loading by returning false
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "stateSave": true,
     *        "stateLoadParams": function (settings, data) {
     *          return false;
     *        }
     *      } );
     *    } );
     */
    "fnStateLoadParams": null,


    /**
     * Callback that is called when the state has been loaded from the state saving method
     * and the DataTables settings object has been modified as a result of the loaded state.
     *  @type function
     *  @param {object} settings DataTables settings object
     *  @param {object} data The state object that was loaded
     *
     *  @dtopt Callbacks
     *  @name DataTable.defaults.stateLoaded
     *
     *  @example
     *    // Show an alert with the filtering value that was saved
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "stateSave": true,
     *        "stateLoaded": function (settings, data) {
     *          alert( 'Saved filter was: '+data.oSearch.sSearch );
     *        }
     *      } );
     *    } );
     */
    "fnStateLoaded": null,


    /**
     * Save the table state. This function allows you to define where and how the state
     * information for the table is stored By default DataTables will use `localStorage`
     * but you might wish to use a server-side database or cookies.
     *  @type function
     *  @member
     *  @param {object} settings DataTables settings object
     *  @param {object} data The state object to be saved
     *
     *  @dtopt Callbacks
     *  @name DataTable.defaults.stateSaveCallback
     *
     *  @example
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "stateSave": true,
     *        "stateSaveCallback": function (settings, data) {
     *          // Send an Ajax request to the server with the state object
     *          $.ajax( {
     *            "url": "/state_save",
     *            "data": data,
     *            "dataType": "json",
     *            "method": "POST"
     *            "success": function () {}
     *          } );
     *        }
     *      } );
     *    } );
     */
    "fnStateSaveCallback": function ( settings, data ) {
      try {
        (settings.iStateDuration === -1 ? sessionStorage : localStorage).setItem(
          'DataTables_'+settings.sInstance+'_'+location.pathname,
          JSON.stringify( data )
        );
      } catch (e) {}
    },


    /**
     * Callback which allows modification of the state to be saved. Called when the table
     * has changed state a new state save is required. This method allows modification of
     * the state saving object prior to actually doing the save, including addition or
     * other state properties or modification. Note that for plug-in authors, you should
     * use the `stateSaveParams` event to save parameters for a plug-in.
     *  @type function
     *  @param {object} settings DataTables settings object
     *  @param {object} data The state object to be saved
     *
     *  @dtopt Callbacks
     *  @name DataTable.defaults.stateSaveParams
     *
     *  @example
     *    // Remove a saved filter, so filtering is never saved
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "stateSave": true,
     *        "stateSaveParams": function (settings, data) {
     *          data.oSearch.sSearch = "";
     *        }
     *      } );
     *    } );
     */
    "fnStateSaveParams": null,


    /**
     * Duration for which the saved state information is considered valid. After this period
     * has elapsed the state will be returned to the default.
     * Value is given in seconds.
     *  @type int
     *  @default 7200 <i>(2 hours)</i>
     *
     *  @dtopt Options
     *  @name DataTable.defaults.stateDuration
     *
     *  @example
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "stateDuration": 60*60*24; // 1 day
     *      } );
     *    } )
     */
    "iStateDuration": 7200,


    /**
     * When enabled DataTables will not make a request to the server for the first
     * page draw - rather it will use the data already on the page (no sorting etc
     * will be applied to it), thus saving on an XHR at load time. `deferLoading`
     * is used to indicate that deferred loading is required, but it is also used
     * to tell DataTables how many records there are in the full table (allowing
     * the information element and pagination to be displayed correctly). In the case
     * where a filtering is applied to the table on initial load, this can be
     * indicated by giving the parameter as an array, where the first element is
     * the number of records available after filtering and the second element is the
     * number of records without filtering (allowing the table information element
     * to be shown correctly).
     *  @type int | array
     *  @default null
     *
     *  @dtopt Options
     *  @name DataTable.defaults.deferLoading
     *
     *  @example
     *    // 57 records available in the table, no filtering applied
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "serverSide": true,
     *        "ajax": "scripts/server_processing.php",
     *        "deferLoading": 57
     *      } );
     *    } );
     *
     *  @example
     *    // 57 records after filtering, 100 without filtering (an initial filter applied)
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "serverSide": true,
     *        "ajax": "scripts/server_processing.php",
     *        "deferLoading": [ 57, 100 ],
     *        "search": {
     *          "search": "my_filter"
     *        }
     *      } );
     *    } );
     */
    "iDeferLoading": null,


    /**
     * Number of rows to display on a single page when using pagination. If
     * feature enabled (`lengthChange`) then the end user will be able to override
     * this to a custom setting using a pop-up menu.
     *  @type int
     *  @default 10
     *
     *  @dtopt Options
     *  @name DataTable.defaults.pageLength
     *
     *  @example
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "pageLength": 50
     *      } );
     *    } )
     */
    "iDisplayLength": 10,


    /**
     * Define the starting point for data display when using DataTables with
     * pagination. Note that this parameter is the number of records, rather than
     * the page number, so if you have 10 records per page and want to start on
     * the third page, it should be "20".
     *  @type int
     *  @default 0
     *
     *  @dtopt Options
     *  @name DataTable.defaults.displayStart
     *
     *  @example
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "displayStart": 20
     *      } );
     *    } )
     */
    "iDisplayStart": 0,


    /**
     * By default DataTables allows keyboard navigation of the table (sorting, paging,
     * and filtering) by adding a `tabindex` attribute to the required elements. This
     * allows you to tab through the controls and press the enter key to activate them.
     * The tabindex is default 0, meaning that the tab follows the flow of the document.
     * You can overrule this using this parameter if you wish. Use a value of -1 to
     * disable built-in keyboard navigation.
     *  @type int
     *  @default 0
     *
     *  @dtopt Options
     *  @name DataTable.defaults.tabIndex
     *
     *  @example
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "tabIndex": 1
     *      } );
     *    } );
     */
    "iTabIndex": 0,


    /**
     * Classes that DataTables assigns to the various components and features
     * that it adds to the HTML table. This allows classes to be configured
     * during initialisation in addition to through the static
     * {@link DataTable.ext.oStdClasses} object).
     *  @namespace
     *  @name DataTable.defaults.classes
     */
    "oClasses": {},


    /**
     * All strings that DataTables uses in the user interface that it creates
     * are defined in this object, allowing you to modified them individually or
     * completely replace them all as required.
     *  @namespace
     *  @name DataTable.defaults.language
     */
    "oLanguage": {
      /**
       * Strings that are used for WAI-ARIA labels and controls only (these are not
       * actually visible on the page, but will be read by screenreaders, and thus
       * must be internationalised as well).
       *  @namespace
       *  @name DataTable.defaults.language.aria
       */
      "oAria": {
        /**
         * ARIA label that is added to the table headers when the column may be
         * sorted ascending by activing the column (click or return when focused).
         * Note that the column header is prefixed to this string.
         *  @type string
         *  @default : activate to sort column ascending
         *
         *  @dtopt Language
         *  @name DataTable.defaults.language.aria.sortAscending
         *
         *  @example
         *    $(document).ready( function() {
         *      $('#example').dataTable( {
         *        "language": {
         *          "aria": {
         *            "sortAscending": " - click/return to sort ascending"
         *          }
         *        }
         *      } );
         *    } );
         */
        "sSortAscending": ": activate to sort column ascending",

        /**
         * ARIA label that is added to the table headers when the column may be
         * sorted descending by activing the column (click or return when focused).
         * Note that the column header is prefixed to this string.
         *  @type string
         *  @default : activate to sort column ascending
         *
         *  @dtopt Language
         *  @name DataTable.defaults.language.aria.sortDescending
         *
         *  @example
         *    $(document).ready( function() {
         *      $('#example').dataTable( {
         *        "language": {
         *          "aria": {
         *            "sortDescending": " - click/return to sort descending"
         *          }
         *        }
         *      } );
         *    } );
         */
        "sSortDescending": ": activate to sort column descending"
      },

      /**
       * Pagination string used by DataTables for the built-in pagination
       * control types.
       *  @namespace
       *  @name DataTable.defaults.language.paginate
       */
      "oPaginate": {
        /**
         * Text to use when using the 'full_numbers' type of pagination for the
         * button to take the user to the first page.
         *  @type string
         *  @default First
         *
         *  @dtopt Language
         *  @name DataTable.defaults.language.paginate.first
         *
         *  @example
         *    $(document).ready( function() {
         *      $('#example').dataTable( {
         *        "language": {
         *          "paginate": {
         *            "first": "First page"
         *          }
         *        }
         *      } );
         *    } );
         */
        "sFirst": "First",


        /**
         * Text to use when using the 'full_numbers' type of pagination for the
         * button to take the user to the last page.
         *  @type string
         *  @default Last
         *
         *  @dtopt Language
         *  @name DataTable.defaults.language.paginate.last
         *
         *  @example
         *    $(document).ready( function() {
         *      $('#example').dataTable( {
         *        "language": {
         *          "paginate": {
         *            "last": "Last page"
         *          }
         *        }
         *      } );
         *    } );
         */
        "sLast": "Last",


        /**
         * Text to use for the 'next' pagination button (to take the user to the
         * next page).
         *  @type string
         *  @default Next
         *
         *  @dtopt Language
         *  @name DataTable.defaults.language.paginate.next
         *
         *  @example
         *    $(document).ready( function() {
         *      $('#example').dataTable( {
         *        "language": {
         *          "paginate": {
         *            "next": "Next page"
         *          }
         *        }
         *      } );
         *    } );
         */
        "sNext": "Next",


        /**
         * Text to use for the 'previous' pagination button (to take the user to
         * the previous page).
         *  @type string
         *  @default Previous
         *
         *  @dtopt Language
         *  @name DataTable.defaults.language.paginate.previous
         *
         *  @example
         *    $(document).ready( function() {
         *      $('#example').dataTable( {
         *        "language": {
         *          "paginate": {
         *            "previous": "Previous page"
         *          }
         *        }
         *      } );
         *    } );
         */
        "sPrevious": "Previous"
      },

      /**
       * This string is shown in preference to `zeroRecords` when the table is
       * empty of data (regardless of filtering). Note that this is an optional
       * parameter - if it is not given, the value of `zeroRecords` will be used
       * instead (either the default or given value).
       *  @type string
       *  @default No data available in table
       *
       *  @dtopt Language
       *  @name DataTable.defaults.language.emptyTable
       *
       *  @example
       *    $(document).ready( function() {
       *      $('#example').dataTable( {
       *        "language": {
       *          "emptyTable": "No data available in table"
       *        }
       *      } );
       *    } );
       */
      "sEmptyTable": "No data available in table",


      /**
       * This string gives information to the end user about the information
       * that is current on display on the page. The following tokens can be
       * used in the string and will be dynamically replaced as the table
       * display updates. This tokens can be placed anywhere in the string, or
       * removed as needed by the language requires:
       *
       * * `\_START\_` - Display index of the first record on the current page
       * * `\_END\_` - Display index of the last record on the current page
       * * `\_TOTAL\_` - Number of records in the table after filtering
       * * `\_MAX\_` - Number of records in the table without filtering
       * * `\_PAGE\_` - Current page number
       * * `\_PAGES\_` - Total number of pages of data in the table
       *
       *  @type string
       *  @default Showing _START_ to _END_ of _TOTAL_ entries
       *
       *  @dtopt Language
       *  @name DataTable.defaults.language.info
       *
       *  @example
       *    $(document).ready( function() {
       *      $('#example').dataTable( {
       *        "language": {
       *          "info": "Showing page _PAGE_ of _PAGES_"
       *        }
       *      } );
       *    } );
       */
      "sInfo": "Showing _START_ to _END_ of _TOTAL_ entries",


      /**
       * Display information string for when the table is empty. Typically the
       * format of this string should match `info`.
       *  @type string
       *  @default Showing 0 to 0 of 0 entries
       *
       *  @dtopt Language
       *  @name DataTable.defaults.language.infoEmpty
       *
       *  @example
       *    $(document).ready( function() {
       *      $('#example').dataTable( {
       *        "language": {
       *          "infoEmpty": "No entries to show"
       *        }
       *      } );
       *    } );
       */
      "sInfoEmpty": "Showing 0 to 0 of 0 entries",


      /**
       * When a user filters the information in a table, this string is appended
       * to the information (`info`) to give an idea of how strong the filtering
       * is. The variable _MAX_ is dynamically updated.
       *  @type string
       *  @default (filtered from _MAX_ total entries)
       *
       *  @dtopt Language
       *  @name DataTable.defaults.language.infoFiltered
       *
       *  @example
       *    $(document).ready( function() {
       *      $('#example').dataTable( {
       *        "language": {
       *          "infoFiltered": " - filtering from _MAX_ records"
       *        }
       *      } );
       *    } );
       */
      "sInfoFiltered": "(filtered from _MAX_ total entries)",


      /**
       * If can be useful to append extra information to the info string at times,
       * and this variable does exactly that. This information will be appended to
       * the `info` (`infoEmpty` and `infoFiltered` in whatever combination they are
       * being used) at all times.
       *  @type string
       *  @default <i>Empty string</i>
       *
       *  @dtopt Language
       *  @name DataTable.defaults.language.infoPostFix
       *
       *  @example
       *    $(document).ready( function() {
       *      $('#example').dataTable( {
       *        "language": {
       *          "infoPostFix": "All records shown are derived from real information."
       *        }
       *      } );
       *    } );
       */
      "sInfoPostFix": "",


      /**
       * This decimal place operator is a little different from the other
       * language options since DataTables doesn't output floating point
       * numbers, so it won't ever use this for display of a number. Rather,
       * what this parameter does is modify the sort methods of the table so
       * that numbers which are in a format which has a character other than
       * a period (`.`) as a decimal place will be sorted numerically.
       *
       * Note that numbers with different decimal places cannot be shown in
       * the same table and still be sortable, the table must be consistent.
       * However, multiple different tables on the page can use different
       * decimal place characters.
       *  @type string
       *  @default
       *
       *  @dtopt Language
       *  @name DataTable.defaults.language.decimal
       *
       *  @example
       *    $(document).ready( function() {
       *      $('#example').dataTable( {
       *        "language": {
       *          "decimal": ","
       *          "thousands": "."
       *        }
       *      } );
       *    } );
       */
      "sDecimal": "",


      /**
       * DataTables has a build in number formatter (`formatNumber`) which is
       * used to format large numbers that are used in the table information.
       * By default a comma is used, but this can be trivially changed to any
       * character you wish with this parameter.
       *  @type string
       *  @default ,
       *
       *  @dtopt Language
       *  @name DataTable.defaults.language.thousands
       *
       *  @example
       *    $(document).ready( function() {
       *      $('#example').dataTable( {
       *        "language": {
       *          "thousands": "'"
       *        }
       *      } );
       *    } );
       */
      "sThousands": ",",


      /**
       * Detail the action that will be taken when the drop down menu for the
       * pagination length option is changed. The '_MENU_' variable is replaced
       * with a default select list of 10, 25, 50 and 100, and can be replaced
       * with a custom select box if required.
       *  @type string
       *  @default Show _MENU_ entries
       *
       *  @dtopt Language
       *  @name DataTable.defaults.language.lengthMenu
       *
       *  @example
       *    // Language change only
       *    $(document).ready( function() {
       *      $('#example').dataTable( {
       *        "language": {
       *          "lengthMenu": "Display _MENU_ records"
       *        }
       *      } );
       *    } );
       *
       *  @example
       *    // Language and options change
       *    $(document).ready( function() {
       *      $('#example').dataTable( {
       *        "language": {
       *          "lengthMenu": 'Display <select>'+
       *            '<option value="10">10</option>'+
       *            '<option value="20">20</option>'+
       *            '<option value="30">30</option>'+
       *            '<option value="40">40</option>'+
       *            '<option value="50">50</option>'+
       *            '<option value="-1">All</option>'+
       *            '</select> records'
       *        }
       *      } );
       *    } );
       */
      "sLengthMenu": "Show _MENU_ entries",


      /**
       * When using Ajax sourced data and during the first draw when DataTables is
       * gathering the data, this message is shown in an empty row in the table to
       * indicate to the end user the the data is being loaded. Note that this
       * parameter is not used when loading data by server-side processing, just
       * Ajax sourced data with client-side processing.
       *  @type string
       *  @default Loading...
       *
       *  @dtopt Language
       *  @name DataTable.defaults.language.loadingRecords
       *
       *  @example
       *    $(document).ready( function() {
       *      $('#example').dataTable( {
       *        "language": {
       *          "loadingRecords": "Please wait - loading..."
       *        }
       *      } );
       *    } );
       */
      "sLoadingRecords": "Loading...",


      /**
       * Text which is displayed when the table is processing a user action
       * (usually a sort command or similar).
       *  @type string
       *
       *  @dtopt Language
       *  @name DataTable.defaults.language.processing
       *
       *  @example
       *    $(document).ready( function() {
       *      $('#example').dataTable( {
       *        "language": {
       *          "processing": "DataTables is currently busy"
       *        }
       *      } );
       *    } );
       */
      "sProcessing": "",


      /**
       * Details the actions that will be taken when the user types into the
       * filtering input text box. The variable "_INPUT_", if used in the string,
       * is replaced with the HTML text box for the filtering input allowing
       * control over where it appears in the string. If "_INPUT_" is not given
       * then the input box is appended to the string automatically.
       *  @type string
       *  @default Search:
       *
       *  @dtopt Language
       *  @name DataTable.defaults.language.search
       *
       *  @example
       *    // Input text box will be appended at the end automatically
       *    $(document).ready( function() {
       *      $('#example').dataTable( {
       *        "language": {
       *          "search": "Filter records:"
       *        }
       *      } );
       *    } );
       *
       *  @example
       *    // Specify where the filter should appear
       *    $(document).ready( function() {
       *      $('#example').dataTable( {
       *        "language": {
       *          "search": "Apply filter _INPUT_ to table"
       *        }
       *      } );
       *    } );
       */
      "sSearch": "Search:",


      /**
       * Assign a `placeholder` attribute to the search `input` element
       *  @type string
       *  @default
       *
       *  @dtopt Language
       *  @name DataTable.defaults.language.searchPlaceholder
       */
      "sSearchPlaceholder": "",


      /**
       * All of the language information can be stored in a file on the
       * server-side, which DataTables will look up if this parameter is passed.
       * It must store the URL of the language file, which is in a JSON format,
       * and the object has the same properties as the oLanguage object in the
       * initialiser object (i.e. the above parameters). Please refer to one of
       * the example language files to see how this works in action.
       *  @type string
       *  @default <i>Empty string - i.e. disabled</i>
       *
       *  @dtopt Language
       *  @name DataTable.defaults.language.url
       *
       *  @example
       *    $(document).ready( function() {
       *      $('#example').dataTable( {
       *        "language": {
       *          "url": "http://www.sprymedia.co.uk/dataTables/lang.txt"
       *        }
       *      } );
       *    } );
       */
      "sUrl": "",


      /**
       * Text shown inside the table records when the is no information to be
       * displayed after filtering. `emptyTable` is shown when there is simply no
       * information in the table at all (regardless of filtering).
       *  @type string
       *  @default No matching records found
       *
       *  @dtopt Language
       *  @name DataTable.defaults.language.zeroRecords
       *
       *  @example
       *    $(document).ready( function() {
       *      $('#example').dataTable( {
       *        "language": {
       *          "zeroRecords": "No records to display"
       *        }
       *      } );
       *    } );
       */
      "sZeroRecords": "No matching records found"
    },


    /**
     * This parameter allows you to have define the global filtering state at
     * initialisation time. As an object the `search` parameter must be
     * defined, but all other parameters are optional. When `regex` is true,
     * the search string will be treated as a regular expression, when false
     * (default) it will be treated as a straight string. When `smart`
     * DataTables will use it's smart filtering methods (to word match at
     * any point in the data), when false this will not be done.
     *  @namespace
     *  @extends DataTable.models.oSearch
     *
     *  @dtopt Options
     *  @name DataTable.defaults.search
     *
     *  @example
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "search": {"search": "Initial search"}
     *      } );
     *    } )
     */
    "oSearch": $.extend( {}, DataTable.models.oSearch ),


    /**
     * __Deprecated__ The functionality provided by this parameter has now been
     * superseded by that provided through `ajax`, which should be used instead.
     *
     * By default DataTables will look for the property `data` (or `aaData` for
     * compatibility with DataTables 1.9-) when obtaining data from an Ajax
     * source or for server-side processing - this parameter allows that
     * property to be changed. You can use Javascript dotted object notation to
     * get a data source for multiple levels of nesting.
     *  @type string
     *  @default data
     *
     *  @dtopt Options
     *  @dtopt Server-side
     *  @name DataTable.defaults.ajaxDataProp
     *
     *  @deprecated 1.10. Please use `ajax` for this functionality now.
     */
    "sAjaxDataProp": "data",


    /**
     * __Deprecated__ The functionality provided by this parameter has now been
     * superseded by that provided through `ajax`, which should be used instead.
     *
     * You can instruct DataTables to load data from an external
     * source using this parameter (use aData if you want to pass data in you
     * already have). Simply provide a url a JSON object can be obtained from.
     *  @type string
     *  @default null
     *
     *  @dtopt Options
     *  @dtopt Server-side
     *  @name DataTable.defaults.ajaxSource
     *
     *  @deprecated 1.10. Please use `ajax` for this functionality now.
     */
    "sAjaxSource": null,


    /**
     * This initialisation variable allows you to specify exactly where in the
     * DOM you want DataTables to inject the various controls it adds to the page
     * (for example you might want the pagination controls at the top of the
     * table). DIV elements (with or without a custom class) can also be added to
     * aid styling. The follow syntax is used:
     *   <ul>
     *     <li>The following options are allowed:
     *       <ul>
     *         <li>'l' - Length changing</li>
     *         <li>'f' - Filtering input</li>
     *         <li>'t' - The table!</li>
     *         <li>'i' - Information</li>
     *         <li>'p' - Pagination</li>
     *         <li>'r' - pRocessing</li>
     *       </ul>
     *     </li>
     *     <li>The following constants are allowed:
     *       <ul>
     *         <li>'H' - jQueryUI theme "header" classes ('fg-toolbar ui-widget-header ui-corner-tl ui-corner-tr ui-helper-clearfix')</li>
     *         <li>'F' - jQueryUI theme "footer" classes ('fg-toolbar ui-widget-header ui-corner-bl ui-corner-br ui-helper-clearfix')</li>
     *       </ul>
     *     </li>
     *     <li>The following syntax is expected:
     *       <ul>
     *         <li>'&lt;' and '&gt;' - div elements</li>
     *         <li>'&lt;"class" and '&gt;' - div with a class</li>
     *         <li>'&lt;"#id" and '&gt;' - div with an ID</li>
     *       </ul>
     *     </li>
     *     <li>Examples:
     *       <ul>
     *         <li>'&lt;"wrapper"flipt&gt;'</li>
     *         <li>'&lt;lf&lt;t&gt;ip&gt;'</li>
     *       </ul>
     *     </li>
     *   </ul>
     *  @type string
     *  @default lfrtip <i>(when `jQueryUI` is false)</i> <b>or</b>
     *    <"H"lfr>t<"F"ip> <i>(when `jQueryUI` is true)</i>
     *
     *  @dtopt Options
     *  @name DataTable.defaults.dom
     *
     *  @example
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "dom": '&lt;"top"i&gt;rt&lt;"bottom"flp&gt;&lt;"clear"&gt;'
     *      } );
     *    } );
     */
    "sDom": "lfrtip",


    /**
     * Search delay option. This will throttle full table searches that use the
     * DataTables provided search input element (it does not effect calls to
     * `dt-api search()`, providing a delay before the search is made.
     *  @type integer
     *  @default 0
     *
     *  @dtopt Options
     *  @name DataTable.defaults.searchDelay
     *
     *  @example
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "searchDelay": 200
     *      } );
     *    } )
     */
    "searchDelay": null,


    /**
     * DataTables features six different built-in options for the buttons to
     * display for pagination control:
     *
     * * `numbers` - Page number buttons only
     * * `simple` - 'Previous' and 'Next' buttons only
     * * 'simple_numbers` - 'Previous' and 'Next' buttons, plus page numbers
     * * `full` - 'First', 'Previous', 'Next' and 'Last' buttons
     * * `full_numbers` - 'First', 'Previous', 'Next' and 'Last' buttons, plus page numbers
     * * `first_last_numbers` - 'First' and 'Last' buttons, plus page numbers
     *
     * Further methods can be added using {@link DataTable.ext.oPagination}.
     *  @type string
     *  @default simple_numbers
     *
     *  @dtopt Options
     *  @name DataTable.defaults.pagingType
     *
     *  @example
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "pagingType": "full_numbers"
     *      } );
     *    } )
     */
    "sPaginationType": "simple_numbers",


    /**
     * Enable horizontal scrolling. When a table is too wide to fit into a
     * certain layout, or you have a large number of columns in the table, you
     * can enable x-scrolling to show the table in a viewport, which can be
     * scrolled. This property can be `true` which will allow the table to
     * scroll horizontally when needed, or any CSS unit, or a number (in which
     * case it will be treated as a pixel measurement). Setting as simply `true`
     * is recommended.
     *  @type boolean|string
     *  @default <i>blank string - i.e. disabled</i>
     *
     *  @dtopt Features
     *  @name DataTable.defaults.scrollX
     *
     *  @example
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "scrollX": true,
     *        "scrollCollapse": true
     *      } );
     *    } );
     */
    "sScrollX": "",


    /**
     * This property can be used to force a DataTable to use more width than it
     * might otherwise do when x-scrolling is enabled. For example if you have a
     * table which requires to be well spaced, this parameter is useful for
     * "over-sizing" the table, and thus forcing scrolling. This property can by
     * any CSS unit, or a number (in which case it will be treated as a pixel
     * measurement).
     *  @type string
     *  @default <i>blank string - i.e. disabled</i>
     *
     *  @dtopt Options
     *  @name DataTable.defaults.scrollXInner
     *
     *  @example
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "scrollX": "100%",
     *        "scrollXInner": "110%"
     *      } );
     *    } );
     */
    "sScrollXInner": "",


    /**
     * Enable vertical scrolling. Vertical scrolling will constrain the DataTable
     * to the given height, and enable scrolling for any data which overflows the
     * current viewport. This can be used as an alternative to paging to display
     * a lot of data in a small area (although paging and scrolling can both be
     * enabled at the same time). This property can be any CSS unit, or a number
     * (in which case it will be treated as a pixel measurement).
     *  @type string
     *  @default <i>blank string - i.e. disabled</i>
     *
     *  @dtopt Features
     *  @name DataTable.defaults.scrollY
     *
     *  @example
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "scrollY": "200px",
     *        "paginate": false
     *      } );
     *    } );
     */
    "sScrollY": "",


    /**
     * __Deprecated__ The functionality provided by this parameter has now been
     * superseded by that provided through `ajax`, which should be used instead.
     *
     * Set the HTTP method that is used to make the Ajax call for server-side
     * processing or Ajax sourced data.
     *  @type string
     *  @default GET
     *
     *  @dtopt Options
     *  @dtopt Server-side
     *  @name DataTable.defaults.serverMethod
     *
     *  @deprecated 1.10. Please use `ajax` for this functionality now.
     */
    "sServerMethod": "GET",


    /**
     * DataTables makes use of renderers when displaying HTML elements for
     * a table. These renderers can be added or modified by plug-ins to
     * generate suitable mark-up for a site. For example the Bootstrap
     * integration plug-in for DataTables uses a paging button renderer to
     * display pagination buttons in the mark-up required by Bootstrap.
     *
     * For further information about the renderers available see
     * DataTable.ext.renderer
     *  @type string|object
     *  @default null
     *
     *  @name DataTable.defaults.renderer
     *
     */
    "renderer": null,


    /**
     * Set the data property name that DataTables should use to get a row's id
     * to set as the `id` property in the node.
     *  @type string
     *  @default DT_RowId
     *
     *  @name DataTable.defaults.rowId
     */
    "rowId": "DT_RowId"
  };

  _fnHungarianMap( DataTable.defaults );



  /*
	 * Developer note - See note in model.defaults.js about the use of Hungarian
	 * notation and camel case.
	 */

  /**
   * Column options that can be given to DataTables at initialisation time.
   *  @namespace
   */
  DataTable.defaults.column = {
    /**
     * Define which column(s) an order will occur on for this column. This
     * allows a column's ordering to take multiple columns into account when
     * doing a sort or use the data from a different column. For example first
     * name / last name columns make sense to do a multi-column sort over the
     * two columns.
     *  @type array|int
     *  @default null <i>Takes the value of the column index automatically</i>
     *
     *  @name DataTable.defaults.column.orderData
     *  @dtopt Columns
     *
     *  @example
     *    // Using `columnDefs`
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columnDefs": [
     *          { "orderData": [ 0, 1 ], "targets": [ 0 ] },
     *          { "orderData": [ 1, 0 ], "targets": [ 1 ] },
     *          { "orderData": 2, "targets": [ 2 ] }
     *        ]
     *      } );
     *    } );
     *
     *  @example
     *    // Using `columns`
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columns": [
     *          { "orderData": [ 0, 1 ] },
     *          { "orderData": [ 1, 0 ] },
     *          { "orderData": 2 },
     *          null,
     *          null
     *        ]
     *      } );
     *    } );
     */
    "aDataSort": null,
    "iDataSort": -1,


    /**
     * You can control the default ordering direction, and even alter the
     * behaviour of the sort handler (i.e. only allow ascending ordering etc)
     * using this parameter.
     *  @type array
     *  @default [ 'asc', 'desc' ]
     *
     *  @name DataTable.defaults.column.orderSequence
     *  @dtopt Columns
     *
     *  @example
     *    // Using `columnDefs`
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columnDefs": [
     *          { "orderSequence": [ "asc" ], "targets": [ 1 ] },
     *          { "orderSequence": [ "desc", "asc", "asc" ], "targets": [ 2 ] },
     *          { "orderSequence": [ "desc" ], "targets": [ 3 ] }
     *        ]
     *      } );
     *    } );
     *
     *  @example
     *    // Using `columns`
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columns": [
     *          null,
     *          { "orderSequence": [ "asc" ] },
     *          { "orderSequence": [ "desc", "asc", "asc" ] },
     *          { "orderSequence": [ "desc" ] },
     *          null
     *        ]
     *      } );
     *    } );
     */
    "asSorting": [ 'asc', 'desc' ],


    /**
     * Enable or disable filtering on the data in this column.
     *  @type boolean
     *  @default true
     *
     *  @name DataTable.defaults.column.searchable
     *  @dtopt Columns
     *
     *  @example
     *    // Using `columnDefs`
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columnDefs": [
     *          { "searchable": false, "targets": [ 0 ] }
     *        ] } );
     *    } );
     *
     *  @example
     *    // Using `columns`
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columns": [
     *          { "searchable": false },
     *          null,
     *          null,
     *          null,
     *          null
     *        ] } );
     *    } );
     */
    "bSearchable": true,


    /**
     * Enable or disable ordering on this column.
     *  @type boolean
     *  @default true
     *
     *  @name DataTable.defaults.column.orderable
     *  @dtopt Columns
     *
     *  @example
     *    // Using `columnDefs`
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columnDefs": [
     *          { "orderable": false, "targets": [ 0 ] }
     *        ] } );
     *    } );
     *
     *  @example
     *    // Using `columns`
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columns": [
     *          { "orderable": false },
     *          null,
     *          null,
     *          null,
     *          null
     *        ] } );
     *    } );
     */
    "bSortable": true,


    /**
     * Enable or disable the display of this column.
     *  @type boolean
     *  @default true
     *
     *  @name DataTable.defaults.column.visible
     *  @dtopt Columns
     *
     *  @example
     *    // Using `columnDefs`
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columnDefs": [
     *          { "visible": false, "targets": [ 0 ] }
     *        ] } );
     *    } );
     *
     *  @example
     *    // Using `columns`
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columns": [
     *          { "visible": false },
     *          null,
     *          null,
     *          null,
     *          null
     *        ] } );
     *    } );
     */
    "bVisible": true,


    /**
     * Developer definable function that is called whenever a cell is created (Ajax source,
     * etc) or processed for input (DOM source). This can be used as a compliment to mRender
     * allowing you to modify the DOM element (add background colour for example) when the
     * element is available.
     *  @type function
     *  @param {element} td The TD node that has been created
     *  @param {*} cellData The Data for the cell
     *  @param {array|object} rowData The data for the whole row
     *  @param {int} row The row index for the aoData data store
     *  @param {int} col The column index for aoColumns
     *
     *  @name DataTable.defaults.column.createdCell
     *  @dtopt Columns
     *
     *  @example
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columnDefs": [ {
     *          "targets": [3],
     *          "createdCell": function (td, cellData, rowData, row, col) {
     *            if ( cellData == "1.7" ) {
     *              $(td).css('color', 'blue')
     *            }
     *          }
     *        } ]
     *      });
     *    } );
     */
    "fnCreatedCell": null,


    /**
     * This parameter has been replaced by `data` in DataTables to ensure naming
     * consistency. `dataProp` can still be used, as there is backwards
     * compatibility in DataTables for this option, but it is strongly
     * recommended that you use `data` in preference to `dataProp`.
     *  @name DataTable.defaults.column.dataProp
     */


    /**
     * This property can be used to read data from any data source property,
     * including deeply nested objects / properties. `data` can be given in a
     * number of different ways which effect its behaviour:
     *
     * * `integer` - treated as an array index for the data source. This is the
     *   default that DataTables uses (incrementally increased for each column).
     * * `string` - read an object property from the data source. There are
     *   three 'special' options that can be used in the string to alter how
     *   DataTables reads the data from the source object:
     *    * `.` - Dotted Javascript notation. Just as you use a `.` in
     *      Javascript to read from nested objects, so to can the options
     *      specified in `data`. For example: `browser.version` or
     *      `browser.name`. If your object parameter name contains a period, use
     *      `\\` to escape it - i.e. `first\\.name`.
     *    * `[]` - Array notation. DataTables can automatically combine data
     *      from and array source, joining the data with the characters provided
     *      between the two brackets. For example: `name[, ]` would provide a
     *      comma-space separated list from the source array. If no characters
     *      are provided between the brackets, the original array source is
     *      returned.
     *    * `()` - Function notation. Adding `()` to the end of a parameter will
     *      execute a function of the name given. For example: `browser()` for a
     *      simple function on the data source, `browser.version()` for a
     *      function in a nested property or even `browser().version` to get an
     *      object property if the function called returns an object. Note that
     *      function notation is recommended for use in `render` rather than
     *      `data` as it is much simpler to use as a renderer.
     * * `null` - use the original data source for the row rather than plucking
     *   data directly from it. This action has effects on two other
     *   initialisation options:
     *    * `defaultContent` - When null is given as the `data` option and
     *      `defaultContent` is specified for the column, the value defined by
     *      `defaultContent` will be used for the cell.
     *    * `render` - When null is used for the `data` option and the `render`
     *      option is specified for the column, the whole data source for the
     *      row is used for the renderer.
     * * `function` - the function given will be executed whenever DataTables
     *   needs to set or get the data for a cell in the column. The function
     *   takes three parameters:
     *    * Parameters:
     *      * `{array|object}` The data source for the row
     *      * `{string}` The type call data requested - this will be 'set' when
     *        setting data or 'filter', 'display', 'type', 'sort' or undefined
     *        when gathering data. Note that when `undefined` is given for the
     *        type DataTables expects to get the raw data for the object back<
     *      * `{*}` Data to set when the second parameter is 'set'.
     *    * Return:
     *      * The return value from the function is not required when 'set' is
     *        the type of call, but otherwise the return is what will be used
     *        for the data requested.
     *
     * Note that `data` is a getter and setter option. If you just require
     * formatting of data for output, you will likely want to use `render` which
     * is simply a getter and thus simpler to use.
     *
     * Note that prior to DataTables 1.9.2 `data` was called `mDataProp`. The
     * name change reflects the flexibility of this property and is consistent
     * with the naming of mRender. If 'mDataProp' is given, then it will still
     * be used by DataTables, as it automatically maps the old name to the new
     * if required.
     *
     *  @type string|int|function|null
     *  @default null <i>Use automatically calculated column index</i>
     *
     *  @name DataTable.defaults.column.data
     *  @dtopt Columns
     *
     *  @example
     *    // Read table data from objects
     *    // JSON structure for each row:
     *    //   {
     *    //      "engine": {value},
     *    //      "browser": {value},
     *    //      "platform": {value},
     *    //      "version": {value},
     *    //      "grade": {value}
     *    //   }
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "ajaxSource": "sources/objects.txt",
     *        "columns": [
     *          { "data": "engine" },
     *          { "data": "browser" },
     *          { "data": "platform" },
     *          { "data": "version" },
     *          { "data": "grade" }
     *        ]
     *      } );
     *    } );
     *
     *  @example
     *    // Read information from deeply nested objects
     *    // JSON structure for each row:
     *    //   {
     *    //      "engine": {value},
     *    //      "browser": {value},
     *    //      "platform": {
     *    //         "inner": {value}
     *    //      },
     *    //      "details": [
     *    //         {value}, {value}
     *    //      ]
     *    //   }
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "ajaxSource": "sources/deep.txt",
     *        "columns": [
     *          { "data": "engine" },
     *          { "data": "browser" },
     *          { "data": "platform.inner" },
     *          { "data": "details.0" },
     *          { "data": "details.1" }
     *        ]
     *      } );
     *    } );
     *
     *  @example
     *    // Using `data` as a function to provide different information for
     *    // sorting, filtering and display. In this case, currency (price)
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columnDefs": [ {
     *          "targets": [ 0 ],
     *          "data": function ( source, type, val ) {
     *            if (type === 'set') {
     *              source.price = val;
     *              // Store the computed display and filter values for efficiency
     *              source.price_display = val=="" ? "" : "$"+numberFormat(val);
     *              source.price_filter  = val=="" ? "" : "$"+numberFormat(val)+" "+val;
     *              return;
     *            }
     *            else if (type === 'display') {
     *              return source.price_display;
     *            }
     *            else if (type === 'filter') {
     *              return source.price_filter;
     *            }
     *            // 'sort', 'type' and undefined all just use the integer
     *            return source.price;
     *          }
     *        } ]
     *      } );
     *    } );
     *
     *  @example
     *    // Using default content
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columnDefs": [ {
     *          "targets": [ 0 ],
     *          "data": null,
     *          "defaultContent": "Click to edit"
     *        } ]
     *      } );
     *    } );
     *
     *  @example
     *    // Using array notation - outputting a list from an array
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columnDefs": [ {
     *          "targets": [ 0 ],
     *          "data": "name[, ]"
     *        } ]
     *      } );
     *    } );
     *
     */
    "mData": null,


    /**
     * This property is the rendering partner to `data` and it is suggested that
     * when you want to manipulate data for display (including filtering,
     * sorting etc) without altering the underlying data for the table, use this
     * property. `render` can be considered to be the the read only companion to
     * `data` which is read / write (then as such more complex). Like `data`
     * this option can be given in a number of different ways to effect its
     * behaviour:
     *
     * * `integer` - treated as an array index for the data source. This is the
     *   default that DataTables uses (incrementally increased for each column).
     * * `string` - read an object property from the data source. There are
     *   three 'special' options that can be used in the string to alter how
     *   DataTables reads the data from the source object:
     *    * `.` - Dotted Javascript notation. Just as you use a `.` in
     *      Javascript to read from nested objects, so to can the options
     *      specified in `data`. For example: `browser.version` or
     *      `browser.name`. If your object parameter name contains a period, use
     *      `\\` to escape it - i.e. `first\\.name`.
     *    * `[]` - Array notation. DataTables can automatically combine data
     *      from and array source, joining the data with the characters provided
     *      between the two brackets. For example: `name[, ]` would provide a
     *      comma-space separated list from the source array. If no characters
     *      are provided between the brackets, the original array source is
     *      returned.
     *    * `()` - Function notation. Adding `()` to the end of a parameter will
     *      execute a function of the name given. For example: `browser()` for a
     *      simple function on the data source, `browser.version()` for a
     *      function in a nested property or even `browser().version` to get an
     *      object property if the function called returns an object.
     * * `object` - use different data for the different data types requested by
     *   DataTables ('filter', 'display', 'type' or 'sort'). The property names
     *   of the object is the data type the property refers to and the value can
     *   defined using an integer, string or function using the same rules as
     *   `render` normally does. Note that an `_` option _must_ be specified.
     *   This is the default value to use if you haven't specified a value for
     *   the data type requested by DataTables.
     * * `function` - the function given will be executed whenever DataTables
     *   needs to set or get the data for a cell in the column. The function
     *   takes three parameters:
     *    * Parameters:
     *      * {array|object} The data source for the row (based on `data`)
     *      * {string} The type call data requested - this will be 'filter',
     *        'display', 'type' or 'sort'.
     *      * {array|object} The full data source for the row (not based on
     *        `data`)
     *    * Return:
     *      * The return value from the function is what will be used for the
     *        data requested.
     *
     *  @type string|int|function|object|null
     *  @default null Use the data source value.
     *
     *  @name DataTable.defaults.column.render
     *  @dtopt Columns
     *
     *  @example
     *    // Create a comma separated list from an array of objects
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "ajaxSource": "sources/deep.txt",
     *        "columns": [
     *          { "data": "engine" },
     *          { "data": "browser" },
     *          {
     *            "data": "platform",
     *            "render": "[, ].name"
     *          }
     *        ]
     *      } );
     *    } );
     *
     *  @example
     *    // Execute a function to obtain data
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columnDefs": [ {
     *          "targets": [ 0 ],
     *          "data": null, // Use the full data source object for the renderer's source
     *          "render": "browserName()"
     *        } ]
     *      } );
     *    } );
     *
     *  @example
     *    // As an object, extracting different data for the different types
     *    // This would be used with a data source such as:
     *    //   { "phone": 5552368, "phone_filter": "5552368 555-2368", "phone_display": "555-2368" }
     *    // Here the `phone` integer is used for sorting and type detection, while `phone_filter`
     *    // (which has both forms) is used for filtering for if a user inputs either format, while
     *    // the formatted phone number is the one that is shown in the table.
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columnDefs": [ {
     *          "targets": [ 0 ],
     *          "data": null, // Use the full data source object for the renderer's source
     *          "render": {
     *            "_": "phone",
     *            "filter": "phone_filter",
     *            "display": "phone_display"
     *          }
     *        } ]
     *      } );
     *    } );
     *
     *  @example
     *    // Use as a function to create a link from the data source
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columnDefs": [ {
     *          "targets": [ 0 ],
     *          "data": "download_link",
     *          "render": function ( data, type, full ) {
     *            return '<a href="'+data+'">Download</a>';
     *          }
     *        } ]
     *      } );
     *    } );
     */
    "mRender": null,


    /**
     * Change the cell type created for the column - either TD cells or TH cells. This
     * can be useful as TH cells have semantic meaning in the table body, allowing them
     * to act as a header for a row (you may wish to add scope='row' to the TH elements).
     *  @type string
     *  @default td
     *
     *  @name DataTable.defaults.column.cellType
     *  @dtopt Columns
     *
     *  @example
     *    // Make the first column use TH cells
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columnDefs": [ {
     *          "targets": [ 0 ],
     *          "cellType": "th"
     *        } ]
     *      } );
     *    } );
     */
    "sCellType": "td",


    /**
     * Class to give to each cell in this column.
     *  @type string
     *  @default <i>Empty string</i>
     *
     *  @name DataTable.defaults.column.class
     *  @dtopt Columns
     *
     *  @example
     *    // Using `columnDefs`
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columnDefs": [
     *          { "class": "my_class", "targets": [ 0 ] }
     *        ]
     *      } );
     *    } );
     *
     *  @example
     *    // Using `columns`
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columns": [
     *          { "class": "my_class" },
     *          null,
     *          null,
     *          null,
     *          null
     *        ]
     *      } );
     *    } );
     */
    "sClass": "",

    /**
     * When DataTables calculates the column widths to assign to each column,
     * it finds the longest string in each column and then constructs a
     * temporary table and reads the widths from that. The problem with this
     * is that "mmm" is much wider then "iiii", but the latter is a longer
     * string - thus the calculation can go wrong (doing it properly and putting
     * it into an DOM object and measuring that is horribly(!) slow). Thus as
     * a "work around" we provide this option. It will append its value to the
     * text that is found to be the longest string for the column - i.e. padding.
     * Generally you shouldn't need this!
     *  @type string
     *  @default <i>Empty string<i>
     *
     *  @name DataTable.defaults.column.contentPadding
     *  @dtopt Columns
     *
     *  @example
     *    // Using `columns`
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columns": [
     *          null,
     *          null,
     *          null,
     *          {
     *            "contentPadding": "mmm"
     *          }
     *        ]
     *      } );
     *    } );
     */
    "sContentPadding": "",


    /**
     * Allows a default value to be given for a column's data, and will be used
     * whenever a null data source is encountered (this can be because `data`
     * is set to null, or because the data source itself is null).
     *  @type string
     *  @default null
     *
     *  @name DataTable.defaults.column.defaultContent
     *  @dtopt Columns
     *
     *  @example
     *    // Using `columnDefs`
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columnDefs": [
     *          {
     *            "data": null,
     *            "defaultContent": "Edit",
     *            "targets": [ -1 ]
     *          }
     *        ]
     *      } );
     *    } );
     *
     *  @example
     *    // Using `columns`
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columns": [
     *          null,
     *          null,
     *          null,
     *          {
     *            "data": null,
     *            "defaultContent": "Edit"
     *          }
     *        ]
     *      } );
     *    } );
     */
    "sDefaultContent": null,


    /**
     * This parameter is only used in DataTables' server-side processing. It can
     * be exceptionally useful to know what columns are being displayed on the
     * client side, and to map these to database fields. When defined, the names
     * also allow DataTables to reorder information from the server if it comes
     * back in an unexpected order (i.e. if you switch your columns around on the
     * client-side, your server-side code does not also need updating).
     *  @type string
     *  @default <i>Empty string</i>
     *
     *  @name DataTable.defaults.column.name
     *  @dtopt Columns
     *
     *  @example
     *    // Using `columnDefs`
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columnDefs": [
     *          { "name": "engine", "targets": [ 0 ] },
     *          { "name": "browser", "targets": [ 1 ] },
     *          { "name": "platform", "targets": [ 2 ] },
     *          { "name": "version", "targets": [ 3 ] },
     *          { "name": "grade", "targets": [ 4 ] }
     *        ]
     *      } );
     *    } );
     *
     *  @example
     *    // Using `columns`
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columns": [
     *          { "name": "engine" },
     *          { "name": "browser" },
     *          { "name": "platform" },
     *          { "name": "version" },
     *          { "name": "grade" }
     *        ]
     *      } );
     *    } );
     */
    "sName": "",


    /**
     * Defines a data source type for the ordering which can be used to read
     * real-time information from the table (updating the internally cached
     * version) prior to ordering. This allows ordering to occur on user
     * editable elements such as form inputs.
     *  @type string
     *  @default std
     *
     *  @name DataTable.defaults.column.orderDataType
     *  @dtopt Columns
     *
     *  @example
     *    // Using `columnDefs`
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columnDefs": [
     *          { "orderDataType": "dom-text", "targets": [ 2, 3 ] },
     *          { "type": "numeric", "targets": [ 3 ] },
     *          { "orderDataType": "dom-select", "targets": [ 4 ] },
     *          { "orderDataType": "dom-checkbox", "targets": [ 5 ] }
     *        ]
     *      } );
     *    } );
     *
     *  @example
     *    // Using `columns`
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columns": [
     *          null,
     *          null,
     *          { "orderDataType": "dom-text" },
     *          { "orderDataType": "dom-text", "type": "numeric" },
     *          { "orderDataType": "dom-select" },
     *          { "orderDataType": "dom-checkbox" }
     *        ]
     *      } );
     *    } );
     */
    "sSortDataType": "std",


    /**
     * The title of this column.
     *  @type string
     *  @default null <i>Derived from the 'TH' value for this column in the
     *    original HTML table.</i>
     *
     *  @name DataTable.defaults.column.title
     *  @dtopt Columns
     *
     *  @example
     *    // Using `columnDefs`
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columnDefs": [
     *          { "title": "My column title", "targets": [ 0 ] }
     *        ]
     *      } );
     *    } );
     *
     *  @example
     *    // Using `columns`
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columns": [
     *          { "title": "My column title" },
     *          null,
     *          null,
     *          null,
     *          null
     *        ]
     *      } );
     *    } );
     */
    "sTitle": null,


    /**
     * The type allows you to specify how the data for this column will be
     * ordered. Four types (string, numeric, date and html (which will strip
     * HTML tags before ordering)) are currently available. Note that only date
     * formats understood by Javascript's Date() object will be accepted as type
     * date. For example: "Mar 26, 2008 5:03 PM". May take the values: 'string',
     * 'numeric', 'date' or 'html' (by default). Further types can be adding
     * through plug-ins.
     *  @type string
     *  @default null <i>Auto-detected from raw data</i>
     *
     *  @name DataTable.defaults.column.type
     *  @dtopt Columns
     *
     *  @example
     *    // Using `columnDefs`
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columnDefs": [
     *          { "type": "html", "targets": [ 0 ] }
     *        ]
     *      } );
     *    } );
     *
     *  @example
     *    // Using `columns`
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columns": [
     *          { "type": "html" },
     *          null,
     *          null,
     *          null,
     *          null
     *        ]
     *      } );
     *    } );
     */
    "sType": null,


    /**
     * Defining the width of the column, this parameter may take any CSS value
     * (3em, 20px etc). DataTables applies 'smart' widths to columns which have not
     * been given a specific width through this interface ensuring that the table
     * remains readable.
     *  @type string
     *  @default null <i>Automatic</i>
     *
     *  @name DataTable.defaults.column.width
     *  @dtopt Columns
     *
     *  @example
     *    // Using `columnDefs`
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columnDefs": [
     *          { "width": "20%", "targets": [ 0 ] }
     *        ]
     *      } );
     *    } );
     *
     *  @example
     *    // Using `columns`
     *    $(document).ready( function() {
     *      $('#example').dataTable( {
     *        "columns": [
     *          { "width": "20%" },
     *          null,
     *          null,
     *          null,
     *          null
     *        ]
     *      } );
     *    } );
     */
    "sWidth": null
  };

  _fnHungarianMap( DataTable.defaults.column );



  /**
   * DataTables settings object - this holds all the information needed for a
   * given table, including configuration, data and current application of the
   * table options. DataTables does not have a single instance for each DataTable
   * with the settings attached to that instance, but rather instances of the
   * DataTable "class" are created on-the-fly as needed (typically by a
   * $().dataTable() call) and the settings object is then applied to that
   * instance.
   *
   * Note that this object is related to {@link DataTable.defaults} but this
   * one is the internal data store for DataTables's cache of columns. It should
   * NOT be manipulated outside of DataTables. Any configuration should be done
   * through the initialisation options.
   *  @namespace
   *  @todo Really should attach the settings object to individual instances so we
   *    don't need to create new instances on each $().dataTable() call (if the
   *    table already exists). It would also save passing oSettings around and
   *    into every single function. However, this is a very significant
   *    architecture change for DataTables and will almost certainly break
   *    backwards compatibility with older installations. This is something that
   *    will be done in 2.0.
   */
  DataTable.models.oSettings = {
    /**
     * Primary features of DataTables and their enablement state.
     *  @namespace
     */
    "oFeatures": {

      /**
       * Flag to say if DataTables should automatically try to calculate the
       * optimum table and columns widths (true) or not (false).
       * Note that this parameter will be set by the initialisation routine. To
       * set a default use {@link DataTable.defaults}.
       *  @type boolean
       */
      "bAutoWidth": null,

      /**
       * Delay the creation of TR and TD elements until they are actually
       * needed by a driven page draw. This can give a significant speed
       * increase for Ajax source and Javascript source data, but makes no
       * difference at all for DOM and server-side processing tables.
       * Note that this parameter will be set by the initialisation routine. To
       * set a default use {@link DataTable.defaults}.
       *  @type boolean
       */
      "bDeferRender": null,

      /**
       * Enable filtering on the table or not. Note that if this is disabled
       * then there is no filtering at all on the table, including fnFilter.
       * To just remove the filtering input use sDom and remove the 'f' option.
       * Note that this parameter will be set by the initialisation routine. To
       * set a default use {@link DataTable.defaults}.
       *  @type boolean
       */
      "bFilter": null,

      /**
       * Table information element (the 'Showing x of y records' div) enable
       * flag.
       * Note that this parameter will be set by the initialisation routine. To
       * set a default use {@link DataTable.defaults}.
       *  @type boolean
       */
      "bInfo": null,

      /**
       * Present a user control allowing the end user to change the page size
       * when pagination is enabled.
       * Note that this parameter will be set by the initialisation routine. To
       * set a default use {@link DataTable.defaults}.
       *  @type boolean
       */
      "bLengthChange": null,

      /**
       * Pagination enabled or not. Note that if this is disabled then length
       * changing must also be disabled.
       * Note that this parameter will be set by the initialisation routine. To
       * set a default use {@link DataTable.defaults}.
       *  @type boolean
       */
      "bPaginate": null,

      /**
       * Processing indicator enable flag whenever DataTables is enacting a
       * user request - typically an Ajax request for server-side processing.
       * Note that this parameter will be set by the initialisation routine. To
       * set a default use {@link DataTable.defaults}.
       *  @type boolean
       */
      "bProcessing": null,

      /**
       * Server-side processing enabled flag - when enabled DataTables will
       * get all data from the server for every draw - there is no filtering,
       * sorting or paging done on the client-side.
       * Note that this parameter will be set by the initialisation routine. To
       * set a default use {@link DataTable.defaults}.
       *  @type boolean
       */
      "bServerSide": null,

      /**
       * Sorting enablement flag.
       * Note that this parameter will be set by the initialisation routine. To
       * set a default use {@link DataTable.defaults}.
       *  @type boolean
       */
      "bSort": null,

      /**
       * Multi-column sorting
       * Note that this parameter will be set by the initialisation routine. To
       * set a default use {@link DataTable.defaults}.
       *  @type boolean
       */
      "bSortMulti": null,

      /**
       * Apply a class to the columns which are being sorted to provide a
       * visual highlight or not. This can slow things down when enabled since
       * there is a lot of DOM interaction.
       * Note that this parameter will be set by the initialisation routine. To
       * set a default use {@link DataTable.defaults}.
       *  @type boolean
       */
      "bSortClasses": null,

      /**
       * State saving enablement flag.
       * Note that this parameter will be set by the initialisation routine. To
       * set a default use {@link DataTable.defaults}.
       *  @type boolean
       */
      "bStateSave": null
    },


    /**
     * Scrolling settings for a table.
     *  @namespace
     */
    "oScroll": {
      /**
       * When the table is shorter in height than sScrollY, collapse the
       * table container down to the height of the table (when true).
       * Note that this parameter will be set by the initialisation routine. To
       * set a default use {@link DataTable.defaults}.
       *  @type boolean
       */
      "bCollapse": null,

      /**
       * Width of the scrollbar for the web-browser's platform. Calculated
       * during table initialisation.
       *  @type int
       *  @default 0
       */
      "iBarWidth": 0,

      /**
       * Viewport width for horizontal scrolling. Horizontal scrolling is
       * disabled if an empty string.
       * Note that this parameter will be set by the initialisation routine. To
       * set a default use {@link DataTable.defaults}.
       *  @type string
       */
      "sX": null,

      /**
       * Width to expand the table to when using x-scrolling. Typically you
       * should not need to use this.
       * Note that this parameter will be set by the initialisation routine. To
       * set a default use {@link DataTable.defaults}.
       *  @type string
       *  @deprecated
       */
      "sXInner": null,

      /**
       * Viewport height for vertical scrolling. Vertical scrolling is disabled
       * if an empty string.
       * Note that this parameter will be set by the initialisation routine. To
       * set a default use {@link DataTable.defaults}.
       *  @type string
       */
      "sY": null
    },

    /**
     * Language information for the table.
     *  @namespace
     *  @extends DataTable.defaults.oLanguage
     */
    "oLanguage": {
      /**
       * Information callback function. See
       * {@link DataTable.defaults.fnInfoCallback}
       *  @type function
       *  @default null
       */
      "fnInfoCallback": null
    },

    /**
     * Browser support parameters
     *  @namespace
     */
    "oBrowser": {
      /**
       * Indicate if the browser incorrectly calculates width:100% inside a
       * scrolling element (IE6/7)
       *  @type boolean
       *  @default false
       */
      "bScrollOversize": false,

      /**
       * Determine if the vertical scrollbar is on the right or left of the
       * scrolling container - needed for rtl language layout, although not
       * all browsers move the scrollbar (Safari).
       *  @type boolean
       *  @default false
       */
      "bScrollbarLeft": false,

      /**
       * Flag for if `getBoundingClientRect` is fully supported or not
       *  @type boolean
       *  @default false
       */
      "bBounding": false,

      /**
       * Browser scrollbar width
       *  @type integer
       *  @default 0
       */
      "barWidth": 0
    },


    "ajax": null,


    /**
     * Array referencing the nodes which are used for the features. The
     * parameters of this object match what is allowed by sDom - i.e.
     *   <ul>
     *     <li>'l' - Length changing</li>
     *     <li>'f' - Filtering input</li>
     *     <li>'t' - The table!</li>
     *     <li>'i' - Information</li>
     *     <li>'p' - Pagination</li>
     *     <li>'r' - pRocessing</li>
     *   </ul>
     *  @type array
     *  @default []
     */
    "aanFeatures": [],

    /**
     * Store data information - see {@link DataTable.models.oRow} for detailed
     * information.
     *  @type array
     *  @default []
     */
    "aoData": [],

    /**
     * Array of indexes which are in the current display (after filtering etc)
     *  @type array
     *  @default []
     */
    "aiDisplay": [],

    /**
     * Array of indexes for display - no filtering
     *  @type array
     *  @default []
     */
    "aiDisplayMaster": [],

    /**
     * Map of row ids to data indexes
     *  @type object
     *  @default {}
     */
    "aIds": {},

    /**
     * Store information about each column that is in use
     *  @type array
     *  @default []
     */
    "aoColumns": [],

    /**
     * Store information about the table's header
     *  @type array
     *  @default []
     */
    "aoHeader": [],

    /**
     * Store information about the table's footer
     *  @type array
     *  @default []
     */
    "aoFooter": [],

    /**
     * Store the applied global search information in case we want to force a
     * research or compare the old search to a new one.
     * Note that this parameter will be set by the initialisation routine. To
     * set a default use {@link DataTable.defaults}.
     *  @namespace
     *  @extends DataTable.models.oSearch
     */
    "oPreviousSearch": {},

    /**
     * Store the applied search for each column - see
     * {@link DataTable.models.oSearch} for the format that is used for the
     * filtering information for each column.
     *  @type array
     *  @default []
     */
    "aoPreSearchCols": [],

    /**
     * Sorting that is applied to the table. Note that the inner arrays are
     * used in the following manner:
     * <ul>
     *   <li>Index 0 - column number</li>
     *   <li>Index 1 - current sorting direction</li>
     * </ul>
     * Note that this parameter will be set by the initialisation routine. To
     * set a default use {@link DataTable.defaults}.
     *  @type array
     *  @todo These inner arrays should really be objects
     */
    "aaSorting": null,

    /**
     * Sorting that is always applied to the table (i.e. prefixed in front of
     * aaSorting).
     * Note that this parameter will be set by the initialisation routine. To
     * set a default use {@link DataTable.defaults}.
     *  @type array
     *  @default []
     */
    "aaSortingFixed": [],

    /**
     * Classes to use for the striping of a table.
     * Note that this parameter will be set by the initialisation routine. To
     * set a default use {@link DataTable.defaults}.
     *  @type array
     *  @default []
     */
    "asStripeClasses": null,

    /**
     * If restoring a table - we should restore its striping classes as well
     *  @type array
     *  @default []
     */
    "asDestroyStripes": [],

    /**
     * If restoring a table - we should restore its width
     *  @type int
     *  @default 0
     */
    "sDestroyWidth": 0,

    /**
     * Callback functions array for every time a row is inserted (i.e. on a draw).
     *  @type array
     *  @default []
     */
    "aoRowCallback": [],

    /**
     * Callback functions for the header on each draw.
     *  @type array
     *  @default []
     */
    "aoHeaderCallback": [],

    /**
     * Callback function for the footer on each draw.
     *  @type array
     *  @default []
     */
    "aoFooterCallback": [],

    /**
     * Array of callback functions for draw callback functions
     *  @type array
     *  @default []
     */
    "aoDrawCallback": [],

    /**
     * Array of callback functions for row created function
     *  @type array
     *  @default []
     */
    "aoRowCreatedCallback": [],

    /**
     * Callback functions for just before the table is redrawn. A return of
     * false will be used to cancel the draw.
     *  @type array
     *  @default []
     */
    "aoPreDrawCallback": [],

    /**
     * Callback functions for when the table has been initialised.
     *  @type array
     *  @default []
     */
    "aoInitComplete": [],


    /**
     * Callbacks for modifying the settings to be stored for state saving, prior to
     * saving state.
     *  @type array
     *  @default []
     */
    "aoStateSaveParams": [],

    /**
     * Callbacks for modifying the settings that have been stored for state saving
     * prior to using the stored values to restore the state.
     *  @type array
     *  @default []
     */
    "aoStateLoadParams": [],

    /**
     * Callbacks for operating on the settings object once the saved state has been
     * loaded
     *  @type array
     *  @default []
     */
    "aoStateLoaded": [],

    /**
     * Cache the table ID for quick access
     *  @type string
     *  @default <i>Empty string</i>
     */
    "sTableId": "",

    /**
     * The TABLE node for the main table
     *  @type node
     *  @default null
     */
    "nTable": null,

    /**
     * Permanent ref to the thead element
     *  @type node
     *  @default null
     */
    "nTHead": null,

    /**
     * Permanent ref to the tfoot element - if it exists
     *  @type node
     *  @default null
     */
    "nTFoot": null,

    /**
     * Permanent ref to the tbody element
     *  @type node
     *  @default null
     */
    "nTBody": null,

    /**
     * Cache the wrapper node (contains all DataTables controlled elements)
     *  @type node
     *  @default null
     */
    "nTableWrapper": null,

    /**
     * Indicate if when using server-side processing the loading of data
     * should be deferred until the second draw.
     * Note that this parameter will be set by the initialisation routine. To
     * set a default use {@link DataTable.defaults}.
     *  @type boolean
     *  @default false
     */
    "bDeferLoading": false,

    /**
     * Indicate if all required information has been read in
     *  @type boolean
     *  @default false
     */
    "bInitialised": false,

    /**
     * Information about open rows. Each object in the array has the parameters
     * 'nTr' and 'nParent'
     *  @type array
     *  @default []
     */
    "aoOpenRows": [],

    /**
     * Dictate the positioning of DataTables' control elements - see
     * {@link DataTable.model.oInit.sDom}.
     * Note that this parameter will be set by the initialisation routine. To
     * set a default use {@link DataTable.defaults}.
     *  @type string
     *  @default null
     */
    "sDom": null,

    /**
     * Search delay (in mS)
     *  @type integer
     *  @default null
     */
    "searchDelay": null,

    /**
     * Which type of pagination should be used.
     * Note that this parameter will be set by the initialisation routine. To
     * set a default use {@link DataTable.defaults}.
     *  @type string
     *  @default two_button
     */
    "sPaginationType": "two_button",

    /**
     * The state duration (for `stateSave`) in seconds.
     * Note that this parameter will be set by the initialisation routine. To
     * set a default use {@link DataTable.defaults}.
     *  @type int
     *  @default 0
     */
    "iStateDuration": 0,

    /**
     * Array of callback functions for state saving. Each array element is an
     * object with the following parameters:
     *   <ul>
     *     <li>function:fn - function to call. Takes two parameters, oSettings
     *       and the JSON string to save that has been thus far created. Returns
     *       a JSON string to be inserted into a json object
     *       (i.e. '"param": [ 0, 1, 2]')</li>
     *     <li>string:sName - name of callback</li>
     *   </ul>
     *  @type array
     *  @default []
     */
    "aoStateSave": [],

    /**
     * Array of callback functions for state loading. Each array element is an
     * object with the following parameters:
     *   <ul>
     *     <li>function:fn - function to call. Takes two parameters, oSettings
     *       and the object stored. May return false to cancel state loading</li>
     *     <li>string:sName - name of callback</li>
     *   </ul>
     *  @type array
     *  @default []
     */
    "aoStateLoad": [],

    /**
     * State that was saved. Useful for back reference
     *  @type object
     *  @default null
     */
    "oSavedState": null,

    /**
     * State that was loaded. Useful for back reference
     *  @type object
     *  @default null
     */
    "oLoadedState": null,

    /**
     * Source url for AJAX data for the table.
     * Note that this parameter will be set by the initialisation routine. To
     * set a default use {@link DataTable.defaults}.
     *  @type string
     *  @default null
     */
    "sAjaxSource": null,

    /**
     * Property from a given object from which to read the table data from. This
     * can be an empty string (when not server-side processing), in which case
     * it is  assumed an an array is given directly.
     * Note that this parameter will be set by the initialisation routine. To
     * set a default use {@link DataTable.defaults}.
     *  @type string
     */
    "sAjaxDataProp": null,

    /**
     * The last jQuery XHR object that was used for server-side data gathering.
     * This can be used for working with the XHR information in one of the
     * callbacks
     *  @type object
     *  @default null
     */
    "jqXHR": null,

    /**
     * JSON returned from the server in the last Ajax request
     *  @type object
     *  @default undefined
     */
    "json": undefined,

    /**
     * Data submitted as part of the last Ajax request
     *  @type object
     *  @default undefined
     */
    "oAjaxData": undefined,

    /**
     * Function to get the server-side data.
     * Note that this parameter will be set by the initialisation routine. To
     * set a default use {@link DataTable.defaults}.
     *  @type function
     */
    "fnServerData": null,

    /**
     * Functions which are called prior to sending an Ajax request so extra
     * parameters can easily be sent to the server
     *  @type array
     *  @default []
     */
    "aoServerParams": [],

    /**
     * Send the XHR HTTP method - GET or POST (could be PUT or DELETE if
     * required).
     * Note that this parameter will be set by the initialisation routine. To
     * set a default use {@link DataTable.defaults}.
     *  @type string
     */
    "sServerMethod": null,

    /**
     * Format numbers for display.
     * Note that this parameter will be set by the initialisation routine. To
     * set a default use {@link DataTable.defaults}.
     *  @type function
     */
    "fnFormatNumber": null,

    /**
     * List of options that can be used for the user selectable length menu.
     * Note that this parameter will be set by the initialisation routine. To
     * set a default use {@link DataTable.defaults}.
     *  @type array
     *  @default []
     */
    "aLengthMenu": null,

    /**
     * Counter for the draws that the table does. Also used as a tracker for
     * server-side processing
     *  @type int
     *  @default 0
     */
    "iDraw": 0,

    /**
     * Indicate if a redraw is being done - useful for Ajax
     *  @type boolean
     *  @default false
     */
    "bDrawing": false,

    /**
     * Draw index (iDraw) of the last error when parsing the returned data
     *  @type int
     *  @default -1
     */
    "iDrawError": -1,

    /**
     * Paging display length
     *  @type int
     *  @default 10
     */
    "_iDisplayLength": 10,

    /**
     * Paging start point - aiDisplay index
     *  @type int
     *  @default 0
     */
    "_iDisplayStart": 0,

    /**
     * Server-side processing - number of records in the result set
     * (i.e. before filtering), Use fnRecordsTotal rather than
     * this property to get the value of the number of records, regardless of
     * the server-side processing setting.
     *  @type int
     *  @default 0
     *  @private
     */
    "_iRecordsTotal": 0,

    /**
     * Server-side processing - number of records in the current display set
     * (i.e. after filtering). Use fnRecordsDisplay rather than
     * this property to get the value of the number of records, regardless of
     * the server-side processing setting.
     *  @type boolean
     *  @default 0
     *  @private
     */
    "_iRecordsDisplay": 0,

    /**
     * The classes to use for the table
     *  @type object
     *  @default {}
     */
    "oClasses": {},

    /**
     * Flag attached to the settings object so you can check in the draw
     * callback if filtering has been done in the draw. Deprecated in favour of
     * events.
     *  @type boolean
     *  @default false
     *  @deprecated
     */
    "bFiltered": false,

    /**
     * Flag attached to the settings object so you can check in the draw
     * callback if sorting has been done in the draw. Deprecated in favour of
     * events.
     *  @type boolean
     *  @default false
     *  @deprecated
     */
    "bSorted": false,

    /**
     * Indicate that if multiple rows are in the header and there is more than
     * one unique cell per column, if the top one (true) or bottom one (false)
     * should be used for sorting / title by DataTables.
     * Note that this parameter will be set by the initialisation routine. To
     * set a default use {@link DataTable.defaults}.
     *  @type boolean
     */
    "bSortCellsTop": null,

    /**
     * Initialisation object that is used for the table
     *  @type object
     *  @default null
     */
    "oInit": null,

    /**
     * Destroy callback functions - for plug-ins to attach themselves to the
     * destroy so they can clean up markup and events.
     *  @type array
     *  @default []
     */
    "aoDestroyCallback": [],


    /**
     * Get the number of records in the current record set, before filtering
     *  @type function
     */
    "fnRecordsTotal": function ()
    {
      return _fnDataSource( this ) == 'ssp' ?
        this._iRecordsTotal * 1 :
        this.aiDisplayMaster.length;
    },

    /**
     * Get the number of records in the current record set, after filtering
     *  @type function
     */
    "fnRecordsDisplay": function ()
    {
      return _fnDataSource( this ) == 'ssp' ?
        this._iRecordsDisplay * 1 :
        this.aiDisplay.length;
    },

    /**
     * Get the display end point - aiDisplay index
     *  @type function
     */
    "fnDisplayEnd": function ()
    {
      var
        len      = this._iDisplayLength,
        start    = this._iDisplayStart,
        calc     = start + len,
        records  = this.aiDisplay.length,
        features = this.oFeatures,
        paginate = features.bPaginate;

      if ( features.bServerSide ) {
        return paginate === false || len === -1 ?
          start + records :
          Math.min( start+len, this._iRecordsDisplay );
      }
      else {
        return ! paginate || calc>records || len===-1 ?
          records :
          calc;
      }
    },

    /**
     * The DataTables object for this table
     *  @type object
     *  @default null
     */
    "oInstance": null,

    /**
     * Unique identifier for each instance of the DataTables object. If there
     * is an ID on the table node, then it takes that value, otherwise an
     * incrementing internal counter is used.
     *  @type string
     *  @default null
     */
    "sInstance": null,

    /**
     * tabindex attribute value that is added to DataTables control elements, allowing
     * keyboard navigation of the table and its controls.
     */
    "iTabIndex": 0,

    /**
     * DIV container for the footer scrolling table if scrolling
     */
    "nScrollHead": null,

    /**
     * DIV container for the footer scrolling table if scrolling
     */
    "nScrollFoot": null,

    /**
     * Last applied sort
     *  @type array
     *  @default []
     */
    "aLastSort": [],

    /**
     * Stored plug-in instances
     *  @type object
     *  @default {}
     */
    "oPlugins": {},

    /**
     * Function used to get a row's id from the row's data
     *  @type function
     *  @default null
     */
    "rowIdFn": null,

    /**
     * Data location where to store a row's id
     *  @type string
     *  @default null
     */
    "rowId": null
  };

  /**
   * Extension object for DataTables that is used to provide all extension
   * options.
   *
   * Note that the `DataTable.ext` object is available through
   * `jQuery.fn.dataTable.ext` where it may be accessed and manipulated. It is
   * also aliased to `jQuery.fn.dataTableExt` for historic reasons.
   *  @namespace
   *  @extends DataTable.models.ext
   */


  /**
   * DataTables extensions
   *
   * This namespace acts as a collection area for plug-ins that can be used to
   * extend DataTables capabilities. Indeed many of the build in methods
   * use this method to provide their own capabilities (sorting methods for
   * example).
   *
   * Note that this namespace is aliased to `jQuery.fn.dataTableExt` for legacy
   * reasons
   *
   *  @namespace
   */
  DataTable.ext = _ext = {
    /**
     * Buttons. For use with the Buttons extension for DataTables. This is
     * defined here so other extensions can define buttons regardless of load
     * order. It is _not_ used by DataTables core.
     *
     *  @type object
     *  @default {}
     */
    buttons: {},


    /**
     * Element class names
     *
     *  @type object
     *  @default {}
     */
    classes: {},


    /**
     * DataTables build type (expanded by the download builder)
     *
     *  @type string
     */
    builder: "-source-",


    /**
     * Error reporting.
     *
     * How should DataTables report an error. Can take the value 'alert',
     * 'throw', 'none' or a function.
     *
     *  @type string|function
     *  @default alert
     */
    errMode: "alert",


    /**
     * Feature plug-ins.
     *
     * This is an array of objects which describe the feature plug-ins that are
     * available to DataTables. These feature plug-ins are then available for
     * use through the `dom` initialisation option.
     *
     * Each feature plug-in is described by an object which must have the
     * following properties:
     *
     * * `fnInit` - function that is used to initialise the plug-in,
     * * `cFeature` - a character so the feature can be enabled by the `dom`
     *   instillation option. This is case sensitive.
     *
     * The `fnInit` function has the following input parameters:
     *
     * 1. `{object}` DataTables settings object: see
     *    {@link DataTable.models.oSettings}
     *
     * And the following return is expected:
     *
     * * {node|null} The element which contains your feature. Note that the
     *   return may also be void if your plug-in does not require to inject any
     *   DOM elements into DataTables control (`dom`) - for example this might
     *   be useful when developing a plug-in which allows table control via
     *   keyboard entry
     *
     *  @type array
     *
     *  @example
     *    $.fn.dataTable.ext.features.push( {
     *      "fnInit": function( oSettings ) {
     *        return new TableTools( { "oDTSettings": oSettings } );
     *      },
     *      "cFeature": "T"
     *    } );
     */
    feature: [],


    /**
     * Row searching.
     *
     * This method of searching is complimentary to the default type based
     * searching, and a lot more comprehensive as it allows you complete control
     * over the searching logic. Each element in this array is a function
     * (parameters described below) that is called for every row in the table,
     * and your logic decides if it should be included in the searching data set
     * or not.
     *
     * Searching functions have the following input parameters:
     *
     * 1. `{object}` DataTables settings object: see
     *    {@link DataTable.models.oSettings}
     * 2. `{array|object}` Data for the row to be processed (same as the
     *    original format that was passed in as the data source, or an array
     *    from a DOM data source
     * 3. `{int}` Row index ({@link DataTable.models.oSettings.aoData}), which
     *    can be useful to retrieve the `TR` element if you need DOM interaction.
     *
     * And the following return is expected:
     *
     * * {boolean} Include the row in the searched result set (true) or not
     *   (false)
     *
     * Note that as with the main search ability in DataTables, technically this
     * is "filtering", since it is subtractive. However, for consistency in
     * naming we call it searching here.
     *
     *  @type array
     *  @default []
     *
     *  @example
     *    // The following example shows custom search being applied to the
     *    // fourth column (i.e. the data[3] index) based on two input values
     *    // from the end-user, matching the data in a certain range.
     *    $.fn.dataTable.ext.search.push(
     *      function( settings, data, dataIndex ) {
     *        var min = document.getElementById('min').value * 1;
     *        var max = document.getElementById('max').value * 1;
     *        var version = data[3] == "-" ? 0 : data[3]*1;
     *
     *        if ( min == "" && max == "" ) {
     *          return true;
     *        }
     *        else if ( min == "" && version < max ) {
     *          return true;
     *        }
     *        else if ( min < version && "" == max ) {
     *          return true;
     *        }
     *        else if ( min < version && version < max ) {
     *          return true;
     *        }
     *        return false;
     *      }
     *    );
     */
    search: [],


    /**
     * Selector extensions
     *
     * The `selector` option can be used to extend the options available for the
     * selector modifier options (`selector-modifier` object data type) that
     * each of the three built in selector types offer (row, column and cell +
     * their plural counterparts). For example the Select extension uses this
     * mechanism to provide an option to select only rows, columns and cells
     * that have been marked as selected by the end user (`{selected: true}`),
     * which can be used in conjunction with the existing built in selector
     * options.
     *
     * Each property is an array to which functions can be pushed. The functions
     * take three attributes:
     *
     * * Settings object for the host table
     * * Options object (`selector-modifier` object type)
     * * Array of selected item indexes
     *
     * The return is an array of the resulting item indexes after the custom
     * selector has been applied.
     *
     *  @type object
     */
    selector: {
      cell: [],
      column: [],
      row: []
    },


    /**
     * Internal functions, exposed for used in plug-ins.
     *
     * Please note that you should not need to use the internal methods for
     * anything other than a plug-in (and even then, try to avoid if possible).
     * The internal function may change between releases.
     *
     *  @type object
     *  @default {}
     */
    internal: {},


    /**
     * Legacy configuration options. Enable and disable legacy options that
     * are available in DataTables.
     *
     *  @type object
     */
    legacy: {
      /**
       * Enable / disable DataTables 1.9 compatible server-side processing
       * requests
       *
       *  @type boolean
       *  @default null
       */
      ajax: null
    },


    /**
     * Pagination plug-in methods.
     *
     * Each entry in this object is a function and defines which buttons should
     * be shown by the pagination rendering method that is used for the table:
     * {@link DataTable.ext.renderer.pageButton}. The renderer addresses how the
     * buttons are displayed in the document, while the functions here tell it
     * what buttons to display. This is done by returning an array of button
     * descriptions (what each button will do).
     *
     * Pagination types (the four built in options and any additional plug-in
     * options defined here) can be used through the `paginationType`
     * initialisation parameter.
     *
     * The functions defined take two parameters:
     *
     * 1. `{int} page` The current page index
     * 2. `{int} pages` The number of pages in the table
     *
     * Each function is expected to return an array where each element of the
     * array can be one of:
     *
     * * `first` - Jump to first page when activated
     * * `last` - Jump to last page when activated
     * * `previous` - Show previous page when activated
     * * `next` - Show next page when activated
     * * `{int}` - Show page of the index given
     * * `{array}` - A nested array containing the above elements to add a
     *   containing 'DIV' element (might be useful for styling).
     *
     * Note that DataTables v1.9- used this object slightly differently whereby
     * an object with two functions would be defined for each plug-in. That
     * ability is still supported by DataTables 1.10+ to provide backwards
     * compatibility, but this option of use is now decremented and no longer
     * documented in DataTables 1.10+.
     *
     *  @type object
     *  @default {}
     *
     *  @example
     *    // Show previous, next and current page buttons only
     *    $.fn.dataTableExt.oPagination.current = function ( page, pages ) {
     *      return [ 'previous', page, 'next' ];
     *    };
     */
    pager: {},


    renderer: {
      pageButton: {},
      header: {}
    },


    /**
     * Ordering plug-ins - custom data source
     *
     * The extension options for ordering of data available here is complimentary
     * to the default type based ordering that DataTables typically uses. It
     * allows much greater control over the the data that is being used to
     * order a column, but is necessarily therefore more complex.
     *
     * This type of ordering is useful if you want to do ordering based on data
     * live from the DOM (for example the contents of an 'input' element) rather
     * than just the static string that DataTables knows of.
     *
     * The way these plug-ins work is that you create an array of the values you
     * wish to be ordering for the column in question and then return that
     * array. The data in the array much be in the index order of the rows in
     * the table (not the currently ordering order!). Which order data gathering
     * function is run here depends on the `dt-init columns.orderDataType`
     * parameter that is used for the column (if any).
     *
     * The functions defined take two parameters:
     *
     * 1. `{object}` DataTables settings object: see
     *    {@link DataTable.models.oSettings}
     * 2. `{int}` Target column index
     *
     * Each function is expected to return an array:
     *
     * * `{array}` Data for the column to be ordering upon
     *
     *  @type array
     *
     *  @example
     *    // Ordering using `input` node values
     *    $.fn.dataTable.ext.order['dom-text'] = function  ( settings, col )
     *    {
     *      return this.api().column( col, {order:'index'} ).nodes().map( function ( td, i ) {
     *        return $('input', td).val();
     *      } );
     *    }
     */
    order: {},


    /**
     * Type based plug-ins.
     *
     * Each column in DataTables has a type assigned to it, either by automatic
     * detection or by direct assignment using the `type` option for the column.
     * The type of a column will effect how it is ordering and search (plug-ins
     * can also make use of the column type if required).
     *
     * @namespace
     */
    type: {
      /**
       * Type detection functions.
       *
       * The functions defined in this object are used to automatically detect
       * a column's type, making initialisation of DataTables super easy, even
       * when complex data is in the table.
       *
       * The functions defined take two parameters:
       *
       *  1. `{*}` Data from the column cell to be analysed
       *  2. `{settings}` DataTables settings object. This can be used to
       *     perform context specific type detection - for example detection
       *     based on language settings such as using a comma for a decimal
       *     place. Generally speaking the options from the settings will not
       *     be required
       *
       * Each function is expected to return:
       *
       * * `{string|null}` Data type detected, or null if unknown (and thus
       *   pass it on to the other type detection functions.
       *
       *  @type array
       *
       *  @example
       *    // Currency type detection plug-in:
       *    $.fn.dataTable.ext.type.detect.push(
       *      function ( data, settings ) {
       *        // Check the numeric part
       *        if ( ! data.substring(1).match(/[0-9]/) ) {
       *          return null;
       *        }
       *
       *        // Check prefixed by currency
       *        if ( data.charAt(0) == '$' || data.charAt(0) == '&pound;' ) {
       *          return 'currency';
       *        }
       *        return null;
       *      }
       *    );
       */
      detect: [],


      /**
       * Type based search formatting.
       *
       * The type based searching functions can be used to pre-format the
       * data to be search on. For example, it can be used to strip HTML
       * tags or to de-format telephone numbers for numeric only searching.
       *
       * Note that is a search is not defined for a column of a given type,
       * no search formatting will be performed.
       *
       * Pre-processing of searching data plug-ins - When you assign the sType
       * for a column (or have it automatically detected for you by DataTables
       * or a type detection plug-in), you will typically be using this for
       * custom sorting, but it can also be used to provide custom searching
       * by allowing you to pre-processing the data and returning the data in
       * the format that should be searched upon. This is done by adding
       * functions this object with a parameter name which matches the sType
       * for that target column. This is the corollary of <i>afnSortData</i>
       * for searching data.
       *
       * The functions defined take a single parameter:
       *
       *  1. `{*}` Data from the column cell to be prepared for searching
       *
       * Each function is expected to return:
       *
       * * `{string|null}` Formatted string that will be used for the searching.
       *
       *  @type object
       *  @default {}
       *
       *  @example
       *    $.fn.dataTable.ext.type.search['title-numeric'] = function ( d ) {
       *      return d.replace(/\n/g," ").replace( /<.*?>/g, "" );
       *    }
       */
      search: {},


      /**
       * Type based ordering.
       *
       * The column type tells DataTables what ordering to apply to the table
       * when a column is sorted upon. The order for each type that is defined,
       * is defined by the functions available in this object.
       *
       * Each ordering option can be described by three properties added to
       * this object:
       *
       * * `{type}-pre` - Pre-formatting function
       * * `{type}-asc` - Ascending order function
       * * `{type}-desc` - Descending order function
       *
       * All three can be used together, only `{type}-pre` or only
       * `{type}-asc` and `{type}-desc` together. It is generally recommended
       * that only `{type}-pre` is used, as this provides the optimal
       * implementation in terms of speed, although the others are provided
       * for compatibility with existing Javascript sort functions.
       *
       * `{type}-pre`: Functions defined take a single parameter:
       *
       *  1. `{*}` Data from the column cell to be prepared for ordering
       *
       * And return:
       *
       * * `{*}` Data to be sorted upon
       *
       * `{type}-asc` and `{type}-desc`: Functions are typical Javascript sort
       * functions, taking two parameters:
       *
       *  1. `{*}` Data to compare to the second parameter
       *  2. `{*}` Data to compare to the first parameter
       *
       * And returning:
       *
       * * `{*}` Ordering match: <0 if first parameter should be sorted lower
       *   than the second parameter, ===0 if the two parameters are equal and
       *   >0 if the first parameter should be sorted height than the second
       *   parameter.
       *
       *  @type object
       *  @default {}
       *
       *  @example
       *    // Numeric ordering of formatted numbers with a pre-formatter
       *    $.extend( $.fn.dataTable.ext.type.order, {
       *      "string-pre": function(x) {
       *        a = (a === "-" || a === "") ? 0 : a.replace( /[^\d\-\.]/g, "" );
       *        return parseFloat( a );
       *      }
       *    } );
       *
       *  @example
       *    // Case-sensitive string ordering, with no pre-formatting method
       *    $.extend( $.fn.dataTable.ext.order, {
       *      "string-case-asc": function(x,y) {
       *        return ((x < y) ? -1 : ((x > y) ? 1 : 0));
       *      },
       *      "string-case-desc": function(x,y) {
       *        return ((x < y) ? 1 : ((x > y) ? -1 : 0));
       *      }
       *    } );
       */
      order: {}
    },

    /**
     * Unique DataTables instance counter
     *
     * @type int
     * @private
     */
    _unique: 0,


    //
    // Depreciated
    // The following properties are retained for backwards compatibility only.
    // The should not be used in new projects and will be removed in a future
    // version
    //

    /**
     * Version check function.
     *  @type function
     *  @depreciated Since 1.10
     */
    fnVersionCheck: DataTable.fnVersionCheck,


    /**
     * Index for what 'this' index API functions should use
     *  @type int
     *  @deprecated Since v1.10
     */
    iApiIndex: 0,


    /**
     * jQuery UI class container
     *  @type object
     *  @deprecated Since v1.10
     */
    oJUIClasses: {},


    /**
     * Software version
     *  @type string
     *  @deprecated Since v1.10
     */
    sVersion: DataTable.version
  };


  //
  // Backwards compatibility. Alias to pre 1.10 Hungarian notation counter parts
  //
  $.extend( _ext, {
    afnFiltering: _ext.search,
    aTypes:       _ext.type.detect,
    ofnSearch:    _ext.type.search,
    oSort:        _ext.type.order,
    afnSortData:  _ext.order,
    aoFeatures:   _ext.feature,
    oApi:         _ext.internal,
    oStdClasses:  _ext.classes,
    oPagination:  _ext.pager
  } );


  $.extend( DataTable.ext.classes, {
    "sTable": "dataTable",
    "sNoFooter": "no-footer",

    /* Paging buttons */
    "sPageButton": "paginate_button",
    "sPageButtonActive": "current",
    "sPageButtonDisabled": "disabled",

    /* Striping classes */
    "sStripeOdd": "odd",
    "sStripeEven": "even",

    /* Empty row */
    "sRowEmpty": "dataTables_empty",

    /* Features */
    "sWrapper": "dataTables_wrapper",
    "sFilter": "dataTables_filter",
    "sInfo": "dataTables_info",
    "sPaging": "dataTables_paginate paging_", /* Note that the type is postfixed */
    "sLength": "dataTables_length",
    "sProcessing": "dataTables_processing",

    /* Sorting */
    "sSortAsc": "sorting_asc",
    "sSortDesc": "sorting_desc",
    "sSortable": "sorting", /* Sortable in both directions */
    "sSortableAsc": "sorting_desc_disabled",
    "sSortableDesc": "sorting_asc_disabled",
    "sSortableNone": "sorting_disabled",
    "sSortColumn": "sorting_", /* Note that an int is postfixed for the sorting order */

    /* Filtering */
    "sFilterInput": "",

    /* Page length */
    "sLengthSelect": "",

    /* Scrolling */
    "sScrollWrapper": "dataTables_scroll",
    "sScrollHead": "dataTables_scrollHead",
    "sScrollHeadInner": "dataTables_scrollHeadInner",
    "sScrollBody": "dataTables_scrollBody",
    "sScrollFoot": "dataTables_scrollFoot",
    "sScrollFootInner": "dataTables_scrollFootInner",

    /* Misc */
    "sHeaderTH": "",
    "sFooterTH": "",

    // Deprecated
    "sSortJUIAsc": "",
    "sSortJUIDesc": "",
    "sSortJUI": "",
    "sSortJUIAscAllowed": "",
    "sSortJUIDescAllowed": "",
    "sSortJUIWrapper": "",
    "sSortIcon": "",
    "sJUIHeader": "",
    "sJUIFooter": ""
  } );


  var extPagination = DataTable.ext.pager;

  function _numbers ( page, pages ) {
    var
      numbers = [],
      buttons = extPagination.numbers_length,
      half = Math.floor( buttons / 2 ),
      i = 1;

    if ( pages <= buttons ) {
      numbers = _range( 0, pages );
    }
    else if ( page <= half ) {
      numbers = _range( 0, buttons-2 );
      numbers.push( 'ellipsis' );
      numbers.push( pages-1 );
    }
    else if ( page >= pages - 1 - half ) {
      numbers = _range( pages-(buttons-2), pages );
      numbers.splice( 0, 0, 'ellipsis' ); // no unshift in ie6
      numbers.splice( 0, 0, 0 );
    }
    else {
      numbers = _range( page-half+2, page+half-1 );
      numbers.push( 'ellipsis' );
      numbers.push( pages-1 );
      numbers.splice( 0, 0, 'ellipsis' );
      numbers.splice( 0, 0, 0 );
    }

    numbers.DT_el = 'span';
    return numbers;
  }


  $.extend( extPagination, {
    simple: function ( page, pages ) {
      return [ 'previous', 'next' ];
    },

    full: function ( page, pages ) {
      return [  'first', 'previous', 'next', 'last' ];
    },

    numbers: function ( page, pages ) {
      return [ _numbers(page, pages) ];
    },

    simple_numbers: function ( page, pages ) {
      return [ 'previous', _numbers(page, pages), 'next' ];
    },

    full_numbers: function ( page, pages ) {
      return [ 'first', 'previous', _numbers(page, pages), 'next', 'last' ];
    },

    first_last_numbers: function (page, pages) {
      return ['first', _numbers(page, pages), 'last'];
    },

    // For testing and plug-ins to use
    _numbers: _numbers,

    // Number of number buttons (including ellipsis) to show. _Must be odd!_
    numbers_length: 7
  } );


  $.extend( true, DataTable.ext.renderer, {
    pageButton: {
      _: function ( settings, host, idx, buttons, page, pages ) {
        var classes = settings.oClasses;
        var lang = settings.oLanguage.oPaginate;
        var aria = settings.oLanguage.oAria.paginate || {};
        var btnDisplay, btnClass, counter=0;

        var attach = function( container, buttons ) {
          var i, ien, node, button, tabIndex;
          var disabledClass = classes.sPageButtonDisabled;
          var clickHandler = function ( e ) {
            _fnPageChange( settings, e.data.action, true );
          };

          for ( i=0, ien=buttons.length ; i<ien ; i++ ) {
            button = buttons[i];

            if ( Array.isArray( button ) ) {
              var inner = $( '<'+(button.DT_el || 'div')+'/>' )
                .appendTo( container );
              attach( inner, button );
            }
            else {
              btnDisplay = null;
              btnClass = button;
              tabIndex = settings.iTabIndex;

              switch ( button ) {
                case 'ellipsis':
                  container.append('<span class="ellipsis">&#x2026;</span>');
                  break;

                case 'first':
                  btnDisplay = lang.sFirst;

                  if ( page === 0 ) {
                    tabIndex = -1;
                    btnClass += ' ' + disabledClass;
                  }
                  break;

                case 'previous':
                  btnDisplay = lang.sPrevious;

                  if ( page === 0 ) {
                    tabIndex = -1;
                    btnClass += ' ' + disabledClass;
                  }
                  break;

                case 'next':
                  btnDisplay = lang.sNext;

                  if ( pages === 0 || page === pages-1 ) {
                    tabIndex = -1;
                    btnClass += ' ' + disabledClass;
                  }
                  break;

                case 'last':
                  btnDisplay = lang.sLast;

                  if ( pages === 0 || page === pages-1 ) {
                    tabIndex = -1;
                    btnClass += ' ' + disabledClass;
                  }
                  break;

                default:
                  btnDisplay = settings.fnFormatNumber( button + 1 );
                  btnClass = page === button ?
                    classes.sPageButtonActive : '';
                  break;
              }

              if ( btnDisplay !== null ) {
                node = $('<a>', {
                  'class': classes.sPageButton+' '+btnClass,
                  'aria-controls': settings.sTableId,
                  'aria-label': aria[ button ],
                  'data-dt-idx': counter,
                  'tabindex': tabIndex,
                  'id': idx === 0 && typeof button === 'string' ?
                    settings.sTableId +'_'+ button :
                    null
                } )
                  .html( btnDisplay )
                  .appendTo( container );

                _fnBindAction(
                  node, {action: button}, clickHandler
                );

                counter++;
              }
            }
          }
        };

        // IE9 throws an 'unknown error' if document.activeElement is used
        // inside an iframe or frame. Try / catch the error. Not good for
        // accessibility, but neither are frames.
        var activeEl;

        try {
          // Because this approach is destroying and recreating the paging
          // elements, focus is lost on the select button which is bad for
          // accessibility. So we want to restore focus once the draw has
          // completed
          activeEl = $(host).find(document.activeElement).data('dt-idx');
        }
        catch (e) {}

        attach( $(host).empty(), buttons );

        if ( activeEl !== undefined ) {
          $(host).find( '[data-dt-idx='+activeEl+']' ).trigger('focus');
        }
      }
    }
  } );



  // Built in type detection. See model.ext.aTypes for information about
  // what is required from this methods.
  $.extend( DataTable.ext.type.detect, [
    // Plain numbers - first since V8 detects some plain numbers as dates
    // e.g. Date.parse('55') (but not all, e.g. Date.parse('22')...).
    function ( d, settings )
    {
      var decimal = settings.oLanguage.sDecimal;
      return _isNumber( d, decimal ) ? 'num'+decimal : null;
    },

    // Dates (only those recognised by the browser's Date.parse)
    function ( d, settings )
    {
      // V8 tries _very_ hard to make a string passed into `Date.parse()`
      // valid, so we need to use a regex to restrict date formats. Use a
      // plug-in for anything other than ISO8601 style strings
      if ( d && !(d instanceof Date) && ! _re_date.test(d) ) {
        return null;
      }
      var parsed = Date.parse(d);
      return (parsed !== null && !isNaN(parsed)) || _empty(d) ? 'date' : null;
    },

    // Formatted numbers
    function ( d, settings )
    {
      var decimal = settings.oLanguage.sDecimal;
      return _isNumber( d, decimal, true ) ? 'num-fmt'+decimal : null;
    },

    // HTML numeric
    function ( d, settings )
    {
      var decimal = settings.oLanguage.sDecimal;
      return _htmlNumeric( d, decimal ) ? 'html-num'+decimal : null;
    },

    // HTML numeric, formatted
    function ( d, settings )
    {
      var decimal = settings.oLanguage.sDecimal;
      return _htmlNumeric( d, decimal, true ) ? 'html-num-fmt'+decimal : null;
    },

    // HTML (this is strict checking - there must be html)
    function ( d, settings )
    {
      return _empty( d ) || (typeof d === 'string' && d.indexOf('<') !== -1) ?
        'html' : null;
    }
  ] );



  // Filter formatting functions. See model.ext.ofnSearch for information about
  // what is required from these methods.
  //
  // Note that additional search methods are added for the html numbers and
  // html formatted numbers by `_addNumericSort()` when we know what the decimal
  // place is


  $.extend( DataTable.ext.type.search, {
    html: function ( data ) {
      return _empty(data) ?
        data :
        typeof data === 'string' ?
          data
            .replace( _re_new_lines, " " )
            .replace( _re_html, "" ) :
          '';
    },

    string: function ( data ) {
      return _empty(data) ?
        data :
        typeof data === 'string' ?
          data.replace( _re_new_lines, " " ) :
          data;
    }
  } );



  var __numericReplace = function ( d, decimalPlace, re1, re2 ) {
    if ( d !== 0 && (!d || d === '-') ) {
      return -Infinity;
    }

    // If a decimal place other than `.` is used, it needs to be given to the
    // function so we can detect it and replace with a `.` which is the only
    // decimal place Javascript recognises - it is not locale aware.
    if ( decimalPlace ) {
      d = _numToDecimal( d, decimalPlace );
    }

    if ( d.replace ) {
      if ( re1 ) {
        d = d.replace( re1, '' );
      }

      if ( re2 ) {
        d = d.replace( re2, '' );
      }
    }

    return d * 1;
  };


  // Add the numeric 'deformatting' functions for sorting and search. This is done
  // in a function to provide an easy ability for the language options to add
  // additional methods if a non-period decimal place is used.
  function _addNumericSort ( decimalPlace ) {
    $.each(
      {
        // Plain numbers
        "num": function ( d ) {
          return __numericReplace( d, decimalPlace );
        },

        // Formatted numbers
        "num-fmt": function ( d ) {
          return __numericReplace( d, decimalPlace, _re_formatted_numeric );
        },

        // HTML numeric
        "html-num": function ( d ) {
          return __numericReplace( d, decimalPlace, _re_html );
        },

        // HTML numeric, formatted
        "html-num-fmt": function ( d ) {
          return __numericReplace( d, decimalPlace, _re_html, _re_formatted_numeric );
        }
      },
      function ( key, fn ) {
        // Add the ordering method
        _ext.type.order[ key+decimalPlace+'-pre' ] = fn;

        // For HTML types add a search formatter that will strip the HTML
        if ( key.match(/^html\-/) ) {
          _ext.type.search[ key+decimalPlace ] = _ext.type.search.html;
        }
      }
    );
  }


  // Default sort methods
  $.extend( _ext.type.order, {
    // Dates
    "date-pre": function ( d ) {
      var ts = Date.parse( d );
      return isNaN(ts) ? -Infinity : ts;
    },

    // html
    "html-pre": function ( a ) {
      return _empty(a) ?
        '' :
        a.replace ?
          a.replace( /<.*?>/g, "" ).toLowerCase() :
          a+'';
    },

    // string
    "string-pre": function ( a ) {
      // This is a little complex, but faster than always calling toString,
      // http://jsperf.com/tostring-v-check
      return _empty(a) ?
        '' :
        typeof a === 'string' ?
          a.toLowerCase() :
          ! a.toString ?
            '' :
            a.toString();
    },

    // string-asc and -desc are retained only for compatibility with the old
    // sort methods
    "string-asc": function ( x, y ) {
      return ((x < y) ? -1 : ((x > y) ? 1 : 0));
    },

    "string-desc": function ( x, y ) {
      return ((x < y) ? 1 : ((x > y) ? -1 : 0));
    }
  } );


  // Numeric sorting types - order doesn't matter here
  _addNumericSort( '' );


  $.extend( true, DataTable.ext.renderer, {
    header: {
      _: function ( settings, cell, column, classes ) {
        // No additional mark-up required
        // Attach a sort listener to update on sort - note that using the
        // `DT` namespace will allow the event to be removed automatically
        // on destroy, while the `dt` namespaced event is the one we are
        // listening for
        $(settings.nTable).on( 'order.dt.DT', function ( e, ctx, sorting, columns ) {
          if ( settings !== ctx ) { // need to check this this is the host
            return;               // table, not a nested one
          }

          var colIdx = column.idx;

          cell
            .removeClass(
              classes.sSortAsc +' '+
              classes.sSortDesc
            )
            .addClass( columns[ colIdx ] == 'asc' ?
              classes.sSortAsc : columns[ colIdx ] == 'desc' ?
                classes.sSortDesc :
                column.sSortingClass
            );
        } );
      },

      jqueryui: function ( settings, cell, column, classes ) {
        $('<div/>')
          .addClass( classes.sSortJUIWrapper )
          .append( cell.contents() )
          .append( $('<span/>')
            .addClass( classes.sSortIcon+' '+column.sSortingClassJUI )
          )
          .appendTo( cell );

        // Attach a sort listener to update on sort
        $(settings.nTable).on( 'order.dt.DT', function ( e, ctx, sorting, columns ) {
          if ( settings !== ctx ) {
            return;
          }

          var colIdx = column.idx;

          cell
            .removeClass( classes.sSortAsc +" "+classes.sSortDesc )
            .addClass( columns[ colIdx ] == 'asc' ?
              classes.sSortAsc : columns[ colIdx ] == 'desc' ?
                classes.sSortDesc :
                column.sSortingClass
            );

          cell
            .find( 'span.'+classes.sSortIcon )
            .removeClass(
              classes.sSortJUIAsc +" "+
              classes.sSortJUIDesc +" "+
              classes.sSortJUI +" "+
              classes.sSortJUIAscAllowed +" "+
              classes.sSortJUIDescAllowed
            )
            .addClass( columns[ colIdx ] == 'asc' ?
              classes.sSortJUIAsc : columns[ colIdx ] == 'desc' ?
                classes.sSortJUIDesc :
                column.sSortingClassJUI
            );
        } );
      }
    }
  } );

  /*
	 * Public helper functions. These aren't used internally by DataTables, or
	 * called by any of the options passed into DataTables, but they can be used
	 * externally by developers working with DataTables. They are helper functions
	 * to make working with DataTables a little bit easier.
	 */

  var __htmlEscapeEntities = function ( d ) {
    if (Array.isArray(d)) {
      d = d.join(',');
    }

    return typeof d === 'string' ?
      d
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;') :
      d;
  };

  // Common logic for moment, luxon or a date action
  function __mld( dt, momentFn, luxonFn, dateFn, arg1 ) {
    if (window.moment) {
      return dt[momentFn]( arg1 );
    }
    else if (window.luxon) {
      return dt[luxonFn]( arg1 );
    }

    return dateFn ? dt[dateFn]( arg1 ) : dt;
  }


  var __mlWarning = false;
  function __mldObj (d, format, locale) {
    var dt;

    if (window.moment) {
      dt = window.moment.utc( d, format, locale, true );

      if (! dt.isValid()) {
        return null;
      }
    }
    else if (window.luxon) {
      dt = format
        ? window.luxon.DateTime.fromFormat( d, format )
        : window.luxon.DateTime.fromISO( d );

      if (! dt.isValid) {
        return null;
      }

      dt.setLocale(locale);
    }
    else if (! format) {
      // No format given, must be ISO
      dt = new Date(d);
    }
    else {
      if (! __mlWarning) {
        alert('DataTables warning: Formatted date without Moment.js or Luxon - https://datatables.net/tn/17');
      }

      __mlWarning = true;
    }

    return dt;
  }

  // Wrapper for date, datetime and time which all operate the same way with the exception of
  // the output string for auto locale support
  function __mlHelper (localeString) {
    return function ( from, to, locale, def ) {
      // Luxon and Moment support
      // Argument shifting
      if ( arguments.length === 0 ) {
        locale = 'en';
        to = null; // means toLocaleString
        from = null; // means iso8601
      }
      else if ( arguments.length === 1 ) {
        locale = 'en';
        to = from;
        from = null;
      }
      else if ( arguments.length === 2 ) {
        locale = to;
        to = from;
        from = null;
      }

      var typeName = 'datetime-' + to;

      // Add type detection and sorting specific to this date format - we need to be able to identify
      // date type columns as such, rather than as numbers in extensions. Hence the need for this.
      if (! DataTable.ext.type.order[typeName]) {
        // The renderer will give the value to type detect as the type!
        DataTable.ext.type.detect.unshift(function (d) {
          return d === typeName ? typeName : false;
        });

        // The renderer gives us Moment, Luxon or Date obects for the sorting, all of which have a
        // `valueOf` which gives milliseconds epoch
        DataTable.ext.type.order[typeName + '-asc'] = function (a, b) {
          var x = a.valueOf();
          var y = b.valueOf();

          return x === y
            ? 0
            : x < y
              ? -1
              : 1;
        }

        DataTable.ext.type.order[typeName + '-desc'] = function (a, b) {
          var x = a.valueOf();
          var y = b.valueOf();

          return x === y
            ? 0
            : x > y
              ? -1
              : 1;
        }
      }

      return function ( d, type ) {
        // Allow for a default value
        if (d === null || d === undefined) {
          if (def === '--now') {
            // We treat everything as UTC further down, so no changes are
            // made, as such need to get the local date / time as if it were
            // UTC
            var local = new Date();
            d = new Date( Date.UTC(
              local.getFullYear(), local.getMonth(), local.getDate(),
              local.getHours(), local.getMinutes(), local.getSeconds()
            ) );
          }
          else {
            d = '';
          }
        }

        if (type === 'type') {
          // Typing uses the type name for fast matching
          return typeName;
        }

        if (d === '') {
          return type !== 'sort'
            ? ''
            : __mldObj('0000-01-01 00:00:00', null, locale);
        }

        // Shortcut. If `from` and `to` are the same, we are using the renderer to
        // format for ordering, not display - its already in the display format.
        if ( to !== null && from === to && type !== 'sort' && type !== 'type' && ! (d instanceof Date) ) {
          return d;
        }

        var dt = __mldObj(d, from, locale);

        if (dt === null) {
          return d;
        }

        if (type === 'sort') {
          return dt;
        }

        var formatted = to === null
          ? __mld(dt, 'toDate', 'toJSDate', '')[localeString]()
          : __mld(dt, 'format', 'toFormat', 'toISOString', to);

        // XSS protection
        return type === 'display' ?
          __htmlEscapeEntities( formatted ) :
          formatted;
      };
    }
  }

  // Based on locale, determine standard number formatting
  // Fallback for legacy browsers is US English
  var __thousands = ',';
  var __decimal = '.';

  if (Intl) {
    try {
      var num = new Intl.NumberFormat().formatToParts(100000.1);

      for (var i=0 ; i<num.length ; i++) {
        if (num[i].type === 'group') {
          __thousands = num[i].value;
        }
        else if (num[i].type === 'decimal') {
          __decimal = num[i].value;
        }
      }
    }
    catch (e) {
      // noop
    }
  }

  // Formatted date time detection - use by declaring the formats you are going to use
  DataTable.datetime = function ( format, locale ) {
    var typeName = 'datetime-detect-' + format;

    if (! locale) {
      locale = 'en';
    }

    if (! DataTable.ext.type.order[typeName]) {
      DataTable.ext.type.detect.unshift(function (d) {
        var dt = __mldObj(d, format, locale);
        return d === '' || dt ? typeName : false;
      });

      DataTable.ext.type.order[typeName + '-pre'] = function (d) {
        return __mldObj(d, format, locale) || 0;
      }
    }
  }

  /**
   * Helpers for `columns.render`.
   *
   * The options defined here can be used with the `columns.render` initialisation
   * option to provide a display renderer. The following functions are defined:
   *
   * * `number` - Will format numeric data (defined by `columns.data`) for
   *   display, retaining the original unformatted data for sorting and filtering.
   *   It takes 5 parameters:
   *   * `string` - Thousands grouping separator
   *   * `string` - Decimal point indicator
   *   * `integer` - Number of decimal points to show
   *   * `string` (optional) - Prefix.
   *   * `string` (optional) - Postfix (/suffix).
   * * `text` - Escape HTML to help prevent XSS attacks. It has no optional
   *   parameters.
   *
   * @example
   *   // Column definition using the number renderer
   *   {
   *     data: "salary",
   *     render: $.fn.dataTable.render.number( '\'', '.', 0, '$' )
   *   }
   *
   * @namespace
   */
  DataTable.render = {
    date: __mlHelper('toLocaleDateString'),
    datetime: __mlHelper('toLocaleString'),
    time: __mlHelper('toLocaleTimeString'),
    number: function ( thousands, decimal, precision, prefix, postfix ) {
      // Auto locale detection
      if (thousands === null || thousands === undefined) {
        thousands = __thousands;
      }

      if (decimal === null || decimal === undefined) {
        decimal = __decimal;
      }

      return {
        display: function ( d ) {
          if ( typeof d !== 'number' && typeof d !== 'string' ) {
            return d;
          }

          if (d === '' || d === null) {
            return d;
          }

          var negative = d < 0 ? '-' : '';
          var flo = parseFloat( d );

          // If NaN then there isn't much formatting that we can do - just
          // return immediately, escaping any HTML (this was supposed to
          // be a number after all)
          if ( isNaN( flo ) ) {
            return __htmlEscapeEntities( d );
          }

          flo = flo.toFixed( precision );
          d = Math.abs( flo );

          var intPart = parseInt( d, 10 );
          var floatPart = precision ?
            decimal+(d - intPart).toFixed( precision ).substring( 2 ):
            '';

          // If zero, then can't have a negative prefix
          if (intPart === 0 && parseFloat(floatPart) === 0) {
            negative = '';
          }

          return negative + (prefix||'') +
            intPart.toString().replace(
              /\B(?=(\d{3})+(?!\d))/g, thousands
            ) +
            floatPart +
            (postfix||'');
        }
      };
    },

    text: function () {
      return {
        display: __htmlEscapeEntities,
        filter: __htmlEscapeEntities
      };
    }
  };


  /*
	 * This is really a good bit rubbish this method of exposing the internal methods
	 * publicly... - To be fixed in 2.0 using methods on the prototype
	 */


  /**
   * Create a wrapper function for exporting an internal functions to an external API.
   *  @param {string} fn API function name
   *  @returns {function} wrapped function
   *  @memberof DataTable#internal
   */
  function _fnExternApiFunc (fn)
  {
    return function() {
      var args = [_fnSettingsFromNode( this[DataTable.ext.iApiIndex] )].concat(
        Array.prototype.slice.call(arguments)
      );
      return DataTable.ext.internal[fn].apply( this, args );
    };
  }


  /**
   * Reference to internal functions for use by plug-in developers. Note that
   * these methods are references to internal functions and are considered to be
   * private. If you use these methods, be aware that they are liable to change
   * between versions.
   *  @namespace
   */
  $.extend( DataTable.ext.internal, {
    _fnExternApiFunc: _fnExternApiFunc,
    _fnBuildAjax: _fnBuildAjax,
    _fnAjaxUpdate: _fnAjaxUpdate,
    _fnAjaxParameters: _fnAjaxParameters,
    _fnAjaxUpdateDraw: _fnAjaxUpdateDraw,
    _fnAjaxDataSrc: _fnAjaxDataSrc,
    _fnAddColumn: _fnAddColumn,
    _fnColumnOptions: _fnColumnOptions,
    _fnAdjustColumnSizing: _fnAdjustColumnSizing,
    _fnVisibleToColumnIndex: _fnVisibleToColumnIndex,
    _fnColumnIndexToVisible: _fnColumnIndexToVisible,
    _fnVisbleColumns: _fnVisbleColumns,
    _fnGetColumns: _fnGetColumns,
    _fnColumnTypes: _fnColumnTypes,
    _fnApplyColumnDefs: _fnApplyColumnDefs,
    _fnHungarianMap: _fnHungarianMap,
    _fnCamelToHungarian: _fnCamelToHungarian,
    _fnLanguageCompat: _fnLanguageCompat,
    _fnBrowserDetect: _fnBrowserDetect,
    _fnAddData: _fnAddData,
    _fnAddTr: _fnAddTr,
    _fnNodeToDataIndex: _fnNodeToDataIndex,
    _fnNodeToColumnIndex: _fnNodeToColumnIndex,
    _fnGetCellData: _fnGetCellData,
    _fnSetCellData: _fnSetCellData,
    _fnSplitObjNotation: _fnSplitObjNotation,
    _fnGetObjectDataFn: _fnGetObjectDataFn,
    _fnSetObjectDataFn: _fnSetObjectDataFn,
    _fnGetDataMaster: _fnGetDataMaster,
    _fnClearTable: _fnClearTable,
    _fnDeleteIndex: _fnDeleteIndex,
    _fnInvalidate: _fnInvalidate,
    _fnGetRowElements: _fnGetRowElements,
    _fnCreateTr: _fnCreateTr,
    _fnBuildHead: _fnBuildHead,
    _fnDrawHead: _fnDrawHead,
    _fnDraw: _fnDraw,
    _fnReDraw: _fnReDraw,
    _fnAddOptionsHtml: _fnAddOptionsHtml,
    _fnDetectHeader: _fnDetectHeader,
    _fnGetUniqueThs: _fnGetUniqueThs,
    _fnFeatureHtmlFilter: _fnFeatureHtmlFilter,
    _fnFilterComplete: _fnFilterComplete,
    _fnFilterCustom: _fnFilterCustom,
    _fnFilterColumn: _fnFilterColumn,
    _fnFilter: _fnFilter,
    _fnFilterCreateSearch: _fnFilterCreateSearch,
    _fnEscapeRegex: _fnEscapeRegex,
    _fnFilterData: _fnFilterData,
    _fnFeatureHtmlInfo: _fnFeatureHtmlInfo,
    _fnUpdateInfo: _fnUpdateInfo,
    _fnInfoMacros: _fnInfoMacros,
    _fnInitialise: _fnInitialise,
    _fnInitComplete: _fnInitComplete,
    _fnLengthChange: _fnLengthChange,
    _fnFeatureHtmlLength: _fnFeatureHtmlLength,
    _fnFeatureHtmlPaginate: _fnFeatureHtmlPaginate,
    _fnPageChange: _fnPageChange,
    _fnFeatureHtmlProcessing: _fnFeatureHtmlProcessing,
    _fnProcessingDisplay: _fnProcessingDisplay,
    _fnFeatureHtmlTable: _fnFeatureHtmlTable,
    _fnScrollDraw: _fnScrollDraw,
    _fnApplyToChildren: _fnApplyToChildren,
    _fnCalculateColumnWidths: _fnCalculateColumnWidths,
    _fnThrottle: _fnThrottle,
    _fnConvertToWidth: _fnConvertToWidth,
    _fnGetWidestNode: _fnGetWidestNode,
    _fnGetMaxLenString: _fnGetMaxLenString,
    _fnStringToCss: _fnStringToCss,
    _fnSortFlatten: _fnSortFlatten,
    _fnSort: _fnSort,
    _fnSortAria: _fnSortAria,
    _fnSortListener: _fnSortListener,
    _fnSortAttachListener: _fnSortAttachListener,
    _fnSortingClasses: _fnSortingClasses,
    _fnSortData: _fnSortData,
    _fnSaveState: _fnSaveState,
    _fnLoadState: _fnLoadState,
    _fnImplementState: _fnImplementState,
    _fnSettingsFromNode: _fnSettingsFromNode,
    _fnLog: _fnLog,
    _fnMap: _fnMap,
    _fnBindAction: _fnBindAction,
    _fnCallbackReg: _fnCallbackReg,
    _fnCallbackFire: _fnCallbackFire,
    _fnLengthOverflow: _fnLengthOverflow,
    _fnRenderer: _fnRenderer,
    _fnDataSource: _fnDataSource,
    _fnRowAttributes: _fnRowAttributes,
    _fnExtend: _fnExtend,
    _fnCalculateEnd: function () {} // Used by a lot of plug-ins, but redundant
                                    // in 1.10, so this dead-end function is
                                    // added to prevent errors
  } );


  // jQuery access
  $.fn.dataTable = DataTable;

  // Provide access to the host jQuery object (circular reference)
  DataTable.$ = $;

  // Legacy aliases
  $.fn.dataTableSettings = DataTable.settings;
  $.fn.dataTableExt = DataTable.ext;

  // With a capital `D` we return a DataTables API instance rather than a
  // jQuery object
  $.fn.DataTable = function ( opts ) {
    return $(this).dataTable( opts ).api();
  };

  // All properties that are available to $.fn.dataTable should also be
  // available on $.fn.DataTable
  $.each( DataTable, function ( prop, val ) {
    $.fn.DataTable[ prop ] = val;
  } );

  return DataTable;
}));
;
/**
 * @file
 * JQuery listener for tables with the nir-datatables class.
 *
 * Tables found will then be a DataTables instance.
 */

(function ($, Drupal) {
  'use strict';
  Drupal.behaviors.datatables = {
    attach: function (context, settings) {
      if (Drupal.panels_ipe) {
        if (Drupal.panels_ipe.app && context != document && context.id != 'panels-ipe-content') {
          $(context).find('table.nir-datatables').once('nir-datatables').each(function () {
            $(this).DataTable();
          });
        }
      }
      if(settings.panelizer && settings.panelizer.entity){
        $(context).find('table.nir-datatables').once('nir-datatables').each(function () {
            $("table.nir-datatables").DataTable();
        });
      }
      if (context == document && !settings.panelizer) {
        $("table.nir-datatables").DataTable();
      }
    }
  }
})(jQuery, Drupal)
;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, Drupal) {
  Drupal.theme.progressBar = function (id) {
    return "<div id=\"".concat(id, "\" class=\"progress\" aria-live=\"polite\">") + '<div class="progress__label">&nbsp;</div>' + '<div class="progress__track"><div class="progress__bar"></div></div>' + '<div class="progress__percentage"></div>' + '<div class="progress__description">&nbsp;</div>' + '</div>';
  };

  Drupal.ProgressBar = function (id, updateCallback, method, errorCallback) {
    this.id = id;
    this.method = method || 'GET';
    this.updateCallback = updateCallback;
    this.errorCallback = errorCallback;
    this.element = $(Drupal.theme('progressBar', id));
  };

  $.extend(Drupal.ProgressBar.prototype, {
    setProgress: function setProgress(percentage, message, label) {
      if (percentage >= 0 && percentage <= 100) {
        $(this.element).find('div.progress__bar').css('width', "".concat(percentage, "%"));
        $(this.element).find('div.progress__percentage').html("".concat(percentage, "%"));
      }

      $('div.progress__description', this.element).html(message);
      $('div.progress__label', this.element).html(label);

      if (this.updateCallback) {
        this.updateCallback(percentage, message, this);
      }
    },
    startMonitoring: function startMonitoring(uri, delay) {
      this.delay = delay;
      this.uri = uri;
      this.sendPing();
    },
    stopMonitoring: function stopMonitoring() {
      clearTimeout(this.timer);
      this.uri = null;
    },
    sendPing: function sendPing() {
      if (this.timer) {
        clearTimeout(this.timer);
      }

      if (this.uri) {
        var pb = this;
        var uri = this.uri;

        if (uri.indexOf('?') === -1) {
          uri += '?';
        } else {
          uri += '&';
        }

        uri += '_format=json';
        $.ajax({
          type: this.method,
          url: uri,
          data: '',
          dataType: 'json',
          success: function success(progress) {
            if (progress.status === 0) {
              pb.displayError(progress.data);
              return;
            }

            pb.setProgress(progress.percentage, progress.message, progress.label);
            pb.timer = setTimeout(function () {
              pb.sendPing();
            }, pb.delay);
          },
          error: function error(xmlhttp) {
            var e = new Drupal.AjaxError(xmlhttp, pb.uri);
            pb.displayError("<pre>".concat(e.message, "</pre>"));
          }
        });
      }
    },
    displayError: function displayError(string) {
      var error = $('<div class="messages messages--error"></div>').html(string);
      $(this.element).before(error).hide();

      if (this.errorCallback) {
        this.errorCallback(this);
      }
    }
  });
})(jQuery, Drupal);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, once) {
  var deprecatedMessageSuffix = "is deprecated in Drupal 9.3.0 and will be removed in Drupal 10.0.0. Use the core/once library instead. See https://www.drupal.org/node/3158256";
  var originalJQOnce = $.fn.once;
  var originalJQRemoveOnce = $.fn.removeOnce;

  $.fn.once = function jQueryOnce(id) {
    Drupal.deprecationError({
      message: "jQuery.once() ".concat(deprecatedMessageSuffix)
    });
    return originalJQOnce.apply(this, [id]);
  };

  $.fn.removeOnce = function jQueryRemoveOnce(id) {
    Drupal.deprecationError({
      message: "jQuery.removeOnce() ".concat(deprecatedMessageSuffix)
    });
    return originalJQRemoveOnce.apply(this, [id]);
  };

  var drupalOnce = once;

  function augmentedOnce(id, selector, context) {
    originalJQOnce.apply($(selector, context), [id]);
    return drupalOnce(id, selector, context);
  }

  function remove(id, selector, context) {
    originalJQRemoveOnce.apply($(selector, context), [id]);
    return drupalOnce.remove(id, selector, context);
  }

  window.once = Object.assign(augmentedOnce, drupalOnce, {
    remove: remove
  });
})(jQuery, once);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function (Drupal) {
  Drupal.behaviors.responsiveImageAJAX = {
    attach: function attach() {
      if (window.picturefill) {
        window.picturefill();
      }
    }
  };
})(Drupal);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

(function ($, window, Drupal, drupalSettings, _ref) {
  var isFocusable = _ref.isFocusable,
      tabbable = _ref.tabbable;
  Drupal.behaviors.AJAX = {
    attach: function attach(context, settings) {
      function loadAjaxBehavior(base) {
        var elementSettings = settings.ajax[base];

        if (typeof elementSettings.selector === 'undefined') {
          elementSettings.selector = "#".concat(base);
        }

        once('drupal-ajax', $(elementSettings.selector)).forEach(function (el) {
          elementSettings.element = el;
          elementSettings.base = base;
          Drupal.ajax(elementSettings);
        });
      }

      Object.keys(settings.ajax || {}).forEach(function (base) {
        return loadAjaxBehavior(base);
      });
      Drupal.ajax.bindAjaxLinks(document.body);
      once('ajax', '.use-ajax-submit').forEach(function (el) {
        var elementSettings = {};
        elementSettings.url = $(el.form).attr('action');
        elementSettings.setClick = true;
        elementSettings.event = 'click';
        elementSettings.progress = {
          type: 'throbber'
        };
        elementSettings.base = el.id;
        elementSettings.element = el;
        Drupal.ajax(elementSettings);
      });
    },
    detach: function detach(context, settings, trigger) {
      if (trigger === 'unload') {
        Drupal.ajax.expired().forEach(function (instance) {
          Drupal.ajax.instances[instance.instanceIndex] = null;
        });
      }
    }
  };

  Drupal.AjaxError = function (xmlhttp, uri, customMessage) {
    var statusCode;
    var statusText;
    var responseText;

    if (xmlhttp.status) {
      statusCode = "\n".concat(Drupal.t('An AJAX HTTP error occurred.'), "\n").concat(Drupal.t('HTTP Result Code: !status', {
        '!status': xmlhttp.status
      }));
    } else {
      statusCode = "\n".concat(Drupal.t('An AJAX HTTP request terminated abnormally.'));
    }

    statusCode += "\n".concat(Drupal.t('Debugging information follows.'));
    var pathText = "\n".concat(Drupal.t('Path: !uri', {
      '!uri': uri
    }));
    statusText = '';

    try {
      statusText = "\n".concat(Drupal.t('StatusText: !statusText', {
        '!statusText': xmlhttp.statusText.trim()
      }));
    } catch (e) {}

    responseText = '';

    try {
      responseText = "\n".concat(Drupal.t('ResponseText: !responseText', {
        '!responseText': xmlhttp.responseText.trim()
      }));
    } catch (e) {}

    responseText = responseText.replace(/<("[^"]*"|'[^']*'|[^'">])*>/gi, '');
    responseText = responseText.replace(/[\n]+\s+/g, '\n');
    var readyStateText = xmlhttp.status === 0 ? "\n".concat(Drupal.t('ReadyState: !readyState', {
      '!readyState': xmlhttp.readyState
    })) : '';
    customMessage = customMessage ? "\n".concat(Drupal.t('CustomMessage: !customMessage', {
      '!customMessage': customMessage
    })) : '';
    this.message = statusCode + pathText + statusText + customMessage + responseText + readyStateText;
    this.name = 'AjaxError';
  };

  Drupal.AjaxError.prototype = new Error();
  Drupal.AjaxError.prototype.constructor = Drupal.AjaxError;

  Drupal.ajax = function (settings) {
    if (arguments.length !== 1) {
      throw new Error('Drupal.ajax() function must be called with one configuration object only');
    }

    var base = settings.base || false;
    var element = settings.element || false;
    delete settings.base;
    delete settings.element;

    if (!settings.progress && !element) {
      settings.progress = false;
    }

    var ajax = new Drupal.Ajax(base, element, settings);
    ajax.instanceIndex = Drupal.ajax.instances.length;
    Drupal.ajax.instances.push(ajax);
    return ajax;
  };

  Drupal.ajax.instances = [];

  Drupal.ajax.expired = function () {
    return Drupal.ajax.instances.filter(function (instance) {
      return instance
        && instance.element !== false
        && instance.element instanceof HTMLElement
        && !document.body.contains(instance.element);
    });
  };

  Drupal.ajax.bindAjaxLinks = function (element) {
    once('ajax', '.use-ajax', element).forEach(function (ajaxLink) {
      var $linkElement = $(ajaxLink);
      var elementSettings = {
        progress: {
          type: 'throbber'
        },
        dialogType: $linkElement.data('dialog-type'),
        dialog: $linkElement.data('dialog-options'),
        dialogRenderer: $linkElement.data('dialog-renderer'),
        base: $linkElement.attr('id'),
        element: ajaxLink
      };
      var href = $linkElement.attr('href');

      if (href) {
        elementSettings.url = href;
        elementSettings.event = 'click';
      }

      Drupal.ajax(elementSettings);
    });
  };

  Drupal.Ajax = function (base, element, elementSettings) {
    var defaults = {
      event: element ? 'mousedown' : null,
      keypress: true,
      selector: base ? "#".concat(base) : null,
      effect: 'none',
      speed: 'none',
      method: 'replaceWith',
      progress: {
        type: 'throbber',
        message: Drupal.t('Please wait...')
      },
      submit: {
        js: true
      }
    };
    $.extend(this, defaults, elementSettings);
    this.commands = new Drupal.AjaxCommands();
    this.instanceIndex = false;

    if (this.wrapper) {
      this.wrapper = "#".concat(this.wrapper);
    }

    this.element = element;
    this.element_settings = elementSettings;
    this.elementSettings = elementSettings;

    if (this.element && this.element.form) {
      this.$form = $(this.element.form);
    }

    if (!this.url) {
      var $element = $(this.element);

      if ($element.is('a')) {
        this.url = $element.attr('href');
      } else if (this.element && element.form) {
        this.url = this.$form.attr('action');
      }
    }

    var originalUrl = this.url;
    this.url = this.url.replace(/\/nojs(\/|$|\?|#)/, '/ajax$1');

    if (drupalSettings.ajaxTrustedUrl[originalUrl]) {
      drupalSettings.ajaxTrustedUrl[this.url] = true;
    }

    var ajax = this;
    ajax.options = {
      url: ajax.url,
      data: ajax.submit,
      beforeSerialize: function beforeSerialize(elementSettings, options) {
        return ajax.beforeSerialize(elementSettings, options);
      },
      beforeSubmit: function beforeSubmit(formValues, elementSettings, options) {
        ajax.ajaxing = true;
        return ajax.beforeSubmit(formValues, elementSettings, options);
      },
      beforeSend: function beforeSend(xmlhttprequest, options) {
        ajax.ajaxing = true;
        return ajax.beforeSend(xmlhttprequest, options);
      },
      success: function success(response, status, xmlhttprequest) {
        if (typeof response === 'string') {
          response = $.parseJSON(response);
        }

        if (response !== null && !drupalSettings.ajaxTrustedUrl[ajax.url]) {
          if (xmlhttprequest.getResponseHeader('X-Drupal-Ajax-Token') !== '1') {
            var customMessage = Drupal.t('The response failed verification so will not be processed.');
            return ajax.error(xmlhttprequest, ajax.url, customMessage);
          }
        }

        return ajax.success(response, status);
      },
      complete: function complete(xmlhttprequest, status) {
        ajax.ajaxing = false;

        if (status === 'error' || status === 'parsererror') {
          return ajax.error(xmlhttprequest, ajax.url);
        }
      },
      dataType: 'json',
      jsonp: false,
      type: typeof ajax.type !== 'undefined' ? ajax.type : 'POST'
    };

    if (elementSettings.dialog) {
      ajax.options.data.dialogOptions = elementSettings.dialog;
    }

    if (ajax.options.url.indexOf('?') === -1) {
      ajax.options.url += '?';
    } else {
      ajax.options.url += '&';
    }

    var wrapper = "drupal_".concat(elementSettings.dialogType || 'ajax');

    if (elementSettings.dialogRenderer) {
      wrapper += ".".concat(elementSettings.dialogRenderer);
    }

    ajax.options.url += "".concat(Drupal.ajax.WRAPPER_FORMAT, "=").concat(wrapper);
    $(ajax.element).on(elementSettings.event, function (event) {
      if (!drupalSettings.ajaxTrustedUrl[ajax.url] && !Drupal.url.isLocal(ajax.url)) {
        throw new Error(Drupal.t('The callback URL is not local and not trusted: !url', {
          '!url': ajax.url
        }));
      }

      return ajax.eventResponse(this, event);
    });

    if (elementSettings.keypress) {
      $(ajax.element).on('keypress', function (event) {
        return ajax.keypressResponse(this, event);
      });
    }

    if (elementSettings.prevent) {
      $(ajax.element).on(elementSettings.prevent, false);
    }
  };

  Drupal.ajax.WRAPPER_FORMAT = '_wrapper_format';
  Drupal.Ajax.AJAX_REQUEST_PARAMETER = '_drupal_ajax';

  Drupal.Ajax.prototype.execute = function () {
    if (this.ajaxing) {
      return;
    }

    try {
      this.beforeSerialize(this.element, this.options);
      return $.ajax(this.options);
    } catch (e) {
      this.ajaxing = false;
      window.alert("An error occurred while attempting to process ".concat(this.options.url, ": ").concat(e.message));
      return $.Deferred().reject();
    }
  };

  Drupal.Ajax.prototype.keypressResponse = function (element, event) {
    var ajax = this;

    if (event.which === 13 || event.which === 32 && element.type !== 'text' && element.type !== 'textarea' && element.type !== 'tel' && element.type !== 'number') {
      event.preventDefault();
      event.stopPropagation();
      $(element).trigger(ajax.elementSettings.event);
    }
  };

  Drupal.Ajax.prototype.eventResponse = function (element, event) {
    event.preventDefault();
    event.stopPropagation();
    var ajax = this;

    if (ajax.ajaxing) {
      return;
    }

    try {
      if (ajax.$form) {
        if (ajax.setClick) {
          element.form.clk = element;
        }

        ajax.$form.ajaxSubmit(ajax.options);
      } else {
        ajax.beforeSerialize(ajax.element, ajax.options);
        $.ajax(ajax.options);
      }
    } catch (e) {
      ajax.ajaxing = false;
      window.alert("An error occurred while attempting to process ".concat(ajax.options.url, ": ").concat(e.message));
    }
  };

  Drupal.Ajax.prototype.beforeSerialize = function (element, options) {
    if (this.$form && document.body.contains(this.$form.get(0))) {
      var settings = this.settings || drupalSettings;
      Drupal.detachBehaviors(this.$form.get(0), settings, 'serialize');
    }

    options.data[Drupal.Ajax.AJAX_REQUEST_PARAMETER] = 1;
    var pageState = drupalSettings.ajaxPageState;
    options.data['ajax_page_state[theme]'] = pageState.theme;
    options.data['ajax_page_state[theme_token]'] = pageState.theme_token;
    options.data['ajax_page_state[libraries]'] = pageState.libraries;
  };

  Drupal.Ajax.prototype.beforeSubmit = function (formValues, element, options) {};

  Drupal.Ajax.prototype.beforeSend = function (xmlhttprequest, options) {
    if (this.$form) {
      options.extraData = options.extraData || {};
      options.extraData.ajax_iframe_upload = '1';
      var v = $.fieldValue(this.element);

      if (v !== null) {
        options.extraData[this.element.name] = v;
      }
    }

    $(this.element).prop('disabled', true);

    if (!this.progress || !this.progress.type) {
      return;
    }

    var progressIndicatorMethod = "setProgressIndicator".concat(this.progress.type.slice(0, 1).toUpperCase()).concat(this.progress.type.slice(1).toLowerCase());

    if (progressIndicatorMethod in this && typeof this[progressIndicatorMethod] === 'function') {
      this[progressIndicatorMethod].call(this);
    }
  };

  Drupal.theme.ajaxProgressThrobber = function (message) {
    var messageMarkup = typeof message === 'string' ? Drupal.theme('ajaxProgressMessage', message) : '';
    var throbber = '<div class="throbber">&nbsp;</div>';
    return "<div class=\"ajax-progress ajax-progress-throbber\">".concat(throbber).concat(messageMarkup, "</div>");
  };

  Drupal.theme.ajaxProgressIndicatorFullscreen = function () {
    return '<div class="ajax-progress ajax-progress-fullscreen">&nbsp;</div>';
  };

  Drupal.theme.ajaxProgressMessage = function (message) {
    return "<div class=\"message\">".concat(message, "</div>");
  };

  Drupal.theme.ajaxProgressBar = function ($element) {
    return $('<div class="ajax-progress ajax-progress-bar"></div>').append($element);
  };

  Drupal.Ajax.prototype.setProgressIndicatorBar = function () {
    var progressBar = new Drupal.ProgressBar("ajax-progress-".concat(this.element.id), $.noop, this.progress.method, $.noop);

    if (this.progress.message) {
      progressBar.setProgress(-1, this.progress.message);
    }

    if (this.progress.url) {
      progressBar.startMonitoring(this.progress.url, this.progress.interval || 1500);
    }

    this.progress.element = $(Drupal.theme('ajaxProgressBar', progressBar.element));
    this.progress.object = progressBar;
    $(this.element).after(this.progress.element);
  };

  Drupal.Ajax.prototype.setProgressIndicatorThrobber = function () {
    this.progress.element = $(Drupal.theme('ajaxProgressThrobber', this.progress.message));
    $(this.element).after(this.progress.element);
  };

  Drupal.Ajax.prototype.setProgressIndicatorFullscreen = function () {
    this.progress.element = $(Drupal.theme('ajaxProgressIndicatorFullscreen'));
    $('body').append(this.progress.element);
  };

  Drupal.Ajax.prototype.success = function (response, status) {
    var _this = this;

    if (this.progress.element) {
      $(this.progress.element).remove();
    }

    if (this.progress.object) {
      this.progress.object.stopMonitoring();
    }

    $(this.element).prop('disabled', false);
    var elementParents = $(this.element).parents('[data-drupal-selector]').addBack().toArray();
    var focusChanged = false;
    Object.keys(response || {}).forEach(function (i) {
      if (response[i].command && _this.commands[response[i].command]) {
        _this.commands[response[i].command](_this, response[i], status);

        if (response[i].command === 'invoke' && response[i].method === 'focus' || response[i].command === 'focusFirst') {
          focusChanged = true;
        }
      }
    });

    if (!focusChanged && this.element && !$(this.element).data('disable-refocus')) {
      var target = false;

      for (var n = elementParents.length - 1; !target && n >= 0; n--) {
        target = document.querySelector("[data-drupal-selector=\"".concat(elementParents[n].getAttribute('data-drupal-selector'), "\"]"));
      }

      if (target) {
        $(target).trigger('focus');
      }
    }

    if (this.$form && document.body.contains(this.$form.get(0))) {
      var settings = this.settings || drupalSettings;
      Drupal.attachBehaviors(this.$form.get(0), settings);
    }

    this.settings = null;
  };

  Drupal.Ajax.prototype.getEffect = function (response) {
    var type = response.effect || this.effect;
    var speed = response.speed || this.speed;
    var effect = {};

    if (type === 'none') {
      effect.showEffect = 'show';
      effect.hideEffect = 'hide';
      effect.showSpeed = '';
    } else if (type === 'fade') {
      effect.showEffect = 'fadeIn';
      effect.hideEffect = 'fadeOut';
      effect.showSpeed = speed;
    } else {
      effect.showEffect = "".concat(type, "Toggle");
      effect.hideEffect = "".concat(type, "Toggle");
      effect.showSpeed = speed;
    }

    return effect;
  };

  Drupal.Ajax.prototype.error = function (xmlhttprequest, uri, customMessage) {
    if (this.progress.element) {
      $(this.progress.element).remove();
    }

    if (this.progress.object) {
      this.progress.object.stopMonitoring();
    }

    $(this.wrapper).show();
    $(this.element).prop('disabled', false);

    if (this.$form && document.body.contains(this.$form.get(0))) {
      var settings = this.settings || drupalSettings;
      Drupal.attachBehaviors(this.$form.get(0), settings);
    }

    throw new Drupal.AjaxError(xmlhttprequest, uri, customMessage);
  };

  Drupal.theme.ajaxWrapperNewContent = function ($newContent, ajax, response) {
    return (response.effect || ajax.effect) !== 'none' && $newContent.filter(function (i) {
      return !($newContent[i].nodeName === '#comment' || $newContent[i].nodeName === '#text' && /^(\s|\n|\r)*$/.test($newContent[i].textContent));
    }).length > 1 ? Drupal.theme('ajaxWrapperMultipleRootElements', $newContent) : $newContent;
  };

  Drupal.theme.ajaxWrapperMultipleRootElements = function ($elements) {
    return $('<div></div>').append($elements);
  };

  Drupal.AjaxCommands = function () {};

  Drupal.AjaxCommands.prototype = {
    insert: function insert(ajax, response) {
      var $wrapper = response.selector ? $(response.selector) : $(ajax.wrapper);
      var method = response.method || ajax.method;
      var effect = ajax.getEffect(response);
      var settings = response.settings || ajax.settings || drupalSettings;
      var $newContent = $($.parseHTML(response.data, document, true));
      $newContent = Drupal.theme('ajaxWrapperNewContent', $newContent, ajax, response);

      switch (method) {
        case 'html':
        case 'replaceWith':
        case 'replaceAll':
        case 'empty':
        case 'remove':
          Drupal.detachBehaviors($wrapper.get(0), settings);
          break;

        default:
          break;
      }

      $wrapper[method]($newContent);

      if (effect.showEffect !== 'show') {
        $newContent.hide();
      }

      var $ajaxNewContent = $newContent.find('.ajax-new-content');

      if ($ajaxNewContent.length) {
        $ajaxNewContent.hide();
        $newContent.show();
        $ajaxNewContent[effect.showEffect](effect.showSpeed);
      } else if (effect.showEffect !== 'show') {
        $newContent[effect.showEffect](effect.showSpeed);
      }

      if ($newContent.parents('html').length) {
        $newContent.each(function (index, element) {
          if (element.nodeType === Node.ELEMENT_NODE) {
            Drupal.attachBehaviors(element, settings);
          }
        });
      }
    },
    remove: function remove(ajax, response, status) {
      var settings = response.settings || ajax.settings || drupalSettings;
      $(response.selector).each(function () {
        Drupal.detachBehaviors(this, settings);
      }).remove();
    },
    changed: function changed(ajax, response, status) {
      var $element = $(response.selector);

      if (!$element.hasClass('ajax-changed')) {
        $element.addClass('ajax-changed');

        if (response.asterisk) {
          $element.find(response.asterisk).append(" <abbr class=\"ajax-changed\" title=\"".concat(Drupal.t('Changed'), "\">*</abbr> "));
        }
      }
    },
    alert: function alert(ajax, response, status) {
      window.alert(response.text);
    },
    announce: function announce(ajax, response) {
      if (response.priority) {
        Drupal.announce(response.text, response.priority);
      } else {
        Drupal.announce(response.text);
      }
    },
    redirect: function redirect(ajax, response, status) {
      window.location = response.url;
    },
    css: function css(ajax, response, status) {
      $(response.selector).css(response.argument);
    },
    settings: function settings(ajax, response, status) {
      var ajaxSettings = drupalSettings.ajax;

      if (ajaxSettings) {
        Drupal.ajax.expired().forEach(function (instance) {
          if (instance.selector) {
            var selector = instance.selector.replace('#', '');

            if (selector in ajaxSettings) {
              delete ajaxSettings[selector];
            }
          }
        });
      }

      if (response.merge) {
        $.extend(true, drupalSettings, response.settings);
      } else {
        ajax.settings = response.settings;
      }
    },
    data: function data(ajax, response, status) {
      $(response.selector).data(response.name, response.value);
    },
    focusFirst: function focusFirst(ajax, response, status) {
      var focusChanged = false;
      var container = document.querySelector(response.selector);

      if (container) {
        var tabbableElements = tabbable(container);

        if (tabbableElements.length) {
          tabbableElements[0].focus();
          focusChanged = true;
        } else if (isFocusable(container)) {
          container.focus();
          focusChanged = true;
        }
      }

      if (ajax.hasOwnProperty('element') && !focusChanged) {
        ajax.element.focus();
      }
    },
    invoke: function invoke(ajax, response, status) {
      var $element = $(response.selector);
      $element[response.method].apply($element, _toConsumableArray(response.args));
    },
    restripe: function restripe(ajax, response, status) {
      $(response.selector).find('> tbody > tr:visible, > tr:visible').removeClass('odd even').filter(':even').addClass('odd').end().filter(':odd').addClass('even');
    },
    update_build_id: function update_build_id(ajax, response, status) {
      $("input[name=\"form_build_id\"][value=\"".concat(response.old, "\"]")).val(response.new);
    },
    add_css: function add_css(ajax, response, status) {
      $('head').prepend(response.data);
    },
    message: function message(ajax, response) {
      var messages = new Drupal.Message(document.querySelector(response.messageWrapperQuerySelector));

      if (response.clearPrevious) {
        messages.clear();
      }

      messages.add(response.message, response.messageOptions);
    }
  };
})(jQuery, window, Drupal, drupalSettings, window.tabbable);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

Drupal.debounce = function (func, wait, immediate) {
  var timeout;
  var result;
  return function () {
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    var context = this;

    var later = function later() {
      timeout = null;

      if (!immediate) {
        result = func.apply(context, args);
      }
    };

    var callNow = immediate && !timeout;
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);

    if (callNow) {
      result = func.apply(context, args);
    }

    return result;
  };
};;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, Drupal, debounce) {
  var offsets = {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0
  };

  function getRawOffset(el, edge) {
    var $el = $(el);
    var documentElement = document.documentElement;
    var displacement = 0;
    var horizontal = edge === 'left' || edge === 'right';
    var placement = $el.offset()[horizontal ? 'left' : 'top'];
    placement -= window["scroll".concat(horizontal ? 'X' : 'Y')] || document.documentElement["scroll".concat(horizontal ? 'Left' : 'Top')] || 0;

    switch (edge) {
      case 'top':
        displacement = placement + $el.outerHeight();
        break;

      case 'left':
        displacement = placement + $el.outerWidth();
        break;

      case 'bottom':
        displacement = documentElement.clientHeight - placement;
        break;

      case 'right':
        displacement = documentElement.clientWidth - placement;
        break;

      default:
        displacement = 0;
    }

    return displacement;
  }

  function calculateOffset(edge) {
    var edgeOffset = 0;
    var displacingElements = document.querySelectorAll("[data-offset-".concat(edge, "]"));
    var n = displacingElements.length;

    for (var i = 0; i < n; i++) {
      var el = displacingElements[i];

      if (el.style.display === 'none') {
        continue;
      }

      var displacement = parseInt(el.getAttribute("data-offset-".concat(edge)), 10);

      if (isNaN(displacement)) {
        displacement = getRawOffset(el, edge);
      }

      edgeOffset = Math.max(edgeOffset, displacement);
    }

    return edgeOffset;
  }

  function calculateOffsets() {
    return {
      top: calculateOffset('top'),
      right: calculateOffset('right'),
      bottom: calculateOffset('bottom'),
      left: calculateOffset('left')
    };
  }

  function displace(broadcast) {
    offsets = calculateOffsets();
    Drupal.displace.offsets = offsets;

    if (typeof broadcast === 'undefined' || broadcast) {
      $(document).trigger('drupalViewportOffsetChange', offsets);
    }

    return offsets;
  }

  Drupal.behaviors.drupalDisplace = {
    attach: function attach() {
      if (this.displaceProcessed) {
        return;
      }

      this.displaceProcessed = true;
      $(window).on('resize.drupalDisplace', debounce(displace, 200));
    }
  };
  Drupal.displace = displace;
  $.extend(Drupal.displace, {
    offsets: offsets,
    calculateOffset: calculateOffset
  });
})(jQuery, Drupal, Drupal.debounce);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, Drupal, _ref) {
  var isTabbable = _ref.isTabbable;
  $.extend($.expr[':'], {
    tabbable: function tabbable(element) {
      Drupal.deprecationError({
        message: 'The :tabbable selector is deprecated in Drupal 9.2.0 and will be removed in Drupal 10.0.0. Use the core/tabbable library instead. See https://www.drupal.org/node/3183730'
      });

      if (element.tagName === 'SUMMARY' || element.tagName === 'DETAILS') {
        var tabIndex = element.getAttribute('tabIndex');

        if (tabIndex === null || tabIndex < 0) {
          return false;
        }
      }

      return isTabbable(element);
    }
  });
})(jQuery, Drupal, window.tabbable);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($) {
  var cachedScrollbarWidth = null;
  var max = Math.max,
      abs = Math.abs;
  var regexHorizontal = /left|center|right/;
  var regexVertical = /top|center|bottom/;
  var regexOffset = /[+-]\d+(\.[\d]+)?%?/;
  var regexPosition = /^\w+/;
  var regexPercent = /%$/;
  var _position = $.fn.position;

  function getOffsets(offsets, width, height) {
    return [parseFloat(offsets[0]) * (regexPercent.test(offsets[0]) ? width / 100 : 1), parseFloat(offsets[1]) * (regexPercent.test(offsets[1]) ? height / 100 : 1)];
  }

  function parseCss(element, property) {
    return parseInt($.css(element, property), 10) || 0;
  }

  function getDimensions(elem) {
    var raw = elem[0];

    if (raw.nodeType === 9) {
      return {
        width: elem.width(),
        height: elem.height(),
        offset: {
          top: 0,
          left: 0
        }
      };
    }

    if ($.isWindow(raw)) {
      return {
        width: elem.width(),
        height: elem.height(),
        offset: {
          top: elem.scrollTop(),
          left: elem.scrollLeft()
        }
      };
    }

    if (raw.preventDefault) {
      return {
        width: 0,
        height: 0,
        offset: {
          top: raw.pageY,
          left: raw.pageX
        }
      };
    }

    return {
      width: elem.outerWidth(),
      height: elem.outerHeight(),
      offset: elem.offset()
    };
  }

  var collisions = {
    fit: {
      left: function left(position, data) {
        var within = data.within;
        var withinOffset = within.isWindow ? within.scrollLeft : within.offset.left;
        var outerWidth = within.width;
        var collisionPosLeft = position.left - data.collisionPosition.marginLeft;
        var overLeft = withinOffset - collisionPosLeft;
        var overRight = collisionPosLeft + data.collisionWidth - outerWidth - withinOffset;
        var newOverRight;

        if (data.collisionWidth > outerWidth) {
          if (overLeft > 0 && overRight <= 0) {
            newOverRight = position.left + overLeft + data.collisionWidth - outerWidth - withinOffset;
            position.left += overLeft - newOverRight;
          } else if (overRight > 0 && overLeft <= 0) {
            position.left = withinOffset;
          } else if (overLeft > overRight) {
            position.left = withinOffset + outerWidth - data.collisionWidth;
          } else {
            position.left = withinOffset;
          }
        } else if (overLeft > 0) {
          position.left += overLeft;
        } else if (overRight > 0) {
          position.left -= overRight;
        } else {
          position.left = max(position.left - collisionPosLeft, position.left);
        }
      },
      top: function top(position, data) {
        var within = data.within;
        var withinOffset = within.isWindow ? within.scrollTop : within.offset.top;
        var outerHeight = data.within.height;
        var collisionPosTop = position.top - data.collisionPosition.marginTop;
        var overTop = withinOffset - collisionPosTop;
        var overBottom = collisionPosTop + data.collisionHeight - outerHeight - withinOffset;
        var newOverBottom;

        if (data.collisionHeight > outerHeight) {
          if (overTop > 0 && overBottom <= 0) {
            newOverBottom = position.top + overTop + data.collisionHeight - outerHeight - withinOffset;
            position.top += overTop - newOverBottom;
          } else if (overBottom > 0 && overTop <= 0) {
            position.top = withinOffset;
          } else if (overTop > overBottom) {
            position.top = withinOffset + outerHeight - data.collisionHeight;
          } else {
            position.top = withinOffset;
          }
        } else if (overTop > 0) {
          position.top += overTop;
        } else if (overBottom > 0) {
          position.top -= overBottom;
        } else {
          position.top = max(position.top - collisionPosTop, position.top);
        }
      }
    },
    flip: {
      left: function left(position, data) {
        var within = data.within;
        var withinOffset = within.offset.left + within.scrollLeft;
        var outerWidth = within.width;
        var offsetLeft = within.isWindow ? within.scrollLeft : within.offset.left;
        var collisionPosLeft = position.left - data.collisionPosition.marginLeft;
        var overLeft = collisionPosLeft - offsetLeft;
        var overRight = collisionPosLeft + data.collisionWidth - outerWidth - offsetLeft;
        var myOffset = data.my[0] === 'left' ? -data.elemWidth : data.my[0] === 'right' ? data.elemWidth : 0;
        var atOffset = data.at[0] === 'left' ? data.targetWidth : data.at[0] === 'right' ? -data.targetWidth : 0;
        var offset = -2 * data.offset[0];
        var newOverRight;
        var newOverLeft;

        if (overLeft < 0) {
          newOverRight = position.left + myOffset + atOffset + offset + data.collisionWidth - outerWidth - withinOffset;

          if (newOverRight < 0 || newOverRight < abs(overLeft)) {
            position.left += myOffset + atOffset + offset;
          }
        } else if (overRight > 0) {
          newOverLeft = position.left - data.collisionPosition.marginLeft + myOffset + atOffset + offset - offsetLeft;

          if (newOverLeft > 0 || abs(newOverLeft) < overRight) {
            position.left += myOffset + atOffset + offset;
          }
        }
      },
      top: function top(position, data) {
        var within = data.within;
        var withinOffset = within.offset.top + within.scrollTop;
        var outerHeight = within.height;
        var offsetTop = within.isWindow ? within.scrollTop : within.offset.top;
        var collisionPosTop = position.top - data.collisionPosition.marginTop;
        var overTop = collisionPosTop - offsetTop;
        var overBottom = collisionPosTop + data.collisionHeight - outerHeight - offsetTop;
        var top = data.my[1] === 'top';
        var myOffset = top ? -data.elemHeight : data.my[1] === 'bottom' ? data.elemHeight : 0;
        var atOffset = data.at[1] === 'top' ? data.targetHeight : data.at[1] === 'bottom' ? -data.targetHeight : 0;
        var offset = -2 * data.offset[1];
        var newOverTop;
        var newOverBottom;

        if (overTop < 0) {
          newOverBottom = position.top + myOffset + atOffset + offset + data.collisionHeight - outerHeight - withinOffset;

          if (newOverBottom < 0 || newOverBottom < abs(overTop)) {
            position.top += myOffset + atOffset + offset;
          }
        } else if (overBottom > 0) {
          newOverTop = position.top - data.collisionPosition.marginTop + myOffset + atOffset + offset - offsetTop;

          if (newOverTop > 0 || abs(newOverTop) < overBottom) {
            position.top += myOffset + atOffset + offset;
          }
        }
      }
    },
    flipfit: {
      left: function left() {
        for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
          args[_key] = arguments[_key];
        }

        collisions.flip.left.apply(this, args);
        collisions.fit.left.apply(this, args);
      },
      top: function top() {
        for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
          args[_key2] = arguments[_key2];
        }

        collisions.flip.top.apply(this, args);
        collisions.fit.top.apply(this, args);
      }
    }
  };
  $.position = {
    scrollbarWidth: function scrollbarWidth() {
      if (cachedScrollbarWidth !== undefined) {
        return cachedScrollbarWidth;
      }

      var div = $('<div ' + "style='display:block;position:absolute;width:50px;height:50px;overflow:hidden;'>" + "<div style='height:100px;width:auto;'></div></div>");
      var innerDiv = div.children()[0];
      $('body').append(div);
      var w1 = innerDiv.offsetWidth;
      div.css('overflow', 'scroll');
      var w2 = innerDiv.offsetWidth;

      if (w1 === w2) {
        w2 = div[0].clientWidth;
      }

      div.remove();
      cachedScrollbarWidth = w1 - w2;
      return cachedScrollbarWidth;
    },
    getScrollInfo: function getScrollInfo(within) {
      var overflowX = within.isWindow || within.isDocument ? '' : within.element.css('overflow-x');
      var overflowY = within.isWindow || within.isDocument ? '' : within.element.css('overflow-y');
      var hasOverflowX = overflowX === 'scroll' || overflowX === 'auto' && within.width < within.element[0].scrollWidth;
      var hasOverflowY = overflowY === 'scroll' || overflowY === 'auto' && within.height < within.element[0].scrollHeight;
      return {
        width: hasOverflowY ? $.position.scrollbarWidth() : 0,
        height: hasOverflowX ? $.position.scrollbarWidth() : 0
      };
    },
    getWithinInfo: function getWithinInfo(element) {
      var withinElement = $(element || window);
      var isWindow = $.isWindow(withinElement[0]);
      var isDocument = !!withinElement[0] && withinElement[0].nodeType === 9;
      var hasOffset = !isWindow && !isDocument;
      return {
        element: withinElement,
        isWindow: isWindow,
        isDocument: isDocument,
        offset: hasOffset ? $(element).offset() : {
          left: 0,
          top: 0
        },
        scrollLeft: withinElement.scrollLeft(),
        scrollTop: withinElement.scrollTop(),
        width: withinElement.outerWidth(),
        height: withinElement.outerHeight()
      };
    }
  };

  $.fn.position = function (options) {
    if (!options || !options.of) {
      return _position.apply(this, arguments);
    }

    options = $.extend({}, options);
    var within = $.position.getWithinInfo(options.within);
    var scrollInfo = $.position.getScrollInfo(within);
    var collision = (options.collision || 'flip').split(' ');
    var offsets = {};
    var target = typeof options.of === 'string' ? $(document).find(options.of) : $(options.of);
    var dimensions = getDimensions(target);
    var targetWidth = dimensions.width;
    var targetHeight = dimensions.height;
    var targetOffset = dimensions.offset;

    if (target[0].preventDefault) {
      options.at = 'left top';
    }

    var basePosition = $.extend({}, targetOffset);
    $.each(['my', 'at'], function () {
      var pos = (options[this] || '').split(' ');

      if (pos.length === 1) {
        pos = regexHorizontal.test(pos[0]) ? pos.concat(['center']) : regexVertical.test(pos[0]) ? ['center'].concat(pos) : ['center', 'center'];
      }

      pos[0] = regexHorizontal.test(pos[0]) ? pos[0] : 'center';
      pos[1] = regexVertical.test(pos[1]) ? pos[1] : 'center';
      var horizontalOffset = regexOffset.exec(pos[0]);
      var verticalOffset = regexOffset.exec(pos[1]);
      offsets[this] = [horizontalOffset ? horizontalOffset[0] : 0, verticalOffset ? verticalOffset[0] : 0];
      options[this] = [regexPosition.exec(pos[0])[0], regexPosition.exec(pos[1])[0]];
    });

    if (collision.length === 1) {
      collision[1] = collision[0];
    }

    if (options.at[0] === 'right') {
      basePosition.left += targetWidth;
    } else if (options.at[0] === 'center') {
      basePosition.left += targetWidth / 2;
    }

    if (options.at[1] === 'bottom') {
      basePosition.top += targetHeight;
    } else if (options.at[1] === 'center') {
      basePosition.top += targetHeight / 2;
    }

    var atOffset = getOffsets(offsets.at, targetWidth, targetHeight);
    basePosition.left += atOffset[0];
    basePosition.top += atOffset[1];
    return this.each(function () {
      var using;
      var elem = $(this);
      var elemWidth = elem.outerWidth();
      var elemHeight = elem.outerHeight();
      var marginLeft = parseCss(this, 'marginLeft');
      var marginTop = parseCss(this, 'marginTop');
      var collisionWidth = elemWidth + marginLeft + parseCss(this, 'marginRight') + scrollInfo.width;
      var collisionHeight = elemHeight + marginTop + parseCss(this, 'marginBottom') + scrollInfo.height;
      var position = $.extend({}, basePosition);
      var myOffset = getOffsets(offsets.my, elem.outerWidth(), elem.outerHeight());

      if (options.my[0] === 'right') {
        position.left -= elemWidth;
      } else if (options.my[0] === 'center') {
        position.left -= elemWidth / 2;
      }

      if (options.my[1] === 'bottom') {
        position.top -= elemHeight;
      } else if (options.my[1] === 'center') {
        position.top -= elemHeight / 2;
      }

      position.left += myOffset[0];
      position.top += myOffset[1];
      var collisionPosition = {
        marginLeft: marginLeft,
        marginTop: marginTop
      };
      $.each(['left', 'top'], function (i, dir) {
        if (collisions[collision[i]]) {
          collisions[collision[i]][dir](position, {
            targetWidth: targetWidth,
            targetHeight: targetHeight,
            elemWidth: elemWidth,
            elemHeight: elemHeight,
            collisionPosition: collisionPosition,
            collisionWidth: collisionWidth,
            collisionHeight: collisionHeight,
            offset: [atOffset[0] + myOffset[0], atOffset[1] + myOffset[1]],
            my: options.my,
            at: options.at,
            within: within,
            elem: elem
          });
        }
      });

      if (options.using) {
        using = function using(props) {
          var left = targetOffset.left - position.left;
          var right = left + targetWidth - elemWidth;
          var top = targetOffset.top - position.top;
          var bottom = top + targetHeight - elemHeight;
          var feedback = {
            target: {
              element: target,
              left: targetOffset.left,
              top: targetOffset.top,
              width: targetWidth,
              height: targetHeight
            },
            element: {
              element: elem,
              left: position.left,
              top: position.top,
              width: elemWidth,
              height: elemHeight
            },
            horizontal: right < 0 ? 'left' : left > 0 ? 'right' : 'center',
            vertical: bottom < 0 ? 'top' : top > 0 ? 'bottom' : 'middle'
          };

          if (targetWidth < elemWidth && abs(left + right) < targetWidth) {
            feedback.horizontal = 'center';
          }

          if (targetHeight < elemHeight && abs(top + bottom) < targetHeight) {
            feedback.vertical = 'middle';
          }

          if (max(abs(left), abs(right)) > max(abs(top), abs(bottom))) {
            feedback.important = 'horizontal';
          } else {
            feedback.important = 'vertical';
          }

          options.using.call(this, props, feedback);
        };
      }

      elem.offset($.extend(position, {
        using: using
      }));
    });
  };

  if (!$.hasOwnProperty('ui')) {
    $.ui = {};
  }

  $.ui.position = collisions;
})(jQuery);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, Drupal, drupalSettings) {
  drupalSettings.dialog = {
    autoOpen: true,
    dialogClass: '',
    buttonClass: 'button',
    buttonPrimaryClass: 'button--primary',
    close: function close(event) {
      Drupal.dialog(event.target).close();
      Drupal.detachBehaviors(event.target, null, 'unload');
    }
  };

  Drupal.dialog = function (element, options) {
    var undef;
    var $element = $(element);
    var dialog = {
      open: false,
      returnValue: undef
    };

    function openDialog(settings) {
      settings = $.extend({}, drupalSettings.dialog, options, settings);
      $(window).trigger('dialog:beforecreate', [dialog, $element, settings]);
      $element.dialog(settings);
      dialog.open = true;
      $(window).trigger('dialog:aftercreate', [dialog, $element, settings]);
    }

    function closeDialog(value) {
      $(window).trigger('dialog:beforeclose', [dialog, $element]);
      $element.dialog('close');
      dialog.returnValue = value;
      dialog.open = false;
      $(window).trigger('dialog:afterclose', [dialog, $element]);
    }

    dialog.show = function () {
      openDialog({
        modal: false
      });
    };

    dialog.showModal = function () {
      openDialog({
        modal: true
      });
    };

    dialog.close = closeDialog;
    return dialog;
  };
})(jQuery, Drupal, drupalSettings);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, Drupal, drupalSettings, debounce, displace) {
  drupalSettings.dialog = $.extend({
    autoResize: true,
    maxHeight: '95%'
  }, drupalSettings.dialog);

  function resetPosition(options) {
    var offsets = displace.offsets;
    var left = offsets.left - offsets.right;
    var top = offsets.top - offsets.bottom;
    var leftString = "".concat((left > 0 ? '+' : '-') + Math.abs(Math.round(left / 2)), "px");
    var topString = "".concat((top > 0 ? '+' : '-') + Math.abs(Math.round(top / 2)), "px");
    options.position = {
      my: "center".concat(left !== 0 ? leftString : '', " center").concat(top !== 0 ? topString : ''),
      of: window
    };
    return options;
  }

  function resetSize(event) {
    var positionOptions = ['width', 'height', 'minWidth', 'minHeight', 'maxHeight', 'maxWidth', 'position'];
    var adjustedOptions = {};
    var windowHeight = $(window).height();
    var option;
    var optionValue;
    var adjustedValue;

    for (var n = 0; n < positionOptions.length; n++) {
      option = positionOptions[n];
      optionValue = event.data.settings[option];

      if (optionValue) {
        if (typeof optionValue === 'string' && /%$/.test(optionValue) && /height/i.test(option)) {
          windowHeight -= displace.offsets.top + displace.offsets.bottom;
          adjustedValue = parseInt(0.01 * parseInt(optionValue, 10) * windowHeight, 10);

          if (option === 'height' && event.data.$element.parent().outerHeight() < adjustedValue) {
            adjustedValue = 'auto';
          }

          adjustedOptions[option] = adjustedValue;
        }
      }
    }

    if (!event.data.settings.modal) {
      adjustedOptions = resetPosition(adjustedOptions);
    }

    event.data.$element.dialog('option', adjustedOptions).trigger('dialogContentResize');
  }

  $(window).on({
    'dialog:aftercreate': function dialogAftercreate(event, dialog, $element, settings) {
      var autoResize = debounce(resetSize, 20);
      var eventData = {
        settings: settings,
        $element: $element
      };

      if (settings.autoResize === true || settings.autoResize === 'true') {
        $element.dialog('option', {
          resizable: false,
          draggable: false
        }).dialog('widget').css('position', 'fixed');
        $(window).on('resize.dialogResize scroll.dialogResize', eventData, autoResize).trigger('resize.dialogResize');
        $(document).on('drupalViewportOffsetChange.dialogResize', eventData, autoResize);
      }
    },
    'dialog:beforeclose': function dialogBeforeclose(event, dialog, $element) {
      $(window).off('.dialogResize');
      $(document).off('.dialogResize');
    }
  });
})(jQuery, Drupal, drupalSettings, Drupal.debounce, Drupal.displace);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, _ref) {
  var tabbable = _ref.tabbable,
      isTabbable = _ref.isTabbable;
  $.widget('ui.dialog', $.ui.dialog, {
    options: {
      buttonClass: 'button',
      buttonPrimaryClass: 'button--primary'
    },
    _createButtons: function _createButtons() {
      var opts = this.options;
      var primaryIndex;
      var index;
      var il = opts.buttons.length;

      for (index = 0; index < il; index++) {
        if (opts.buttons[index].primary && opts.buttons[index].primary === true) {
          primaryIndex = index;
          delete opts.buttons[index].primary;
          break;
        }
      }

      this._super();

      var $buttons = this.uiButtonSet.children().addClass(opts.buttonClass);

      if (typeof primaryIndex !== 'undefined') {
        $buttons.eq(index).addClass(opts.buttonPrimaryClass);
      }
    },
    _focusTabbable: function _focusTabbable() {
      var hasFocus = this._focusedElement ? this._focusedElement.get(0) : null;

      if (!hasFocus) {
        hasFocus = this.element.find('[autofocus]').get(0);
      }

      if (!hasFocus) {
        var $elements = [this.element, this.uiDialogButtonPane];

        for (var i = 0; i < $elements.length; i++) {
          var element = $elements[i].get(0);

          if (element) {
            var elementTabbable = tabbable(element);
            hasFocus = elementTabbable.length ? elementTabbable[0] : null;
          }

          if (hasFocus) {
            break;
          }
        }
      }

      if (!hasFocus) {
        var closeBtn = this.uiDialogTitlebarClose.get(0);
        hasFocus = closeBtn && isTabbable(closeBtn) ? closeBtn : null;
      }

      if (!hasFocus) {
        hasFocus = this.uiDialog.get(0);
      }

      $(hasFocus).eq(0).trigger('focus');
    }
  });
})(jQuery, window.tabbable);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, Drupal) {
  Drupal.behaviors.dialog = {
    attach: function attach(context, settings) {
      var $context = $(context);

      if (!$('#drupal-modal').length) {
        $('<div id="drupal-modal" class="ui-front"></div>').hide().appendTo('body');
      }

      var $dialog = $context.closest('.ui-dialog-content');

      if ($dialog.length) {
        if ($dialog.dialog('option', 'drupalAutoButtons')) {
          $dialog.trigger('dialogButtonsChange');
        }

        $dialog.dialog('widget').trigger('focus');
      }

      var originalClose = settings.dialog.close;

      settings.dialog.close = function (event) {
        for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
          args[_key - 1] = arguments[_key];
        }

        originalClose.apply(settings.dialog, [event].concat(args));
        $(event.target).remove();
      };
    },
    prepareDialogButtons: function prepareDialogButtons($dialog) {
      var buttons = [];
      var $buttons = $dialog.find('.form-actions input[type=submit], .form-actions a.button');
      $buttons.each(function () {
        var $originalButton = $(this).css({
          display: 'none'
        });
        buttons.push({
          text: $originalButton.html() || $originalButton.attr('value'),
          class: $originalButton.attr('class'),
          click: function click(e) {
            if ($originalButton.is('a')) {
              $originalButton[0].click();
            } else {
              $originalButton.trigger('mousedown').trigger('mouseup').trigger('click');
              e.preventDefault();
            }
          }
        });
      });
      return buttons;
    }
  };

  Drupal.AjaxCommands.prototype.openDialog = function (ajax, response, status) {
    if (!response.selector) {
      return false;
    }

    var $dialog = $(response.selector);

    if (!$dialog.length) {
      $dialog = $("<div id=\"".concat(response.selector.replace(/^#/, ''), "\" class=\"ui-front\"></div>")).appendTo('body');
    }

    if (!ajax.wrapper) {
      ajax.wrapper = $dialog.attr('id');
    }

    response.command = 'insert';
    response.method = 'html';
    ajax.commands.insert(ajax, response, status);

    if (!response.dialogOptions.buttons) {
      response.dialogOptions.drupalAutoButtons = true;
      response.dialogOptions.buttons = Drupal.behaviors.dialog.prepareDialogButtons($dialog);
    }

    $dialog.on('dialogButtonsChange', function () {
      var buttons = Drupal.behaviors.dialog.prepareDialogButtons($dialog);
      $dialog.dialog('option', 'buttons', buttons);
    });
    response.dialogOptions = response.dialogOptions || {};
    var dialog = Drupal.dialog($dialog.get(0), response.dialogOptions);

    if (response.dialogOptions.modal) {
      dialog.showModal();
    } else {
      dialog.show();
    }

    $dialog.parent().find('.ui-dialog-buttonset').addClass('form-actions');
  };

  Drupal.AjaxCommands.prototype.closeDialog = function (ajax, response, status) {
    var $dialog = $(response.selector);

    if ($dialog.length) {
      Drupal.dialog($dialog.get(0)).close();

      if (!response.persist) {
        $dialog.remove();
      }
    }

    $dialog.off('dialogButtonsChange');
  };

  Drupal.AjaxCommands.prototype.setDialogOption = function (ajax, response, status) {
    var $dialog = $(response.selector);

    if ($dialog.length) {
      $dialog.dialog('option', response.optionName, response.optionValue);
    }
  };

  $(window).on('dialog:aftercreate', function (e, dialog, $element, settings) {
    $element.on('click.dialog', '.dialog-cancel', function (e) {
      dialog.close('cancel');
      e.preventDefault();
      e.stopPropagation();
    });
  });
  $(window).on('dialog:beforeclose', function (e, dialog, $element) {
    $element.off('.dialog');
  });
})(jQuery, Drupal);;
/**
 * @file entity_browser.common.js
 *
 * Common helper functions used by various parts of entity browser.
 */

(function ($, Drupal, drupalSettings) {

  'use strict';

  Drupal.entityBrowser = {};

  /**
   * Command to refresh an entity_browser_entity_reference field widget.
   *
   * @param {Drupal.Ajax} [ajax]
   *   The ajax object.
   * @param {object} response
   *   Object holding the server response.
   * @param {string} response.details_id
   *   The ID for the details element.
   * @param {number} [status]
   *   The HTTP status code.
   */
  Drupal.AjaxCommands.prototype.entity_browser_value_updated = function (ajax, response, status) {
    $('#' + response.details_id)
      .find('input[type="hidden"][name$="[target_id]"]')
      .trigger('entity_browser_value_updated');
  };

  /**
   * Reacts on "entities selected" event.
   *
   * @param {object} event
   *   Event object.
   * @param {string} uuid
   *   Entity browser UUID.
   * @param {array} entities
   *   Array of selected entities.
   */
  Drupal.entityBrowser.selectionCompleted = function (event, uuid, entities) {
    var selected_entities = $.map(entities, function (item) {
      return item[2] + ':' + item[0];
    });
    // @todo Use uuid here. But for this to work we need to move eb uuid
    // generation from display to eb directly. When we do this, we can change
    // \Drupal\entity_browser\Plugin\Field\FieldWidget\EntityReferenceBrowserWidget::formElement
    // also.
    // Checking if cardinality is set - assume unlimited.
    var cardinality = isNaN(parseInt(drupalSettings['entity_browser'][uuid]['cardinality'])) ? -1 : parseInt(drupalSettings['entity_browser'][uuid]['cardinality']);

    // Get field widget selection mode.
    var selection_mode = drupalSettings['entity_browser'][uuid]['selection_mode'];

    // Update value form element with new entity IDs.
    var selector = drupalSettings['entity_browser'][uuid]['selector'] ? $(drupalSettings['entity_browser'][uuid]['selector']) : $(this).parent().parent().find('input[type*=hidden]');
    var entity_ids = selector.val();
    var existing_entities = (entity_ids.length !== 0) ? entity_ids.split(' ') : [];

    entity_ids = Drupal.entityBrowser.updateEntityIds(
      existing_entities,
      selected_entities,
      selection_mode,
      cardinality
    );

    selector.val(entity_ids);
    selector.trigger('entity_browser_value_updated');
  };

  /**
   * Updates the list of selected entities.
   *
   * It uses existing selection and selected entities in entity browser. Also
   * considers cardinality and used selection mode.
   *
   * Note: Selection modes are defined in EntityBrowserElement class and same
   * options should be used here to determine what action will be performed.
   * Default action is append ('selection_append').
   *
   * @param {Array} existing_entities
   *   List of existing entity IDs.
   * @param {Array} selected_entities
   *   The entities that are selected and entity browser.
   * @param {string} selection_mode
   *   Selection mode defined by entity browser field widget.
   * @param {int} cardinality
   *   The maximal amount of items the field can store.
   *
   * @return {string}
   *   List of entities as a string, separated by space.
   */
  Drupal.entityBrowser.updateEntityIds = function (existing_entities, selected_entities, selection_mode, cardinality) {
    var combined_entities;

    if (selection_mode === 'selection_edit') {
      // Propagate new selected entities.
      combined_entities = selected_entities;
    }
    else if (selection_mode === 'selection_prepend') {
      // Prepend selected entities to existing list of entities.
      combined_entities = selected_entities.concat(existing_entities);
    }
    else {
      // Append selected entities to existing list of entities.
      combined_entities = existing_entities.concat(selected_entities);
    }

    // Having more elements than cardinality should never happen, because
    // server side authentication should prevent it, but we handle it here
    // anyway.
    if (cardinality > 0 && combined_entities.length > cardinality) {
      combined_entities = combined_entities.slice(0, cardinality);
    }

    return combined_entities.join(' ');
  };

  /**
   * Reacts on "entities selected" event.
   *
   * @param {object} element
   *   Element to bind on.
   * @param {array} callbacks
   *   List of callbacks.
   * @param {string} event_name
   *   Name of event to bind to.
   */
  Drupal.entityBrowser.registerJsCallbacks = function (element, callbacks, event_name) {
    // JS callbacks are registred as strings. We need to split their names and
    // find actual functions.
    for (var i = 0; i < callbacks.length; i++) {
      var callback = callbacks[i].split('.');
      var fn = window;

      for (var j = 0; j < callback.length; j++) {
        fn = fn[callback[j]];
      }

      if (typeof fn === 'function') {
        $(element).bind(event_name, fn);
      }
    }
  };

}(jQuery, Drupal, drupalSettings));
;
/**
 * @file nir_multimedia.js
 *
 * Common helper functions used by various parts of entity browser.
 */

(function ($, Drupal) {
    Drupal.behaviors.entityBrowserEntityForm = {
        attach: function (context) {
            $(document).on('DOMNodeInserted', '.entities-list', function(e) {
                var element = e.target;
                var id = $(element).attr('class');
                var field_collection = $(element).closest('.field--name-field-nir-multimedia-file').parent();
                var height  = $(field_collection).find("input[id*='-item-height-0-value']");
                var width   = $(field_collection).find("input[id*='-item-width-0-value']");
                var size    = $(field_collection).find("input[id*='-item-size-0-value']");
                var format  = $(field_collection).find("input[id*='-item-format-0-value']");

                if (id == 'tabledrag-handle') {
                    var file = $(field_collection).find('[data-multimedia-item^="file"]');
                    if (typeof $(file).val() == 'undefined') {
                        return;
                    }
                    var fid =  $(file).val().split(":")[1];
                    jQuery.ajax({
                        url: "/ajax/multimedia/file/" + fid,
                        method: "GET",
                        headers: {"Accept": "application/json", "Content-Type": "application/json"},
                        success: function (data, status, xhr) {
                            if(!data.error){
                                if ($(height).attr('value').length == 0) {
                                    $(height).attr('value', data.height);
                                }
                                if ($(width).attr('value').length == 0) {
                                    $(width).attr('value', data.width);
                                }
                                if ($(size).attr('value').length == 0) {
                                    $(size).attr('value', data.size);
                                }
                                if ($(format).attr('value').length == 0) {
                                    $(format).attr('value', data.mime);
                                }
                            }
                        }
                    });
                }
                else {
                    $(height).attr('value', '');
                    $(width).attr('value', '');
                    $(size).attr('value', '');
                    $(format).attr('value', '');
                }
            });
        }
    };
})(jQuery, Drupal);
;
/*! sidr - v2.2.1 - 2016-02-17
 * http://www.berriart.com/sidr/
 * Copyright (c) 2013-2016 Alberto Varela; Licensed MIT */
!function(){"use strict";function a(a,b,c){var d=new o(b);switch(a){case"open":d.open(c);break;case"close":d.close(c);break;case"toggle":d.toggle(c);break;default:p.error("Method "+a+" does not exist on jQuery.sidr")}}function b(a){return"status"===a?h:s[a]?s[a].apply(this,Array.prototype.slice.call(arguments,1)):"function"!=typeof a&&"string"!=typeof a&&a?void q.error("Method "+a+" does not exist on jQuery.sidr"):s.toggle.apply(this,arguments)}function c(a,b){if("function"==typeof b.source){var c=b.source(name);a.html(c)}else if("string"==typeof b.source&&i.isUrl(b.source))u.get(b.source,function(b){a.html(b)});else if("string"==typeof b.source){var d="",e=b.source.split(",");if(u.each(e,function(a,b){d+='<div class="sidr-inner">'+u(b).html()+"</div>"}),b.renaming){var f=u("<div />").html(d);f.find("*").each(function(a,b){var c=u(b);i.addPrefixes(c)}),d=f.html()}a.html(d)}else null!==b.source&&u.error("Invalid Sidr Source");return a}function d(a){var d=i.transitions,e=u.extend({name:"sidr",speed:200,side:"left",source:null,renaming:!0,body:"body",displace:!0,timing:"ease",method:"toggle",bind:"touchstart click",onOpen:function(){},onClose:function(){},onOpenEnd:function(){},onCloseEnd:function(){}},a),f=e.name,g=u("#"+f);return 0===g.length&&(g=u("<div />").attr("id",f).appendTo(u("body"))),d.supported&&g.css(d.property,e.side+" "+e.speed/1e3+"s "+e.timing),g.addClass("sidr").addClass(e.side).data({speed:e.speed,side:e.side,body:e.body,displace:e.displace,timing:e.timing,method:e.method,onOpen:e.onOpen,onClose:e.onClose,onOpenEnd:e.onOpenEnd,onCloseEnd:e.onCloseEnd}),g=c(g,e),this.each(function(){var a=u(this),c=a.data("sidr"),d=!1;c||(h.moving=!1,h.opened=!1,a.data("sidr",f),a.bind(e.bind,function(a){a.preventDefault(),d||(d=!0,b(e.method,f),setTimeout(function(){d=!1},100))}))})}var e={};e.classCallCheck=function(a,b){if(!(a instanceof b))throw new TypeError("Cannot call a class as a function")},e.createClass=function(){function a(a,b){for(var c=0;c<b.length;c++){var d=b[c];d.enumerable=d.enumerable||!1,d.configurable=!0,"value"in d&&(d.writable=!0),Object.defineProperty(a,d.key,d)}}return function(b,c,d){return c&&a(b.prototype,c),d&&a(b,d),b}}();var f,g,h={moving:!1,opened:!1},i={isUrl:function(a){var b=new RegExp("^(https?:\\/\\/)?((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.?)+[a-z]{2,}|((\\d{1,3}\\.){3}\\d{1,3}))(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*(\\?[;&a-z\\d%_.~+=-]*)?(\\#[-a-z\\d_]*)?$","i");return b.test(a)?!0:!1},addPrefixes:function(a){this.addPrefix(a,"id"),this.addPrefix(a,"class"),a.removeAttr("style")},addPrefix:function(a,b){var c=a.attr(b);"string"==typeof c&&""!==c&&"sidr-inner"!==c&&a.attr(b,c.replace(/([A-Za-z0-9_.\-]+)/g,"sidr-"+b+"-$1"))},transitions:function(){var a=document.body||document.documentElement,b=a.style,c=!1,d="transition";return d in b?c=!0:!function(){var a=["moz","webkit","o","ms"],e=void 0,f=void 0;d=d.charAt(0).toUpperCase()+d.substr(1),c=function(){for(f=0;f<a.length;f++)if(e=a[f],e+d in b)return!0;return!1}(),d=c?"-"+e.toLowerCase()+"-"+d.toLowerCase():null}(),{supported:c,property:d}}()},j=jQuery,k="sidr-animating",l="open",m="close",n="webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend",o=function(){function a(b){e.classCallCheck(this,a),this.name=b,this.item=j("#"+b),this.openClass="sidr"===b?"sidr-open":"sidr-open "+b+"-open",this.menuWidth=this.item.outerWidth(!0),this.speed=this.item.data("speed"),this.side=this.item.data("side"),this.displace=this.item.data("displace"),this.timing=this.item.data("timing"),this.method=this.item.data("method"),this.onOpenCallback=this.item.data("onOpen"),this.onCloseCallback=this.item.data("onClose"),this.onOpenEndCallback=this.item.data("onOpenEnd"),this.onCloseEndCallback=this.item.data("onCloseEnd"),this.body=j(this.item.data("body"))}return e.createClass(a,[{key:"getAnimation",value:function(a,b){var c={},d=this.side;return"open"===a&&"body"===b?c[d]=this.menuWidth+"px":"close"===a&&"menu"===b?c[d]="-"+this.menuWidth+"px":c[d]=0,c}},{key:"prepareBody",value:function(a){var b="open"===a?"hidden":"";if(this.body.is("body")){var c=j("html"),d=c.scrollTop();c.css("overflow-x",b).scrollTop(d)}}},{key:"openBody",value:function(){if(this.displace){var a=i.transitions,b=this.body;if(a.supported)b.css(a.property,this.side+" "+this.speed/1e3+"s "+this.timing).css(this.side,0).css({width:b.width(),position:"absolute"}),b.css(this.side,this.menuWidth+"px");else{var c=this.getAnimation(l,"body");b.css({width:b.width(),position:"absolute"}).animate(c,{queue:!1,duration:this.speed})}}}},{key:"onCloseBody",value:function(){var a=i.transitions,b={width:"",position:"",right:"",left:""};a.supported&&(b[a.property]=""),this.body.css(b).unbind(n)}},{key:"closeBody",value:function(){var a=this;if(this.displace)if(i.transitions.supported)this.body.css(this.side,0).one(n,function(){a.onCloseBody()});else{var b=this.getAnimation(m,"body");this.body.animate(b,{queue:!1,duration:this.speed,complete:function(){a.onCloseBody()}})}}},{key:"moveBody",value:function(a){a===l?this.openBody():this.closeBody()}},{key:"onOpenMenu",value:function(a){var b=this.name;h.moving=!1,h.opened=b,this.item.unbind(n),this.body.removeClass(k).addClass(this.openClass),this.onOpenEndCallback(),"function"==typeof a&&a(b)}},{key:"openMenu",value:function(a){var b=this,c=this.item;if(i.transitions.supported)c.css(this.side,0).one(n,function(){b.onOpenMenu(a)});else{var d=this.getAnimation(l,"menu");c.css("display","block").animate(d,{queue:!1,duration:this.speed,complete:function(){b.onOpenMenu(a)}})}}},{key:"onCloseMenu",value:function(a){this.item.css({left:"",right:""}).unbind(n),j("html").css("overflow-x",""),h.moving=!1,h.opened=!1,this.body.removeClass(k).removeClass(this.openClass),this.onCloseEndCallback(),"function"==typeof a&&a(name)}},{key:"closeMenu",value:function(a){var b=this,c=this.item;if(i.transitions.supported)c.css(this.side,"").one(n,function(){b.onCloseMenu(a)});else{var d=this.getAnimation(m,"menu");c.animate(d,{queue:!1,duration:this.speed,complete:function(){b.onCloseMenu()}})}}},{key:"moveMenu",value:function(a,b){this.body.addClass(k),a===l?this.openMenu(b):this.closeMenu(b)}},{key:"move",value:function(a,b){h.moving=!0,this.prepareBody(a),this.moveBody(a),this.moveMenu(a,b)}},{key:"open",value:function(b){var c=this;if(h.opened!==this.name&&!h.moving){if(h.opened!==!1){var d=new a(h.opened);return void d.close(function(){c.open(b)})}this.move("open",b),this.onOpenCallback()}}},{key:"close",value:function(a){h.opened!==this.name||h.moving||(this.move("close",a),this.onCloseCallback())}},{key:"toggle",value:function(a){h.opened===this.name?this.close(a):this.open(a)}}]),a}(),p=jQuery,q=jQuery,r=["open","close","toggle"],s={},t=function(b){return function(c,d){"function"==typeof c?(d=c,c="sidr"):c||(c="sidr"),a(b,c,d)}};for(f=0;f<r.length;f++)g=r[f],s[g]=t(g);var u=jQuery;jQuery.sidr=b,jQuery.fn.sidr=d}();;
/**
 * @file
 * A JavaScript file for the theme.
 *
 */

(function ($, Drupal, window, document) {
  'use strict';

  Drupal.behaviors.chosen = {
    attach: function (context, settings) {
      $('select[multiple="multiple"]').chosen({
        placeholder_text_multiple: 'Choose from list',
        inherit_select_classes: true,
        width: '150px'
      });
      $('select:not([data-timestamp], .quote-wrap select, .ipe-block-plugin-form select, .ipe-form:not(.flipped) select)').chosen({
        inherit_select_classes: true,
        disable_search_threshold: 10,
        width: '150px'
      });
    }
  };

  Drupal.behaviors.faqAcc = {
    attach: function (context, settings) {
      $('.faq-acc-dl dd:first').removeClass('visually-hidden');
      $('.faq-acc-dl dt:first').addClass('opened');
      $('.faq-acc-dl').on('click focus', 'dt', function () {
        if (!$(this).data('fired')) {
          $(this).toggleClass('opened')
          .next('dd').toggleClass('visually-hidden');
        }
        $(this).data('fired', true);
        setTimeout(function (self) {
          $(self).data('fired', false);
        }, 200, this);
      });
      $('.block-faq').on('click', '.show-all', function (e) {
        if ($(this).html() === 'Show all') {
          $('.faq-acc-dl dd').removeClass('visually-hidden');
          $('.faq-acc-dl dt').addClass('opened');
          $(this).html('Hide all');
        }
        else {
          $('.faq-acc-dl dd').addClass('visually-hidden');
          $('.faq-acc-dl dt').removeClass('opened');
          $(this).html('Show all');
        }
        e.preventDefault();
      });
    }
  };

  Drupal.behaviors.accordian = {
    attach: function (context, settings) {

      var firstTitle = $('.acc-title:first');
      var firstWrap = $(firstTitle).next('.acc-content-wrap');
      $(firstTitle).addClass('opened');
      $('.acc-body', firstWrap).removeClass('visually-hidden');
      $('.acc-body:first').removeClass('visually-hidden');

      $('.acc-title').click(function () {
        $(this).addClass('opened');
        $('.acc-title').not(this).removeClass('opened');
        $('.acc-body').addClass('visually-hidden');
        var bodyWrap = $(this).next('.acc-content-wrap');
        $('.acc-body', bodyWrap).removeClass('visually-hidden');
        $(this).next('.acc-body').removeClass('visually-hidden');

      });

      $('.block-views-blockwidget-bundled-content-block-1').on('click', '.show-all', function (e) {
        if ($(this).html() === 'Show all') {
          $('.acc-wrap .acc-body').removeClass('visually-hidden');
          $('.acc-wrap .acc-title').addClass('opened');
          $('.block-views-blockwidget-bundled-content-block-1 .show-all').addClass('hide-all');
          $(this).html('Hide all');
        }
        else {
          $('.acc-wrap .acc-body').addClass('visually-hidden');
          $('.acc-wrap .acc-title').removeClass('opened');
          $('.block-views-blockwidget-bundled-content-block-1 .show-all').removeClass('hide-all');
          $(this).html('Show all');
        }
        e.preventDefault();
      });
    }
  };

  Drupal.behaviors.nirTooltip = {
    attach: function (context, settings) {
      $('[role="tooltip"]').each(function () {
        var markup = $(this).text();
        $(this).html(markup);
      });
      var openTooltip = function () {
        var tooltip = $('#' + $(this).attr('aria-describedby'));
        $(tooltip)
        .stop()
        .attr({
          'aria-hidden': 'false'
        })
        .animate({opacity: 1, zIndex: 100}, 200)
        .position({
          my: 'left bottom-10',
          at: 'left top',
          of: this
        });
      };
      var closeTooltip = function () {
        var tooltip = $('#' + $(this).attr('aria-describedby'));
        $(tooltip)
        .stop()
        .attr({
          'aria-hidden': 'true'
        })
        .animate({opacity: 0, zIndex: -1}, 200);
      };
      $('.nir-tooltip').hover(openTooltip, closeTooltip);
      $('.nir-tooltip').on('click', function (event) {
        event.preventDefault();
      });
      $('.nir-tooltip').on('touchstart', openTooltip);
      $('.nir-tooltip').on('touchend', closeTooltip);
    }
  };

  Drupal.behaviors.tableCollapse = {
    attach: function (context, settings) {
      var collTable = $('table.collapse-table, table.collapse-table-wide');
      $(collTable).each(function () {
        $('tbody tr td, tfoot tr td', this).each(function () {
          var rowIndex = $(this).index();
          var thisTable = $(this).parents().eq(2);
          var headIndex = $('tr th', thisTable)[rowIndex];
          var regex = /(<([^>]+)>)/ig;
          var rawTitle = $(headIndex).html();
          var title;
          if (typeof rawTitle != 'undefined') {
            title = rawTitle.replace(regex, '');
          }
          if (title !== '&nbsp;' && title !== '') {
            $(this).attr('data-before', title);
          }
        });
        $('tr', this).each(function () {
          if ($(this).hasClass('total-row')) {
            $('td', this).first().attr('data-before', '');
          }
        });
      });
    }
  };

  Drupal.behaviors.modalLink = {
    attach: function (context, settings) {
      $('.modal').on('click', function (event) {
        var link = $(this).attr('href');
        var width = $('#content-area').width();
        $('.modal-content').load(link + ' .node__content', function () {
          $('.modal-content').dialog({
            width: width
          });
        });
        event.preventDefault();
      });
    }
  };

  Drupal.behaviors.nirNewsWidgetSummaryToggleTitle = {
    attach: function (context, settings) {
      $('.nir-news-widget-summary-toggle-title').each(function () {
        if ($(this).parents('.views-field-field-nir-news-title').siblings('.views-field-field-nir-news-teaser').length === 0) {
          $(this).hide();
        }
      });
      $('.nir-news-widget-summary-toggle-title').once().on('click', function (e) {
        e.preventDefault();
        $(this).parents('.views-field-field-nir-news-title').siblings('.views-field-field-nir-news-teaser').children('.summary-hidden').slideToggle('fast', 'linear');
        $(this).toggleClass('open');
      });
    }
  };

  Drupal.behaviors.nirWidgetAccordion = {
    attach: function (context, settings) {
      $('.nir-widget--accordion-wrapper').hide();
      $('.nir-widget--accordion-toggle').once().on('click', function (e) {
        e.preventDefault();
        $(this).siblings('.nir-widget--accordion-wrapper').slideToggle('fast', 'linear');
        $(this).toggleClass('open');
      });
    }
  };

  Drupal.behaviors.nirNewsWidgetSummaryToggleDate = {
    attach: function (context, settings) {
      $('.nir-news-widget-summary-toggle-date').each(function () {
        if ($(this).parents('.views-field-field-nir-news-date').siblings('.views-field-field-nir-news-title').find('.nir-news-table-teaser').length === 0) {
          $(this).hide();
        }
      });
      $('.nir-news-widget-summary-toggle-date').once().on('click', function (e) {
        e.preventDefault();
        $(this).parents('.views-field-field-nir-news-date').siblings('.views-field-field-nir-news-title').find('.summary-hidden').slideToggle('fast', 'linear');
        $(this).toggleClass('open');
      });
    }
  };

  Drupal.behaviors.nirEventsTableWidgetSummaryToggleDate = {
    attach: function (context, settings) {
      $('.nir-events-table-widget-summary-toggle-date').each(function () {
        if ($(this).parents('.views-field-field-nir-event-start-date').siblings('.views-field-nothing').find('.nir-events-widget-event-details').hasClass('summary-empty')) {
          $(this).hide();
        }
      });
      $('.nir-events-table-widget-summary-toggle-date').once().on('click', function (e) {
        e.preventDefault();
        $(this).parents('.views-field-field-nir-event-start-date').siblings('.views-field-nothing').find('.summary-hidden').slideToggle('fast', 'linear');
        $(this).toggleClass('open');
      });
    }
  };

  Drupal.behaviors.nirViewsSearch = {
    attach: function (context, settings) {
      $('.view-search #edit-query').attr('placeholder', 'Search');
    }
  };

  Drupal.behaviors.targetBlank = {
    attach: function (context, settings) {
      $('span.file a').attr('target', '_blank');
    }
  };

  Drupal.behaviors.tablesort = {
    attach: function (context, settings) {
      $('table').each(function () {
        $('th a', this).each(function () {
          if ($('span', this).length < 1) {
            $(this).append('<span class="tablesort">');
          }
        });
      });
    }
  };

  Drupal.behaviors.autoSubmitFilters = {
    // This is a hack until autosubmit is supported in drupal 8 views.
    // https://www.drupal.org/node/2475595
    attach: function (context, settings) {
      // Autosubmit 'view-class-here' views exposed form.
      $('div[class*="view-widget"], .view-nir-media-gallery-items-grid').find('form.views-exposed-form').find('select').bind('change', function () {
        var id = $(this).closest('form').attr('id');
        $(this).closest('form').attr('action', $(this).closest('form').attr('action') + '#' + id);
        $(this).closest('form').trigger('submit');
      }).end().find('input[type="submit"]').addClass('visually-hidden');
    }
  };

})(jQuery, Drupal, this, this.document);
;
/**
 * @file
 * A JavaScript file for sidr behaviors.
 *
 */

(function ($, Drupal, window, document) {

  'use strict';

  Drupal.behaviors.sidr = {
    attach: function (context, settings) {
      if ($('#responsive-menu-button').length > 0) {
        $('#responsive-menu-button').sidr({
          name: 'sidr-main',
          source: '#block-investorrelationshorizontal',
          side: 'right'
        });
      }
    }
  };

})(jQuery, Drupal, this, this.document);
;
/*!
 * JavaScript Cookie v2.1.3
 * https://github.com/js-cookie/js-cookie
 *
 * Copyright 2006, 2015 Klaus Hartl & Fagner Brack
 * Released under the MIT license
 */
;(function (factory) {
	var registeredInModuleLoader = false;
	if (typeof define === 'function' && define.amd) {
		define(factory);
		registeredInModuleLoader = true;
	}
	if (typeof exports === 'object') {
		module.exports = factory();
		registeredInModuleLoader = true;
	}
	if (!registeredInModuleLoader) {
		var OldCookies = window.Cookies;
		var api = window.Cookies = factory();
		api.noConflict = function () {
			window.Cookies = OldCookies;
			return api;
		};
	}
}(function () {
	function extend () {
		var i = 0;
		var result = {};
		for (; i < arguments.length; i++) {
			var attributes = arguments[ i ];
			for (var key in attributes) {
				result[key] = attributes[key];
			}
		}
		return result;
	}

	function init (converter) {
		function api (key, value, attributes) {
			var result;
			if (typeof document === 'undefined') {
				return;
			}

			// Write

			if (arguments.length > 1) {
				attributes = extend({
					path: '/'
				}, api.defaults, attributes);

				if (typeof attributes.expires === 'number') {
					var expires = new Date();
					expires.setMilliseconds(expires.getMilliseconds() + attributes.expires * 864e+5);
					attributes.expires = expires;
				}

				try {
					result = JSON.stringify(value);
					if (/^[\{\[]/.test(result)) {
						value = result;
					}
				} catch (e) {}

				if (!converter.write) {
					value = encodeURIComponent(String(value))
						.replace(/%(23|24|26|2B|3A|3C|3E|3D|2F|3F|40|5B|5D|5E|60|7B|7D|7C)/g, decodeURIComponent);
				} else {
					value = converter.write(value, key);
				}

				key = encodeURIComponent(String(key));
				key = key.replace(/%(23|24|26|2B|5E|60|7C)/g, decodeURIComponent);
				key = key.replace(/[\(\)]/g, escape);

				return (document.cookie = [
					key, '=', value,
					attributes.expires ? '; expires=' + attributes.expires.toUTCString() : '', // use expires attribute, max-age is not supported by IE
					attributes.path ? '; path=' + attributes.path : '',
					attributes.domain ? '; domain=' + attributes.domain : '',
					attributes.secure ? '; secure' : ''
				].join(''));
			}

			// Read

			if (!key) {
				result = {};
			}

			// To prevent the for loop in the first place assign an empty array
			// in case there are no cookies at all. Also prevents odd result when
			// calling "get()"
			var cookies = document.cookie ? document.cookie.split('; ') : [];
			var rdecode = /(%[0-9A-Z]{2})+/g;
			var i = 0;

			for (; i < cookies.length; i++) {
				var parts = cookies[i].split('=');
				var cookie = parts.slice(1).join('=');

				if (cookie.charAt(0) === '"') {
					cookie = cookie.slice(1, -1);
				}

				try {
					var name = parts[0].replace(rdecode, decodeURIComponent);
					cookie = converter.read ?
						converter.read(cookie, name) : converter(cookie, name) ||
						cookie.replace(rdecode, decodeURIComponent);

					if (this.json) {
						try {
							cookie = JSON.parse(cookie);
						} catch (e) {}
					}

					if (key === name) {
						result = cookie;
						break;
					}

					if (!key) {
						result[name] = cookie;
					}
				} catch (e) {}
			}

			return result;
		}

		api.set = api;
		api.get = function (key) {
			return api.call(api, key);
		};
		api.getJSON = function () {
			return api.apply({
				json: true
			}, [].slice.call(arguments));
		};
		api.defaults = {};

		api.remove = function (key, attributes) {
			api(key, '', extend(attributes, {
				expires: -1
			}));
		};

		api.withConverter = init;

		return api;
	}

	return init(function () {});
}));
;
(function() {
  var $, AbstractChosen, Chosen, SelectParser, _ref,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  SelectParser = (function() {
    function SelectParser() {
      this.options_index = 0;
      this.parsed = [];
    }

    SelectParser.prototype.add_node = function(child) {
      if (child.nodeName.toUpperCase() === "OPTGROUP") {
        return this.add_group(child);
      } else {
        return this.add_option(child);
      }
    };

    SelectParser.prototype.add_group = function(group) {
      var group_position, option, _i, _len, _ref, _results;
      group_position = this.parsed.length;
      this.parsed.push({
        array_index: group_position,
        group: true,
        label: this.escapeExpression(group.label),
        title: group.title ? group.title : void 0,
        children: 0,
        disabled: group.disabled,
        classes: group.className
      });
      _ref = group.childNodes;
      _results = [];
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        option = _ref[_i];
        _results.push(this.add_option(option, group_position, group.disabled));
      }
      return _results;
    };

    SelectParser.prototype.add_option = function(option, group_position, group_disabled) {
      if (option.nodeName.toUpperCase() === "OPTION") {
        if (option.text !== "") {
          if (group_position != null) {
            this.parsed[group_position].children += 1;
          }
          this.parsed.push({
            array_index: this.parsed.length,
            options_index: this.options_index,
            value: option.value,
            text: option.text,
            html: option.innerHTML,
            title: option.title ? option.title : void 0,
            selected: option.selected,
            disabled: group_disabled === true ? group_disabled : option.disabled,
            group_array_index: group_position,
            group_label: group_position != null ? this.parsed[group_position].label : null,
            classes: option.className,
            style: option.style.cssText
          });
        } else {
          this.parsed.push({
            array_index: this.parsed.length,
            options_index: this.options_index,
            empty: true
          });
        }
        return this.options_index += 1;
      }
    };

    SelectParser.prototype.escapeExpression = function(text) {
      var map, unsafe_chars;
      if ((text == null) || text === false) {
        return "";
      }
      if (!/[\&\<\>\"\'\`]/.test(text)) {
        return text;
      }
      map = {
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#x27;",
        "`": "&#x60;"
      };
      unsafe_chars = /&(?!\w+;)|[\<\>\"\'\`]/g;
      return text.replace(unsafe_chars, function(chr) {
        return map[chr] || "&amp;";
      });
    };

    return SelectParser;

  })();

  SelectParser.select_to_array = function(select) {
    var child, parser, _i, _len, _ref;
    parser = new SelectParser();
    _ref = select.childNodes;
    for (_i = 0, _len = _ref.length; _i < _len; _i++) {
      child = _ref[_i];
      parser.add_node(child);
    }
    return parser.parsed;
  };

  AbstractChosen = (function() {
    function AbstractChosen(form_field, options) {
      this.form_field = form_field;
      this.options = options != null ? options : {};
      if (!AbstractChosen.browser_is_supported()) {
        return;
      }
      this.is_multiple = this.form_field.multiple;
      this.set_default_text();
      this.set_default_values();
      this.setup();
      this.set_up_html();
      this.register_observers();
      this.on_ready();
    }

    AbstractChosen.prototype.set_default_values = function() {
      var _this = this;
      this.click_test_action = function(evt) {
        return _this.test_active_click(evt);
      };
      this.activate_action = function(evt) {
        return _this.activate_field(evt);
      };
      this.active_field = false;
      this.mouse_on_container = false;
      this.results_showing = false;
      this.result_highlighted = null;
      this.allow_single_deselect = (this.options.allow_single_deselect != null) && (this.form_field.options[0] != null) && this.form_field.options[0].text === "" ? this.options.allow_single_deselect : false;
      this.disable_search_threshold = this.options.disable_search_threshold || 0;
      this.disable_search = this.options.disable_search || false;
      this.enable_split_word_search = this.options.enable_split_word_search != null ? this.options.enable_split_word_search : true;
      this.group_search = this.options.group_search != null ? this.options.group_search : true;
      this.search_contains = this.options.search_contains || false;
      this.single_backstroke_delete = this.options.single_backstroke_delete != null ? this.options.single_backstroke_delete : true;
      this.max_selected_options = this.options.max_selected_options || Infinity;
      this.inherit_select_classes = this.options.inherit_select_classes || false;
      this.display_selected_options = this.options.display_selected_options != null ? this.options.display_selected_options : true;
      this.display_disabled_options = this.options.display_disabled_options != null ? this.options.display_disabled_options : true;
      this.include_group_label_in_selected = this.options.include_group_label_in_selected || false;
      return this.max_shown_results = this.options.max_shown_results || Number.POSITIVE_INFINITY;
    };

    AbstractChosen.prototype.set_default_text = function() {
      if (this.form_field.getAttribute("data-placeholder")) {
        this.default_text = this.form_field.getAttribute("data-placeholder");
      } else if (this.is_multiple) {
        this.default_text = this.options.placeholder_text_multiple || this.options.placeholder_text || AbstractChosen.default_multiple_text;
      } else {
        this.default_text = this.options.placeholder_text_single || this.options.placeholder_text || AbstractChosen.default_single_text;
      }
      return this.results_none_found = this.form_field.getAttribute("data-no_results_text") || this.options.no_results_text || AbstractChosen.default_no_result_text;
    };

    AbstractChosen.prototype.choice_label = function(item) {
      if (this.include_group_label_in_selected && (item.group_label != null)) {
        return "<b class='group-name'>" + item.group_label + "</b>" + item.html;
      } else {
        return item.html;
      }
    };

    AbstractChosen.prototype.mouse_enter = function() {
      return this.mouse_on_container = true;
    };

    AbstractChosen.prototype.mouse_leave = function() {
      return this.mouse_on_container = false;
    };

    AbstractChosen.prototype.input_focus = function(evt) {
      var _this = this;
      if (this.is_multiple) {
        if (!this.active_field) {
          return setTimeout((function() {
            return _this.container_mousedown();
          }), 50);
        }
      } else {
        if (!this.active_field) {
          return this.activate_field();
        }
      }
    };

    AbstractChosen.prototype.input_blur = function(evt) {
      var _this = this;
      if (!this.mouse_on_container) {
        this.active_field = false;
        return setTimeout((function() {
          return _this.blur_test();
        }), 100);
      }
    };

    AbstractChosen.prototype.results_option_build = function(options) {
      var content, data, data_content, shown_results, _i, _len, _ref;
      content = '';
      shown_results = 0;
      _ref = this.results_data;
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        data = _ref[_i];
        data_content = '';
        if (data.group) {
          data_content = this.result_add_group(data);
        } else {
          data_content = this.result_add_option(data);
        }
        if (data_content !== '') {
          shown_results++;
          content += data_content;
        }
        if (options != null ? options.first : void 0) {
          if (data.selected && this.is_multiple) {
            this.choice_build(data);
          } else if (data.selected && !this.is_multiple) {
            this.single_set_selected_text(this.choice_label(data));
          }
        }
        if (shown_results >= this.max_shown_results) {
          break;
        }
      }
      return content;
    };

    AbstractChosen.prototype.result_add_option = function(option) {
      var classes, option_el;
      if (!option.search_match) {
        return '';
      }
      if (!this.include_option_in_results(option)) {
        return '';
      }
      classes = [];
      if (!option.disabled && !(option.selected && this.is_multiple)) {
        classes.push("active-result");
      }
      if (option.disabled && !(option.selected && this.is_multiple)) {
        classes.push("disabled-result");
      }
      if (option.selected) {
        classes.push("result-selected");
      }
      if (option.group_array_index != null) {
        classes.push("group-option");
      }
      if (option.classes !== "") {
        classes.push(option.classes);
      }
      option_el = document.createElement("li");
      option_el.className = classes.join(" ");
      option_el.style.cssText = option.style;
      option_el.setAttribute("data-option-array-index", option.array_index);
      option_el.innerHTML = option.search_text;
      if (option.title) {
        option_el.title = option.title;
      }
      return this.outerHTML(option_el);
    };

    AbstractChosen.prototype.result_add_group = function(group) {
      var classes, group_el;
      if (!(group.search_match || group.group_match)) {
        return '';
      }
      if (!(group.active_options > 0)) {
        return '';
      }
      classes = [];
      classes.push("group-result");
      if (group.classes) {
        classes.push(group.classes);
      }
      group_el = document.createElement("li");
      group_el.className = classes.join(" ");
      group_el.innerHTML = group.search_text;
      if (group.title) {
        group_el.title = group.title;
      }
      return this.outerHTML(group_el);
    };

    AbstractChosen.prototype.results_update_field = function() {
      this.set_default_text();
      if (!this.is_multiple) {
        this.results_reset_cleanup();
      }
      this.result_clear_highlight();
      this.results_build();
      if (this.results_showing) {
        return this.winnow_results();
      }
    };

    AbstractChosen.prototype.reset_single_select_options = function() {
      var result, _i, _len, _ref, _results;
      _ref = this.results_data;
      _results = [];
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        result = _ref[_i];
        if (result.selected) {
          _results.push(result.selected = false);
        } else {
          _results.push(void 0);
        }
      }
      return _results;
    };

    AbstractChosen.prototype.results_toggle = function() {
      if (this.results_showing) {
        return this.results_hide();
      } else {
        return this.results_show();
      }
    };

    AbstractChosen.prototype.results_search = function(evt) {
      if (this.results_showing) {
        return this.winnow_results();
      } else {
        return this.results_show();
      }
    };

    AbstractChosen.prototype.winnow_results = function() {
      var escapedSearchText, option, regex, results, results_group, searchText, startpos, text, zregex, _i, _len, _ref;
      this.no_results_clear();
      results = 0;
      searchText = this.get_search_text();
      escapedSearchText = searchText.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
      zregex = new RegExp(escapedSearchText, 'i');
      regex = this.get_search_regex(escapedSearchText);
      _ref = this.results_data;
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        option = _ref[_i];
        option.search_match = false;
        results_group = null;
        if (this.include_option_in_results(option)) {
          if (option.group) {
            option.group_match = false;
            option.active_options = 0;
          }
          if ((option.group_array_index != null) && this.results_data[option.group_array_index]) {
            results_group = this.results_data[option.group_array_index];
            if (results_group.active_options === 0 && results_group.search_match) {
              results += 1;
            }
            results_group.active_options += 1;
          }
          option.search_text = option.group ? option.label : option.html;
          if (!(option.group && !this.group_search)) {
            option.search_match = this.search_string_match(option.search_text, regex);
            if (option.search_match && !option.group) {
              results += 1;
            }
            if (option.search_match) {
              if (searchText.length) {
                startpos = option.search_text.search(zregex);
                text = option.search_text.substr(0, startpos + searchText.length) + '</em>' + option.search_text.substr(startpos + searchText.length);
                option.search_text = text.substr(0, startpos) + '<em>' + text.substr(startpos);
              }
              if (results_group != null) {
                results_group.group_match = true;
              }
            } else if ((option.group_array_index != null) && this.results_data[option.group_array_index].search_match) {
              option.search_match = true;
            }
          }
        }
      }
      this.result_clear_highlight();
      if (results < 1 && searchText.length) {
        this.update_results_content("");
        return this.no_results(searchText);
      } else {
        this.update_results_content(this.results_option_build());
        return this.winnow_results_set_highlight();
      }
    };

    AbstractChosen.prototype.get_search_regex = function(escaped_search_string) {
      var regex_anchor;
      regex_anchor = this.search_contains ? "" : "^";
      return new RegExp(regex_anchor + escaped_search_string, 'i');
    };

    AbstractChosen.prototype.search_string_match = function(search_string, regex) {
      var part, parts, _i, _len;
      if (regex.test(search_string)) {
        return true;
      } else if (this.enable_split_word_search && (search_string.indexOf(" ") >= 0 || search_string.indexOf("[") === 0)) {
        parts = search_string.replace(/\[|\]/g, "").split(" ");
        if (parts.length) {
          for (_i = 0, _len = parts.length; _i < _len; _i++) {
            part = parts[_i];
            if (regex.test(part)) {
              return true;
            }
          }
        }
      }
    };

    AbstractChosen.prototype.choices_count = function() {
      var option, _i, _len, _ref;
      if (this.selected_option_count != null) {
        return this.selected_option_count;
      }
      this.selected_option_count = 0;
      _ref = this.form_field.options;
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        option = _ref[_i];
        if (option.selected) {
          this.selected_option_count += 1;
        }
      }
      return this.selected_option_count;
    };

    AbstractChosen.prototype.choices_click = function(evt) {
      evt.preventDefault();
      if (!(this.results_showing || this.is_disabled)) {
        return this.results_show();
      }
    };

    AbstractChosen.prototype.keyup_checker = function(evt) {
      var stroke, _ref;
      stroke = (_ref = evt.which) != null ? _ref : evt.keyCode;
      this.search_field_scale();
      switch (stroke) {
        case 8:
          if (this.is_multiple && this.backstroke_length < 1 && this.choices_count() > 0) {
            return this.keydown_backstroke();
          } else if (!this.pending_backstroke) {
            this.result_clear_highlight();
            return this.results_search();
          }
          break;
        case 13:
          evt.preventDefault();
          if (this.results_showing) {
            return this.result_select(evt);
          }
          break;
        case 27:
          if (this.results_showing) {
            this.results_hide();
          }
          return true;
        case 9:
        case 38:
        case 40:
        case 16:
        case 91:
        case 17:
        case 18:
          break;
        default:
          return this.results_search();
      }
    };

    AbstractChosen.prototype.clipboard_event_checker = function(evt) {
      var _this = this;
      return setTimeout((function() {
        return _this.results_search();
      }), 50);
    };

    AbstractChosen.prototype.container_width = function() {
      if (this.options.width != null) {
        return this.options.width;
      } else {
        return "" + this.form_field.offsetWidth + "px";
      }
    };

    AbstractChosen.prototype.include_option_in_results = function(option) {
      if (this.is_multiple && (!this.display_selected_options && option.selected)) {
        return false;
      }
      if (!this.display_disabled_options && option.disabled) {
        return false;
      }
      if (option.empty) {
        return false;
      }
      return true;
    };

    AbstractChosen.prototype.search_results_touchstart = function(evt) {
      this.touch_started = true;
      return this.search_results_mouseover(evt);
    };

    AbstractChosen.prototype.search_results_touchmove = function(evt) {
      this.touch_started = false;
      return this.search_results_mouseout(evt);
    };

    AbstractChosen.prototype.search_results_touchend = function(evt) {
      if (this.touch_started) {
        return this.search_results_mouseup(evt);
      }
    };

    AbstractChosen.prototype.outerHTML = function(element) {
      var tmp;
      if (element.outerHTML) {
        return element.outerHTML;
      }
      tmp = document.createElement("div");
      tmp.appendChild(element);
      return tmp.innerHTML;
    };

    AbstractChosen.browser_is_supported = function() {
      if (/iP(od|hone)/i.test(window.navigator.userAgent)) {
        return false;
      }
      if (/Android/i.test(window.navigator.userAgent)) {
        if (/Mobile/i.test(window.navigator.userAgent)) {
          return false;
        }
      }
      if (/IEMobile/i.test(window.navigator.userAgent)) {
        return false;
      }
      if (/Windows Phone/i.test(window.navigator.userAgent)) {
        return false;
      }
      if (/BlackBerry/i.test(window.navigator.userAgent)) {
        return false;
      }
      if (/BB10/i.test(window.navigator.userAgent)) {
        return false;
      }
      if (window.navigator.appName === "Microsoft Internet Explorer") {
        return document.documentMode >= 8;
      }
      return true;
    };

    AbstractChosen.default_multiple_text = "Select Some Options";

    AbstractChosen.default_single_text = "Select an Option";

    AbstractChosen.default_no_result_text = "No results match";

    return AbstractChosen;

  })();

  $ = jQuery;

  $.fn.extend({
    chosen: function(options) {
      if (!AbstractChosen.browser_is_supported()) {
        return this;
      }
      return this.each(function(input_field) {
        var $this, chosen;
        $this = $(this);
        chosen = $this.data('chosen');
        if (options === 'destroy') {
          if (chosen instanceof Chosen) {
            chosen.destroy();
          }
          return;
        }
        if (!(chosen instanceof Chosen)) {
          $this.data('chosen', new Chosen(this, options));
        }
      });
    }
  });

  Chosen = (function(_super) {
    __extends(Chosen, _super);

    function Chosen() {
      _ref = Chosen.__super__.constructor.apply(this, arguments);
      return _ref;
    }

    Chosen.prototype.setup = function() {
      this.form_field_jq = $(this.form_field);
      this.current_selectedIndex = this.form_field.selectedIndex;
      return this.is_rtl = this.form_field_jq.hasClass("chosen-rtl");
    };

    Chosen.prototype.set_up_html = function() {
      var container_classes, container_props;
      container_classes = ["chosen-container"];
      container_classes.push("chosen-container-" + (this.is_multiple ? "multi" : "single"));
      if (this.inherit_select_classes && this.form_field.className) {
        container_classes.push(this.form_field.className);
      }
      if (this.is_rtl) {
        container_classes.push("chosen-rtl");
      }
      container_props = {
        'class': container_classes.join(' '),
        'style': "width: " + (this.container_width()) + ";",
        'title': this.form_field.title
      };
      if (this.form_field.id.length) {
        container_props.id = this.form_field.id.replace(/[^\w]/g, '_') + "_chosen";
      }
      this.container = $("<div />", container_props);
      if (this.is_multiple) {
        this.container.html('<ul class="chosen-choices"><li class="search-field"><input type="text" value="' + this.default_text + '" class="default" autocomplete="off" style="width:25px;" /></li></ul><div class="chosen-drop"><ul class="chosen-results"></ul></div>');
      } else {
        this.container.html('<a class="chosen-single chosen-default"><span>' + this.default_text + '</span><div><b></b></div></a><div class="chosen-drop"><div class="chosen-search"><input type="text" autocomplete="off" /></div><ul class="chosen-results"></ul></div>');
      }
      this.form_field_jq.hide().after(this.container);
      this.dropdown = this.container.find('div.chosen-drop').first();
      this.search_field = this.container.find('input').first();
      this.search_results = this.container.find('ul.chosen-results').first();
      this.search_field_scale();
      this.search_no_results = this.container.find('li.no-results').first();
      if (this.is_multiple) {
        this.search_choices = this.container.find('ul.chosen-choices').first();
        this.search_container = this.container.find('li.search-field').first();
      } else {
        this.search_container = this.container.find('div.chosen-search').first();
        this.selected_item = this.container.find('.chosen-single').first();
      }
      this.results_build();
      this.set_tab_index();
      return this.set_label_behavior();
    };

    Chosen.prototype.on_ready = function() {
      return this.form_field_jq.trigger("chosen:ready", {
        chosen: this
      });
    };

    Chosen.prototype.register_observers = function() {
      var _this = this;
      this.container.bind('touchstart.chosen', function(evt) {
        _this.container_mousedown(evt);
        return evt.preventDefault();
      });
      this.container.bind('touchend.chosen', function(evt) {
        _this.container_mouseup(evt);
        return evt.preventDefault();
      });
      this.container.bind('mousedown.chosen', function(evt) {
        _this.container_mousedown(evt);
      });
      this.container.bind('mouseup.chosen', function(evt) {
        _this.container_mouseup(evt);
      });
      this.container.bind('mouseenter.chosen', function(evt) {
        _this.mouse_enter(evt);
      });
      this.container.bind('mouseleave.chosen', function(evt) {
        _this.mouse_leave(evt);
      });
      this.search_results.bind('mouseup.chosen', function(evt) {
        _this.search_results_mouseup(evt);
      });
      this.search_results.bind('mouseover.chosen', function(evt) {
        _this.search_results_mouseover(evt);
      });
      this.search_results.bind('mouseout.chosen', function(evt) {
        _this.search_results_mouseout(evt);
      });
      this.search_results.bind('mousewheel.chosen DOMMouseScroll.chosen', function(evt) {
        _this.search_results_mousewheel(evt);
      });
      this.search_results.bind('touchstart.chosen', function(evt) {
        _this.search_results_touchstart(evt);
      });
      this.search_results.bind('touchmove.chosen', function(evt) {
        _this.search_results_touchmove(evt);
      });
      this.search_results.bind('touchend.chosen', function(evt) {
        _this.search_results_touchend(evt);
      });
      this.form_field_jq.bind("chosen:updated.chosen", function(evt) {
        _this.results_update_field(evt);
      });
      this.form_field_jq.bind("chosen:activate.chosen", function(evt) {
        _this.activate_field(evt);
      });
      this.form_field_jq.bind("chosen:open.chosen", function(evt) {
        _this.container_mousedown(evt);
      });
      this.form_field_jq.bind("chosen:close.chosen", function(evt) {
        _this.input_blur(evt);
      });
      this.search_field.bind('blur.chosen', function(evt) {
        _this.input_blur(evt);
      });
      this.search_field.bind('keyup.chosen', function(evt) {
        _this.keyup_checker(evt);
      });
      this.search_field.bind('keydown.chosen', function(evt) {
        _this.keydown_checker(evt);
      });
      this.search_field.bind('focus.chosen', function(evt) {
        _this.input_focus(evt);
      });
      this.search_field.bind('cut.chosen', function(evt) {
        _this.clipboard_event_checker(evt);
      });
      this.search_field.bind('paste.chosen', function(evt) {
        _this.clipboard_event_checker(evt);
      });
      if (this.is_multiple) {
        return this.search_choices.bind('click.chosen', function(evt) {
          _this.choices_click(evt);
        });
      } else {
        return this.container.bind('click.chosen', function(evt) {
          evt.preventDefault();
        });
      }
    };

    Chosen.prototype.destroy = function() {
      $(this.container[0].ownerDocument).unbind("click.chosen", this.click_test_action);
      if (this.search_field[0].tabIndex) {
        this.form_field_jq[0].tabIndex = this.search_field[0].tabIndex;
      }
      this.container.remove();
      this.form_field_jq.removeData('chosen');
      return this.form_field_jq.show();
    };

    Chosen.prototype.search_field_disabled = function() {
      this.is_disabled = this.form_field_jq[0].disabled;
      if (this.is_disabled) {
        this.container.addClass('chosen-disabled');
        this.search_field[0].disabled = true;
        if (!this.is_multiple) {
          this.selected_item.unbind("focus.chosen", this.activate_action);
        }
        return this.close_field();
      } else {
        this.container.removeClass('chosen-disabled');
        this.search_field[0].disabled = false;
        if (!this.is_multiple) {
          return this.selected_item.bind("focus.chosen", this.activate_action);
        }
      }
    };

    Chosen.prototype.container_mousedown = function(evt) {
      if (!this.is_disabled) {
        if (evt && evt.type === "mousedown" && !this.results_showing) {
          evt.preventDefault();
        }
        if (!((evt != null) && ($(evt.target)).hasClass("search-choice-close"))) {
          if (!this.active_field) {
            if (this.is_multiple) {
              this.search_field.val("");
            }
            $(this.container[0].ownerDocument).bind('click.chosen', this.click_test_action);
            this.results_show();
          } else if (!this.is_multiple && evt && (($(evt.target)[0] === this.selected_item[0]) || $(evt.target).parents("a.chosen-single").length)) {
            evt.preventDefault();
            this.results_toggle();
          }
          return this.activate_field();
        }
      }
    };

    Chosen.prototype.container_mouseup = function(evt) {
      if (evt.target.nodeName === "ABBR" && !this.is_disabled) {
        return this.results_reset(evt);
      }
    };

    Chosen.prototype.search_results_mousewheel = function(evt) {
      var delta;
      if (evt.originalEvent) {
        delta = evt.originalEvent.deltaY || -evt.originalEvent.wheelDelta || evt.originalEvent.detail;
      }
      if (delta != null) {
        evt.preventDefault();
        if (evt.type === 'DOMMouseScroll') {
          delta = delta * 40;
        }
        return this.search_results.scrollTop(delta + this.search_results.scrollTop());
      }
    };

    Chosen.prototype.blur_test = function(evt) {
      if (!this.active_field && this.container.hasClass("chosen-container-active")) {
        return this.close_field();
      }
    };

    Chosen.prototype.close_field = function() {
      $(this.container[0].ownerDocument).unbind("click.chosen", this.click_test_action);
      this.active_field = false;
      this.results_hide();
      this.container.removeClass("chosen-container-active");
      this.clear_backstroke();
      this.show_search_field_default();
      return this.search_field_scale();
    };

    Chosen.prototype.activate_field = function() {
      this.container.addClass("chosen-container-active");
      this.active_field = true;
      this.search_field.val(this.search_field.val());
      return this.search_field.focus();
    };

    Chosen.prototype.test_active_click = function(evt) {
      var active_container;
      active_container = $(evt.target).closest('.chosen-container');
      if (active_container.length && this.container[0] === active_container[0]) {
        return this.active_field = true;
      } else {
        return this.close_field();
      }
    };

    Chosen.prototype.results_build = function() {
      this.parsing = true;
      this.selected_option_count = null;
      this.results_data = SelectParser.select_to_array(this.form_field);
      if (this.is_multiple) {
        this.search_choices.find("li.search-choice").remove();
      } else if (!this.is_multiple) {
        this.single_set_selected_text();
        if (this.disable_search || this.form_field.options.length <= this.disable_search_threshold) {
          this.search_field[0].readOnly = true;
          this.container.addClass("chosen-container-single-nosearch");
        } else {
          this.search_field[0].readOnly = false;
          this.container.removeClass("chosen-container-single-nosearch");
        }
      }
      this.update_results_content(this.results_option_build({
        first: true
      }));
      this.search_field_disabled();
      this.show_search_field_default();
      this.search_field_scale();
      return this.parsing = false;
    };

    Chosen.prototype.result_do_highlight = function(el) {
      var high_bottom, high_top, maxHeight, visible_bottom, visible_top;
      if (el.length) {
        this.result_clear_highlight();
        this.result_highlight = el;
        this.result_highlight.addClass("highlighted");
        maxHeight = parseInt(this.search_results.css("maxHeight"), 10);
        visible_top = this.search_results.scrollTop();
        visible_bottom = maxHeight + visible_top;
        high_top = this.result_highlight.position().top + this.search_results.scrollTop();
        high_bottom = high_top + this.result_highlight.outerHeight();
        if (high_bottom >= visible_bottom) {
          return this.search_results.scrollTop((high_bottom - maxHeight) > 0 ? high_bottom - maxHeight : 0);
        } else if (high_top < visible_top) {
          return this.search_results.scrollTop(high_top);
        }
      }
    };

    Chosen.prototype.result_clear_highlight = function() {
      if (this.result_highlight) {
        this.result_highlight.removeClass("highlighted");
      }
      return this.result_highlight = null;
    };

    Chosen.prototype.results_show = function() {
      if (this.is_multiple && this.max_selected_options <= this.choices_count()) {
        this.form_field_jq.trigger("chosen:maxselected", {
          chosen: this
        });
        return false;
      }
      this.container.addClass("chosen-with-drop");
      this.results_showing = true;
      this.search_field.focus();
      this.search_field.val(this.search_field.val());
      this.winnow_results();
      return this.form_field_jq.trigger("chosen:showing_dropdown", {
        chosen: this
      });
    };

    Chosen.prototype.update_results_content = function(content) {
      return this.search_results.html(content);
    };

    Chosen.prototype.results_hide = function() {
      if (this.results_showing) {
        this.result_clear_highlight();
        this.container.removeClass("chosen-with-drop");
        this.form_field_jq.trigger("chosen:hiding_dropdown", {
          chosen: this
        });
      }
      return this.results_showing = false;
    };

    Chosen.prototype.set_tab_index = function(el) {
      var ti;
      if (this.form_field.tabIndex) {
        ti = this.form_field.tabIndex;
        this.form_field.tabIndex = -1;
        return this.search_field[0].tabIndex = ti;
      }
    };

    Chosen.prototype.set_label_behavior = function() {
      var _this = this;
      this.form_field_label = this.form_field_jq.parents("label");
      if (!this.form_field_label.length && this.form_field.id.length) {
        this.form_field_label = $("label[for='" + this.form_field.id + "']");
      }
      if (this.form_field_label.length > 0) {
        return this.form_field_label.bind('click.chosen', function(evt) {
          if (_this.is_multiple) {
            return _this.container_mousedown(evt);
          } else {
            return _this.activate_field();
          }
        });
      }
    };

    Chosen.prototype.show_search_field_default = function() {
      if (this.is_multiple && this.choices_count() < 1 && !this.active_field) {
        this.search_field.val(this.default_text);
        return this.search_field.addClass("default");
      } else {
        this.search_field.val("");
        return this.search_field.removeClass("default");
      }
    };

    Chosen.prototype.search_results_mouseup = function(evt) {
      var target;
      target = $(evt.target).hasClass("active-result") ? $(evt.target) : $(evt.target).parents(".active-result").first();
      if (target.length) {
        this.result_highlight = target;
        this.result_select(evt);
        return this.search_field.focus();
      }
    };

    Chosen.prototype.search_results_mouseover = function(evt) {
      var target;
      target = $(evt.target).hasClass("active-result") ? $(evt.target) : $(evt.target).parents(".active-result").first();
      if (target) {
        return this.result_do_highlight(target);
      }
    };

    Chosen.prototype.search_results_mouseout = function(evt) {
      if ($(evt.target).hasClass("active-result" || $(evt.target).parents('.active-result').first())) {
        return this.result_clear_highlight();
      }
    };

    Chosen.prototype.choice_build = function(item) {
      var choice, close_link,
        _this = this;
      choice = $('<li />', {
        "class": "search-choice"
      }).html("<span>" + (this.choice_label(item)) + "</span>");
      if (item.disabled) {
        choice.addClass('search-choice-disabled');
      } else {
        close_link = $('<a />', {
          "class": 'search-choice-close',
          'data-option-array-index': item.array_index
        });
        close_link.bind('click.chosen', function(evt) {
          return _this.choice_destroy_link_click(evt);
        });
        choice.append(close_link);
      }
      return this.search_container.before(choice);
    };

    Chosen.prototype.choice_destroy_link_click = function(evt) {
      evt.preventDefault();
      evt.stopPropagation();
      if (!this.is_disabled) {
        return this.choice_destroy($(evt.target));
      }
    };

    Chosen.prototype.choice_destroy = function(link) {
      if (this.result_deselect(link[0].getAttribute("data-option-array-index"))) {
        this.show_search_field_default();
        if (this.is_multiple && this.choices_count() > 0 && this.search_field.val().length < 1) {
          this.results_hide();
        }
        link.parents('li').first().remove();
        return this.search_field_scale();
      }
    };

    Chosen.prototype.results_reset = function() {
      this.reset_single_select_options();
      this.form_field.options[0].selected = true;
      this.single_set_selected_text();
      this.show_search_field_default();
      this.results_reset_cleanup();
      this.form_field_jq.trigger("change");
      if (this.active_field) {
        return this.results_hide();
      }
    };

    Chosen.prototype.results_reset_cleanup = function() {
      this.current_selectedIndex = this.form_field.selectedIndex;
      return this.selected_item.find("abbr").remove();
    };

    Chosen.prototype.result_select = function(evt) {
      var high, item;
      if (this.result_highlight) {
        high = this.result_highlight;
        this.result_clear_highlight();
        if (this.is_multiple && this.max_selected_options <= this.choices_count()) {
          this.form_field_jq.trigger("chosen:maxselected", {
            chosen: this
          });
          return false;
        }
        if (this.is_multiple) {
          high.removeClass("active-result");
        } else {
          this.reset_single_select_options();
        }
        high.addClass("result-selected");
        item = this.results_data[high[0].getAttribute("data-option-array-index")];
        item.selected = true;
        this.form_field.options[item.options_index].selected = true;
        this.selected_option_count = null;
        if (this.is_multiple) {
          this.choice_build(item);
        } else {
          this.single_set_selected_text(this.choice_label(item));
        }
        if (!((evt.metaKey || evt.ctrlKey) && this.is_multiple)) {
          this.results_hide();
        }
        this.show_search_field_default();
        if (this.is_multiple || this.form_field.selectedIndex !== this.current_selectedIndex) {
          this.form_field_jq.trigger("change", {
            'selected': this.form_field.options[item.options_index].value
          });
        }
        this.current_selectedIndex = this.form_field.selectedIndex;
        evt.preventDefault();
        return this.search_field_scale();
      }
    };

    Chosen.prototype.single_set_selected_text = function(text) {
      if (text == null) {
        text = this.default_text;
      }
      if (text === this.default_text) {
        this.selected_item.addClass("chosen-default");
      } else {
        this.single_deselect_control_build();
        this.selected_item.removeClass("chosen-default");
      }
      return this.selected_item.find("span").html(text);
    };

    Chosen.prototype.result_deselect = function(pos) {
      var result_data;
      result_data = this.results_data[pos];
      if (!this.form_field.options[result_data.options_index].disabled) {
        result_data.selected = false;
        this.form_field.options[result_data.options_index].selected = false;
        this.selected_option_count = null;
        this.result_clear_highlight();
        if (this.results_showing) {
          this.winnow_results();
        }
        this.form_field_jq.trigger("change", {
          deselected: this.form_field.options[result_data.options_index].value
        });
        this.search_field_scale();
        return true;
      } else {
        return false;
      }
    };

    Chosen.prototype.single_deselect_control_build = function() {
      if (!this.allow_single_deselect) {
        return;
      }
      if (!this.selected_item.find("abbr").length) {
        this.selected_item.find("span").first().after("<abbr class=\"search-choice-close\"></abbr>");
      }
      return this.selected_item.addClass("chosen-single-with-deselect");
    };

    Chosen.prototype.get_search_text = function() {
      return $('<div/>').text($.trim(this.search_field.val())).html();
    };

    Chosen.prototype.winnow_results_set_highlight = function() {
      var do_high, selected_results;
      selected_results = !this.is_multiple ? this.search_results.find(".result-selected.active-result") : [];
      do_high = selected_results.length ? selected_results.first() : this.search_results.find(".active-result").first();
      if (do_high != null) {
        return this.result_do_highlight(do_high);
      }
    };

    Chosen.prototype.no_results = function(terms) {
      var no_results_html;
      no_results_html = $('<li class="no-results">' + this.results_none_found + ' "<span></span>"</li>');
      no_results_html.find("span").first().html(terms);
      this.search_results.append(no_results_html);
      return this.form_field_jq.trigger("chosen:no_results", {
        chosen: this
      });
    };

    Chosen.prototype.no_results_clear = function() {
      return this.search_results.find(".no-results").remove();
    };

    Chosen.prototype.keydown_arrow = function() {
      var next_sib;
      if (this.results_showing && this.result_highlight) {
        next_sib = this.result_highlight.nextAll("li.active-result").first();
        if (next_sib) {
          return this.result_do_highlight(next_sib);
        }
      } else {
        return this.results_show();
      }
    };

    Chosen.prototype.keyup_arrow = function() {
      var prev_sibs;
      if (!this.results_showing && !this.is_multiple) {
        return this.results_show();
      } else if (this.result_highlight) {
        prev_sibs = this.result_highlight.prevAll("li.active-result");
        if (prev_sibs.length) {
          return this.result_do_highlight(prev_sibs.first());
        } else {
          if (this.choices_count() > 0) {
            this.results_hide();
          }
          return this.result_clear_highlight();
        }
      }
    };

    Chosen.prototype.keydown_backstroke = function() {
      var next_available_destroy;
      if (this.pending_backstroke) {
        this.choice_destroy(this.pending_backstroke.find("a").first());
        return this.clear_backstroke();
      } else {
        next_available_destroy = this.search_container.siblings("li.search-choice").last();
        if (next_available_destroy.length && !next_available_destroy.hasClass("search-choice-disabled")) {
          this.pending_backstroke = next_available_destroy;
          if (this.single_backstroke_delete) {
            return this.keydown_backstroke();
          } else {
            return this.pending_backstroke.addClass("search-choice-focus");
          }
        }
      }
    };

    Chosen.prototype.clear_backstroke = function() {
      if (this.pending_backstroke) {
        this.pending_backstroke.removeClass("search-choice-focus");
      }
      return this.pending_backstroke = null;
    };

    Chosen.prototype.keydown_checker = function(evt) {
      var stroke, _ref1;
      stroke = (_ref1 = evt.which) != null ? _ref1 : evt.keyCode;
      this.search_field_scale();
      if (stroke !== 8 && this.pending_backstroke) {
        this.clear_backstroke();
      }
      switch (stroke) {
        case 8:
          this.backstroke_length = this.search_field.val().length;
          break;
        case 9:
          if (this.results_showing && !this.is_multiple) {
            this.result_select(evt);
          }
          this.mouse_on_container = false;
          break;
        case 13:
          if (this.results_showing) {
            evt.preventDefault();
          }
          break;
        case 32:
          if (this.disable_search) {
            evt.preventDefault();
          }
          break;
        case 38:
          evt.preventDefault();
          this.keyup_arrow();
          break;
        case 40:
          evt.preventDefault();
          this.keydown_arrow();
          break;
      }
    };

    Chosen.prototype.search_field_scale = function() {
      var div, f_width, h, style, style_block, styles, w, _i, _len;
      if (this.is_multiple) {
        h = 0;
        w = 0;
        style_block = "position:absolute; left: -1000px; top: -1000px; display:none;";
        styles = ['font-size', 'font-style', 'font-weight', 'font-family', 'line-height', 'text-transform', 'letter-spacing'];
        for (_i = 0, _len = styles.length; _i < _len; _i++) {
          style = styles[_i];
          style_block += style + ":" + this.search_field.css(style) + ";";
        }
        div = $('<div />', {
          'style': style_block
        });
        div.text(this.search_field.val());
        $('body').append(div);
        w = div.width() + 25;
        div.remove();
        f_width = this.container.outerWidth();
        if (w > f_width - 10) {
          w = f_width - 10;
        }
        return this.search_field.css({
          'width': w + 'px'
        });
      }
    };

    return Chosen;

  })(AbstractChosen);

}).call(this);
;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function (Drupal, debounce) {
  var liveElement;
  var announcements = [];
  Drupal.behaviors.drupalAnnounce = {
    attach: function attach(context) {
      if (!liveElement) {
        liveElement = document.createElement('div');
        liveElement.id = 'drupal-live-announce';
        liveElement.className = 'visually-hidden';
        liveElement.setAttribute('aria-live', 'polite');
        liveElement.setAttribute('aria-busy', 'false');
        document.body.appendChild(liveElement);
      }
    }
  };

  function announce() {
    var text = [];
    var priority = 'polite';
    var announcement;
    var il = announcements.length;

    for (var i = 0; i < il; i++) {
      announcement = announcements.pop();
      text.unshift(announcement.text);

      if (announcement.priority === 'assertive') {
        priority = 'assertive';
      }
    }

    if (text.length) {
      liveElement.innerHTML = '';
      liveElement.setAttribute('aria-busy', 'true');
      liveElement.setAttribute('aria-live', priority);
      liveElement.innerHTML = text.join('\n');
      liveElement.setAttribute('aria-busy', 'false');
    }
  }

  Drupal.announce = function (text, priority) {
    announcements.push({
      text: text,
      priority: priority
    });
    return debounce(announce, 200)();
  };
})(Drupal, Drupal.debounce);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, Drupal, drupalSettings) {
  var activeItem = Drupal.url(drupalSettings.path.currentPath);

  $.fn.drupalToolbarMenu = function () {
    var ui = {
      handleOpen: Drupal.t('Extend'),
      handleClose: Drupal.t('Collapse')
    };

    function toggleList($item, switcher) {
      var $toggle = $item.children('.toolbar-box').children('.toolbar-handle');
      switcher = typeof switcher !== 'undefined' ? switcher : !$item.hasClass('open');
      $item.toggleClass('open', switcher);
      $toggle.toggleClass('open', switcher);
      $toggle.find('.action').text(switcher ? ui.handleClose : ui.handleOpen);
    }

    function toggleClickHandler(event) {
      var $toggle = $(event.target);
      var $item = $toggle.closest('li');
      toggleList($item);
      var $openItems = $item.siblings().filter('.open');
      toggleList($openItems, false);
    }

    function linkClickHandler(event) {
      if (!Drupal.toolbar.models.toolbarModel.get('isFixed')) {
        Drupal.toolbar.models.toolbarModel.set('activeTab', null);
      }

      event.stopPropagation();
    }

    function initItems($menu) {
      var options = {
        class: 'toolbar-icon toolbar-handle',
        action: ui.handleOpen,
        text: ''
      };
      $menu.find('li > a').wrap('<div class="toolbar-box">');
      $menu.find('li').each(function (index, element) {
        var $item = $(element);

        if ($item.children('ul.toolbar-menu').length) {
          var $box = $item.children('.toolbar-box');
          options.text = Drupal.t('@label', {
            '@label': $box.find('a').text()
          });
          $item.children('.toolbar-box').append(Drupal.theme('toolbarMenuItemToggle', options));
        }
      });
    }

    function markListLevels($lists, level) {
      level = !level ? 1 : level;
      var $lis = $lists.children('li').addClass("level-".concat(level));
      $lists = $lis.children('ul');

      if ($lists.length) {
        markListLevels($lists, level + 1);
      }
    }

    function openActiveItem($menu) {
      var pathItem = $menu.find("a[href=\"".concat(window.location.pathname, "\"]"));

      if (pathItem.length && !activeItem) {
        activeItem = window.location.pathname;
      }

      if (activeItem) {
        var $activeItem = $menu.find("a[href=\"".concat(activeItem, "\"]")).addClass('menu-item--active');
        var $activeTrail = $activeItem.parentsUntil('.root', 'li').addClass('menu-item--active-trail');
        toggleList($activeTrail, true);
      }
    }

    return this.each(function (selector) {
      var menu = once('toolbar-menu', this);

      if (menu.length) {
        var $menu = $(menu);
        $menu.on('click.toolbar', '.toolbar-box', toggleClickHandler).on('click.toolbar', '.toolbar-box a', linkClickHandler);
        $menu.addClass('root');
        initItems($menu);
        markListLevels($menu);
        openActiveItem($menu);
      }
    });
  };

  Drupal.theme.toolbarMenuItemToggle = function (options) {
    return "<button class=\"".concat(options.class, "\"><span class=\"action\">").concat(options.action, "</span> <span class=\"label\">").concat(options.text, "</span></button>");
  };
})(jQuery, Drupal, drupalSettings);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, Drupal, drupalSettings) {
  var options = $.extend({
    breakpoints: {
      'toolbar.narrow': '',
      'toolbar.standard': '',
      'toolbar.wide': ''
    }
  }, drupalSettings.toolbar, {
    strings: {
      horizontal: Drupal.t('Horizontal orientation'),
      vertical: Drupal.t('Vertical orientation')
    }
  });
  Drupal.behaviors.toolbar = {
    attach: function attach(context) {
      if (!window.matchMedia('only screen').matches) {
        return;
      }

      once('toolbar', '#toolbar-administration', context).forEach(function (toolbar) {
        var model = new Drupal.toolbar.ToolbarModel({
          locked: JSON.parse(localStorage.getItem('Drupal.toolbar.trayVerticalLocked')),
          activeTab: document.getElementById(JSON.parse(localStorage.getItem('Drupal.toolbar.activeTabID'))),
          height: $('#toolbar-administration').outerHeight()
        });
        Drupal.toolbar.models.toolbarModel = model;
        Object.keys(options.breakpoints).forEach(function (label) {
          var mq = options.breakpoints[label];
          var mql = window.matchMedia(mq);
          Drupal.toolbar.mql[label] = mql;
          mql.addListener(Drupal.toolbar.mediaQueryChangeHandler.bind(null, model, label));
          Drupal.toolbar.mediaQueryChangeHandler.call(null, model, label, mql);
        });
        Drupal.toolbar.views.toolbarVisualView = new Drupal.toolbar.ToolbarVisualView({
          el: toolbar,
          model: model,
          strings: options.strings
        });
        Drupal.toolbar.views.toolbarAuralView = new Drupal.toolbar.ToolbarAuralView({
          el: toolbar,
          model: model,
          strings: options.strings
        });
        Drupal.toolbar.views.bodyVisualView = new Drupal.toolbar.BodyVisualView({
          el: toolbar,
          model: model
        });
        model.trigger('change:isFixed', model, model.get('isFixed'));
        model.trigger('change:activeTray', model, model.get('activeTray'));
        var menuModel = new Drupal.toolbar.MenuModel();
        Drupal.toolbar.models.menuModel = menuModel;
        Drupal.toolbar.views.menuVisualView = new Drupal.toolbar.MenuVisualView({
          el: $(toolbar).find('.toolbar-menu-administration').get(0),
          model: menuModel,
          strings: options.strings
        });
        Drupal.toolbar.setSubtrees.done(function (subtrees) {
          menuModel.set('subtrees', subtrees);
          var theme = drupalSettings.ajaxPageState.theme;
          localStorage.setItem("Drupal.toolbar.subtrees.".concat(theme), JSON.stringify(subtrees));
          model.set('areSubtreesLoaded', true);
        });
        Drupal.toolbar.views.toolbarVisualView.loadSubtrees();
        $(document).on('drupalViewportOffsetChange.toolbar', function (event, offsets) {
          model.set('offsets', offsets);
        });
        model.on('change:orientation', function (model, orientation) {
          $(document).trigger('drupalToolbarOrientationChange', orientation);
        }).on('change:activeTab', function (model, tab) {
          $(document).trigger('drupalToolbarTabChange', tab);
        }).on('change:activeTray', function (model, tray) {
          $(document).trigger('drupalToolbarTrayChange', tray);
        });

        if (Drupal.toolbar.models.toolbarModel.get('orientation') === 'horizontal' && Drupal.toolbar.models.toolbarModel.get('activeTab') === null) {
          Drupal.toolbar.models.toolbarModel.set({
            activeTab: $('.toolbar-bar .toolbar-tab:not(.home-toolbar-tab) a').get(0)
          });
        }

        $(window).on({
          'dialog:aftercreate': function dialogAftercreate(event, dialog, $element, settings) {
            var $toolbar = $('#toolbar-bar');
            $toolbar.css('margin-top', '0');

            if (settings.drupalOffCanvasPosition === 'top') {
              var height = Drupal.offCanvas.getContainer($element).outerHeight();
              $toolbar.css('margin-top', "".concat(height, "px"));
              $element.on('dialogContentResize.off-canvas', function () {
                var newHeight = Drupal.offCanvas.getContainer($element).outerHeight();
                $toolbar.css('margin-top', "".concat(newHeight, "px"));
              });
            }
          },
          'dialog:beforeclose': function dialogBeforeclose() {
            $('#toolbar-bar').css('margin-top', '0');
          }
        });
      });
    }
  };
  Drupal.toolbar = {
    views: {},
    models: {},
    mql: {},
    setSubtrees: new $.Deferred(),
    mediaQueryChangeHandler: function mediaQueryChangeHandler(model, label, mql) {
      switch (label) {
        case 'toolbar.narrow':
          model.set({
            isOriented: mql.matches,
            isTrayToggleVisible: false
          });

          if (!mql.matches || !model.get('orientation')) {
            model.set({
              orientation: 'vertical'
            }, {
              validate: true
            });
          }

          break;

        case 'toolbar.standard':
          model.set({
            isFixed: mql.matches
          });
          break;

        case 'toolbar.wide':
          model.set({
            orientation: mql.matches && !model.get('locked') ? 'horizontal' : 'vertical'
          }, {
            validate: true
          });
          model.set({
            isTrayToggleVisible: mql.matches
          });
          break;

        default:
          break;
      }
    }
  };

  Drupal.theme.toolbarOrientationToggle = function () {
    return '<div class="toolbar-toggle-orientation"><div class="toolbar-lining">' + '<button class="toolbar-icon" type="button"></button>' + '</div></div>';
  };

  Drupal.AjaxCommands.prototype.setToolbarSubtrees = function (ajax, response, status) {
    Drupal.toolbar.setSubtrees.resolve(response.subtrees);
  };
})(jQuery, Drupal, drupalSettings);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function (Backbone, Drupal) {
  Drupal.toolbar.MenuModel = Backbone.Model.extend({
    defaults: {
      subtrees: {}
    }
  });
})(Backbone, Drupal);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function (Backbone, Drupal) {
  Drupal.toolbar.ToolbarModel = Backbone.Model.extend({
    defaults: {
      activeTab: null,
      activeTray: null,
      isOriented: false,
      isFixed: false,
      areSubtreesLoaded: false,
      isViewportOverflowConstrained: false,
      orientation: 'horizontal',
      locked: false,
      isTrayToggleVisible: true,
      height: null,
      offsets: {
        top: 0,
        right: 0,
        bottom: 0,
        left: 0
      }
    },
    validate: function validate(attributes, options) {
      if (attributes.orientation === 'horizontal' && this.get('locked') && !options.override) {
        return Drupal.t('The toolbar cannot be set to a horizontal orientation when it is locked.');
      }
    }
  });
})(Backbone, Drupal);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, Drupal, Backbone) {
  Drupal.toolbar.BodyVisualView = Backbone.View.extend({
    initialize: function initialize() {
      this.listenTo(this.model, 'change:activeTray ', this.render);
      this.listenTo(this.model, 'change:isFixed change:isViewportOverflowConstrained', this.isToolbarFixed);
    },
    isToolbarFixed: function isToolbarFixed() {
      var isViewportOverflowConstrained = this.model.get('isViewportOverflowConstrained');
      $('body').toggleClass('toolbar-fixed', isViewportOverflowConstrained || this.model.get('isFixed'));
    },
    render: function render() {
      $('body').toggleClass('toolbar-tray-open', !!this.model.get('activeTray'));
    }
  });
})(jQuery, Drupal, Backbone);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, Backbone, Drupal) {
  Drupal.toolbar.MenuVisualView = Backbone.View.extend({
    initialize: function initialize() {
      this.listenTo(this.model, 'change:subtrees', this.render);
    },
    render: function render() {
      var _this = this;

      var subtrees = this.model.get('subtrees');
      Object.keys(subtrees || {}).forEach(function (id) {
        $(once('toolbar-subtrees', _this.$el.find("#toolbar-link-".concat(id)))).after(subtrees[id]);
      });

      if ('drupalToolbarMenu' in $.fn) {
        this.$el.children('.toolbar-menu').drupalToolbarMenu();
      }
    }
  });
})(jQuery, Backbone, Drupal);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function (Backbone, Drupal) {
  Drupal.toolbar.ToolbarAuralView = Backbone.View.extend({
    initialize: function initialize(options) {
      this.strings = options.strings;
      this.listenTo(this.model, 'change:orientation', this.onOrientationChange);
      this.listenTo(this.model, 'change:activeTray', this.onActiveTrayChange);
    },
    onOrientationChange: function onOrientationChange(model, orientation) {
      Drupal.announce(Drupal.t('Tray orientation changed to @orientation.', {
        '@orientation': orientation
      }));
    },
    onActiveTrayChange: function onActiveTrayChange(model, tray) {
      var relevantTray = tray === null ? model.previous('activeTray') : tray;

      if (!relevantTray) {
        return;
      }

      var action = tray === null ? Drupal.t('closed') : Drupal.t('opened');
      var trayNameElement = relevantTray.querySelector('.toolbar-tray-name');
      var text;

      if (trayNameElement !== null) {
        text = Drupal.t('Tray "@tray" @action.', {
          '@tray': trayNameElement.textContent,
          '@action': action
        });
      } else {
        text = Drupal.t('Tray @action.', {
          '@action': action
        });
      }

      Drupal.announce(text);
    }
  });
})(Backbone, Drupal);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, Drupal, drupalSettings, Backbone) {
  Drupal.toolbar.ToolbarVisualView = Backbone.View.extend({
    events: function events() {
      var touchEndToClick = function touchEndToClick(event) {
        event.preventDefault();
        event.target.click();
      };

      return {
        'click .toolbar-bar .toolbar-tab .trigger': 'onTabClick',
        'click .toolbar-toggle-orientation button': 'onOrientationToggleClick',
        'touchend .toolbar-bar .toolbar-tab .trigger': touchEndToClick,
        'touchend .toolbar-toggle-orientation button': touchEndToClick
      };
    },
    initialize: function initialize(options) {
      this.strings = options.strings;
      this.listenTo(this.model, 'change:activeTab change:orientation change:isOriented change:isTrayToggleVisible', this.render);
      this.listenTo(this.model, 'change:mqMatches', this.onMediaQueryChange);
      this.listenTo(this.model, 'change:offsets', this.adjustPlacement);
      this.listenTo(this.model, 'change:activeTab change:orientation change:isOriented', this.updateToolbarHeight);
      this.$el.find('.toolbar-tray .toolbar-lining').append(Drupal.theme('toolbarOrientationToggle'));
      this.model.trigger('change:activeTab');
    },
    updateToolbarHeight: function updateToolbarHeight() {
      var toolbarTabOuterHeight = $('#toolbar-bar').find('.toolbar-tab').outerHeight() || 0;
      var toolbarTrayHorizontalOuterHeight = $('.is-active.toolbar-tray-horizontal').outerHeight() || 0;
      this.model.set('height', toolbarTabOuterHeight + toolbarTrayHorizontalOuterHeight);
      $('body').css({
        'padding-top': this.model.get('height')
      });
      $('html').css({
        'scroll-padding-top': this.model.get('height')
      });
      this.triggerDisplace();
    },
    triggerDisplace: function triggerDisplace() {
      _.defer(function () {
        Drupal.displace(true);
      });
    },
    render: function render() {
      this.updateTabs();
      this.updateTrayOrientation();
      this.updateBarAttributes();
      $('body').removeClass('toolbar-loading');

      if (this.model.changed.orientation === 'vertical' || this.model.changed.activeTab) {
        this.loadSubtrees();
      }

      return this;
    },
    onTabClick: function onTabClick(event) {
      if (event.currentTarget.hasAttribute('data-toolbar-tray')) {
        var activeTab = this.model.get('activeTab');
        var clickedTab = event.currentTarget;
        this.model.set('activeTab', !activeTab || clickedTab !== activeTab ? clickedTab : null);
        event.preventDefault();
        event.stopPropagation();
      }
    },
    onOrientationToggleClick: function onOrientationToggleClick(event) {
      var orientation = this.model.get('orientation');
      var antiOrientation = orientation === 'vertical' ? 'horizontal' : 'vertical';
      var locked = antiOrientation === 'vertical';

      if (locked) {
        localStorage.setItem('Drupal.toolbar.trayVerticalLocked', 'true');
      } else {
        localStorage.removeItem('Drupal.toolbar.trayVerticalLocked');
      }

      this.model.set({
        locked: locked,
        orientation: antiOrientation
      }, {
        validate: true,
        override: true
      });
      event.preventDefault();
      event.stopPropagation();
    },
    updateTabs: function updateTabs() {
      var $tab = $(this.model.get('activeTab'));
      $(this.model.previous('activeTab')).removeClass('is-active').prop('aria-pressed', false);
      $(this.model.previous('activeTray')).removeClass('is-active');

      if ($tab.length > 0) {
        $tab.addClass('is-active').prop('aria-pressed', true);
        var name = $tab.attr('data-toolbar-tray');
        var id = $tab.get(0).id;

        if (id) {
          localStorage.setItem('Drupal.toolbar.activeTabID', JSON.stringify(id));
        }

        var $tray = this.$el.find("[data-toolbar-tray=\"".concat(name, "\"].toolbar-tray"));

        if ($tray.length) {
          $tray.addClass('is-active');
          this.model.set('activeTray', $tray.get(0));
        } else {
          this.model.set('activeTray', null);
        }
      } else {
        this.model.set('activeTray', null);
        localStorage.removeItem('Drupal.toolbar.activeTabID');
      }
    },
    updateBarAttributes: function updateBarAttributes() {
      var isOriented = this.model.get('isOriented');

      if (isOriented) {
        this.$el.find('.toolbar-bar').attr('data-offset-top', '');
      } else {
        this.$el.find('.toolbar-bar').removeAttr('data-offset-top');
      }

      this.$el.toggleClass('toolbar-oriented', isOriented);
    },
    updateTrayOrientation: function updateTrayOrientation() {
      var orientation = this.model.get('orientation');
      var antiOrientation = orientation === 'vertical' ? 'horizontal' : 'vertical';
      $('body').toggleClass('toolbar-vertical', orientation === 'vertical').toggleClass('toolbar-horizontal', orientation === 'horizontal');
      var removeClass = antiOrientation === 'horizontal' ? 'toolbar-tray-horizontal' : 'toolbar-tray-vertical';
      var $trays = this.$el.find('.toolbar-tray').removeClass(removeClass).addClass("toolbar-tray-".concat(orientation));
      var iconClass = "toolbar-icon-toggle-".concat(orientation);
      var iconAntiClass = "toolbar-icon-toggle-".concat(antiOrientation);
      var $orientationToggle = this.$el.find('.toolbar-toggle-orientation').toggle(this.model.get('isTrayToggleVisible'));
      $orientationToggle.find('button').val(antiOrientation).attr('title', this.strings[antiOrientation]).text(this.strings[antiOrientation]).removeClass(iconClass).addClass(iconAntiClass);
      var dir = document.documentElement.dir;
      var edge = dir === 'rtl' ? 'right' : 'left';
      $trays.removeAttr('data-offset-left data-offset-right data-offset-top');
      $trays.filter('.toolbar-tray-vertical.is-active').attr("data-offset-".concat(edge), '');
      $trays.filter('.toolbar-tray-horizontal.is-active').attr('data-offset-top', '');
    },
    adjustPlacement: function adjustPlacement() {
      var $trays = this.$el.find('.toolbar-tray');

      if (!this.model.get('isOriented')) {
        $trays.removeClass('toolbar-tray-horizontal').addClass('toolbar-tray-vertical');
      }
    },
    loadSubtrees: function loadSubtrees() {
      var $activeTab = $(this.model.get('activeTab'));
      var orientation = this.model.get('orientation');

      if (!this.model.get('areSubtreesLoaded') && typeof $activeTab.data('drupal-subtrees') !== 'undefined' && orientation === 'vertical') {
        var subtreesHash = drupalSettings.toolbar.subtreesHash;
        var theme = drupalSettings.ajaxPageState.theme;
        var endpoint = Drupal.url("toolbar/subtrees/".concat(subtreesHash));
        var cachedSubtreesHash = localStorage.getItem("Drupal.toolbar.subtreesHash.".concat(theme));
        var cachedSubtrees = JSON.parse(localStorage.getItem("Drupal.toolbar.subtrees.".concat(theme)));
        var isVertical = this.model.get('orientation') === 'vertical';

        if (isVertical && subtreesHash === cachedSubtreesHash && cachedSubtrees) {
          Drupal.toolbar.setSubtrees.resolve(cachedSubtrees);
        } else if (isVertical) {
          localStorage.removeItem("Drupal.toolbar.subtreesHash.".concat(theme));
          localStorage.removeItem("Drupal.toolbar.subtrees.".concat(theme));
          Drupal.ajax({
            url: endpoint
          }).execute();
          localStorage.setItem("Drupal.toolbar.subtreesHash.".concat(theme), subtreesHash);
        }
      }
    }
  });
})(jQuery, Drupal, drupalSettings, Backbone);;
/**
 * @file
 * Javascript for the NIR Toolbar.
 *
 */

(function ($, Drupal) {
  'use strict';

  Drupal.behaviors.nirToolbarNav = {
    attach: function (context, settings) {
      $('#toolbar-bar > ul > li a').once().click(function (e) {
        $(this).toggleClass('menu-open');
        $('#toolbar-bar > ul > li a').not($(this)).removeClass('menu-open');
        var subMenu = $(this).parent().find('ul');
        $('#toolbar-bar > ul > li ul').not(subMenu).removeClass('visually-hidden--off');
        $(subMenu).toggleClass('visually-hidden--off');
        if (subMenu.length > 0) {
          e.preventDefault();
        }
      });
      $('.toolbar-item > a:not(".help-tab")').once().click(function (e) {
        $(this).toggleClass('menu-open');
        $('.toolbar-item a').not($(this)).not('.local-tasks-tab').removeClass('menu-open');
        var tray = $(this).next('ul');
        $('.toolbar-item > ul').not(tray).removeClass('visually-hidden--off');
        $(tray).toggleClass('visually-hidden--off');
        if (!($(this).parent().hasClass('help-tab'))) {
          e.preventDefault();
        }
      });

      var $toolbarToggle = $(".toolbar--toggle", context);
      if ($toolbarToggle.length > 0) {
        $toolbarToggle.once().off('click').on('click', function(e) {
          e.preventDefault();
          $(".toolbar--wrapper").slideToggle();
          $(this).toggleClass('toolbar--toggle--closed').toggleClass('toolbar--toggle--open');
          if ($(this).hasClass('toolbar--toggle--closed')) {
            $(this).find('a').attr('title', Drupal.t('Show Toolbar'));
            $(this).find('span').text(Drupal.t('Show Toolbar'));
          }
          else {
            $(this).find('a').attr('title', Drupal.t('Hide Toolbar'));
            $(this).find('span').text(Drupal.t('Hide Toolbar'));
          }
          $('.local-tasks-sidebar--wrapper').toggleClass('toolbar--closed');
        });
      }

      var $sidebarToggle = $(".local-tasks-sidebar--toggle", context);
      if ($sidebarToggle.length > 0) {
        $('body', context).addClass('local-tasks-sidebar--toggle--open');
        $sidebarToggle.off('click').on('click', function(e) {
          e.preventDefault();
          var sideBar = $(".local-tasks-sidebar--wrapper");
          var wrapperClosedClass = 'local-tasks-sidebar--wrapper--closed';
          if (sideBar.hasClass(wrapperClosedClass)) {
            sideBar.removeClass(wrapperClosedClass);
          }
          else {
            sideBar.addClass(wrapperClosedClass);
          }
          $(this).toggleClass('local-tasks-sidebar--toggle--open').toggleClass('local-tasks-sidebar--toggle--closed');
          $('body').toggleClass('local-tasks-sidebar--toggle--closed')
            .toggleClass('local-tasks-sidebar--toggle--open');
          if ($(this).hasClass('local-tasks-sidebar--toggle--open')) {
            $(this).find('a').attr('title', Drupal.t('Hide Local Tasks'));
            $(this).find('span').find('span').text(Drupal.t('Hide Local Tasks'));
          }
          else {
            $(this).find('a').attr('title', Drupal.t('Show Local Tasks'));
            $(this).find('span').find('span').text(Drupal.t('Show Local Tasks'));
          }
        });
      }
    }
  };

})(jQuery, Drupal);
;
document.querySelectorAll("a.nav-link").forEach($link => {
  const url = new URL($link.href);
  if (url.href === location.href) {
    $link.classList.add("active");
  }
});

document.querySelector(".menu-button").addEventListener("click", () => {
  document.querySelector(".menu").classList.toggle("hidden");
});

document.querySelectorAll(".select").forEach($selectWrapper => {
  const $select = $selectWrapper.querySelector("select");
  const render = () => {
    $selectWrapper.querySelector("span").innerText = $select.options[$select.selectedIndex].text;
  };
  render();
  $select.addEventListener("change", render);
});

document.querySelectorAll(".page .question").forEach($question =>
  $question.querySelector("h4").addEventListener("click", () => {
    $question.classList.toggle("expanded");
  }),
);;
/**
 * Owl Carousel v2.3.4
 * Copyright 2013-2018 David Deutsch
 * Licensed under: SEE LICENSE IN https://github.com/OwlCarousel2/OwlCarousel2/blob/master/LICENSE
 */
!function(a,b,c,d){function e(b,c){this.settings=null,this.options=a.extend({},e.Defaults,c),this.$element=a(b),this._handlers={},this._plugins={},this._supress={},this._current=null,this._speed=null,this._coordinates=[],this._breakpoint=null,this._width=null,this._items=[],this._clones=[],this._mergers=[],this._widths=[],this._invalidated={},this._pipe=[],this._drag={time:null,target:null,pointer:null,stage:{start:null,current:null},direction:null},this._states={current:{},tags:{initializing:["busy"],animating:["busy"],dragging:["interacting"]}},a.each(["onResize","onThrottledResize"],a.proxy(function(b,c){this._handlers[c]=a.proxy(this[c],this)},this)),a.each(e.Plugins,a.proxy(function(a,b){this._plugins[a.charAt(0).toLowerCase()+a.slice(1)]=new b(this)},this)),a.each(e.Workers,a.proxy(function(b,c){this._pipe.push({filter:c.filter,run:a.proxy(c.run,this)})},this)),this.setup(),this.initialize()}e.Defaults={items:3,loop:!1,center:!1,rewind:!1,checkVisibility:!0,mouseDrag:!0,touchDrag:!0,pullDrag:!0,freeDrag:!1,margin:0,stagePadding:0,merge:!1,mergeFit:!0,autoWidth:!1,startPosition:0,rtl:!1,smartSpeed:250,fluidSpeed:!1,dragEndSpeed:!1,responsive:{},responsiveRefreshRate:200,responsiveBaseElement:b,fallbackEasing:"swing",slideTransition:"",info:!1,nestedItemSelector:!1,itemElement:"div",stageElement:"div",refreshClass:"owl-refresh",loadedClass:"owl-loaded",loadingClass:"owl-loading",rtlClass:"owl-rtl",responsiveClass:"owl-responsive",dragClass:"owl-drag",itemClass:"owl-item",stageClass:"owl-stage sameH",stageOuterClass:"owl-stage-outer",grabClass:"owl-grab"},e.Width={Default:"default",Inner:"inner",Outer:"outer"},e.Type={Event:"event",State:"state"},e.Plugins={},e.Workers=[{filter:["width","settings"],run:function(){this._width=this.$element.width()}},{filter:["width","items","settings"],run:function(a){a.current=this._items&&this._items[this.relative(this._current)]}},{filter:["items","settings"],run:function(){this.$stage.children(".cloned").remove()}},{filter:["width","items","settings"],run:function(a){var b=this.settings.margin||"",c=!this.settings.autoWidth,d=this.settings.rtl,e={width:"auto","margin-left":d?b:"","margin-right":d?"":b};!c&&this.$stage.children().css(e),a.css=e}},{filter:["width","items","settings"],run:function(a){var b=(this.width()/this.settings.items).toFixed(3)-this.settings.margin,c=null,d=this._items.length,e=!this.settings.autoWidth,f=[];for(a.items={merge:!1,width:b};d--;)c=this._mergers[d],c=this.settings.mergeFit&&Math.min(c,this.settings.items)||c,a.items.merge=c>1||a.items.merge,f[d]=e?b*c:this._items[d].width();this._widths=f}},{filter:["items","settings"],run:function(){var b=[],c=this._items,d=this.settings,e=Math.max(2*d.items,4),f=2*Math.ceil(c.length/2),g=d.loop&&c.length?d.rewind?e:Math.max(e,f):0,h="",i="";for(g/=2;g>0;)b.push(this.normalize(b.length/2,!0)),h+=c[b[b.length-1]][0].outerHTML,b.push(this.normalize(c.length-1-(b.length-1)/2,!0)),i=c[b[b.length-1]][0].outerHTML+i,g-=1;this._clones=b,a(h).addClass("cloned").appendTo(this.$stage),a(i).addClass("cloned").prependTo(this.$stage)}},{filter:["width","items","settings"],run:function(){for(var a=this.settings.rtl?1:-1,b=this._clones.length+this._items.length,c=-1,d=0,e=0,f=[];++c<b;)d=f[c-1]||0,e=this._widths[this.relative(c)]+this.settings.margin,f.push(d+e*a);this._coordinates=f}},{filter:["width","items","settings"],run:function(){var a=this.settings.stagePadding,b=this._coordinates,c={width:Math.ceil(Math.abs(b[b.length-1]))+2*a,"padding-left":a||"","padding-right":a||""};this.$stage.css(c)}},{filter:["width","items","settings"],run:function(a){var b=this._coordinates.length,c=!this.settings.autoWidth,d=this.$stage.children();if(c&&a.items.merge)for(;b--;)a.css.width=this._widths[this.relative(b)],d.eq(b).css(a.css);else c&&(a.css.width=a.items.width,d.css(a.css))}},{filter:["items"],run:function(){this._coordinates.length<1&&this.$stage.removeAttr("style")}},{filter:["width","items","settings"],run:function(a){a.current=a.current?this.$stage.children().index(a.current):0,a.current=Math.max(this.minimum(),Math.min(this.maximum(),a.current)),this.reset(a.current)}},{filter:["position"],run:function(){this.animate(this.coordinates(this._current))}},{filter:["width","position","items","settings"],run:function(){var a,b,c,d,e=this.settings.rtl?1:-1,f=2*this.settings.stagePadding,g=this.coordinates(this.current())+f,h=g+this.width()*e,i=[];for(c=0,d=this._coordinates.length;c<d;c++)a=this._coordinates[c-1]||0,b=Math.abs(this._coordinates[c])+f*e,(this.op(a,"<=",g)&&this.op(a,">",h)||this.op(b,"<",g)&&this.op(b,">",h))&&i.push(c);this.$stage.children(".active").removeClass("active"),this.$stage.children(":eq("+i.join("), :eq(")+")").addClass("active"),this.$stage.children(".center").removeClass("center"),this.settings.center&&this.$stage.children().eq(this.current()).addClass("center")}}],e.prototype.initializeStage=function(){this.$stage=this.$element.find("."+this.settings.stageClass),this.$stage.length||(this.$element.addClass(this.options.loadingClass),this.$stage=a("<"+this.settings.stageElement+">",{class:this.settings.stageClass}).wrap(a("<div/>",{class:this.settings.stageOuterClass})),this.$element.append(this.$stage.parent()))},e.prototype.initializeItems=function(){var b=this.$element.find(".owl-item");if(b.length)return this._items=b.get().map(function(b){return a(b)}),this._mergers=this._items.map(function(){return 1}),void this.refresh();this.replace(this.$element.children().not(this.$stage.parent())),this.isVisible()?this.refresh():this.invalidate("width"),this.$element.removeClass(this.options.loadingClass).addClass(this.options.loadedClass)},e.prototype.initialize=function(){if(this.enter("initializing"),this.trigger("initialize"),this.$element.toggleClass(this.settings.rtlClass,this.settings.rtl),this.settings.autoWidth&&!this.is("pre-loading")){var a,b,c;a=this.$element.find("img"),b=this.settings.nestedItemSelector?"."+this.settings.nestedItemSelector:d,c=this.$element.children(b).width(),a.length&&c<=0&&this.preloadAutoWidthImages(a)}this.initializeStage(),this.initializeItems(),this.registerEventHandlers(),this.leave("initializing"),this.trigger("initialized")},e.prototype.isVisible=function(){return!this.settings.checkVisibility||this.$element.is(":visible")},e.prototype.setup=function(){var b=this.viewport(),c=this.options.responsive,d=-1,e=null;c?(a.each(c,function(a){a<=b&&a>d&&(d=Number(a))}),e=a.extend({},this.options,c[d]),"function"==typeof e.stagePadding&&(e.stagePadding=e.stagePadding()),delete e.responsive,e.responsiveClass&&this.$element.attr("class",this.$element.attr("class").replace(new RegExp("("+this.options.responsiveClass+"-)\\S+\\s","g"),"$1"+d))):e=a.extend({},this.options),this.trigger("change",{property:{name:"settings",value:e}}),this._breakpoint=d,this.settings=e,this.invalidate("settings"),this.trigger("changed",{property:{name:"settings",value:this.settings}})},e.prototype.optionsLogic=function(){this.settings.autoWidth&&(this.settings.stagePadding=!1,this.settings.merge=!1)},e.prototype.prepare=function(b){var c=this.trigger("prepare",{content:b});return c.data||(c.data=a("<"+this.settings.itemElement+"/>").addClass(this.options.itemClass).append(b)),this.trigger("prepared",{content:c.data}),c.data},e.prototype.update=function(){for(var b=0,c=this._pipe.length,d=a.proxy(function(a){return this[a]},this._invalidated),e={};b<c;)(this._invalidated.all||a.grep(this._pipe[b].filter,d).length>0)&&this._pipe[b].run(e),b++;this._invalidated={},!this.is("valid")&&this.enter("valid")},e.prototype.width=function(a){switch(a=a||e.Width.Default){case e.Width.Inner:case e.Width.Outer:return this._width;default:return this._width-2*this.settings.stagePadding+this.settings.margin}},e.prototype.refresh=function(){this.enter("refreshing"),this.trigger("refresh"),this.setup(),this.optionsLogic(),this.$element.addClass(this.options.refreshClass),this.update(),this.$element.removeClass(this.options.refreshClass),this.leave("refreshing"),this.trigger("refreshed")},e.prototype.onThrottledResize=function(){b.clearTimeout(this.resizeTimer),this.resizeTimer=b.setTimeout(this._handlers.onResize,this.settings.responsiveRefreshRate)},e.prototype.onResize=function(){return!!this._items.length&&(this._width!==this.$element.width()&&(!!this.isVisible()&&(this.enter("resizing"),this.trigger("resize").isDefaultPrevented()?(this.leave("resizing"),!1):(this.invalidate("width"),this.refresh(),this.leave("resizing"),void this.trigger("resized")))))},e.prototype.registerEventHandlers=function(){a.support.transition&&this.$stage.on(a.support.transition.end+".owl.core",a.proxy(this.onTransitionEnd,this)),!1!==this.settings.responsive&&this.on(b,"resize",this._handlers.onThrottledResize),this.settings.mouseDrag&&(this.$element.addClass(this.options.dragClass),this.$stage.on("mousedown.owl.core",a.proxy(this.onDragStart,this)),this.$stage.on("dragstart.owl.core selectstart.owl.core",function(){return!1})),this.settings.touchDrag&&(this.$stage.on("touchstart.owl.core",a.proxy(this.onDragStart,this)),this.$stage.on("touchcancel.owl.core",a.proxy(this.onDragEnd,this)))},e.prototype.onDragStart=function(b){var d=null;3!==b.which&&(a.support.transform?(d=this.$stage.css("transform").replace(/.*\(|\)| /g,"").split(","),d={x:d[16===d.length?12:4],y:d[16===d.length?13:5]}):(d=this.$stage.position(),d={x:this.settings.rtl?d.left+this.$stage.width()-this.width()+this.settings.margin:d.left,y:d.top}),this.is("animating")&&(a.support.transform?this.animate(d.x):this.$stage.stop(),this.invalidate("position")),this.$element.toggleClass(this.options.grabClass,"mousedown"===b.type),this.speed(0),this._drag.time=(new Date).getTime(),this._drag.target=a(b.target),this._drag.stage.start=d,this._drag.stage.current=d,this._drag.pointer=this.pointer(b),a(c).on("mouseup.owl.core touchend.owl.core",a.proxy(this.onDragEnd,this)),a(c).one("mousemove.owl.core touchmove.owl.core",a.proxy(function(b){var d=this.difference(this._drag.pointer,this.pointer(b));a(c).on("mousemove.owl.core touchmove.owl.core",a.proxy(this.onDragMove,this)),Math.abs(d.x)<Math.abs(d.y)&&this.is("valid")||(b.preventDefault(),this.enter("dragging"),this.trigger("drag"))},this)))},e.prototype.onDragMove=function(a){var b=null,c=null,d=null,e=this.difference(this._drag.pointer,this.pointer(a)),f=this.difference(this._drag.stage.start,e);this.is("dragging")&&(a.preventDefault(),this.settings.loop?(b=this.coordinates(this.minimum()),c=this.coordinates(this.maximum()+1)-b,f.x=((f.x-b)%c+c)%c+b):(b=this.settings.rtl?this.coordinates(this.maximum()):this.coordinates(this.minimum()),c=this.settings.rtl?this.coordinates(this.minimum()):this.coordinates(this.maximum()),d=this.settings.pullDrag?-1*e.x/5:0,f.x=Math.max(Math.min(f.x,b+d),c+d)),this._drag.stage.current=f,this.animate(f.x))},e.prototype.onDragEnd=function(b){var d=this.difference(this._drag.pointer,this.pointer(b)),e=this._drag.stage.current,f=d.x>0^this.settings.rtl?"left":"right";a(c).off(".owl.core"),this.$element.removeClass(this.options.grabClass),(0!==d.x&&this.is("dragging")||!this.is("valid"))&&(this.speed(this.settings.dragEndSpeed||this.settings.smartSpeed),this.current(this.closest(e.x,0!==d.x?f:this._drag.direction)),this.invalidate("position"),this.update(),this._drag.direction=f,(Math.abs(d.x)>3||(new Date).getTime()-this._drag.time>300)&&this._drag.target.one("click.owl.core",function(){return!1})),this.is("dragging")&&(this.leave("dragging"),this.trigger("dragged"))},e.prototype.closest=function(b,c){var e=-1,f=30,g=this.width(),h=this.coordinates();return this.settings.freeDrag||a.each(h,a.proxy(function(a,i){return"left"===c&&b>i-f&&b<i+f?e=a:"right"===c&&b>i-g-f&&b<i-g+f?e=a+1:this.op(b,"<",i)&&this.op(b,">",h[a+1]!==d?h[a+1]:i-g)&&(e="left"===c?a+1:a),-1===e},this)),this.settings.loop||(this.op(b,">",h[this.minimum()])?e=b=this.minimum():this.op(b,"<",h[this.maximum()])&&(e=b=this.maximum())),e},e.prototype.animate=function(b){var c=this.speed()>0;this.is("animating")&&this.onTransitionEnd(),c&&(this.enter("animating"),this.trigger("translate")),a.support.transform3d&&a.support.transition?this.$stage.css({transform:"translate3d("+b+"px,0px,0px)",transition:this.speed()/1e3+"s"+(this.settings.slideTransition?" "+this.settings.slideTransition:"")}):c?this.$stage.animate({left:b+"px"},this.speed(),this.settings.fallbackEasing,a.proxy(this.onTransitionEnd,this)):this.$stage.css({left:b+"px"})},e.prototype.is=function(a){return this._states.current[a]&&this._states.current[a]>0},e.prototype.current=function(a){if(a===d)return this._current;if(0===this._items.length)return d;if(a=this.normalize(a),this._current!==a){var b=this.trigger("change",{property:{name:"position",value:a}});b.data!==d&&(a=this.normalize(b.data)),this._current=a,this.invalidate("position"),this.trigger("changed",{property:{name:"position",value:this._current}})}return this._current},e.prototype.invalidate=function(b){return"string"===a.type(b)&&(this._invalidated[b]=!0,this.is("valid")&&this.leave("valid")),a.map(this._invalidated,function(a,b){return b})},e.prototype.reset=function(a){(a=this.normalize(a))!==d&&(this._speed=0,this._current=a,this.suppress(["translate","translated"]),this.animate(this.coordinates(a)),this.release(["translate","translated"]))},e.prototype.normalize=function(a,b){var c=this._items.length,e=b?0:this._clones.length;return!this.isNumeric(a)||c<1?a=d:(a<0||a>=c+e)&&(a=((a-e/2)%c+c)%c+e/2),a},e.prototype.relative=function(a){return a-=this._clones.length/2,this.normalize(a,!0)},e.prototype.maximum=function(a){var b,c,d,e=this.settings,f=this._coordinates.length;if(e.loop)f=this._clones.length/2+this._items.length-1;else if(e.autoWidth||e.merge){if(b=this._items.length)for(c=this._items[--b].width(),d=this.$element.width();b--&&!((c+=this._items[b].width()+this.settings.margin)>d););f=b+1}else f=e.center?this._items.length-1:this._items.length-e.items;return a&&(f-=this._clones.length/2),Math.max(f,0)},e.prototype.minimum=function(a){return a?0:this._clones.length/2},e.prototype.items=function(a){return a===d?this._items.slice():(a=this.normalize(a,!0),this._items[a])},e.prototype.mergers=function(a){return a===d?this._mergers.slice():(a=this.normalize(a,!0),this._mergers[a])},e.prototype.clones=function(b){var c=this._clones.length/2,e=c+this._items.length,f=function(a){return a%2==0?e+a/2:c-(a+1)/2};return b===d?a.map(this._clones,function(a,b){return f(b)}):a.map(this._clones,function(a,c){return a===b?f(c):null})},e.prototype.speed=function(a){return a!==d&&(this._speed=a),this._speed},e.prototype.coordinates=function(b){var c,e=1,f=b-1;return b===d?a.map(this._coordinates,a.proxy(function(a,b){return this.coordinates(b)},this)):(this.settings.center?(this.settings.rtl&&(e=-1,f=b+1),c=this._coordinates[b],c+=(this.width()-c+(this._coordinates[f]||0))/2*e):c=this._coordinates[f]||0,c=Math.ceil(c))},e.prototype.duration=function(a,b,c){return 0===c?0:Math.min(Math.max(Math.abs(b-a),1),6)*Math.abs(c||this.settings.smartSpeed)},e.prototype.to=function(a,b){var c=this.current(),d=null,e=a-this.relative(c),f=(e>0)-(e<0),g=this._items.length,h=this.minimum(),i=this.maximum();this.settings.loop?(!this.settings.rewind&&Math.abs(e)>g/2&&(e+=-1*f*g),a=c+e,(d=((a-h)%g+g)%g+h)!==a&&d-e<=i&&d-e>0&&(c=d-e,a=d,this.reset(c))):this.settings.rewind?(i+=1,a=(a%i+i)%i):a=Math.max(h,Math.min(i,a)),this.speed(this.duration(c,a,b)),this.current(a),this.isVisible()&&this.update()},e.prototype.next=function(a){a=a||!1,this.to(this.relative(this.current())+1,a)},e.prototype.prev=function(a){a=a||!1,this.to(this.relative(this.current())-1,a)},e.prototype.onTransitionEnd=function(a){if(a!==d&&(a.stopPropagation(),(a.target||a.srcElement||a.originalTarget)!==this.$stage.get(0)))return!1;this.leave("animating"),this.trigger("translated")},e.prototype.viewport=function(){var d;return this.options.responsiveBaseElement!==b?d=a(this.options.responsiveBaseElement).width():b.innerWidth?d=b.innerWidth:c.documentElement&&c.documentElement.clientWidth?d=c.documentElement.clientWidth:console.warn("Can not detect viewport width."),d},e.prototype.replace=function(b){this.$stage.empty(),this._items=[],b&&(b=b instanceof jQuery?b:a(b)),this.settings.nestedItemSelector&&(b=b.find("."+this.settings.nestedItemSelector)),b.filter(function(){return 1===this.nodeType}).each(a.proxy(function(a,b){b=this.prepare(b),this.$stage.append(b),this._items.push(b),this._mergers.push(1*b.find("[data-merge]").addBack("[data-merge]").attr("data-merge")||1)},this)),this.reset(this.isNumeric(this.settings.startPosition)?this.settings.startPosition:0),this.invalidate("items")},e.prototype.add=function(b,c){var e=this.relative(this._current);c=c===d?this._items.length:this.normalize(c,!0),b=b instanceof jQuery?b:a(b),this.trigger("add",{content:b,position:c}),b=this.prepare(b),0===this._items.length||c===this._items.length?(0===this._items.length&&this.$stage.append(b),0!==this._items.length&&this._items[c-1].after(b),this._items.push(b),this._mergers.push(1*b.find("[data-merge]").addBack("[data-merge]").attr("data-merge")||1)):(this._items[c].before(b),this._items.splice(c,0,b),this._mergers.splice(c,0,1*b.find("[data-merge]").addBack("[data-merge]").attr("data-merge")||1)),this._items[e]&&this.reset(this._items[e].index()),this.invalidate("items"),this.trigger("added",{content:b,position:c})},e.prototype.remove=function(a){(a=this.normalize(a,!0))!==d&&(this.trigger("remove",{content:this._items[a],position:a}),this._items[a].remove(),this._items.splice(a,1),this._mergers.splice(a,1),this.invalidate("items"),this.trigger("removed",{content:null,position:a}))},e.prototype.preloadAutoWidthImages=function(b){b.each(a.proxy(function(b,c){this.enter("pre-loading"),c=a(c),a(new Image).one("load",a.proxy(function(a){c.attr("src",a.target.src),c.css("opacity",1),this.leave("pre-loading"),!this.is("pre-loading")&&!this.is("initializing")&&this.refresh()},this)).attr("src",c.attr("src")||c.attr("data-src")||c.attr("data-src-retina"))},this))},e.prototype.destroy=function(){this.$element.off(".owl.core"),this.$stage.off(".owl.core"),a(c).off(".owl.core"),!1!==this.settings.responsive&&(b.clearTimeout(this.resizeTimer),this.off(b,"resize",this._handlers.onThrottledResize));for(var d in this._plugins)this._plugins[d].destroy();this.$stage.children(".cloned").remove(),this.$stage.unwrap(),this.$stage.children().contents().unwrap(),this.$stage.children().unwrap(),this.$stage.remove(),this.$element.removeClass(this.options.refreshClass).removeClass(this.options.loadingClass).removeClass(this.options.loadedClass).removeClass(this.options.rtlClass).removeClass(this.options.dragClass).removeClass(this.options.grabClass).attr("class",this.$element.attr("class").replace(new RegExp(this.options.responsiveClass+"-\\S+\\s","g"),"")).removeData("owl.carousel")},e.prototype.op=function(a,b,c){var d=this.settings.rtl;switch(b){case"<":return d?a>c:a<c;case">":return d?a<c:a>c;case">=":return d?a<=c:a>=c;case"<=":return d?a>=c:a<=c}},e.prototype.on=function(a,b,c,d){a.addEventListener?a.addEventListener(b,c,d):a.attachEvent&&a.attachEvent("on"+b,c)},e.prototype.off=function(a,b,c,d){a.removeEventListener?a.removeEventListener(b,c,d):a.detachEvent&&a.detachEvent("on"+b,c)},e.prototype.trigger=function(b,c,d,f,g){var h={item:{count:this._items.length,index:this.current()}},i=a.camelCase(a.grep(["on",b,d],function(a){return a}).join("-").toLowerCase()),j=a.Event([b,"owl",d||"carousel"].join(".").toLowerCase(),a.extend({relatedTarget:this},h,c));return this._supress[b]||(a.each(this._plugins,function(a,b){b.onTrigger&&b.onTrigger(j)}),this.register({type:e.Type.Event,name:b}),this.$element.trigger(j),this.settings&&"function"==typeof this.settings[i]&&this.settings[i].call(this,j)),j},e.prototype.enter=function(b){a.each([b].concat(this._states.tags[b]||[]),a.proxy(function(a,b){this._states.current[b]===d&&(this._states.current[b]=0),this._states.current[b]++},this))},e.prototype.leave=function(b){a.each([b].concat(this._states.tags[b]||[]),a.proxy(function(a,b){this._states.current[b]--},this))},e.prototype.register=function(b){if(b.type===e.Type.Event){if(a.event.special[b.name]||(a.event.special[b.name]={}),!a.event.special[b.name].owl){var c=a.event.special[b.name]._default;a.event.special[b.name]._default=function(a){return!c||!c.apply||a.namespace&&-1!==a.namespace.indexOf("owl")?a.namespace&&a.namespace.indexOf("owl")>-1:c.apply(this,arguments)},a.event.special[b.name].owl=!0}}else b.type===e.Type.State&&(this._states.tags[b.name]?this._states.tags[b.name]=this._states.tags[b.name].concat(b.tags):this._states.tags[b.name]=b.tags,this._states.tags[b.name]=a.grep(this._states.tags[b.name],a.proxy(function(c,d){return a.inArray(c,this._states.tags[b.name])===d},this)))},e.prototype.suppress=function(b){a.each(b,a.proxy(function(a,b){this._supress[b]=!0},this))},e.prototype.release=function(b){a.each(b,a.proxy(function(a,b){delete this._supress[b]},this))},e.prototype.pointer=function(a){var c={x:null,y:null};return a=a.originalEvent||a||b.event,a=a.touches&&a.touches.length?a.touches[0]:a.changedTouches&&a.changedTouches.length?a.changedTouches[0]:a,a.pageX?(c.x=a.pageX,c.y=a.pageY):(c.x=a.clientX,c.y=a.clientY),c},e.prototype.isNumeric=function(a){return!isNaN(parseFloat(a))},e.prototype.difference=function(a,b){return{x:a.x-b.x,y:a.y-b.y}},a.fn.owlCarousel=function(b){var c=Array.prototype.slice.call(arguments,1);return this.each(function(){var d=a(this),f=d.data("owl.carousel");f||(f=new e(this,"object"==typeof b&&b),d.data("owl.carousel",f),a.each(["next","prev","to","destroy","refresh","replace","add","remove"],function(b,c){f.register({type:e.Type.Event,name:c}),f.$element.on(c+".owl.carousel.core",a.proxy(function(a){a.namespace&&a.relatedTarget!==this&&(this.suppress([c]),f[c].apply(this,[].slice.call(arguments,1)),this.release([c]))},f))})),"string"==typeof b&&"_"!==b.charAt(0)&&f[b].apply(f,c)})},a.fn.owlCarousel.Constructor=e}(window.Zepto||window.jQuery,window,document),function(a,b,c,d){var e=function(b){this._core=b,this._interval=null,this._visible=null,this._handlers={"initialized.owl.carousel":a.proxy(function(a){a.namespace&&this._core.settings.autoRefresh&&this.watch()},this)},this._core.options=a.extend({},e.Defaults,this._core.options),this._core.$element.on(this._handlers)};e.Defaults={autoRefresh:!0,autoRefreshInterval:500},e.prototype.watch=function(){this._interval||(this._visible=this._core.isVisible(),this._interval=b.setInterval(a.proxy(this.refresh,this),this._core.settings.autoRefreshInterval))},e.prototype.refresh=function(){this._core.isVisible()!==this._visible&&(this._visible=!this._visible,this._core.$element.toggleClass("owl-hidden",!this._visible),this._visible&&this._core.invalidate("width")&&this._core.refresh())},e.prototype.destroy=function(){var a,c;b.clearInterval(this._interval);for(a in this._handlers)this._core.$element.off(a,this._handlers[a]);for(c in Object.getOwnPropertyNames(this))"function"!=typeof this[c]&&(this[c]=null)},a.fn.owlCarousel.Constructor.Plugins.AutoRefresh=e}(window.Zepto||window.jQuery,window,document),function(a,b,c,d){var e=function(b){this._core=b,this._loaded=[],this._handlers={"initialized.owl.carousel change.owl.carousel resized.owl.carousel":a.proxy(function(b){if(b.namespace&&this._core.settings&&this._core.settings.lazyLoad&&(b.property&&"position"==b.property.name||"initialized"==b.type)){var c=this._core.settings,e=c.center&&Math.ceil(c.items/2)||c.items,f=c.center&&-1*e||0,g=(b.property&&b.property.value!==d?b.property.value:this._core.current())+f,h=this._core.clones().length,i=a.proxy(function(a,b){this.load(b)},this);for(c.lazyLoadEager>0&&(e+=c.lazyLoadEager,c.loop&&(g-=c.lazyLoadEager,e++));f++<e;)this.load(h/2+this._core.relative(g)),h&&a.each(this._core.clones(this._core.relative(g)),i),g++}},this)},this._core.options=a.extend({},e.Defaults,this._core.options),this._core.$element.on(this._handlers)};e.Defaults={lazyLoad:!1,lazyLoadEager:0},e.prototype.load=function(c){var d=this._core.$stage.children().eq(c),e=d&&d.find(".owl-lazy");!e||a.inArray(d.get(0),this._loaded)>-1||(e.each(a.proxy(function(c,d){var e,f=a(d),g=b.devicePixelRatio>1&&f.attr("data-src-retina")||f.attr("data-src")||f.attr("data-srcset");this._core.trigger("load",{element:f,url:g},"lazy"),f.is("img")?f.one("load.owl.lazy",a.proxy(function(){f.css("opacity",1),this._core.trigger("loaded",{element:f,url:g},"lazy")},this)).attr("src",g):f.is("source")?f.one("load.owl.lazy",a.proxy(function(){this._core.trigger("loaded",{element:f,url:g},"lazy")},this)).attr("srcset",g):(e=new Image,e.onload=a.proxy(function(){f.css({"background-image":'url("'+g+'")',opacity:"1"}),this._core.trigger("loaded",{element:f,url:g},"lazy")},this),e.src=g)},this)),this._loaded.push(d.get(0)))},e.prototype.destroy=function(){var a,b;for(a in this.handlers)this._core.$element.off(a,this.handlers[a]);for(b in Object.getOwnPropertyNames(this))"function"!=typeof this[b]&&(this[b]=null)},a.fn.owlCarousel.Constructor.Plugins.Lazy=e}(window.Zepto||window.jQuery,window,document),function(a,b,c,d){var e=function(c){this._core=c,this._previousHeight=null,this._handlers={"initialized.owl.carousel refreshed.owl.carousel":a.proxy(function(a){a.namespace&&this._core.settings.autoHeight&&this.update()},this),"changed.owl.carousel":a.proxy(function(a){a.namespace&&this._core.settings.autoHeight&&"position"===a.property.name&&this.update()},this),"loaded.owl.lazy":a.proxy(function(a){a.namespace&&this._core.settings.autoHeight&&a.element.closest("."+this._core.settings.itemClass).index()===this._core.current()&&this.update()},this)},this._core.options=a.extend({},e.Defaults,this._core.options),this._core.$element.on(this._handlers),this._intervalId=null;var d=this;a(b).on("load",function(){d._core.settings.autoHeight&&d.update()}),a(b).resize(function(){d._core.settings.autoHeight&&(null!=d._intervalId&&clearTimeout(d._intervalId),d._intervalId=setTimeout(function(){d.update()},250))})};e.Defaults={autoHeight:!1,autoHeightClass:"owl-height"},e.prototype.update=function(){var b=this._core._current,c=b+this._core.settings.items,d=this._core.settings.lazyLoad,e=this._core.$stage.children().toArray().slice(b,c),f=[],g=0;a.each(e,function(b,c){f.push(a(c).height())}),g=Math.max.apply(null,f),g<=1&&d&&this._previousHeight&&(g=this._previousHeight),this._previousHeight=g,this._core.$stage.parent().height(g).addClass(this._core.settings.autoHeightClass)},e.prototype.destroy=function(){var a,b;for(a in this._handlers)this._core.$element.off(a,this._handlers[a]);for(b in Object.getOwnPropertyNames(this))"function"!=typeof this[b]&&(this[b]=null)},a.fn.owlCarousel.Constructor.Plugins.AutoHeight=e}(window.Zepto||window.jQuery,window,document),function(a,b,c,d){var e=function(b){this._core=b,this._videos={},this._playing=null,this._handlers={"initialized.owl.carousel":a.proxy(function(a){a.namespace&&this._core.register({type:"state",name:"playing",tags:["interacting"]})},this),"resize.owl.carousel":a.proxy(function(a){a.namespace&&this._core.settings.video&&this.isInFullScreen()&&a.preventDefault()},this),"refreshed.owl.carousel":a.proxy(function(a){a.namespace&&this._core.is("resizing")&&this._core.$stage.find(".cloned .owl-video-frame").remove()},this),"changed.owl.carousel":a.proxy(function(a){a.namespace&&"position"===a.property.name&&this._playing&&this.stop()},this),"prepared.owl.carousel":a.proxy(function(b){if(b.namespace){var c=a(b.content).find(".owl-video");c.length&&(c.css("display","none"),this.fetch(c,a(b.content)))}},this)},this._core.options=a.extend({},e.Defaults,this._core.options),this._core.$element.on(this._handlers),this._core.$element.on("click.owl.video",".owl-video-play-icon",a.proxy(function(a){this.play(a)},this))};e.Defaults={video:!1,videoHeight:!1,videoWidth:!1},e.prototype.fetch=function(a,b){var c=function(){return a.attr("data-vimeo-id")?"vimeo":a.attr("data-vzaar-id")?"vzaar":"youtube"}(),d=a.attr("data-vimeo-id")||a.attr("data-youtube-id")||a.attr("data-vzaar-id"),e=a.attr("data-width")||this._core.settings.videoWidth,f=a.attr("data-height")||this._core.settings.videoHeight,g=a.attr("href");if(!g)throw new Error("Missing video URL.");if(d=g.match(/(http:|https:|)\/\/(player.|www.|app.)?(vimeo\.com|youtu(be\.com|\.be|be\.googleapis\.com|be\-nocookie\.com)|vzaar\.com)\/(video\/|videos\/|embed\/|channels\/.+\/|groups\/.+\/|watch\?v=|v\/)?([A-Za-z0-9._%-]*)(\&\S+)?/),d[3].indexOf("youtu")>-1)c="youtube";else if(d[3].indexOf("vimeo")>-1)c="vimeo";else{if(!(d[3].indexOf("vzaar")>-1))throw new Error("Video URL not supported.");c="vzaar"}d=d[6],this._videos[g]={type:c,id:d,width:e,height:f},b.attr("data-video",g),this.thumbnail(a,this._videos[g])},e.prototype.thumbnail=function(b,c){var d,e,f,g=c.width&&c.height?"width:"+c.width+"px;height:"+c.height+"px;":"",h=b.find("img"),i="src",j="",k=this._core.settings,l=function(c){e='<div class="owl-video-play-icon"></div>',d=k.lazyLoad?a("<div/>",{class:"owl-video-tn "+j,srcType:c}):a("<div/>",{class:"owl-video-tn",style:"opacity:1;background-image:url("+c+")"}),b.after(d),b.after(e)};if(b.wrap(a("<div/>",{class:"owl-video-wrapper",style:g})),this._core.settings.lazyLoad&&(i="data-src",j="owl-lazy"),h.length)return l(h.attr(i)),h.remove(),!1;"youtube"===c.type?(f="//img.youtube.com/vi/"+c.id+"/hqdefault.jpg",l(f)):"vimeo"===c.type?a.ajax({type:"GET",url:"//vimeo.com/api/v2/video/"+c.id+".json",jsonp:"callback",dataType:"jsonp",success:function(a){f=a[0].thumbnail_large,l(f)}}):"vzaar"===c.type&&a.ajax({type:"GET",url:"//vzaar.com/api/videos/"+c.id+".json",jsonp:"callback",dataType:"jsonp",success:function(a){f=a.framegrab_url,l(f)}})},e.prototype.stop=function(){this._core.trigger("stop",null,"video"),this._playing.find(".owl-video-frame").remove(),this._playing.removeClass("owl-video-playing"),this._playing=null,this._core.leave("playing"),this._core.trigger("stopped",null,"video")},e.prototype.play=function(b){var c,d=a(b.target),e=d.closest("."+this._core.settings.itemClass),f=this._videos[e.attr("data-video")],g=f.width||"100%",h=f.height||this._core.$stage.height();this._playing||(this._core.enter("playing"),this._core.trigger("play",null,"video"),e=this._core.items(this._core.relative(e.index())),this._core.reset(e.index()),c=a('<iframe frameborder="0" allowfullscreen mozallowfullscreen webkitAllowFullScreen ></iframe>'),c.attr("height",h),c.attr("width",g),"youtube"===f.type?c.attr("src","//www.youtube.com/embed/"+f.id+"?autoplay=1&rel=0&v="+f.id):"vimeo"===f.type?c.attr("src","//player.vimeo.com/video/"+f.id+"?autoplay=1"):"vzaar"===f.type&&c.attr("src","//view.vzaar.com/"+f.id+"/player?autoplay=true"),a(c).wrap('<div class="owl-video-frame" />').insertAfter(e.find(".owl-video")),this._playing=e.addClass("owl-video-playing"))},e.prototype.isInFullScreen=function(){var b=c.fullscreenElement||c.mozFullScreenElement||c.webkitFullscreenElement;return b&&a(b).parent().hasClass("owl-video-frame")},e.prototype.destroy=function(){var a,b;this._core.$element.off("click.owl.video");for(a in this._handlers)this._core.$element.off(a,this._handlers[a]);for(b in Object.getOwnPropertyNames(this))"function"!=typeof this[b]&&(this[b]=null)},a.fn.owlCarousel.Constructor.Plugins.Video=e}(window.Zepto||window.jQuery,window,document),function(a,b,c,d){var e=function(b){this.core=b,this.core.options=a.extend({},e.Defaults,this.core.options),this.swapping=!0,this.previous=d,this.next=d,this.handlers={"change.owl.carousel":a.proxy(function(a){a.namespace&&"position"==a.property.name&&(this.previous=this.core.current(),this.next=a.property.value)},this),"drag.owl.carousel dragged.owl.carousel translated.owl.carousel":a.proxy(function(a){a.namespace&&(this.swapping="translated"==a.type)},this),"translate.owl.carousel":a.proxy(function(a){a.namespace&&this.swapping&&(this.core.options.animateOut||this.core.options.animateIn)&&this.swap()},this)},this.core.$element.on(this.handlers)};e.Defaults={animateOut:!1,
animateIn:!1},e.prototype.swap=function(){if(1===this.core.settings.items&&a.support.animation&&a.support.transition){this.core.speed(0);var b,c=a.proxy(this.clear,this),d=this.core.$stage.children().eq(this.previous),e=this.core.$stage.children().eq(this.next),f=this.core.settings.animateIn,g=this.core.settings.animateOut;this.core.current()!==this.previous&&(g&&(b=this.core.coordinates(this.previous)-this.core.coordinates(this.next),d.one(a.support.animation.end,c).css({left:b+"px"}).addClass("animated owl-animated-out").addClass(g)),f&&e.one(a.support.animation.end,c).addClass("animated owl-animated-in").addClass(f))}},e.prototype.clear=function(b){a(b.target).css({left:""}).removeClass("animated owl-animated-out owl-animated-in").removeClass(this.core.settings.animateIn).removeClass(this.core.settings.animateOut),this.core.onTransitionEnd()},e.prototype.destroy=function(){var a,b;for(a in this.handlers)this.core.$element.off(a,this.handlers[a]);for(b in Object.getOwnPropertyNames(this))"function"!=typeof this[b]&&(this[b]=null)},a.fn.owlCarousel.Constructor.Plugins.Animate=e}(window.Zepto||window.jQuery,window,document),function(a,b,c,d){var e=function(b){this._core=b,this._call=null,this._time=0,this._timeout=0,this._paused=!0,this._handlers={"changed.owl.carousel":a.proxy(function(a){a.namespace&&"settings"===a.property.name?this._core.settings.autoplay?this.play():this.stop():a.namespace&&"position"===a.property.name&&this._paused&&(this._time=0)},this),"initialized.owl.carousel":a.proxy(function(a){a.namespace&&this._core.settings.autoplay&&this.play()},this),"play.owl.autoplay":a.proxy(function(a,b,c){a.namespace&&this.play(b,c)},this),"stop.owl.autoplay":a.proxy(function(a){a.namespace&&this.stop()},this),"mouseover.owl.autoplay":a.proxy(function(){this._core.settings.autoplayHoverPause&&this._core.is("rotating")&&this.pause()},this),"mouseleave.owl.autoplay":a.proxy(function(){this._core.settings.autoplayHoverPause&&this._core.is("rotating")&&this.play()},this),"touchstart.owl.core":a.proxy(function(){this._core.settings.autoplayHoverPause&&this._core.is("rotating")&&this.pause()},this),"touchend.owl.core":a.proxy(function(){this._core.settings.autoplayHoverPause&&this.play()},this)},this._core.$element.on(this._handlers),this._core.options=a.extend({},e.Defaults,this._core.options)};e.Defaults={autoplay:!1,autoplayTimeout:5e3,autoplayHoverPause:!1,autoplaySpeed:!1},e.prototype._next=function(d){this._call=b.setTimeout(a.proxy(this._next,this,d),this._timeout*(Math.round(this.read()/this._timeout)+1)-this.read()),this._core.is("interacting")||c.hidden||this._core.next(d||this._core.settings.autoplaySpeed)},e.prototype.read=function(){return(new Date).getTime()-this._time},e.prototype.play=function(c,d){var e;this._core.is("rotating")||this._core.enter("rotating"),c=c||this._core.settings.autoplayTimeout,e=Math.min(this._time%(this._timeout||c),c),this._paused?(this._time=this.read(),this._paused=!1):b.clearTimeout(this._call),this._time+=this.read()%c-e,this._timeout=c,this._call=b.setTimeout(a.proxy(this._next,this,d),c-e)},e.prototype.stop=function(){this._core.is("rotating")&&(this._time=0,this._paused=!0,b.clearTimeout(this._call),this._core.leave("rotating"))},e.prototype.pause=function(){this._core.is("rotating")&&!this._paused&&(this._time=this.read(),this._paused=!0,b.clearTimeout(this._call))},e.prototype.destroy=function(){var a,b;this.stop();for(a in this._handlers)this._core.$element.off(a,this._handlers[a]);for(b in Object.getOwnPropertyNames(this))"function"!=typeof this[b]&&(this[b]=null)},a.fn.owlCarousel.Constructor.Plugins.autoplay=e}(window.Zepto||window.jQuery,window,document),function(a,b,c,d){"use strict";var e=function(b){this._core=b,this._initialized=!1,this._pages=[],this._controls={},this._templates=[],this.$element=this._core.$element,this._overrides={next:this._core.next,prev:this._core.prev,to:this._core.to},this._handlers={"prepared.owl.carousel":a.proxy(function(b){b.namespace&&this._core.settings.dotsData&&this._templates.push('<div class="'+this._core.settings.dotClass+'">'+a(b.content).find("[data-dot]").addBack("[data-dot]").attr("data-dot")+"</div>")},this),"added.owl.carousel":a.proxy(function(a){a.namespace&&this._core.settings.dotsData&&this._templates.splice(a.position,0,this._templates.pop())},this),"remove.owl.carousel":a.proxy(function(a){a.namespace&&this._core.settings.dotsData&&this._templates.splice(a.position,1)},this),"changed.owl.carousel":a.proxy(function(a){a.namespace&&"position"==a.property.name&&this.draw()},this),"initialized.owl.carousel":a.proxy(function(a){a.namespace&&!this._initialized&&(this._core.trigger("initialize",null,"navigation"),this.initialize(),this.update(),this.draw(),this._initialized=!0,this._core.trigger("initialized",null,"navigation"))},this),"refreshed.owl.carousel":a.proxy(function(a){a.namespace&&this._initialized&&(this._core.trigger("refresh",null,"navigation"),this.update(),this.draw(),this._core.trigger("refreshed",null,"navigation"))},this)},this._core.options=a.extend({},e.Defaults,this._core.options),this.$element.on(this._handlers)};e.Defaults={nav:!1,navText:['<span aria-label="Previous">&#x2039;</span>','<span aria-label="Next">&#x203a;</span>'],navSpeed:!1,navElement:'button type="button" role="presentation"',navContainer:!1,navContainerClass:"owl-nav",navClass:["owl-prev","owl-next"],slideBy:1,dotClass:"owl-dot",dotsClass:"owl-dots",dots:!0,dotsEach:!1,dotsData:!1,dotsSpeed:!1,dotsContainer:!1},e.prototype.initialize=function(){var b,c=this._core.settings;this._controls.$relative=(c.navContainer?a(c.navContainer):a("<div>").addClass(c.navContainerClass).appendTo(this.$element)).addClass("disabled"),this._controls.$previous=a("<"+c.navElement+">").addClass(c.navClass[0]).html(c.navText[0]).prependTo(this._controls.$relative).on("click",a.proxy(function(a){this.prev(c.navSpeed)},this)),this._controls.$next=a("<"+c.navElement+">").addClass(c.navClass[1]).html(c.navText[1]).appendTo(this._controls.$relative).on("click",a.proxy(function(a){this.next(c.navSpeed)},this)),c.dotsData||(this._templates=[a('<button role="button">').addClass(c.dotClass).append(a("<span>")).prop("outerHTML")]),this._controls.$absolute=(c.dotsContainer?a(c.dotsContainer):a("<div>").addClass(c.dotsClass).appendTo(this.$element)).addClass("disabled"),this._controls.$absolute.on("click","button",a.proxy(function(b){var d=a(b.target).parent().is(this._controls.$absolute)?a(b.target).index():a(b.target).parent().index();b.preventDefault(),this.to(d,c.dotsSpeed)},this));for(b in this._overrides)this._core[b]=a.proxy(this[b],this)},e.prototype.destroy=function(){var a,b,c,d,e;e=this._core.settings;for(a in this._handlers)this.$element.off(a,this._handlers[a]);for(b in this._controls)"$relative"===b&&e.navContainer?this._controls[b].html(""):this._controls[b].remove();for(d in this.overides)this._core[d]=this._overrides[d];for(c in Object.getOwnPropertyNames(this))"function"!=typeof this[c]&&(this[c]=null)},e.prototype.update=function(){var a,b,c,d=this._core.clones().length/2,e=d+this._core.items().length,f=this._core.maximum(!0),g=this._core.settings,h=g.center||g.autoWidth||g.dotsData?1:g.dotsEach||g.items;if("page"!==g.slideBy&&(g.slideBy=Math.min(g.slideBy,g.items)),g.dots||"page"==g.slideBy)for(this._pages=[],a=d,b=0,c=0;a<e;a++){if(b>=h||0===b){if(this._pages.push({start:Math.min(f,a-d),end:a-d+h-1}),Math.min(f,a-d)===f)break;b=0,++c}b+=this._core.mergers(this._core.relative(a))}},e.prototype.draw=function(){var b,c=this._core.settings,d=this._core.items().length<=c.items,e=this._core.relative(this._core.current()),f=c.loop||c.rewind;this._controls.$relative.toggleClass("disabled",!c.nav||d),c.nav&&(this._controls.$previous.toggleClass("disabled",!f&&e<=this._core.minimum(!0)),this._controls.$next.toggleClass("disabled",!f&&e>=this._core.maximum(!0))),this._controls.$absolute.toggleClass("disabled",!c.dots||d),c.dots&&(b=this._pages.length-this._controls.$absolute.children().length,c.dotsData&&0!==b?this._controls.$absolute.html(this._templates.join("")):b>0?this._controls.$absolute.append(new Array(b+1).join(this._templates[0])):b<0&&this._controls.$absolute.children().slice(b).remove(),this._controls.$absolute.find(".active").removeClass("active"),this._controls.$absolute.children().eq(a.inArray(this.current(),this._pages)).addClass("active"))},e.prototype.onTrigger=function(b){var c=this._core.settings;b.page={index:a.inArray(this.current(),this._pages),count:this._pages.length,size:c&&(c.center||c.autoWidth||c.dotsData?1:c.dotsEach||c.items)}},e.prototype.current=function(){var b=this._core.relative(this._core.current());return a.grep(this._pages,a.proxy(function(a,c){return a.start<=b&&a.end>=b},this)).pop()},e.prototype.getPosition=function(b){var c,d,e=this._core.settings;return"page"==e.slideBy?(c=a.inArray(this.current(),this._pages),d=this._pages.length,b?++c:--c,c=this._pages[(c%d+d)%d].start):(c=this._core.relative(this._core.current()),d=this._core.items().length,b?c+=e.slideBy:c-=e.slideBy),c},e.prototype.next=function(b){a.proxy(this._overrides.to,this._core)(this.getPosition(!0),b)},e.prototype.prev=function(b){a.proxy(this._overrides.to,this._core)(this.getPosition(!1),b)},e.prototype.to=function(b,c,d){var e;!d&&this._pages.length?(e=this._pages.length,a.proxy(this._overrides.to,this._core)(this._pages[(b%e+e)%e].start,c)):a.proxy(this._overrides.to,this._core)(b,c)},a.fn.owlCarousel.Constructor.Plugins.Navigation=e}(window.Zepto||window.jQuery,window,document),function(a,b,c,d){"use strict";var e=function(c){this._core=c,this._hashes={},this.$element=this._core.$element,this._handlers={"initialized.owl.carousel":a.proxy(function(c){c.namespace&&"URLHash"===this._core.settings.startPosition&&a(b).trigger("hashchange.owl.navigation")},this),"prepared.owl.carousel":a.proxy(function(b){if(b.namespace){var c=a(b.content).find("[data-hash]").addBack("[data-hash]").attr("data-hash");if(!c)return;this._hashes[c]=b.content}},this),"changed.owl.carousel":a.proxy(function(c){if(c.namespace&&"position"===c.property.name){var d=this._core.items(this._core.relative(this._core.current())),e=a.map(this._hashes,function(a,b){return a===d?b:null}).join();if(!e||b.location.hash.slice(1)===e)return;b.location.hash=e}},this)},this._core.options=a.extend({},e.Defaults,this._core.options),this.$element.on(this._handlers),a(b).on("hashchange.owl.navigation",a.proxy(function(a){var c=b.location.hash.substring(1),e=this._core.$stage.children(),f=this._hashes[c]&&e.index(this._hashes[c]);f!==d&&f!==this._core.current()&&this._core.to(this._core.relative(f),!1,!0)},this))};e.Defaults={URLhashListener:!1},e.prototype.destroy=function(){var c,d;a(b).off("hashchange.owl.navigation");for(c in this._handlers)this._core.$element.off(c,this._handlers[c]);for(d in Object.getOwnPropertyNames(this))"function"!=typeof this[d]&&(this[d]=null)},a.fn.owlCarousel.Constructor.Plugins.Hash=e}(window.Zepto||window.jQuery,window,document),function(a,b,c,d){function e(b,c){var e=!1,f=b.charAt(0).toUpperCase()+b.slice(1);return a.each((b+" "+h.join(f+" ")+f).split(" "),function(a,b){if(g[b]!==d)return e=!c||b,!1}),e}function f(a){return e(a,!0)}var g=a("<support>").get(0).style,h="Webkit Moz O ms".split(" "),i={transition:{end:{WebkitTransition:"webkitTransitionEnd",MozTransition:"transitionend",OTransition:"oTransitionEnd",transition:"transitionend"}},animation:{end:{WebkitAnimation:"webkitAnimationEnd",MozAnimation:"animationend",OAnimation:"oAnimationEnd",animation:"animationend"}}},j={csstransforms:function(){return!!e("transform")},csstransforms3d:function(){return!!e("perspective")},csstransitions:function(){return!!e("transition")},cssanimations:function(){return!!e("animation")}};j.csstransitions()&&(a.support.transition=new String(f("transition")),a.support.transition.end=i.transition.end[a.support.transition]),j.cssanimations()&&(a.support.animation=new String(f("animation")),a.support.animation.end=i.animation.end[a.support.animation]),j.csstransforms()&&(a.support.transform=new String(f("transform")),a.support.transform3d=j.csstransforms3d())}(window.Zepto||window.jQuery,window,document);;
// you have to hide default FAQ JS in .info
// Use the code bellow
/*
  nir_faq/nir_faq_widget_accordion:
    js:
      js/nir_faq_widget_accordion.js: false
*/

(function ($, Drupal, drupalSettings) {

  'use strict';

  Drupal.behaviors.nirFaqWidgetAccordion= {
    attach: function (context) {
      var $open_class = 'nir-faq--open';
      var $closed_class = 'nir-faq--closed';
      $('.nir-faq-widget--accordion-link').off('click').on('click',  function (e) {
        e.preventDefault();

        var $parent = $(this).closest('.nir-widget--list');
        var $acc = $parent.find('.idm-acc');


        if ($(this).hasClass($open_class)) {
          $(this).removeClass($open_class).removeClass($closed_class).addClass($closed_class).text($(this).data('open'));
          $acc.find('.idm-acc-Q').attr('aria-expanded', 'false');
          $acc.find('.idm-acc-A').removeClass('show');
        }
        else {
          $(this).removeClass($open_class).removeClass($closed_class).addClass($open_class).text($(this).data('closed'));
          $acc.find('.idm-acc-Q').attr('aria-expanded', 'true');
          $acc.find('.idm-acc-A').addClass('show');
        }
      });
    }
  };

})(jQuery, Drupal, drupalSettings);;
(function ($, Drupal) {

  Drupal.behaviors.resultsSlider = {
    attach: function (context, settings) {



    if ($('.results-slider').length) {

//      add title column
        resultsArr = []
        $('.results-slider .item').each(function(ev) {
            numItems = $(this).find('.asset-list li.views-row').length;
            resultTitle = []
            $(this).find('.asset-list li.views-row').each(function(i) {

                // resultTitle.splice(i, 1, $(this).find('h5.result-title').html());
                resultTitle.push($(this).find('h5.result-title').html());
                // alert('parent index: ' + ev + ' child index: ' + i);
                if (i === numItems - 1) {
                    resultsArr.splice(ev, 1, resultTitle);
                    // resultsArr.push[i](resultTitle);
                    // alert('index: ' + i + ' number of items: ' + numItems)
                    // alert(resultTitle);
                }

            }) ;
            // alert(resultsArr[ev])
        });

        // matches = '';
        function allthesame(arr){
            var L = arr.length-1;
            while(L){
                if(arr[L--].join(',') !== arr[L].join(',')) {
                    matches = false
                    return false;
                } else {
                    matches = true;
                    // alert();
                }
            }
            // return true;

        }

        // alert(allthesame(resultsArr));
        // alert(resultsArr);
        allthesame(resultsArr);
        // alert(matches);
        matches = 1;
        if (matches) {
            // alert;
            $('.result-title').css({display: 'none'});
            $('.results-container > .idm-row').prepend('<div class="idm-col-6 idm-col-md-5 idm-col-lg-4"><h4>&nbsp;</h4><ul class="appended-titles"></ul></div>');
            // $('.results-container > .row').prepend('<div class="hidden visible-lg col-lg-4"><h4>&nbsp;</h4><ul class="appended-titles"></ul></div>');
            for(i = 0; i < resultsArr[0].length; i++) {
                $('.appended-titles').append('<li>' + resultsArr[0][i] + '</li>');
            }
        } else {
            $('.main-results-housing').removeClass('idm-col-lg-8').addClass('idm-col-lg-12');
        }



// $(document).ready(function() {
        /*$('.results-slider').owlCarousel({
            loop: false,
            margin: 0,
            nav: true,
            dots: false,
            navText: ["", ""],
            //autoplay:true,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 1
                },
                1000: {
                    items: 2
                }
            }
        });*/
// });




// asset-list
//     alert(itemHeight);

        function matchLiHeight() {
            var itemHeight = [];
            $('.appended-titles li').each(function(i) {
                var tHt = $(this).outerHeight();
                itemHeight[i] = tHt;
            });
            $('.results-slider .asset-list').each(function() {
                $(this).children('li').each(function(i) {
                    $(this).outerHeight(itemHeight[i]);
                    // $(this).css('min-height', itemHeight[i])
                })
            });
        }

        $(document).ready(matchLiHeight);
        $(window).resize(matchLiHeight);


        //add blank Qs
        jQuery('.results-slider .views-field-field-nir-bundle-content .item-list').each(function() {
            var $numItems = jQuery(this).find('li').length;
            var $linkItems = jQuery(this).find('a');
            var $numLinks = $linkItems.length;
            var $numBlanks = $numItems - $numLinks;
            // alert($numLinks);

            var $dataArr = new Array($numItems);


            $linkItems.each(function(i) {
                // alert(i);
                var $q = $(this).text().split('Q').pop();
                var $qNum = Number($q);
                var $qInd = $qNum - 1;
                var $parentLi = jQuery(this).closest('li');
                var $parentUl = $parentLi.closest('ul');

                if (!isNaN($qNum)) {
                    $parentLi.attr('data-order', $q);

                    //add items to array in order and detach
                    $dataArr.splice($qInd, 1, $parentLi);
                    $parentLi.detach();
                }


                // add back content and blanks in correct order
                if ((i+1) == $numLinks) {
                    // alert($dataArr);
                    // jQuery.fn.reverse = [].reverse;

                    var $addBlanks = $numBlanks;
                    jQuery.each($dataArr, function(index, value) {
                        // alert(index)
                        if(jQuery(this).find('a').length) {
                            // $parentUl.append(value);
                        } else {
                            if ($addBlanks > 0) {
                                if ((index+1) <= 4) {  // dont allow the blank quarters to go beyond 4
                                    $dataArr.splice(index, 1, '<li><span class="Qblank">Q' + (index+1) +'</span></li>');
                                }
                            }
                            --$addBlanks;
                        }
                    });

                    //to output in chronological order, remove "reverse()"
                    jQuery.each($dataArr.reverse(), function(index, value) {
                        $parentUl.append(value);
                    });


                }


            });

        });


        $('.results-slider').owlCarousel({
            loop: false,
            margin: 0,
            nav: true,
            dots: false,
            navText: ["", ""],
            //autoplay:true,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 1
                },
                1000: {
                    items: 2
                },
                1200: {
                    items: 3
                }
            }
        });

    } /*endif results-slider*/

    }
  };

})(jQuery, Drupal);
;
// Default Theme JS that will be loaded on all pages.
// Note that this is the format JS should be wrapped in.
//
// See: https://www.drupal.org/node/2269515

// (function ($, Drupal) {
  // Drupal.behaviors.myModuleBehavior = {
    // attach: function (context, settings) {
      // Apply the myCustomBehaviour effect to the elements only once.
    // });
    // }
  // };
// })(jQuery, Drupal);

(function ($, Drupal) {

  Drupal.behaviors.irNavActive = {
    attach: function (context, settings) {

      var link = window.location.pathname;

      $('.topbar nav a.nav-link').each(function (){
        var aURL = $(this).attr('href');


        if (link == '/') {
          if (aURL.indexOf("/investor-relations") != -1) {
            $(this).addClass('active');
          }
        }
        if (link != undefined && link != '/') {
          if (link.indexOf("/event-details/") != -1) {
            if (aURL.indexOf("/news-and-events") != -1) {
              $(this).addClass('active');
            }
          }
          if (link.indexOf("/news-release-details/") != -1) {
            if (aURL.indexOf("/news-and-events") != -1) { 
              $(this).addClass('active');
            }
          }
          if (link.indexOf("/sec-filings/") != -1) {
            if (aURL.indexOf("/financials") != -1) {
              $(this).addClass('active');
            }
          }
          if (aURL.indexOf(link) != -1) {
            $(this).addClass('active');
          }
        }
      });

      $('#irNav > li').each(function (){
        if($(this).find('a').hasClass('active')){
          $(this).addClass('opened');
        }
      });
    }
  };

	Drupal.behaviors.showHideAll = {
		attach: function (context, settings) {
			$('.show-all').click( function(){
				$(this).toggleClass('hide-all');
			});
		}
	};


  /* Enviroment */
  Drupal.behaviors.Enviroment = {
    attach: function (context, settings) {
      var env = $('#toolbar-administration .secondary-toolbar .environment').text();
      $('body').addClass(env);
    }
  };


  /* CHESEN all - remove search */
  $("#ndq-content form select, #ndq-content .block--market-data-block__estimates__all select").chosen({
    disable_search: true
  });

  /* CHOSEN Year */
  Drupal.behaviors.chosenYearDD = {
    attach: function (context, settings) {
      $('#ndq-content form[id*=widget-form-base]').each(function () {
        var sel = $(this).find('select[id*=-year-value]');
        sel.find('option:first').html("All Years");
        sel.trigger("chosen:updated");
      });
      $('#ndq-content .block--qr form[id*=widget-form-base]').each(function () {
        var sel = $(this).find('select[id*=-year-value]');
        sel.find('option:first').remove();
        sel.trigger("chosen:updated");
      });

      $('select#edit-field-nir-sec-date-filed-value option:first').html("All Years");
      $('select#edit-field-nir-sec-date-filed-value').trigger("chosen:updated");;
    }
  };

  Drupal.behaviors.chosenAssetsCategory = {
    attach: function (context, settings) {
      var link = window.location.search;
      var $select = $('[id$=-field-nir-asset-category-value]', context);
      var allOption = {value: 'all',text : 'All'};

      $select.each(function(){

        if (link != undefined) {
          if (link.indexOf("field_nir_asset_category") == -1) {
            allOption.selected = 'selected';
          }
        }

        if(!$(this).val()) {
          allOption.selected = 'selected'
        };
        $(this).prepend($('<option/>', allOption));

        $(this).chosen('destroy');
        $(this).removeAttr('multiple');

        $(this).chosen({
          placeholder_text_single: 'All',
          disable_search: true
        });

        $(this).closest('form').submit(function(e) {
          if($(this).find('[id$=-field-nir-asset-category-value]').val() == 'all') {
            $(this).find('[id$=-field-nir-asset-category-value]').remove();
          }
        });
      });
    }
  };

  Drupal.behaviors.chosenNews = {
    attach: function (context, settings) {
      var link = window.location.search;
      var $select = $('[id$=-field-nir-news-category-value]', context);
      var allOption = {value: 'all',text : 'All Releases'};

      $select.each(function(){

        if (link != undefined) {
          if (link.indexOf("field_nir_news_category") == -1) {
            allOption.selected = 'selected';
          }
        }

        if(!$(this).val()) {
          allOption.selected = 'selected'
        };
        $(this).prepend($('<option/>', allOption));

        $(this).chosen('destroy');
        $(this).removeAttr('multiple');

        $(this).chosen({
          placeholder_text_single: 'All Releases',
          disable_search: true
        });

        $(this).closest('form').submit(function(e) {
          if($(this).find('[id$=-field-nir-news-category-value]').val() == 'all') {
            $(this).find('[id$=-field-nir-news-category-value]').remove();
          }
        });
      });
    }
  };

  /* CHOSEN SEC */
  Drupal.behaviors.chosenSEC = {
    attach: function (context, settings) {

      var $select = $('#edit-field-nir-sec-form-group-target-id', context);
      var allOption = {value: 'all',text : 'All Filings'};

      $select.each(function(){
        $(this).chosen('destroy');
        $(this).removeAttr('multiple');

        if(!$(this).val()) {
          allOption.selected = 'selected'
        };
        $(this).prepend($('<option/>', allOption));

        $(this).chosen({
          placeholder_text_single: 'All Filings',
          disable_search: true
        });

        $(this).closest('form').submit(function(e) {
          if($(this).find('#edit-field-nir-sec-form-group-target-id').val() == 'all') {
            $(this).find('#edit-field-nir-sec-form-group-target-id').remove();
          }
        });

        $(this).on('change',function(){
          if($(this).val() == 'all'){
            $(this).remove();
            $(this).closest("form").submit();
          }
        });
      });

    }
  };


  Drupal.behaviors.modalPopup = {
    attach: function (context, settings) {
        $('#ndq-content.ndq-5841 .view-widget-people .item-list table span.ccbnTxtBold a', context).each(function() {
            var $link = $(this);
            var $bioFull = $(this).parent().next('.node__content').parent().html(); // get a full wrapper of each Bio

            // get clean Bio; If Bio lenght is more than 499 characters trim it
            var $bioDetail = $(this).parent().parent().next('.ccbnPopover').find('.ccbnBgTxt td').html();
                if ( $bioDetail.length > 499 ) {
                  $bioDetail = $.trim($bioDetail).substring(0, 499).split(" ").slice(0, -1).join(" ") + " ...";
                  // replace original Bio with trimmed Bio
                  $($bioFull).find('.field--name-field-nir-person-bio').html($bioDetail);
                } 

            //narrow to right DIV with all nessesary info we need to diplay    
            var $bio = $($bioFull).find('.field--name-field-nir-person-bio').html($bioDetail).parent().parent();

            var $modalDialog = $('<div/>', {
              'class': 'modalPopup',
              'id': 'modalPopup'
            });    
          
            $modalDialog.append($bio);
            
            $link.mouseover(function(e) { 
              e.preventDefault();    
              $modalDialog.dialog({
                dialogClass: "bio-modal",
                resizable: false,
                autoOpen: true,
                width: 500,
                position: { my: 'left top', at: 'right', of: $link },
                modal: false, /* no overlay */
                closeOnEscape: false, /* remove close button */
                open: function(event, ui) {
                  $(".ui-dialog-titlebar-close").hide();
                  $('.ui-widget-overlay').on('click', function() {
                    $modalDialog.dialog('destroy');
                  });
                }
              });
            }).mouseout(function() {
              $modalDialog.dialog( "close" );
            });
        });
    }
  };




	Drupal.behaviors.modalBiosAndCC = {
    attach: function (context, settings) {
        $('#ndq-content .commiteetable tbody td:first-child a, #--ndq-content .people .person a', context).each(function() {
            var $link = $(this);
            var $url = $link.attr('href');
            var $modalDialog = $('<div/>', {
              'class': 'modalDialog',
              'id': 'modalDialog'
        });
            $modalDialog.load($url + ' .node--person--full');
            $link.click(function(e) {
                e.preventDefault();
                                 
              $modalDialog.appendTo('body')
              .dialog({
                resizable: false,
                autoOpen: true,
                width: $(window).width() * 60 /100,
                modal: true,
                open: function(event, ui) {   //added here
                  $('.ui-widget-overlay').on('click', function() {
                    $('.modalDialog').dialog('close');
                  });
                },
                close: function(event, ui) {
                  $(this).dialog("close");
                  $(this).remove();
                }
            });
        });
      });
    }
  };

	
    Drupal.behaviors.irTabs = {
        attach: function (context, settings) {
            $('#ndq-content ul.ir-tabs li', context).click(function() {
                var $link = $(this);
                var $id = $link.attr('data-tab');

                $('#ndq-content ul.ir-tabs li').removeClass('active');
                $('#ndq-content .ir-tab-content').removeClass('active');

                $link.addClass('active');
                $('#ndq-content').find("#"+$id).addClass('active');
            });
        }
    };

  Drupal.behaviors.removeH1 = {
    attach: function (context, settings) {
      $('.node--type-nir_landing_page > h1').remove();
      $('.node--nir-system--full h1.field__item').remove();
      $('.node--nir-sec-filing--full h1').remove();
    }
  }

/*  Drupal.behaviors.newsDetailPDF = {
    attach: function (context, settings) {
      $('article.node--nir-news--full .box__right .file--application-pdf a', context).each(function() {
          $(this).text('Download PDF');
      });
    }
  }*/

  Drupal.behaviors.targetBlank = {
    attach: function (context, settings) {
      $('#ndq-content a[type*="application/pdf"]', context).each(function() {
        $(this).attr('target', '_blank');
      });

      $('.node--nir-sec-filing--full .field--name-field-nir-sec-form .field__item a').attr('target', '_blank');
      $('.node--nir-sec-filing--full .doc-group .html-link a').attr('target', '_blank');

      $('#bio .nir-widget--person--bio-external a').attr('target', '_blank');

      $('.nir-widget--event--add-to-calendar .add-gcal a').attr('target', '_blank');
    }
  };

  Drupal.behaviors.mobiSlidingTable = {
    attach: function (context, settings) {
      $('.node--nir-news--full table', context).once('tableFix').wrap('<div id="nir-table-wrapper"></div>');
    }
  };

  Drupal.behaviors.releaseDetail = {
    attach: function (context, settings) {
        $('#ndq-content .wsh-releases .views-field-field-nir-news-title a:nth-child(2)', context).each(function() {
            var $link = $(this);
            var $url = $link.attr('href');
            var $rDetail = $('<div/>', {
              'class': 'nirReleaseDetail',
              'id': 'nirReleaseDetail'
            });
            $rDetail.load($url + ' .node--nir-news--full');
            $link.click(function(e) {
              e.preventDefault();                   
              $rDetail.appendTo('body')
              .dialog({
                  resizable: false,
                  autoOpen: true,
                  width: $(window).width() * 60 /100,
                  modal: true,
                  close: function(event, ui) {
                    $(this).dialog("close");
                    $(this).remove();
                  }
              });
        });
      });
    }
  };



  Drupal.behaviors.bSubmitLabel = {
    attach: function (context, settings) {
      /* contact the board */
      $('.ndq-5866').find('.contact-form input.button').attr('value', 'Submit');
      /* lookup*/
      $('.ndq-5921').find('#historical-lookup-form input.button').attr('value', 'Lookup');
      /* calculator*/
      $('.ndq-5926').find('#stock-price-calculator-form input.button').attr('value', 'Calculate');
      /* alerts */
      //$('.ndq-5946').find('#nir-email-alerts-signup-form input.button').attr('value', 'Continue');
      /* search page */
      $('#ndq-content').find('.views-exposed-form input#edit-submit-search').attr('value', 'Search');
    }
  };



  /* Dynamic Stock Chart mobile fix */
  Drupal.behaviors.mobileChartFix = {
    attach: function (context, settings) {
      if ( $('body').hasClass('nir-node--5911') ) {
        window.onorientationchange = function() { window.location.reload(); };
      }
    }
  };


  /* Toolbar */
  $(".ndq-tools a.ndqicon-print").click(function (e) {
    e.preventDefault();
    window.print();
  });
  $(".ndq-tools a.ndqicon-mail").click(function (e) {
    e.preventDefault();
    window.location.href = "mailto:?body=" + window.location + "&subject=" + document.title;
  });

  /* for pages with short content */
  /*Drupal.behaviors.contentHeight = {
    attach: function (context, settings) {
      function contentHeight() {
        var winH = $(window).outerHeight(true),
          headerH = $("header").outerHeight(true),
          headerPad = $("header").css('padding-top').replace('px',''),
          footerH = $("footer").outerHeight(true),
          footerPad = $("footer").css('padding-top').replace('px',''),
          paddings = parseInt(footerPad) + parseInt(headerPad),
          contentH = winH - (headerH + footerH + paddings);
        $("#ndq-content").css("min-height", contentH);
      }

      $(document).ready(function () {
        contentHeight();
      });
      $(window).resize(function () {
        contentHeight();
      });
    }
  };*/


  Drupal.behaviors.jumpToSection = {
    attach: function (context, settings) {
      var link = window.location.search;

      if (link.indexOf("?bod") != -1) {
        $('html, body').animate({scrollTop: $('.block-region-column1').offset().top - 400});
      }
    }
  };



  /*

  Drupal.behaviors.share = {
    attach: function (context, settings) {

        $('a[href="#idm-share"]').on('click', function (event) {
            var link = $(this).attr('href');
            var width = $('#ndq-content').width();
            $('.gcs-share-modal').dialog({
                minHeight: 200,
                minWidth: 500,
                maxWidth: width,
                resizable: false,
                modal: true,
                open: function(event, ui) {   //added here
                    jQuery('.ui-widget-overlay').on('click', function() {
                        jQuery('.gcs-share-modal').dialog('close');
                    });
                },
            });
            event.preventDefault();
        });
    }
};

  Drupal.behaviors.newsViewMore = {
    attach: function (context, settings) {
      $size_itmes  = $('#ndq-content #view-more-news > div').length;
      x=9;

      $('#ndq-content  #view-more-news > div:lt('+x+')').show();

  $size_itmes_visibale  = $('#ndq-content #view-more-news > div:visible').length;
  if ($size_itmes_visibale == $size_itmes) {
    $('a#aMoreNews').hide();
  }

  $('a#aMoreNews').click(function () {
    $('#ndq-content  #view-more-news > div:lt('+x+')').attr('name', '');
    x = (x+9 <= $size_itmes) ? x+9 : $size_itmes;
    $('#ndq-content  #view-more-news > div:lt('+x+')').attr('name', 'view-next-news');
    $('#ndq-content  #view-more-news > div:lt('+x+')').show();

    $size_itmes_visibale  = $('#ndq-content #view-more-news > div:visible').length;
    if ($size_itmes_visibale == $size_itmes) {
      $('a#aMoreNews').hide();
    }
  });
}
};


Drupal.behaviors.qrViewMore = {
    attach: function (context, settings) {

      var latestY = $('#ndq-content .view-grouping #QRs tbody tr').attr('class');
      var nextY = 0;
      var lastY = 0;
      var sizeItems = 0;

      $('.ndq-5806 .view-grouping #QRs tbody tr', context).each(function() {
        lastY  = $(this).attr('class');
        nextY = latestY-2;
        var trClass = $(this).attr('class');

        if (trClass >= latestY-1) {
          $(this).show();
        }
      });

      $('.ndq-5806 .view-grouping a.showMore', context).click(function(e) {
        e.preventDefault();

        if (nextY >= lastY ) {
          $('.ndq-5806 .view-grouping #QRs tbody tr.' + nextY).show();
          if (nextY == lastY ) {
            $(this).addClass('disable');
          }
          nextY = nextY - 1;
        }
        $(this).next('.showLess').removeClass('disable');

      });
      $('.ndq-5806 .view-grouping a.showLess', context).click(function(e) {
        e.preventDefault();

        $(this).prev('.showMore').removeClass('disable');
        if (nextY < latestY-2 ) {
          nextY = nextY + 1;
          $('.ndq-5806 .view-grouping #QRs tbody tr.' + nextY).hide();
          if (nextY == latestY-2 ) {
            $(this).addClass('disable');
          }
        }
      });


   Drupal.behaviors.alertsAutoFill = {
      attach: function (context, settings) {
        $("body.nir-node--5946").each(function(){
          var getUrlParameter = function getUrlParameter(sParam) {
            var sPageURL = decodeURIComponent(window.location.search.substring(1)),
              sURLVariables = sPageURL.split('&'),
              sParameterName,
              i;

            for (i = 0; i < sURLVariables.length; i++) {
              sParameterName = sURLVariables[i].split('=');

              if (sParameterName[0] === sParam) {
                return sParameterName[1] === undefined ? true : sParameterName[1];
              }
            }
          };

          var getEmailValue = getUrlParameter('name');

          if(typeof getEmailValue != 'undefined'){
            $("input#edit-nir-email-alerts-signup-email").val(getEmailValue)
          }else{
            console.log("no var")
          };
        });
      }
    };

    // viacomCBS
    Drupal.behaviors.secCIKs = {
    attach: function (context, settings) {
      var link = window.location.pathname;
      $("#sec-company-name, #news-archive-status, #presentations-archive-status").each(function() {
        $("option[value='" + link +"']", this).attr("selected", true).trigger("chosen:updated");;
      });
      $("#sec-company-name, #news-archive-status, #presentations-archive-status").on('change',function(){
        window.location.href = $(this).val();
      });
    }
  };

     Drupal.behaviors.allSECFilings = {
       attach: function (context, settings) {
         $(".ndq-5876 form.views-exposed-form select#edit-field-nir-sec-form-group-target-id option", context).each(function (index, elem) {
           var $ddOption = $(elem);

           $ddOption.parent().on('change', function () {
             if ($ddOption.is(':selected') && $ddOption.text() == "All Filings") {
               var url = '/financial-information/sec-filings';
               window.location = url; // redirect
             }
           });
         });
       }
     };

      Drupal.behaviors.searchOnFocus = {
      attach: function (context, settings) {
        $('#ndq-tools-search input[type="text"]').focus(function() {
          if (this.value === 'Search Investors') {
            $(this).val('');
          }
        });
        $('#ndq-tools-search input[type="text"]').blur(function() {
          if (this.value === '') {
            $(this).val('Search Investors');
          }
        });
      }
    };


    Drupal.behaviors.mlSinglePage = {
      attach: function (context, settings) {
        $('html[lang="en"] #lang-tabs a[rel="swe"]', context).each(function(index, elem) {
          var enUrl = $(this).attr('href');
          if (link != undefined) {
            $(this).attr('href', '/sv' + enUrl);
          }
        });

        $('html[lang="sv"] #lang-tabs a:not([rel="swe"]), html[lang="sv"] .menu a, html[lang="sv"] .tools a', context).each(function(index, elem) {
          var link = $(this).attr('href');

          if (link != undefined) {
            if (link.indexOf("/sv/") != -1 ) {
              $(this).attr('href', link.replace('/sv/', '/'));
            }
          }
        });
      }
    };


  Drupal.behaviors.modalQRs = {
    attach: function (context, settings) {
      $('#ndq-content .view-widget-bundled-content .btn-modal', context).each(function() {
        var $link = $(this);
        var $urlID = $link.attr('href');
        var $modalDialog = $('<div/>', {
          'class': 'modalDialog',
          'id': 'modalDialog'
        }).html($($urlID).html());

        $modalDialog.load();
        $link.click(function(e) {
          e.preventDefault();

          $modalDialog.appendTo('body')
            .dialog({
              resizable: false,
              autoOpen: true,
              width: $(window).width() * 120 /600,
              modal: true,
              close: function(event, ui) {
                $(this).dialog("close");
                $(this).remove();
              }
            });
        });
      });
    }
  };

   Drupal.behaviors.modalLeaveSite = {
    attach: function (context, settings) {
      $('.leaveSite', context).each(function() {
        var $link = $(this);
        var $url = $(this).attr('href');
        var $id = $link.attr('class').split(" ");
        $id  = $id[0];
        var $modalContent = $('#ndq-content').find('#'+$id).html();

        var $modalDialog = $('<div/>', {
          'class': 'modalPopup',
          'id': 'modalPopup'
        });

        $modalDialog.append($modalContent);

        $link.click(function(e) {
          e.preventDefault();
          $modalDialog.dialog({
            resizable: true,
            autoOpen: true,
            width: 500,
            modal: true,
            closeOnEscape: true,
            open: function(event, ui) {
              $(".ui-dialog-titlebar-close", ui.dialog | ui).show();
            },
            close: function (event, ui) {
              $modalDialog.dialog('destroy');
            },
            buttons: [{
              text: "Continue",
              icon: "ui-icon-heart",
              class: "modal-btn",
              click: function() {
                window.location = $url;
                //window.open($url, '_blank');
              }
            }]
          });
        });

      });
    }
  };


  Drupal.behaviors.pplGrid2 = {
    attach: function (context, settings) {
      $('#ppl-grid-2 #ppl-grid-2-bio a', context).click(function (e) {
        e.preventDefault();
        var $link = $(this).attr('href');
        $(this).parents('#ppl-grid-2-bio').next('.full-width-bio').load($link +" .node--person--full").addClass('active');
      });
    }
  };


  Drupal.behaviors.domainRedirect = {
      attach: function (context, settings) {
		if(window.location.hostname == 'ir.axonicsmodulation.com') {
			var urlCurrent = window.location.href;
			urlCurrent = urlCurrent.toString();
			urlFinal = urlCurrent.replace(/ir\.axonicsmodulation\.com/,"ir.axonics.com")
			window.location = urlFinal;
		}
      }
  	};

  Drupal.behaviors.jumpToSection = {
    attach: function (context, settings) {
      var link = window.location.search;

      if (link.indexOf("views-exposed-form-widget-sec-filings-table") != -1) {
        $('html, body').animate({scrollTop: $('#tabSEC').offset().top - 120}, 1000);
      }

      if (link.indexOf("ec248921-9633-4641-a38b-cbf1d114d2dc") != -1) {
        $('html, body').animate({scrollTop: $('.block--market-data-block__historical-price-lookup').offset().top - 120}, 1000);
      }

      if (link.indexOf("e718f924-519a-4d0f-b9d0-96847c73d715") != -1) {
        $('html, body').animate({scrollTop: $('.block--market-data-block__stock-price-calculator').offset().top - 120}, 1000);
      }


      $('#irSubNavs li a', context).click(function() {
        var aURL = $(this).attr('href');
        $(this).attr('href', aURL +'?sect=navStatements');
      });
      $('.market-data-filter-form', context).each(function() {
        location.hash = "#irSubNavsJump";
      });
      if (link.indexOf("navStatements") != -1) {
        //$('html, body').animate({scrollTop: $('#irSubNavs').offset().top - 130}, 1000);
        location.hash = "#irSubNavsJump";
      }
    }
  };


  Drupal.behaviors.iframeResize = {
    attach: function (context, settings) {
      var iframe = document.getElementById("secFrame");

      // Adjusting the iframe height onload event
      iframe.onload = function () {
        iframe.style.height = iframe.contentWindow.document.body.scrollHeight + 'px';
      }
    }
  };


  */
  
  Drupal.behaviors.homeImages = {
    attach: function (context, settings) {
      $('.nir-node--5806 .glance-cell',context).each(function () {
        var thisImg = $(this).find('img');
        thisImg.attr('src', '/' + drupalSettings.path.themeUrl + '/dist/images/' + thisImg.attr('src'));

      });
    }
  };

})(jQuery, Drupal);
;
(function ($, Drupal) {
  'use strict';
  Drupal.behaviors.nirWebsiteNotices = {
    attach: function (context, settings) {

      $('.notification-modal').each(function (index) {
        var cookieLength = $(this).data('cookie-length');
        if (cookieLength === 0) {
          cookieLength = '';
        }
        var cookieId = $(this).data('id');
        var notificationType = $(this).data('notification-type');

        if (!Cookies.get('nir_notice_' + cookieId)) {
          var buttonText = 'Accept';
          if (notificationType === 'notification') {
            buttonText = 'OK';
          }
          $(this).dialog({
            modal: true,
            width: 500,
            closeOnEscape: false,
            close: function () {
              $(this).dialog('close');
              Cookies.set(
                'nir_notice_' + cookieId,
                'true',
                {expires: cookieLength});
            },
            buttons: [
              {
                text: buttonText,
                dialogClass: notificationType,
                click: function () {
                  $(this).dialog('close');
                  Cookies.set(
                    'nir_notice_' + cookieId,
                    'true',
                    {expires: cookieLength});
                }
              }
            ]
          });
          if (notificationType === 'disclaimer'){
            $('.ui-dialog-titlebar-close').hide();
          }
        }

      });
    }
  };
})(jQuery, Drupal);
;
(function ($, Drupal) {
  'use strict';
  Drupal.behaviors.nirMarketDataBlockFilter = {
    attach: function (context, settings) {
      $('#edit-timeframe-display').change(function () {
        $(this).closest('form').submit();
      });

      $('#market-data-file-download-csv').click(function (e) {
        var query_string = '&';
        var period = ($('#edit-period').val()) ? $('#edit-period').val() : 'current';
        query_string += 'period=' + period;
        if (period === 'compare') {
          var period_compare_one = $('#edit-period-compare-one :selected').val();
          var period_compare_two = $('#edit-period-compare-two :selected').val();
          query_string += '&';
          query_string += 'compare_one=' + period_compare_one;
          query_string += '&';
          query_string += 'compare_two=' + period_compare_two;
        }
        var current_href = $('#market-data-file-download-csv').attr('href');
        var new_href = current_href + query_string;
        $('#market-data-file-download-csv').attr('href', new_href);

      });

    }
  };
})(jQuery, Drupal);
;
(function ($, Drupal, drupalSettings) {

  'use strict';

  Drupal.behaviors.adobelaunch = {
    attach: function (context, settings) {
      window.dataLayer = window.dataLayer || [];
      window.dataLayer.push({
        "event":"Page Loaded",
        "reportSuite":{
          "name": " "
        },
        "page":{
          "pageInfo":{
            "pageName": " ",
            "pageURL": " ",
            "siteDomains": " "
          }
        },
        // "category":{
        //   "siteSection": " ",
        //   "siteSubSection1": " ",
        //   "siteSubSection2": " ",
        //   "siteSubSection3": " ",
        //   "siteSubSection4": " "
        // }
      });

    }
  };

})(jQuery, Drupal, drupalSettings);
;
